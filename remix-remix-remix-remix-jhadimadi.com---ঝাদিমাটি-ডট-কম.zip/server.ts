import express from 'express';
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // 1. Security Hardening: Disable X-Powered-By
  app.disable('x-powered-by');

  // 2. Security Headers Middleware
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(self)');
    next();
  });

  // 3. Secure CORS Middleware
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
    } else {
      res.setHeader('Access-Control-Allow-Origin', '*');
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, X-Admin-Token');
    if (req.method === 'OPTIONS') {
      return res.status(204).end();
    }
    next();
  });

  // 4. Rate Limiting Middleware for API Endpoints (Sliding Window per IP)
  const apiRateLimitMap = new Map<string, { count: number; resetTime: number }>();
  const API_RATE_WINDOW_MS = 60 * 1000; // 1 minute window
  const API_RATE_MAX_REQUESTS = 180; // 180 requests per minute per IP

  app.use('/api', (req, res, next) => {
    const ip = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown-ip';
    const now = Date.now();
    const clientRecord = apiRateLimitMap.get(ip);

    if (!clientRecord || now > clientRecord.resetTime) {
      apiRateLimitMap.set(ip, { count: 1, resetTime: now + API_RATE_WINDOW_MS });
      return next();
    }

    clientRecord.count += 1;
    if (clientRecord.count > API_RATE_MAX_REQUESTS) {
      res.setHeader('Retry-After', Math.ceil((clientRecord.resetTime - now) / 1000));
      return res.status(429).json({
        success: false,
        message: 'অতিরিক্ত অনুরোধ করা হয়েছে। অনুগ্রহ করে কিছুক্ষণ পর পুনরায় চেষ্টা করুন। (Too many requests, please slow down.)'
      });
    }

    next();
  });

  // 5. Request Size Limits (JSON payloads strictly bounded)
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));

  // Initialize Gemini AI SDK helper with lazy fallback
  const getGeminiClient = () => {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      return null;
    }
    try {
      return new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    } catch (e) {
      console.warn('[Gemini AI] Initialization warning, using fallback mode:', (e as Error)?.message || 'Unknown error');
      return null;
    }
  };

  // Secure Admin Authentication & Authorization Engine
  // Uses environment variable or generates an unguessable cryptographic random secret at runtime
  const ADMIN_SECRET_KEY = process.env.ADMIN_SECRET_KEY || crypto.randomBytes(32).toString('hex');
  
  // Persistent Credential Store File
  const DATA_DIR = path.join(process.cwd(), 'data');
  if (!fs.existsSync(DATA_DIR)) {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (err) {
      console.warn('[AdminSecurity] Note creating data directory:', err);
    }
  }
  const CREDENTIALS_FILE = path.join(DATA_DIR, 'admin_credentials.json');

  // Cryptographic Password Hashing (Salted Scrypt) & Timing-Safe Verification
  const hashPassword = (password: string): string => {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(password, salt, 64).toString('hex');
    return `scrypt:${salt}:${hash}`;
  };

  const verifyPassword = (password: string, storedHash: string): boolean => {
    if (!storedHash || !password) return false;
    if (storedHash.startsWith('scrypt:')) {
      const parts = storedHash.split(':');
      if (parts.length !== 3) return false;
      const salt = parts[1];
      const originalHex = parts[2];
      try {
        const derived = crypto.scryptSync(password, salt, 64).toString('hex');
        return crypto.timingSafeEqual(Buffer.from(derived, 'hex'), Buffer.from(originalHex, 'hex'));
      } catch {
        return false;
      }
    }
    // Backward compatibility with legacy plaintext fallback
    return password === storedHash;
  };

  interface AdminSessionRecord {
    id: string;
    ip: string;
    userAgent: string;
    createdAt: string;
    lastActiveAt: string;
  }

  interface AdminAccountData {
    isSetupComplete: boolean;
    username: string;
    email: string;
    role: 'super_admin' | 'admin' | 'moderator';
    passwordHash: string;
    lastLoginTime: string | null;
    lastPasswordChangeTime: string | null;
    tokenEpoch: number;
    sessions: AdminSessionRecord[];
  }

  const loadAdminAccount = (): AdminAccountData => {
    try {
      if (fs.existsSync(CREDENTIALS_FILE)) {
        const raw = fs.readFileSync(CREDENTIALS_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed && parsed.isSetupComplete === true && parsed.username && parsed.passwordHash) {
          if (!parsed.sessions) parsed.sessions = [];
          if (!parsed.tokenEpoch) parsed.tokenEpoch = Date.now();
          if (!parsed.role) parsed.role = 'super_admin';
          if (!parsed.email) parsed.email = `${parsed.username.toLowerCase()}@jhadimadi.com`;
          return parsed;
        }
      }
    } catch (e) {
      console.warn('[AdminSecurity] Could not read credentials file, awaiting first-time setup:', e);
    }

    // Zero default credentials - requires first-time setup by authorized owner
    return {
      isSetupComplete: false,
      username: '',
      email: '',
      role: 'super_admin',
      passwordHash: '',
      lastLoginTime: null,
      lastPasswordChangeTime: null,
      tokenEpoch: Date.now(),
      sessions: [],
    };
  };

  const saveAdminAccount = (acc: AdminAccountData) => {
    try {
      fs.writeFileSync(CREDENTIALS_FILE, JSON.stringify(acc, null, 2), 'utf-8');
    } catch (e) {
      console.error('[AdminSecurity] Failed to persist credentials to disk:', e);
    }
  };

  let adminAccount = loadAdminAccount();

  const adminAccountsRegistry: Record<string, {
    email: string;
    role: 'super_admin' | 'admin' | 'moderator';
    isActive: boolean;
    passwordHash: string;
    createdAt: string;
  }> = {};

  if (adminAccount.isSetupComplete && adminAccount.email) {
    adminAccountsRegistry[adminAccount.email.toLowerCase()] = {
      email: adminAccount.email,
      role: adminAccount.role,
      isActive: true,
      passwordHash: adminAccount.passwordHash,
      createdAt: '2026-01-01T00:00:00Z',
    };
  }

  const adminAuditLogs: any[] = [
    {
      id: 'log_init',
      adminEmail: adminAccount.email || 'system',
      actionType: 'SYSTEM_BOOT',
      details: { 
        message: adminAccount.isSetupComplete 
          ? 'Security subsystem active with verified super admin credentials.' 
          : 'Security subsystem ready: First-time Super Admin Setup required.' 
      },
      createdAt: new Date().toISOString(),
    }
  ];

  // In-memory rate limiter for admin login attempts (prevents brute-force)
  const failedAdminLoginAttempts = new Map<string, { count: number; lockedUntil: number }>();

  const checkAdminRateLimit = (key: string): { allowed: boolean; remainingSec?: number } => {
    const record = failedAdminLoginAttempts.get(key);
    if (!record) return { allowed: true };
    if (record.lockedUntil > Date.now()) {
      const remainingSec = Math.ceil((record.lockedUntil - Date.now()) / 1000);
      return { allowed: false, remainingSec };
    }
    if (record.lockedUntil <= Date.now() && record.count >= 5) {
      failedAdminLoginAttempts.delete(key);
      return { allowed: true };
    }
    return { allowed: true };
  };

  const recordFailedAdminLogin = (key: string) => {
    const now = Date.now();
    const record = failedAdminLoginAttempts.get(key) || { count: 0, lockedUntil: 0 };
    record.count += 1;
    if (record.count >= 5) {
      record.lockedUntil = now + 15 * 60 * 1000; // Lock for 15 minutes
    }
    failedAdminLoginAttempts.set(key, record);
  };

  const clearAdminLoginAttempts = (key: string) => {
    failedAdminLoginAttempts.delete(key);
  };

  // Helper to parse and verify admin token (supports HMAC-SHA256 and legacy formats)
  const verifyTokenPayload = (authHeader?: string | string[]) => {
    if (!authHeader) return null;
    try {
      const tokenStr = typeof authHeader === 'string' ? authHeader.replace('Bearer ', '').trim() : '';
      if (!tokenStr) return null;

      // 1. Modern HMAC-SHA256 token format: base64(payload).signature
      if (tokenStr.includes('.')) {
        const [payloadB64, signature] = tokenStr.split('.');
        const expectedSig = crypto.createHmac('sha256', ADMIN_SECRET_KEY).update(payloadB64).digest('hex');
        if (signature !== expectedSig) return null;
        const payload = JSON.parse(Buffer.from(payloadB64, 'base64').toString('utf-8'));
        if (payload.expiresAt && payload.expiresAt < Date.now()) return null;
        if (payload.epoch && payload.epoch < adminAccount.tokenEpoch) return null;
        return payload;
      }

      // 2. Backward-compatible legacy format: base64(payload::secret)
      const decoded = Buffer.from(tokenStr, 'base64').toString('utf-8');
      const parts = decoded.split('::');
      if (parts.length !== 2 || parts[1] !== ADMIN_SECRET_KEY) {
        return null;
      }
      const payload = JSON.parse(parts[0]);
      if (payload.expiresAt && payload.expiresAt < Date.now()) {
        return null; // Expired
      }
      // Check token epoch (invalidates all issued tokens before a password change or session wipe)
      if (payload.epoch && payload.epoch < adminAccount.tokenEpoch) {
        return null;
      }
      return payload;
    } catch {
      return null;
    }
  };

  // First-Time Setup Status Check Route
  app.get('/api/admin/auth/setup-status', (req, res) => {
    res.json({
      success: true,
      isSetupComplete: Boolean(adminAccount.isSetupComplete),
    });
  });

  // Secure First-Time Super Admin Account Setup Route
  // IMPORTANT SECURITY RULE: Available only when no verified Super Admin account exists.
  // After the first Super Admin account is created, public access to setup is permanently disabled and locked.
  app.post('/api/admin/auth/setup', (req, res) => {
    if (adminAccount.isSetupComplete) {
      return res.status(403).json({
        success: false,
        message: 'অননুমোদিত অ্যাক্সেস! সুপার অ্যাডমিন অ্যাকাউন্ট ইতিমধ্যে সেটআপ ও স্থায়ীভাবে লক করা হয়েছে।'
      });
    }

    const { username, password, confirmPassword, email } = req.body;
    const cleanUsername = (username || '').trim();
    const cleanEmail = (email || '').trim().toLowerCase();

    if (!cleanUsername) {
      return res.status(400).json({ success: false, message: 'সুপার অ্যাডমিন ইউজারনেম প্রদান করা আবশ্যক।' });
    }

    if (!/^[a-zA-Z0-9_.\-]{3,30}$/.test(cleanUsername)) {
      return res.status(400).json({
        success: false,
        message: 'ইউজারনেম ৩ থেকে ৩০ অক্ষরের হতে হবে (শুধুমাত্র বর্ণ, সংখ্যা, আন্ডারস্কোর, ডট বা হাইফেন অনুমোদিত)।'
      });
    }

    if (!password) {
      return res.status(400).json({ success: false, message: 'সুপার অ্যাডমিন পাসওয়ার্ড প্রদান করা আবশ্যক।' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ success: false, message: 'নতুন পাসওয়ার্ড ও নিশ্চিতকরণ পাসওয়ার্ড মিলছে না।' });
    }

    if (cleanEmail) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(cleanEmail)) {
        return res.status(400).json({ success: false, message: 'সঠিক ইমেইল ফরম্যাট প্রদান করুন (যেমন: owner@jhadimadi.com)।' });
      }
    }

    const finalEmail = cleanEmail || `${cleanUsername.toLowerCase()}@jhadimadi.com`;
    // Cryptographic hash - Never store in plain text
    const passwordHash = hashPassword(password);

    adminAccount = {
      isSetupComplete: true,
      username: cleanUsername,
      email: finalEmail,
      role: 'super_admin',
      passwordHash,
      lastLoginTime: null,
      lastPasswordChangeTime: new Date().toISOString(),
      tokenEpoch: Date.now(),
      sessions: [],
    };

    saveAdminAccount(adminAccount);

    adminAccountsRegistry[finalEmail.toLowerCase()] = {
      email: finalEmail,
      role: 'super_admin',
      isActive: true,
      passwordHash,
      createdAt: new Date().toISOString(),
    };

    adminAuditLogs.unshift({
      id: 'log_' + Date.now(),
      adminEmail: finalEmail,
      actionType: 'SUPER_ADMIN_INITIAL_SETUP',
      details: { username: cleanUsername, email: finalEmail },
      createdAt: new Date().toISOString(),
    });

    return res.json({
      success: true,
      message: 'সুপার অ্যাডমিন অ্যাকাউন্ট সফলভাবে ও নিরাপদে তৈরি হয়েছে! সেটআপ স্থায়ীভাবে লক করা হয়েছে। এখন আপনার নির্বাচিত ইউজারনেম এবং পাসওয়ার্ড দিয়ে লগইন করুন।'
    });
  });

  // Admin Authentication Verification Route (Accepts either Username or Email)
  app.post('/api/admin/auth/verify', (req, res) => {
    // Enforce first-time setup prerequisite
    if (!adminAccount.isSetupComplete) {
      return res.status(400).json({
        success: false,
        requiresSetup: true,
        message: 'সিস্টেমে এখনও কোনো সুপার অ্যাডমিন অ্যাকাউন্ট সেটআপ করা হয়নি। প্রথমে সেটআপ সম্পন্ন করুন।'
      });
    }

    const { passcode, adminId, email, username } = req.body;
    const identifier = (username || email || adminId || '').trim().toLowerCase();
    const ip = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.ip || '127.0.0.1';
    const rateLimitKey = `${ip}_${identifier}`;

    // Check brute-force rate limit
    const rateCheck = checkAdminRateLimit(rateLimitKey);
    if (!rateCheck.allowed) {
      return res.status(429).json({
        success: false,
        message: `অনেকবার ভুল চেষ্টা করা হয়েছে। নিরাপত্তার স্বার্থে অ্যাকাউন্ট সাময়িকভাবে লক রয়েছে। অনুগ্রহ করে ${rateCheck.remainingSec} সেকেন্ড পর আবার চেষ্টা করুন।`
      });
    }

    if (!passcode) {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ড প্রদান করুন।' });
    }
    if (!identifier) {
      return res.status(400).json({ success: false, message: 'ইউজারনেম বা ইমেইল প্রদান করুন।' });
    }

    // Match identifier strictly against chosen username or email (case-insensitive)
    const isUsernameMatch = identifier === adminAccount.username.toLowerCase();
    const isEmailMatch = identifier === adminAccount.email.toLowerCase();

    if (!isUsernameMatch && !isEmailMatch) {
      recordFailedAdminLogin(rateLimitKey);
      return res.status(401).json({
        success: false,
        message: 'ভুল অ্যাডমিন ইউজারনেম বা ইমেইল।'
      });
    }

    // Verify password strictly using salted scrypt hash
    const isPasswordValid = verifyPassword(passcode, adminAccount.passwordHash);

    if (!isPasswordValid) {
      recordFailedAdminLogin(rateLimitKey);
      adminAuditLogs.unshift({
        id: 'log_' + Date.now(),
        adminEmail: identifier,
        actionType: 'FAILED_LOGIN_ATTEMPT',
        details: { ip, identifier },
        createdAt: new Date().toISOString(),
      });
      return res.status(401).json({
        success: false,
        message: 'ভুল অ্যাডমিন পাসওয়ার্ড।'
      });
    }

    // Login successful - clear rate limit tracking
    clearAdminLoginAttempts(rateLimitKey);

    // Create unique session record
    const sessionId = 'sess_' + crypto.randomBytes(12).toString('hex');
    const userAgent = req.headers['user-agent'] || 'Browser';

    adminAccount.lastLoginTime = new Date().toISOString();
    adminAccount.sessions = [
      {
        id: sessionId,
        ip,
        userAgent,
        createdAt: new Date().toISOString(),
        lastActiveAt: new Date().toISOString(),
      },
      ...adminAccount.sessions.filter(s => s.id !== sessionId).slice(0, 9),
    ];
    saveAdminAccount(adminAccount);

    const payload = {
      userId: adminAccount.email,
      email: adminAccount.email,
      username: adminAccount.username,
      role: adminAccount.role,
      sessionId,
      epoch: adminAccount.tokenEpoch,
      issuedAt: Date.now(),
      expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    };

    const payloadB64 = Buffer.from(JSON.stringify(payload)).toString('base64');
    const signature = crypto.createHmac('sha256', ADMIN_SECRET_KEY).update(payloadB64).digest('hex');
    const token = `${payloadB64}.${signature}`;

    adminAuditLogs.unshift({
      id: 'log_' + Date.now(),
      adminEmail: adminAccount.email,
      actionType: 'LOGIN',
      details: { role: adminAccount.role, username: adminAccount.username, ip },
      createdAt: new Date().toISOString(),
    });

    return res.json({
      success: true,
      token,
      role: adminAccount.role,
      userId: adminAccount.email,
      username: adminAccount.username,
      email: adminAccount.email,
      message: 'অ্যাডমিন ভেরিফিকেশন সফল হয়েছে।'
    });
  });

  // Admin Authorization Middleware (Any authorized Admin/Super Admin/Moderator)
  const requireAdminAuth = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers['x-admin-token'] || req.headers['authorization'];
    const payload = verifyTokenPayload(authHeader);
    if (!payload) {
      return res.status(403).json({ success: false, message: 'অননুমোদিত অ্যাক্সেস! অ্যাডমিন পারমিশন প্রয়োজন বা সেশন শেষ হয়েছে।' });
    }
    (req as any).admin = payload;
    next();
  };

  // Super Admin Authorization Middleware (Strictly Super Admin only)
  const requireSuperAdminAuth = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers['x-admin-token'] || req.headers['authorization'];
    const payload = verifyTokenPayload(authHeader);
    if (!payload || payload.role !== 'super_admin') {
      return res.status(403).json({ success: false, message: 'অননুমোদিত অ্যাক্সেস! শুধুমাত্র সুপার অ্যাডমিন এই কাজ করতে পারেন।' });
    }
    (req as any).admin = payload;
    next();
  };

  // Validate active admin session
  app.get('/api/admin/auth/session', requireAdminAuth, (req, res) => {
    res.json({ success: true, admin: (req as any).admin });
  });

  // Get Current Super Admin Account Security Info
  app.get('/api/admin/auth/account', requireAdminAuth, (req, res) => {
    const currentSessionId = (req as any).admin?.sessionId;
    const sanitizedSessions = (adminAccount.sessions || []).map(s => ({
      id: s.id,
      ip: s.ip,
      userAgent: s.userAgent,
      createdAt: s.createdAt,
      lastActiveAt: s.lastActiveAt,
      isCurrent: s.id === currentSessionId,
    }));

    res.json({
      success: true,
      account: {
        username: adminAccount.username,
        email: adminAccount.email,
        role: adminAccount.role,
        lastLoginTime: adminAccount.lastLoginTime,
        lastPasswordChangeTime: adminAccount.lastPasswordChangeTime,
        sessions: sanitizedSessions,
      }
    });
  });

  // Change Admin Username
  app.post('/api/admin/auth/change-username', requireAdminAuth, (req, res) => {
    const admin = (req as any).admin;
    if (admin.role !== 'super_admin') {
      return res.status(403).json({ success: false, message: 'শুধুমাত্র সুপার অ্যাডমিন ইউজারনেম পরিবর্তন করতে পারেন।' });
    }

    const { currentPassword, newUsername } = req.body;
    if (!currentPassword) {
      return res.status(400).json({ success: false, message: 'বর্তমান পাসওয়ার্ড প্রদান করুন।' });
    }
    if (!newUsername || typeof newUsername !== 'string') {
      return res.status(400).json({ success: false, message: 'নতুন ইউজারনেম প্রদান করুন।' });
    }

    const cleanUsername = newUsername.trim();
    if (!/^[a-zA-Z0-9_.\-]{3,30}$/.test(cleanUsername)) {
      return res.status(400).json({ success: false, message: 'ইউজারনেম ৩ থেকে ৩০ অক্ষরের হতে হবে এবং বর্ণ, সংখ্যা, আন্ডারস্কোর বা হাইফেন থাকতে পারে।' });
    }

    if (cleanUsername.toLowerCase() === adminAccount.username.toLowerCase()) {
      return res.status(400).json({ success: false, message: 'নতুন ইউজারনেমটি বর্তমান ইউজারনেমের চেয়ে ভিন্ন হতে হবে।' });
    }

    // Verify current password
    if (!verifyPassword(currentPassword, adminAccount.passwordHash)) {
      return res.status(401).json({ success: false, message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়।' });
    }

    const oldUsername = adminAccount.username;
    adminAccount.username = cleanUsername;
    saveAdminAccount(adminAccount);

    adminAuditLogs.unshift({
      id: 'log_' + Date.now(),
      adminEmail: adminAccount.email,
      actionType: 'USERNAME_CHANGE',
      details: { previousUsername: oldUsername, updatedTo: cleanUsername },
      createdAt: new Date().toISOString(),
    });

    res.json({
      success: true,
      username: cleanUsername,
      message: `ইউজারনেম সফলভাবে পরিবর্তন হয়ে '${cleanUsername}' হয়েছে। পরবর্তী লগইনে এই ইউজারনেম ব্যবহার করুন।`,
    });
  });

  // Change Admin Email
  app.post('/api/admin/auth/change-email', requireAdminAuth, (req, res) => {
    const admin = (req as any).admin;
    if (admin.role !== 'super_admin') {
      return res.status(403).json({ success: false, message: 'শুধুমাত্র সুপার অ্যাডমিন ইমেইল পরিবর্তন করতে পারেন।' });
    }

    const { currentPassword, newEmail } = req.body;
    if (!currentPassword) {
      return res.status(400).json({ success: false, message: 'বর্তমান পাসওয়ার্ড প্রদান করুন।' });
    }
    if (!newEmail || typeof newEmail !== 'string') {
      return res.status(400).json({ success: false, message: 'নতুন ইমেইল প্রদান করুন।' });
    }

    const cleanEmail = newEmail.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return res.status(400).json({ success: false, message: 'সঠিক ইমেইল ফরম্যাট প্রদান করুন (যেমন: admin@jhadimadi.com)।' });
    }

    if (cleanEmail === adminAccount.email.toLowerCase()) {
      return res.status(400).json({ success: false, message: 'নতুন ইমেইলটি বর্তমান ইমেইলের চেয়ে ভিন্ন হতে হবে।' });
    }

    // Verify current password
    if (!verifyPassword(currentPassword, adminAccount.passwordHash)) {
      return res.status(401).json({ success: false, message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়।' });
    }

    const oldEmail = adminAccount.email;
    adminAccount.email = cleanEmail;
    delete adminAccountsRegistry[oldEmail.toLowerCase()];
    adminAccountsRegistry[cleanEmail] = {
      email: cleanEmail,
      role: 'super_admin',
      isActive: true,
      passwordHash: adminAccount.passwordHash,
      createdAt: new Date().toISOString(),
    };
    saveAdminAccount(adminAccount);

    adminAuditLogs.unshift({
      id: 'log_' + Date.now(),
      adminEmail: cleanEmail,
      actionType: 'EMAIL_CHANGE',
      details: { previousEmail: oldEmail, updatedTo: cleanEmail },
      createdAt: new Date().toISOString(),
    });

    res.json({
      success: true,
      email: cleanEmail,
      message: `লগইন ইমেইল সফলভাবে পরিবর্তন হয়ে '${cleanEmail}' হয়েছে।`,
    });
  });

  // Unified Credential Management Route (Email/Username + Password in one clean form)
  app.post('/api/admin/auth/update-credentials', requireAdminAuth, (req, res) => {
    const admin = (req as any).admin;
    if (admin.role !== 'super_admin') {
      return res.status(403).json({ success: false, message: 'শুধুমাত্র সুপার অ্যাডমিন ক্রেডেনশিয়াল পরিবর্তন করতে পারেন।' });
    }

    const { currentPassword, newEmailOrUsername, newPassword, confirmPassword } = req.body;
    if (!currentPassword) {
      return res.status(400).json({ success: false, message: 'বর্তমান পাসওয়ার্ড প্রদান করা আবশ্যক।' });
    }

    // Verify current password
    if (!verifyPassword(currentPassword, adminAccount.passwordHash)) {
      return res.status(401).json({ success: false, message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়।' });
    }

    let emailChanged = false;
    let passwordChanged = false;
    const oldEmail = adminAccount.email;

    // 1. Update Email or Username if provided
    if (newEmailOrUsername && typeof newEmailOrUsername === 'string' && newEmailOrUsername.trim()) {
      const clean = newEmailOrUsername.trim();
      if (clean.includes('@')) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(clean)) {
          return res.status(400).json({ success: false, message: 'সঠিক ইমেইল ফরম্যাট প্রদান করুন (যেমন: admin@jhadimadi.com)।' });
        }
        if (clean.toLowerCase() !== adminAccount.email.toLowerCase()) {
          delete adminAccountsRegistry[adminAccount.email.toLowerCase()];
          adminAccount.email = clean.toLowerCase();
          adminAccountsRegistry[adminAccount.email] = {
            email: adminAccount.email,
            role: 'super_admin',
            isActive: true,
            passwordHash: adminAccount.passwordHash,
            createdAt: new Date().toISOString(),
          };
          emailChanged = true;
        }
      } else {
        if (!/^[a-zA-Z0-9_.\-]{3,30}$/.test(clean)) {
          return res.status(400).json({ success: false, message: 'ইউজারনেম ৩ থেকে ৩০ অক্ষরের হতে হবে।' });
        }
        if (clean.toLowerCase() !== adminAccount.username.toLowerCase()) {
          adminAccount.username = clean;
          emailChanged = true;
        }
      }
    }

    // 2. Update Password if provided
    if (newPassword) {
      if (!confirmPassword) {
        return res.status(400).json({ success: false, message: 'পাসওয়ার্ড নিশ্চিতকরণ প্রদান করুন।' });
      }
      if (newPassword !== confirmPassword) {
        return res.status(400).json({ success: false, message: 'নতুন পাসওয়ার্ড এবং নিশ্চিতকরণ পাসওয়ার্ড মিলছে না।' });
      }
      if (newPassword === currentPassword) {
        return res.status(400).json({ success: false, message: 'নতুন পাসওয়ার্ডটি বর্তমান পাসওয়ার্ডের চেয়ে ভিন্ন হতে হবে।' });
      }
      if (newPassword.length < 6) {
        return res.status(400).json({ success: false, message: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' });
      }

      const newHash = hashPassword(newPassword);
      adminAccount.passwordHash = newHash;
      adminAccount.lastPasswordChangeTime = new Date().toISOString();
      adminAccount.tokenEpoch = Date.now();
      adminAccount.sessions = [];
      if (adminAccountsRegistry[adminAccount.email.toLowerCase()]) {
        adminAccountsRegistry[adminAccount.email.toLowerCase()].passwordHash = newHash;
      }
      passwordChanged = true;
    }

    if (!emailChanged && !passwordChanged) {
      return res.status(400).json({ success: false, message: 'অনুগ্রহ করে নতুন ইমেইল/ইউজারনেম বা নতুন পাসওয়ার্ড প্রদান করুন।' });
    }

    saveAdminAccount(adminAccount);

    adminAuditLogs.unshift({
      id: 'log_' + Date.now(),
      adminEmail: adminAccount.email,
      actionType: 'CREDENTIALS_UPDATE',
      details: { emailChanged, passwordChanged, previousEmail: oldEmail, updatedEmail: adminAccount.email },
      createdAt: new Date().toISOString(),
    });

    let message = 'অ্যাডমিন ক্রেডেনশিয়াল সফলভাবে আপডেট হয়েছে!';
    if (passwordChanged) {
      message = 'ক্রেডেনশিয়াল ও পাসওয়ার্ড সফলভাবে আপডেট হয়েছে। পরবর্তী লগইনে নতুন তথ্য ব্যবহার করুন।';
    } else if (emailChanged) {
      message = `লগইন ক্রেডেনশিয়াল সফলভাবে '${adminAccount.email}' এ আপডেট হয়েছে।`;
    }

    res.json({
      success: true,
      message,
      email: adminAccount.email,
      username: adminAccount.username,
      passwordChanged,
    });
  });

  // Change Dashboard Password (Strict requirements: min 10 chars, uppercase, lowercase, number, special char)
  app.post('/api/admin/auth/change-password', requireAdminAuth, (req, res) => {
    const admin = (req as any).admin;
    if (admin.role !== 'super_admin') {
      return res.status(403).json({ success: false, message: 'শুধুমাত্র সুপার অ্যাডমিন পাসওয়ার্ড পরিবর্তন করতে পারেন।' });
    }

    const { currentPassword, newPassword, confirmPassword } = req.body;
    if (!currentPassword || !newPassword || !confirmPassword) {
      return res.status(400).json({ success: false, message: 'সকল পাসওয়ার্ড ফিল্ড পূরণ করা আবশ্যক।' });
    }

    if (newPassword !== confirmPassword) {
      return res.status(400).json({ success: false, message: 'নতুন পাসওয়ার্ড এবং নিশ্চিতকরণ পাসওয়ার্ড মিলছে না।' });
    }

    if (newPassword === currentPassword) {
      return res.status(400).json({ success: false, message: 'নতুন পাসওয়ার্ডটি বর্তমান পাসওয়ার্ডের চেয়ে ভিন্ন হতে হবে।' });
    }

    // Password Complexity Validation:
    // Minimum 10 characters, at least one uppercase, at least one lowercase, at least one number, at least one special character
    if (newPassword.length < 10) {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ড কমপক্ষে ১০ অক্ষরের হতে হবে।' });
    }
    if (!/[A-Z]/.test(newPassword)) {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ডে কমপক্ষে একটি বড় হাতের অক্ষর (A-Z) থাকতে হবে।' });
    }
    if (!/[a-z]/.test(newPassword)) {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ডে কমপক্ষে একটি ছোট হাতের অক্ষর (a-z) থাকতে হবে।' });
    }
    if (!/[0-9]/.test(newPassword)) {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ডে কমপক্ষে একটি সংখ্যা (0-9) থাকতে হবে।' });
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(newPassword)) {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ডে কমপক্ষে একটি বিশেষ অক্ষর (!@#$%^&*...) থাকতে হবে।' });
    }

    // Verify current password
    if (!verifyPassword(currentPassword, adminAccount.passwordHash)) {
      return res.status(401).json({ success: false, message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়।' });
    }

    // Hash new password securely with random salt and scrypt
    const newHash = hashPassword(newPassword);
    adminAccount.passwordHash = newHash;
    adminAccount.lastPasswordChangeTime = new Date().toISOString();
    // Invalidate all previously issued tokens
    adminAccount.tokenEpoch = Date.now();
    adminAccount.sessions = [];
    saveAdminAccount(adminAccount);

    if (adminAccountsRegistry[adminAccount.email.toLowerCase()]) {
      adminAccountsRegistry[adminAccount.email.toLowerCase()].passwordHash = newHash;
    }

    adminAuditLogs.unshift({
      id: 'log_' + Date.now(),
      adminEmail: adminAccount.email,
      actionType: 'PASSWORD_CHANGE',
      details: { timestamp: adminAccount.lastPasswordChangeTime },
      createdAt: new Date().toISOString(),
    });

    res.json({
      success: true,
      message: 'Password changed successfully. Please sign in again using your new password.',
    });
  });

  // Sign out from other sessions
  app.post('/api/admin/auth/sessions/revoke-others', requireAdminAuth, (req, res) => {
    const currentSessionId = (req as any).admin?.sessionId;
    adminAccount.sessions = (adminAccount.sessions || []).filter(s => s.id === currentSessionId);
    saveAdminAccount(adminAccount);

    res.json({
      success: true,
      message: 'অন্যান্য সকল সেশন থেকে সাইন আউট সম্পন্ন হয়েছে।',
      sessions: adminAccount.sessions,
    });
  });

  // Sign out from this current session
  app.post('/api/admin/auth/sessions/revoke-current', requireAdminAuth, (req, res) => {
    const currentSessionId = (req as any).admin?.sessionId;
    adminAccount.sessions = (adminAccount.sessions || []).filter(s => s.id !== currentSessionId);
    saveAdminAccount(adminAccount);

    res.json({
      success: true,
      message: 'বর্তমান সেশন সমাপ্ত করা হয়েছে।',
    });
  });

  // Legacy Proxy for backward-compatible password change
  app.post('/api/admin/password-change', requireAdminAuth, (req, res) => {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ড ফিল্ড পূরণ করুন।' });
    }
    if (!verifyPassword(currentPassword, adminAccount.passwordHash)) {
      return res.status(401).json({ success: false, message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়।' });
    }
    const newHash = hashPassword(newPassword);
    adminAccount.passwordHash = newHash;
    adminAccount.lastPasswordChangeTime = new Date().toISOString();
    adminAccount.tokenEpoch = Date.now();
    adminAccount.sessions = [];
    saveAdminAccount(adminAccount);

    res.json({ success: true, message: 'Password changed successfully. Please sign in again using your new password.' });
  });

  // Legacy Proxy for email/username change
  app.post('/api/admin/email-change', requireAdminAuth, (req, res) => {
    const { currentPassword, newEmail } = req.body;
    const clean = (newEmail || '').trim().toLowerCase();
    if (!verifyPassword(currentPassword, adminAccount.passwordHash)) {
      return res.status(401).json({ success: false, message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়।' });
    }
    if (clean.includes('@')) {
      adminAccount.email = clean;
    } else {
      adminAccount.username = clean;
    }
    saveAdminAccount(adminAccount);
    res.json({ success: true, message: 'ক্রেডেনশিয়াল সফলভাবে আপডেট হয়েছে।' });
  });

  // Role verification check
  app.post('/api/admin/roles/check', (req, res) => {
    const { email } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();
    const found = adminAccountsRegistry[cleanEmail];
    if (found && found.isActive) {
      return res.json({ success: true, role: found.role });
    }
    if (cleanEmail === 'admin@jhadimadi.com' || cleanEmail === 'changmapurna1993@gmail.com') {
      return res.json({ success: true, role: 'super_admin' });
    }
    res.json({ success: false, role: null });
  });

  // List Admin Accounts (Super Admin only)
  app.get('/api/admin/roles/list', requireSuperAdminAuth, (req, res) => {
    const accounts = Object.values(adminAccountsRegistry).map(acc => ({
      id: acc.email,
      email: acc.email,
      role: acc.role,
      isActive: acc.isActive,
      createdAt: acc.createdAt,
    }));
    res.json({ success: true, accounts });
  });

  // Update Admin Role (Super Admin only)
  app.post('/api/admin/roles/update', requireSuperAdminAuth, (req, res) => {
    const { email, role, isActive } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();

    if (cleanEmail === 'changmapurna1993@gmail.com' && role !== 'super_admin') {
      return res.status(400).json({ success: false, message: 'প্রাথমিক সুপার অ্যাডমিনের রোল পরিবর্তন করা যাবে না।' });
    }

    if (!['super_admin', 'admin', 'moderator'].includes(role)) {
      return res.status(400).json({ success: false, message: 'অবৈধ রোল।' });
    }

    adminAccountsRegistry[cleanEmail] = {
      email: cleanEmail,
      role,
      isActive: isActive !== false,
      passwordHash: adminAccountsRegistry[cleanEmail]?.passwordHash || loadAdminAccount().passwordHash,
      createdAt: adminAccountsRegistry[cleanEmail]?.createdAt || new Date().toISOString(),
    };

    adminAuditLogs.unshift({
      id: 'log_' + Date.now(),
      adminEmail: (req as any).admin.email,
      actionType: 'ROLE_CHANGE',
      details: { targetEmail: cleanEmail, newRole: role, isActive },
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, message: `অ্যাডমিন (${cleanEmail})-এর রোল আপডেট হয়েছে!` });
  });

  // Create New Staff Account (Super Admin only)
  app.post('/api/admin/roles/create', requireSuperAdminAuth, (req, res) => {
    const { email, role, tempPassword } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();

    if (!cleanEmail || !cleanEmail.includes('@')) {
      return res.status(400).json({ success: false, message: 'সঠিক ইমেইল অ্যাড্রেস দিন।' });
    }

    if (adminAccountsRegistry[cleanEmail]) {
      return res.status(400).json({ success: false, message: 'এই ইমেইলে ইতোমধ্যেই একটি একাউন্ট রয়েছে।' });
    }

    if (!['super_admin', 'admin', 'moderator'].includes(role)) {
      return res.status(400).json({ success: false, message: 'অবৈধ রোল।' });
    }

    const passwordToHash = tempPassword || 'AdminPass@' + Math.floor(1000 + Math.random() * 9000);
    const passwordHash = hashPassword(passwordToHash);

    adminAccountsRegistry[cleanEmail] = {
      email: cleanEmail,
      role,
      isActive: true,
      passwordHash,
      createdAt: new Date().toISOString(),
    };

    adminAuditLogs.unshift({
      id: 'log_' + Date.now(),
      adminEmail: (req as any).admin.email,
      actionType: 'STAFF_ACCOUNT_CREATED',
      details: { email: cleanEmail, role },
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, message: `নতুন স্টাফ (${cleanEmail}, ${role}) সফলভাবে তৈরি হয়েছে!` });
  });

  // Toggle Staff Account Status (Super Admin only)
  app.post('/api/admin/roles/toggle-status', requireSuperAdminAuth, (req, res) => {
    const { email, isActive } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();

    if (cleanEmail === 'changmapurna1993@gmail.com') {
      return res.status(400).json({ success: false, message: 'মূল সুপার অ্যাডমিন একাউন্ট নিষ্ক্রিয় করা যাবে না।' });
    }

    if (!adminAccountsRegistry[cleanEmail]) {
      return res.status(404).json({ success: false, message: 'অ্যাকাউন্টটি পাওয়া যায়নি।' });
    }

    adminAccountsRegistry[cleanEmail].isActive = Boolean(isActive);

    adminAuditLogs.unshift({
      id: 'log_' + Date.now(),
      adminEmail: (req as any).admin.email,
      actionType: 'STAFF_STATUS_TOGGLE',
      details: { email: cleanEmail, isActive: Boolean(isActive) },
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, message: `স্টাফ একাউন্টের স্ট্যাটাস পরিবর্তিত হয়েছে।` });
  });

  // Homepage Content & Announcements API
  const HOMEPAGE_CONTENT_FILE = path.join(process.cwd(), 'data', 'homepage_content.json');

  const defaultHomepageContent = {
    announcementTicker: {
      enabled: true,
      text: '🎉 পার্বত্য জুম ফসল ও অর্গানিক ফ্রুটসের স্পেশাল কালেকশন লাইভ! হোম ডেলিভারিতে ১০০% মানসম্মত ও সতেজ পণ্য।',
      tag: 'জরুরি বিজ্ঞপ্তি',
      speed: 'normal'
    },
    heroBanner: {
      title: 'পাহাড়ের সেরা অর্গানিক পণ্য ও দক্ষ কারিগর এক ছাদের নিচে',
      subtitle: 'রাঙ্গামাটি, খাগড়াছড়ি ও বান্দরবানের শতভাগ খাঁটি জুম ফসল, হস্তশিল্প ও বিশ্বস্ত টেকনিশিয়ানদের ডিজিটাল সেবা।',
      badge: 'পার্বত্য ডিজিটাল হাব ২০২৬',
      primaryBtnText: 'পণ্য এক্সপ্লোর করুন'
    },
    helpline: {
      phone: '01800-000000',
      whatsapp: '01800-000000',
      emergencyAmbulance: '01800-999999',
      supportEmail: 'support@jhadimadi.com'
    },
    operationalSettings: {
      maintenanceMode: false,
      registrationOpen: true,
      codEnabled: true,
      minOrderAmount: 100,
      defaultDeliveryCharge: 60,
      platformCommissionPercent: 5
    }
  };

  app.get('/api/admin/homepage-content', (req, res) => {
    try {
      if (fs.existsSync(HOMEPAGE_CONTENT_FILE)) {
        const data = JSON.parse(fs.readFileSync(HOMEPAGE_CONTENT_FILE, 'utf-8'));
        return res.json({ success: true, content: data });
      }
    } catch (e) {
      console.warn('Error reading homepage content file:', e);
    }
    res.json({ success: true, content: defaultHomepageContent });
  });

  app.post('/api/admin/homepage-content', requireAdminAuth, (req, res) => {
    try {
      const updatedContent = req.body;
      const dataDir = path.dirname(HOMEPAGE_CONTENT_FILE);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      fs.writeFileSync(HOMEPAGE_CONTENT_FILE, JSON.stringify(updatedContent, null, 2), 'utf-8');

      adminAuditLogs.unshift({
        id: 'log_' + Date.now(),
        adminEmail: (req as any).admin.email,
        actionType: 'HOMEPAGE_CONTENT_UPDATE',
        details: { updatedKeys: Object.keys(updatedContent) },
        createdAt: new Date().toISOString(),
      });

      res.json({ success: true, message: 'হোমপেজ কনটেন্ট ও ঘোষণা সফলভাবে সংরক্ষিত হয়েছে।' });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Audit Logs API (Admin only)
  app.get('/api/admin/audit-log/list', requireAdminAuth, (req, res) => {
    const limit = Number(req.query.limit) || 30;
    res.json({ success: true, logs: adminAuditLogs.slice(0, limit) });
  });

  // Ingest Audit Log Entry (Admin only)
  app.post('/api/admin/audit-log', requireAdminAuth, (req, res) => {
    const { actionType, details, adminEmail } = req.body;
    if (actionType) {
      adminAuditLogs.unshift({
        id: 'log_' + Date.now(),
        adminEmail: adminEmail || (req as any).admin.email,
        actionType,
        details: details || {},
        createdAt: new Date().toISOString(),
      });
    }
    res.json({ success: true });
  });

  // Helper for generating high-quality domain fallback mock responses for Jhadimadi Super-App
  const generateMockAssistantResponse = (userQuery: string, location?: string) => {
    const q = (userQuery || '').toLowerCase();
    const loc = location || 'পার্বত্য চট্টগ্রাম / রাঙ্গামাটি';

    if (q.includes('মিস্ত্রি') || q.includes('লেবার') || q.includes('গাঁথুনি') || q.includes('বিল্ডিং') || q.includes('mason')) {
      return {
        responseBn: `🧱 **রাজমিস্ত্রি ও নির্মাণ কাজের বাজারদর পরামর্শ (${loc}):**\n\n• **প্রধান রাজমিস্ত্রি (হেড মিস্ত্রি):** ৳১,০০০ - ৳১,২০০ / দিন (৮ ঘণ্টা ডিউটি)\n• **সহকারী কারিগর (জোগানদার / কামলা):** ৳৭০০ - ৳৮৫০ / দিন\n• **পাহাড়ী রিটেইনিং ওয়াল ও ড্রেন কাজ:** স্কয়ার ফিট বা চুক্তিভিত্তিক আলোচনা সাপেক্ষ।\n\n💡 *টিপস: ঝাদিমাটি থেকে বুক করার পূর্বে মিস্ত্রির NID ভেরিফিকেশন ও পূর্ববর্তী কাজের ছবি দেখে নিন।*`,
        recommendedCategory: 'mason',
        estimatedPriceRange: '৳৮০০ - ৳১,২০০ / দিন',
        suggestedActions: ['সার্চে রাজমিস্ত্রি দেখুন', 'সরাসরি কল করুন', 'পোস্ট জমা দিন'],
      };
    }

    if (q.includes('ইলেকট্রিক') || q.includes('বিদ্যুৎ') || q.includes('সোলার') || q.includes('ওয়্যারিং') || q.includes('ফ্যান') || q.includes('electrician')) {
      return {
        responseBn: `⚡ **ইলেকট্রিশিয়ান ও সোলার সিস্টেম সার্ভিস রেট:**\n\n• **বাসা ওয়্যারিং ও সুইচ মেরামত:** ৳৩৫০ - ৳৬০০ / কাজ\n• **পাহাড়ি সোলার প্যানেল ও ব্যাটারি সেটআপ:** ৳৮০০ - ৳১,৫০০\n• **শর্ট সার্কিট ও মেইন লাইন চেক:** ৳৫০০ - ৳৮০০\n\n💡 *ঝাদিমাটি ভেরিফাইড টেকনিশিয়ানদের কাছে রয়েছে স্ট্যান্ডার্ড টেস্টিং সরঞ্জাম। নিরাপদ সংযোগে কাজ করান।*`,
        recommendedCategory: 'electrician',
        estimatedPriceRange: '৳৪০০ - ৳৮০০ / সার্ভিস',
        suggestedActions: ['সার্চে ইলেকট্রিশিয়ান দেখুন', 'জরুরি সেবা বুকিং', 'কল করুন'],
      };
    }

    if (q.includes('গাড়ি') || q.includes('সিএনজি') || q.includes('চাঁদের গাড়ি') || q.includes('জিপ') || q.includes('সাজেক') || q.includes('ড্রাইভার') || q.includes('driver')) {
      return {
        responseBn: `🚗 **পাহাড়ি ট্রান্সপোর্ট ও রাইড ভাড়ার স্ট্যান্ডার্ড তালিকা:**\n\n• **রাঙ্গামাটি সদর লোকাল সিএনজি (রিজার্ভ):** ৳২০০ - ৳৫০০ (দূরত্ব অনুযায়ী)\n• **খাগড়াছড়ি - সাজেক ভ্যালি চাঁদের গাড়ি (আপ-ডাউন রিজার্ভ):** ৳৭,৫০০ - ৳১০,৫০০\n• **কাপ্তাই লেক ইঞ্জিন বোট / স্পিড বোট:** ৳১,২০০ - ৳৩,০০০ / ঘণ্টা\n\n💡 *পাহাড়ে অভিজ্ঞ লাইসেন্সধারী পাহাড়ি চালকদের সরাসরি যোগাযোগ করতে ঝাদিমাটি রাইডস অপশন ব্যবহার করুন।*`,
        recommendedCategory: 'driver',
        estimatedPriceRange: '৳৫০০ - ৳৮,০০০ / ট্রিপ',
        suggestedActions: ['চাঁদের গাড়ি খুঁজুন', 'সিএনজি চালক দেখুন', 'জরুরি অ্যাম্বুলেন্স'],
      };
    }

    if (q.includes('বাসা') || q.includes('ভাড়া') || q.includes('ফ্ল্যাট') || q.includes('বাড়ি') || q.includes('রুম') || q.includes('জমি') || q.includes('rent') || q.includes('property')) {
      return {
        responseBn: `🏢 **বাসা ভাড়া ও প্রপার্টি গাইডলাইন (${loc}):**\n\n• **২ রুমের পাহাড়ি ভিউ ফ্যামিলি ফ্ল্যাট:** ৳৬,০০০ - ৳৯,৫০০ / মাস\n• **৩ রুমের প্রিমিয়াম টাউন ফ্ল্যাট:** ৳১০,০০০ - ৳১৫,০০০ / মাস\n• **ব্যাচেলর / সিংগেল সিট মেস:** ৳১,৫০০ - ৳২,৫০০ / মাস\n\n💡 *ঝাদিমাটিতে কোনো দালাল কমিশন নেই। সরাসরি বাড়িওয়ালা ও ল্যান্ডলর্ডের সাথে কথা বলে ভিউ শিডিউল করুন।*`,
        recommendedCategory: 'realestate',
        estimatedPriceRange: '৳৫,০০০ - ৳১২,০০০ / মাস',
        suggestedActions: ['বাসা ভাড়া তালিকা দেখুন', 'ফ্ল্যাট সার্চ করুন', 'বাড়িওয়ালাকে মেসেজ'],
      };
    }

    if (q.includes('ডাক্তার') || q.includes('নার্স') || q.includes('হাসপাতাল') || q.includes('চিকিৎসা') || q.includes('রক্ত') || q.includes('doctor')) {
      return {
        responseBn: `🩺 **স্বাস্থ্যসেবা ও অন-কল হোম মেডিকেল সহায়তা:**\n\n• **জেনারেল ফিজিশিয়ান কনসালট্যান্ট:** ৳৫০০ - ৳৮০০ / পরামর্শ\n• **হোম ভিজিট ও বয়স্ক কেয়ারটেকার:** ৳৮০০ - ৳১,২০০ / দিন অথবা ৳১৫,০০০ / মাস\n• **জরুরি অ্যাম্বুলেন্স ও অক্সিজেন সার্ভিস:** ২৪/৭ অন-কল সরাসরি সক্রিয়।\n\n🚨 *জরুরি মুহূর্তে নিচে থাকা লাল SOS বাটনে চাপ দিয়ে তাৎক্ষণিক পুলিশ ও অ্যাম্বুলেন্স (৯৯৯) সহায়তা পান।*`,
        recommendedCategory: 'doctor',
        estimatedPriceRange: '৳৫০০ - ৳১,০০০ / ভিজিট',
        suggestedActions: ['ডাক্তার ডিরেক্টরি দেখুন', 'জরুরি SOS কল ৯৯৯', 'নার্সিং সেবা'],
      };
    }

    if (q.includes('আম') || q.includes('পেঁপে') || q.includes('বাগান') || q.includes('ফল') || q.includes('শুটকি') || q.includes('মধু') || q.includes('হলুদ') || q.includes('agri') || q.includes('food')) {
      return {
        responseBn: `🥭 **পাহাড়ি অর্গানিক কৃষিপণ্য ও ফলবাগান পরামর্শ:**\n\n• **রেড লেডি পেঁপে বাগান লিজ/উৎপাদন:** প্রতি একরে বছরে মুনাফা ৳১.৫ - ৳৩ লাখ।\n• **হিমসাগর/আম্রপালি বাগান সরাসরি ক্রয়:** ৳১০০ - ৳১৩০ / কেজি (পাইকারি)\n• **ন্যাচারাল পাহাড়ি মধু ও কেমিক্যালমুক্ত হলুদ:** ঝাদিমাটি গ্রিন ফার্মার্স ক্লাব থেকে ১০০% অরিজিনাল ডেলিভারি।`,
        recommendedCategory: 'hillfood',
        estimatedPriceRange: '৳১০০ - ৳৩৫০ / কেজি',
        suggestedActions: ['পাহাড়ি ফল দেখুন', 'অর্গানিক ফুড অর্ডার', 'বাগান লিজ দেখুন'],
      };
    }

    if (q.includes('টিউটর') || q.includes('পড়াশোনা') || q.includes('শিক্ষক') || q.includes('গণিত') || q.includes('ইংরেজি') || q.includes('tutor')) {
      return {
        responseBn: `📚 **হোম টিউটর ও গৃহশিক্ষক সংক্রান্ত তথ্য (${loc}):**\n\n• **প্রাথমিক ও ৫ম শ্রেণী (অল সাবজেক্ট):** ৳২,৫০০ - ৳৪,০০০ / মাস (সপ্তাহে ৪ দিন)\n• **মাধ্যমিক/এসএসসি (গণিত ও বিজ্ঞান):** ৳৪,০০০ - ৳৬,০০০ / মাস\n• **উচ্চমাধ্যমিক/এইচএসসি (আইসিটি/ইংরেজি):** ৳৫,০০০ - ৳৮,০০০ / মাস\n\n💡 *ঝাদিমাটি ডিরেক্টরি থেকে অভিজ্ঞ বিশ্ববিদ্যালয় শিক্ষার্থী ও শিক্ষকদের প্রোফাইল যাচাই করে বেছে নিন।*`,
        recommendedCategory: 'tutor',
        estimatedPriceRange: '৳৩,০০০ - ৳৬,০০০ / মাস',
        suggestedActions: ['টিউটর তালিকা দেখুন', 'শিক্ষক সার্চ করুন', 'কল করুন'],
      };
    }

    // Default universal helpful fallback
    return {
      responseBn: `✨ **ঝাদিমাটি এআই সুপার-অ্যাসিস্ট্যান্ট (${loc}):**\n\nআপনার অনুসন্ধান: "${userQuery}" সফলভাবে গৃহীত হয়েছে।\n\n• **অন-ডিমান্ড মিস্ত্রি ও লোকাল টেকনিশিয়ান:** রাজমিস্ত্রি, ইলেকট্রিশিয়ান, প্লাম্বার, মেকানিক এবং গৃহকর্মী ভেরিফাইড প্রোফাইল বিদ্যমান।\n• **পাহাড়ি প্রপার্টি ও পণ্য:** সরাসরি বাসা ভাড়া, জমি, গাড়ি রিজার্ভ এবং ১০০% খাঁটি পাহাড়ি ফল/খাবার অর্ডার করতে পারবেন।\n\nনিচের বোতামগুলো ব্যবহার করে সরাসরি সার্চ রেজাল্ট অথবা সংশ্লিষ্ট বিভাগে যান।`,
      recommendedCategory: 'all',
      estimatedPriceRange: 'সরকারি ও স্থানীয় রেট অনুযায়ী',
      suggestedActions: ['সার্চ ডিরেক্টরি ওপেন করুন', 'সব সেবা দেখুন', 'জরুরি ৯৯৯'],
    };
  };

  // Health check API
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'Jhadimadi API' });
  });

  // In-Memory Live Database Storage
  const liveUsers: Record<string, any> = {};

  // 1. DATABASE TABLE: DRIVERS & VEHICLES
  const liveDriversVehicles: any[] = [];

  // 2. DATABASE TABLE: SERVICES & MEDICAL
  const liveServicesMedical: any[] = [];

  // 3. DATABASE TABLE: FOOD & GROCERY ORDERS
  const liveFoodGroceryOrders: any[] = [];

  const livePosts: any[] = [];

  const liveBookings: any[] = [];
  const liveSOSBroadcasts: any[] = [];

  // ================= LIVE DATABASE REST ENDPOINTS =================

  // 1. LIVE DRIVERS & VEHICLES ENDPOINTS
  app.get('/api/drivers-vehicles', (req, res) => {
    const { district, upazila, status } = req.query;
    let list = liveDriversVehicles;
    if (district) {
      list = list.filter(d => d.district.toLowerCase() === (district as string).toLowerCase());
    }
    if (upazila) {
      list = list.filter(d => d.upazila.toLowerCase() === (upazila as string).toLowerCase());
    }
    if (status) {
      list = list.filter(d => d.status === status);
    }
    res.json({ success: true, drivers: list });
  });

  app.post('/api/drivers-vehicles', (req, res) => {
    const { driverName, phone, vehicleType, vehicleRegNo, district, upazila, mahalla, nidNumber, drivingLicense, nidFrontUrl, vehiclePhotoUrl } = req.body;
    
    if (!driverName || !phone || !vehicleType) {
      return res.status(400).json({ success: false, message: 'ড্রাইভারের নাম, ফোন ও যানবাহনের ধরণ আবশ্যক।' });
    }

    const newDriver = {
      id: 'drv_' + Date.now(),
      driverName,
      phone,
      vehicleType,
      vehicleRegNo: vehicleRegNo || 'প্রক্রিয়াধীন',
      district: district || 'Rangamati',
      upazila: upazila || 'Rangamati Sadar',
      mahalla: mahalla || 'বনরুপা (Bonorupa)',
      nidNumber: nidNumber || '1990000000000',
      drivingLicense: drivingLicense || 'DL-PENDING',
      status: 'pending_approval', // CNG/Vehicle registration saved with pending_approval state
      capabilities: [`${vehicleType} চালক`, 'পাহাড়ী রাস্তায় ড্রাইভ অভিজ্ঞ', 'স্থানীয় এলাকা বিশেষজ্ঞ'],
      certificates: ['NID ভেরিফিকেশন জমা দেওয়া হয়েছে', 'ড্রাইভিং লাইসেন্স স্ক্যান'],
      completedJobsCount: 0,
      rating: 5.0,
      image: vehiclePhotoUrl || 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80',
      nidFrontUrl,
      createdAt: new Date().toISOString().split('T')[0],
    };

    liveDriversVehicles.unshift(newDriver);
    res.json({ 
      success: true, 
      driver: newDriver, 
      message: '🎉 আপনার যানবাহন ও ড্রাইভার তথ্য ডাটাবেজে জমা হয়েছে! স্ট্যাটাস: "Pending Approval" (এডমিন রিভিউ এর পর একটিভ হবে)।' 
    });
  });

  app.patch('/api/drivers-vehicles/:id/status', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const driver = liveDriversVehicles.find(d => d.id === id);
    if (!driver) return res.status(404).json({ success: false, message: 'ড্রাইভার পাওয়া যায়নি।' });
    
    driver.status = status || 'Approved';
    res.json({ success: true, driver, message: `স্ট্যাটাস আপডেট করা হয়েছে: ${driver.status}` });
  });

  // 2. LIVE SERVICES & MEDICAL ENDPOINTS
  app.get('/api/services-medical', (req, res) => {
    const { district, upazila, role } = req.query;
    let list = liveServicesMedical;
    if (district) {
      list = list.filter(m => m.district.toLowerCase() === (district as string).toLowerCase());
    }
    if (upazila) {
      list = list.filter(m => m.upazila.toLowerCase() === (upazila as string).toLowerCase());
    }
    if (role) {
      list = list.filter(m => m.role.toLowerCase() === (role as string).toLowerCase());
    }
    res.json({ success: true, services: list });
  });

  app.post('/api/services-medical', (req, res) => {
    const { providerName, phone, role, specialtyBn, district, upazila, bmdcRegNo, hourlyRate } = req.body;
    if (!providerName || !phone || !role) {
      return res.status(400).json({ success: false, message: 'প্রোভাইডারের নাম, ফোন ও রোলে তথ্য প্রদান করুন।' });
    }

    const newMedical = {
      id: 'med_' + Date.now(),
      providerName,
      phone,
      role: role || 'Medical Personnel',
      specialtyBn: specialtyBn || 'স্বাস্থ্যসেবা কর্মী',
      district: district || 'Rangamati',
      upazila: upazila || 'Rangamati Sadar',
      bmdcRegNo: bmdcRegNo || 'BMDC-PENDING',
      status: 'Approved',
      capabilities: ['অন-কল সার্ভিস', 'জরুরি সেবা', 'স্থানীয় নার্সিং'],
      certificates: ['স্বাস্থ্য সেবা সনদপত্র (ডাটাবেজ ভেরিফাইড)'],
      completedJobsCount: 0,
      rating: 5.0,
      avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80',
      hourlyRate: hourlyRate ? Number(hourlyRate) : 400,
      createdAt: new Date().toISOString().split('T')[0],
    };

    liveServicesMedical.unshift(newMedical);
    res.json({ success: true, service: newMedical, message: 'মেডিকেল সেবাদাতা ডাটাবেজে যুক্ত হয়েছেন!' });
  });

  // 3. LIVE FOOD & GROCERY ORDERS ENDPOINT
  app.get('/api/food-grocery-orders', (req, res) => {
    res.json({ success: true, orders: liveFoodGroceryOrders });
  });

  app.post('/api/food-grocery-orders', (req, res) => {
    const { customerName, customerPhone, items, deliveryAddress, district, upazila, orderType } = req.body;
    
    if (!customerPhone || !items || items.length === 0) {
      return res.status(400).json({ success: false, message: 'কাস্টমার ফোন নম্বর ও অর্ডার সামগ্রী আবশ্যক।' });
    }

    // Query active local drivers / delivery providers in customer area
    const matchedDrivers = liveDriversVehicles.filter(d => 
      d.district.toLowerCase() === (district || 'Rangamati').toLowerCase() && d.status === 'Approved'
    );
    
    const assignedRider = matchedDrivers.length > 0 ? matchedDrivers[0] : {
      driverName: 'সুনীল চাকমা (হাইপারলোকাল রাইডার)',
      phone: '01812345678',
      vehicleType: 'বাইক ডেলিভারি বয়'
    };

    const newOrder = {
      id: 'FGO-' + Date.now(),
      customerName: customerName || 'সম্মানিত গ্রাহক',
      customerPhone,
      items,
      deliveryAddress: deliveryAddress || `${upazila || 'Rangamati Sadar'}, ${district || 'Rangamati'}`,
      district: district || 'Rangamati',
      upazila: upazila || 'Rangamati Sadar',
      orderType: orderType || 'Food & Grocery Delivery',
      assignedRider,
      status: 'Dispatched',
      whatsappConnectUrl: `https://wa.me/88${assignedRider.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`হ্যালো ${assignedRider.driverName}, আমি ঝাদিমাটি ডট কম থেকে অর্ডার #${Date.now()} বিষয়ে যোগাযোগ করছি।`)}`,
      telCallUrl: `tel:${assignedRider.phone}`,
      createdAt: new Date().toISOString(),
    };

    liveFoodGroceryOrders.unshift(newOrder);

    res.json({
      success: true,
      order: newOrder,
      message: `🎉 আপনার ${orderType || 'খাবার/বাজার'} অর্ডারটি ডাটাবেজে সেভ হয়েছে! লোকাল রাইডার ${assignedRider.driverName} (${assignedRider.phone}) এর সাথে কানেক্ট করা হয়েছে।`,
    });
  });

  // 4. LIVE USERS ENDPOINT (Secured for Admin only, password stripped)
  app.get('/api/users', requireAdminAuth, (req, res) => {
    const sanitizedUsers = (Object.values(liveUsers) as any[]).map(u => {
      const { password, ...safeUser } = u;
      return safeUser;
    });
    res.json({ success: true, users: sanitizedUsers });
  });

  // ================= 5. HYPERLOCAL FREELANCER DIRECTORY & WORKER PORTFOLIOS =================
  const liveFreelancers: any[] = [];

  // GET /api/freelancers: Search and Filter with Public Data Sanitization (Sensitive NID & Wallet Hidden)
  app.get('/api/freelancers', (req, res) => {
    const { district, upazila, mahalla, profession, verifiedOnly, search } = req.query;
    let list = [...liveFreelancers];

    if (district && district !== 'All') {
      list = list.filter(f => f.district?.toLowerCase() === (district as string).toLowerCase());
    }
    if (upazila && upazila !== 'All') {
      list = list.filter(f => f.upazila?.toLowerCase().includes((upazila as string).toLowerCase()));
    }
    if (mahalla && mahalla !== 'All') {
      list = list.filter(f => f.mahalla?.toLowerCase().includes((mahalla as string).toLowerCase()));
    }
    if (profession && profession !== 'All') {
      const q = (profession as string).toLowerCase();
      list = list.filter(f => 
        f.categoryBn?.toLowerCase().includes(q) || 
        f.categoryEn?.toLowerCase().includes(q) ||
        f.subCategory?.toLowerCase().includes(q) ||
        f.skills?.some((s: string) => s.toLowerCase().includes(q))
      );
    }
    if (verifiedOnly === 'true') {
      list = list.filter(f => f.nidVerified);
    }
    if (search) {
      const term = (search as string).toLowerCase();
      list = list.filter(f => 
        f.name?.toLowerCase().includes(term) ||
        f.categoryBn?.toLowerCase().includes(term) ||
        f.skills?.some((s: string) => s.toLowerCase().includes(term)) ||
        f.upazila?.toLowerCase().includes(term) ||
        f.coveredAreas?.some((a: string) => a.toLowerCase().includes(term))
      );
    }

    // Public Sanitization: Strip private NID and wallet earnings
    const publicList = list.map(f => {
      const { nidNumber, nidFrontUrl, nidBackUrl, privateWallet, ...publicData } = f;
      return publicData;
    });

    res.json({ success: true, count: publicList.length, freelancers: publicList });
  });

  // POST /api/freelancers/register: Create or Update Freelancer Portfolio
  app.post('/api/freelancers/register', (req, res) => {
    const body = req.body;
    if (!body.name || !body.realPhone || !body.categoryBn) {
      return res.status(400).json({ success: false, message: 'নাম, মোবাইল নম্বর ও পেশার তথ্য আবশ্যক।' });
    }

    const newWorker = {
      id: body.id || 'prov_' + Date.now(),
      name: body.name,
      avatar: body.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      categoryBn: body.categoryBn,
      categoryEn: body.categoryEn || 'Service Provider',
      subCategory: body.subCategory || 'Hyperlocal In-Person Service',
      rating: body.rating || 5.0,
      jobsCompleted: body.jobsCompleted || 0,
      experienceYears: Number(body.experienceYears) || 5,
      hourlyRate: Number(body.hourlyRate) || 350,
      dailyRate: body.dailyRate ? Number(body.dailyRate) : undefined,
      fixedRate: body.fixedRate ? Number(body.fixedRate) : undefined,
      rateType: body.rateType || 'Hourly',
      phoneHidden: body.phoneHidden || (body.realPhone.slice(0, 4) + 'XXXX' + body.realPhone.slice(-3)),
      realPhone: body.realPhone,
      district: body.district || 'Rangamati',
      upazila: body.upazila || 'Rangamati Sadar',
      mahalla: body.mahalla || 'বনরুপা',
      coveredAreas: Array.isArray(body.coveredAreas) && body.coveredAreas.length > 0 
        ? body.coveredAreas 
        : [body.mahalla || 'বনরুপা', body.upazila || 'Rangamati Sadar', body.district || 'Rangamati'],
      coverageRadiusKm: Number(body.coverageRadiusKm) || 15,
      nidVerified: true,
      selfieVerified: true,
      blueTickActive: true,
      isAvailableNow: true,
      distanceKm: body.distanceKm || 0.8,
      latitude: body.latitude || 22.6515,
      longitude: body.longitude || 92.1792,
      googleMapsEmbedUrl: body.googleMapsEmbedUrl || `https://maps.google.com/?q=${body.latitude || 22.6515},${body.longitude || 92.1792}`,
      mapPinAddress: body.detailedAddress || `${body.mahalla}, ${body.upazila}, ${body.district}`,
      bioBn: body.bioBn || 'দক্ষ সার্ভিস প্রোভাইডার।',
      bioEn: body.bioEn || body.bioBn || 'Experienced professional provider.',
      skills: body.skills || ['অন-স্পট সার্ভিস', 'ভেরিফাইড প্রোভাইডার'],
      skillsDetails: body.skillsDetails || body.bioBn || 'দক্ষ টেকনিশিয়ান। গ্রাহক সন্তুষ্টি ও নির্ভরযোগ্য কাজের নিশ্চয়তা প্রদান করি।',
      workGallery: body.workGallery || [],
      verifiedCertificates: body.verifiedCertificates || ['ঝাদিমাটি এনআইডি ভেরিফাইড প্রো মেম্বার [✓]'],
      nidNumber: body.nidNumber || '19900000000000',
      nidFrontUrl: body.nidFrontUrl,
      nidBackUrl: body.nidBackUrl,
      privateWallet: body.privateWallet || {
        walletBalance: 0,
        totalEarnings: 0,
        completedJobs: 0,
        pendingPayouts: 0,
        pendingEscrow: 0,
      },
      createdAt: new Date().toISOString(),
    };

    const existingIdx = liveFreelancers.findIndex(f => f.id === newWorker.id || f.realPhone === newWorker.realPhone);
    if (existingIdx >= 0) {
      liveFreelancers[existingIdx] = { ...liveFreelancers[existingIdx], ...newWorker };
    } else {
      liveFreelancers.unshift(newWorker);
    }

    res.json({
      success: true,
      freelancer: newWorker,
      message: '🎉 আপনার ইন-পার্সন ফ্রিল্যান্সার পোর্টফোলিও সফলভাবে পাবলিশ হয়েছে!'
    });
  });

  // GET /api/freelancers/:id/private-dashboard: Private Worker Financial Data (Visible ONLY to owner)
  app.get('/api/freelancers/:id/private-dashboard', (req, res) => {
    const { id } = req.params;
    const worker = liveFreelancers.find(f => f.id === id || f.realPhone === id);
    if (!worker) {
      return res.status(404).json({ success: false, message: 'প্রোভাইডার প্রোফাইল পাওয়া যায়নি।' });
    }

    res.json({
      success: true,
      workerId: worker.id,
      workerName: worker.name,
      wallet: worker.privateWallet || {
        walletBalance: 1850,
        totalEarnings: 18600,
        completedJobs: worker.jobsCompleted || 42,
        pendingPayouts: 0,
        pendingEscrow: 750,
      }
    });
  });

  // POST /api/freelancers/:id/cashout: Worker Wallet Cashout Request (Min BDT 600 required for BDT 500 cashout)
  app.post('/api/freelancers/:id/cashout', (req, res) => {
    const { id } = req.params;
    const { amount = 500, paymentMethod = 'bKash', payoutAccount } = req.body;
    const worker = liveFreelancers.find(f => f.id === id || f.realPhone === id);

    if (!worker) {
      return res.status(404).json({ success: false, message: 'প্রোভাইডার প্রোফাইল পাওয়া যায়নি।' });
    }

    const currentBalance = worker.privateWallet?.walletBalance || 0;
    if (currentBalance < 600) {
      return res.status(400).json({ 
        success: false, 
        message: `❌ ক্যাশআউট করার জন্য ওয়ালেটে ন্যূনতম ৳৬০০ ব্যালেন্স থাকা আবশ্যক। আপনার বর্তমান ব্যালেন্স: ৳${currentBalance}` 
      });
    }

    if (currentBalance < amount) {
      return res.status(400).json({
        success: false,
        message: `❌ পর্যাপ্ত ব্যালেন্স নেই। আপনার বর্তমান ব্যালেন্স: ৳${currentBalance}`
      });
    }

    // Process Cashout
    worker.privateWallet.walletBalance -= Number(amount);
    worker.privateWallet.pendingPayouts = (worker.privateWallet.pendingPayouts || 0) + Number(amount);

    res.json({
      success: true,
      cashoutAmount: Number(amount),
      remainingBalance: worker.privateWallet.walletBalance,
      payoutMethod: paymentMethod,
      payoutAccount: payoutAccount || worker.realPhone,
      message: `🎉 ৳${amount} ক্যাশআউট রিকোয়েস্ট গৃহীত হয়েছে! ১২ ঘণ্টার মধ্যে আপনার ${paymentMethod} অ্যাকাউন্টে জমা হবে।`
    });
  });

  // POST /api/freelancers/:id/hire: Customer Hire/Booking Request with Escrow
  app.post('/api/freelancers/:id/hire', (req, res) => {
    const { id } = req.params;
    const { customerName, customerPhone, serviceNote, scheduledDate, agreedAmount } = req.body;
    const worker = liveFreelancers.find(f => f.id === id);

    if (!worker) {
      return res.status(404).json({ success: false, message: 'প্রোভাইডার পাওয়া যায়নি।' });
    }

    const totalAmount = Number(agreedAmount) || worker.hourlyRate;
    const platformCommission = Math.round(totalAmount * 0.10); // 10% Platform Commission
    const workerNetEarning = totalAmount - platformCommission; // 90% Worker Net Earning

    const bookingId = 'BK-' + Date.now();
    const newBooking = {
      id: bookingId,
      bookingId,
      workerId: worker.id,
      workerName: worker.name,
      workerPhone: worker.realPhone,
      customerName: customerName || 'গ্রাহক',
      customerPhone: customerPhone || '01812345678',
      serviceNote: serviceNote || worker.categoryBn,
      serviceTitleBn: worker.categoryBn,
      serviceTitleEn: worker.categoryEn,
      scheduledDate: scheduledDate || 'আজই জরুরি',
      totalAmount,
      clientPaidAmount: totalAmount,
      platformCommission,
      workerNetEarning,
      escrowStatus: 'HELD_IN_ESCROW',
      status: 'Confirmed_Escrow_Locked',
      location: worker.mapPinAddress || `${worker.mahalla}, ${worker.upazila}, ${worker.district}`,
      provider: worker,
      createdAt: new Date().toISOString(),
    };

    // Update worker stats (held in pending escrow)
    if (worker.privateWallet) {
      worker.privateWallet.pendingEscrow = (worker.privateWallet.pendingEscrow || 0) + totalAmount;
    }

    liveBookings.unshift(newBooking);

    res.json({
      success: true,
      booking: newBooking,
      commissionBreakdown: {
        clientPaid: totalAmount,
        platformCommission10Pct: platformCommission,
        workerNetEarning90Pct: workerNetEarning,
        escrowStatus: 'HELD_IN_ESCROW',
      },
      message: `🎉 ${worker.name} কে হায়ার রিকোয়েস্ট সফলভাবে পাঠানো হয়েছে! ৳${totalAmount} টাকা ঝাদিমাটি এসক্রোতে সংরক্ষিত হয়েছে।`
    });
  });

  // POST /api/bookings/:id/complete: Complete Booking & Release 90% Escrow to Worker (10% Platform Fee Deducted)
  app.post('/api/bookings/:id/complete', (req, res) => {
    const { id } = req.params;
    const booking = liveBookings.find(b => b.id === id || b.bookingId === id);

    if (!booking) {
      return res.status(404).json({ success: false, message: 'বুকিং রেকর্ড পাওয়া যায়নি।' });
    }

    if (booking.escrowStatus === 'RELEASED_TO_WORKER') {
      return res.json({ success: true, booking, message: 'এই বুকিংয়ের পেমেন্ট ইতোমধ্যে রিলিজ করা হয়েছে।' });
    }

    const totalAmount = Number(booking.clientPaidAmount || booking.totalAmount) || 500;
    const platformCommission = Math.round(totalAmount * 0.10); // 10%
    const workerNetEarning = totalAmount - platformCommission; // 90%

    booking.status = 'Completed';
    booking.escrowStatus = 'RELEASED_TO_WORKER';
    booking.platformCommission = platformCommission;
    booking.workerNetEarning = workerNetEarning;
    booking.completedAt = new Date().toISOString();

    // Credit Worker Wallet
    const worker = liveFreelancers.find(f => f.id === booking.workerId || f.id === booking.provider?.id);
    if (worker && worker.privateWallet) {
      worker.privateWallet.pendingEscrow = Math.max(0, (worker.privateWallet.pendingEscrow || totalAmount) - totalAmount);
      worker.privateWallet.walletBalance = (worker.privateWallet.walletBalance || 0) + workerNetEarning;
      worker.privateWallet.totalEarnings = (worker.privateWallet.totalEarnings || 0) + workerNetEarning;
      worker.privateWallet.completedJobs = (worker.privateWallet.completedJobs || 0) + 1;
      worker.jobsCompleted = (worker.jobsCompleted || 0) + 1;
    }

    res.json({
      success: true,
      booking,
      payoutSummary: {
        clientPaid: totalAmount,
        deductedCommission: platformCommission,
        creditedToWorkerWallet: workerNetEarning,
        workerNewBalance: worker?.privateWallet?.walletBalance || workerNetEarning,
      },
      message: `🎉 কাজ সফলভাবে সম্পন্ন হয়েছে! ১০% (৳${platformCommission}) কমিশন কেটে কর্মীর ওয়ালেটে ৯০% (৳${workerNetEarning}) নিট আয় যোগ হয়েছে।`
    });
  });

  // 1. LIVE POSTS ENDPOINTS
  app.get('/api/posts', (req, res) => {
    res.json({ success: true, posts: livePosts });
  });

  app.post('/api/posts', async (req, res) => {
    try {
      const { title, content, category, postType, price, division, district, upazila, mahalla, authorName, authorPhone, image } = req.body;
      
      const newPost = {
        id: 'post_' + Date.now(),
        authorName: authorName || 'ভেরিফাইড সেলার',
        authorRole: 'User',
        postType: postType || 'ECommerce',
        title,
        content,
        division: division || 'Chittagong Division (চট্টগ্রাম)',
        district: district || 'Rangamati',
        upazila: upazila || 'Rangamati Sadar',
        mahalla: mahalla || 'বনরুপা (Bonorupa)',
        category: category || 'General',
        price: price ? Number(price) : undefined,
        contactPhoneHidden: authorPhone ? `${authorPhone.substring(0, 5)}***${authorPhone.substring(8)}` : '01812***567',
        realPhone: authorPhone || '01812345678',
        status: 'Approved', // Auto-approved for verified active members
        createdAt: 'এখনই',
        likes: 0,
        commentsCount: 0,
        isVerifiedUser: true,
        image: image || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=600&q=80',
      };

      livePosts.unshift(newPost);
      res.json({ success: true, post: newPost });
    } catch (err) {
      res.status(500).json({ success: false, message: 'পোস্ট সেভ করতে সমস্যা হয়েছে।' });
    }
  });

  // 2. LIVE AUTH ENDPOINTS
  app.post('/api/auth/register', (req, res) => {
    const { name, phone, email, password, division, district, upazila, mahalla, nidFrontUrl, nidBackUrl, selfieUrl } = req.body;
    if ((!phone && !email) || !name) {
      return res.status(400).json({ success: false, message: 'মোবাইল নম্বর অথবা ইমেইল এবং নাম আবশ্যক।' });
    }

    const identifier = (phone || email || '').trim().toLowerCase();

    if (!password) {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ড প্রদান করা আবশ্যক।' });
    }

    // Hash password securely with salted scrypt
    const hashedPassword = hashPassword(password);

    const newUser = {
      id: 'u_' + Date.now(),
      name,
      phone: phone || '',
      email: email || '',
      password: hashedPassword,
      division: division || 'Chittagong Division (চট্টগ্রাম)',
      district: district || 'Rangamati',
      upazila: upazila || 'Rangamati Sadar',
      mahalla: mahalla || 'বনরুপা (Bonorupa)',
      avatar: selfieUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      nidFrontUrl,
      nidBackUrl,
      selfieUrl,
      isNidVerified: true,
      isPaidMember: true,
      createdAt: new Date().toISOString().split('T')[0],
    };

    liveUsers[identifier] = newUser;
    if (phone) liveUsers[phone] = newUser;
    if (email) liveUsers[email.toLowerCase()] = newUser;

    const { password: _p, ...safeUser } = newUser;
    res.json({ success: true, user: safeUser, message: 'রেজিস্ট্রেশন সফল হয়েছে!' });
  });

  app.post('/api/auth/login', (req, res) => {
    const { phone, email, phoneOrEmail, password } = req.body;
    const identifier = (phoneOrEmail || phone || email || '').trim().toLowerCase();

    if (!identifier) {
      return res.status(400).json({ success: false, message: 'মোবাইল নম্বর বা ইমেইল প্রদান করুন।' });
    }

    let user = liveUsers[identifier];
    if (!user) {
      // Look up in values by phone or email
      const allUsers = Object.values(liveUsers) as any[];
      user = allUsers.find((u: any) => 
        (u.phone && u.phone.trim().toLowerCase() === identifier) || 
        (u.email && u.email.trim().toLowerCase() === identifier)
      );
    }

    if (user) {
      // If user has a password set, verify using salted hash with fallback for pre-existing records
      if (user.password && password) {
        const isMatch = verifyPassword(password, user.password) || user.password === password;
        if (!isMatch) {
          return res.status(401).json({ success: false, message: 'ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন।' });
        }
        // Seamlessly upgrade legacy plaintext password to secure salted hash
        if (user.password === password) {
          user.password = hashPassword(password);
        }
      }
    } else {
      return res.status(404).json({ success: false, message: 'কোনো রেজিস্টার্ড অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে সাইন আপ করুন।' });
    }

    const { password: _p2, ...safeUser } = user;
    res.json({ success: true, user: safeUser, message: 'লগইন সফল হয়েছে!' });
  });

  // 3. LIVE BDT 100 ANNUAL MEMBERSHIP & VERIFICATION DATABASE
  const livePendingVerifications: any[] = [
    {
      id: 'vrf_101',
      userId: 'u_101',
      name: 'সৌরভ চাকমা',
      phone: '01844-556677',
      email: 'sourav.chakma@gmail.com',
      profession: 'সার্টিফাইড সোলার ও ইলেকট্রিক্যাল ইঞ্জিনিয়ার',
      subCategory: 'Solar Inverter & Wiring',
      rateType: 'Daily',
      rateAmount: 2500,
      division: 'Chittagong Division (চট্টগ্রাম)',
      district: 'Rangamati',
      upazila: 'Rangamati Sadar',
      mahalla: 'তবলছড়ি',
      nidNumber: '19948472910482',
      nidFrontUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80',
      nidBackUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80',
      selfieUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      certificates: ['বাংলাদেশ কারিগরি শিক্ষা বোর্ড ডিপ্লোমা সার্টিফিকেট', 'সোলার এনার্জি ট্রেনিং সার্টিফিকেট'],
      portfolioImages: [
        'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80'
      ],
      skills: ['সোলার প্যানেল ইনস্টলেশন', 'আইপিএস ও ব্যাটারি মেরামত', 'ইলেকট্রিক্যাল ওয়্যারিং'],
      bio: 'কারিগরি শিক্ষা বোর্ড থেকে ডিপ্লোমা সম্পন্ন। রাঙামাটি ও কাপ্তাই লেক অঞ্চলে ৮ বছর ধরে সোলার ও হোম ওয়্যারিং করছি।',
      feeAmount: 100,
      paymentMethod: 'bKash',
      trxId: 'BK9A87X412',
      status: 'pending',
      adminNotes: '',
      submittedAt: '২০২৬-০৮-২৫ ১০:৩০ AM',
    },
    {
      id: 'vrf_102',
      userId: 'u_102',
      name: 'ডা. রীমা দেওয়ান',
      phone: '01712-889900',
      email: 'dr.reema.dewan@gmail.com',
      profession: 'এমবিবিএস ডাক্তার ও শিশুরোগ বিশেষজ্ঞ',
      subCategory: 'Child Healthcare & General Visit',
      rateType: 'Hourly',
      rateAmount: 600,
      division: 'Chittagong Division (চট্টগ্রাম)',
      district: 'Khagrachhari',
      upazila: 'Khagrachhari Sadar',
      mahalla: 'আদালত পাড়া',
      nidNumber: '19918273910293',
      nidFrontUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80',
      nidBackUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80',
      selfieUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      certificates: ['BMDC রেজিস্ট্রেশন নম্বর: A-74892', 'এমবিবিএস চট্টগ্রাম মেডিকেল কলেজ'],
      portfolioImages: [
        'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=600&q=80'
      ],
      skills: ['শিশু স্বাস্থ্য পরামর্শ', 'মৌসুমি জ্বর ও ডায়রিয়া চিকিৎসা', 'হোম ভিজিট ও টেলিমেডিসিন'],
      bio: 'বিএমডিসি রেজিস্টার্ড চিকিৎসক। খাগড়াছড়ি সদর ও দীঘিনালা এলাকার প্রসূতি ও শিশুদের জরুরি স্বাস্থ্যসেবা প্রদান করি।',
      feeAmount: 100,
      paymentMethod: 'Nagad',
      trxId: 'NG77T9021Q',
      status: 'pending',
      adminNotes: '',
      submittedAt: '২০২৬-০৮-২৫ ০২:১৫ PM',
    }
  ];

  const livePaymentLedger: any[] = [
    {
      id: 'led_1',
      trxId: 'BK9A87X412',
      senderName: 'সৌরভ চাকমা',
      senderPhone: '01844-556677',
      paymentMethod: 'bKash',
      amount: 100,
      purpose: '100_REGISTRATION_FEE',
      status: 'Success',
      date: '2026-08-25 10:30 AM',
      reviewedBy: 'Admin Team',
    },
    {
      id: 'led_2',
      trxId: 'NG77T9021Q',
      senderName: 'ডা. রীমা দেওয়ান',
      senderPhone: '01712-889900',
      paymentMethod: 'Nagad',
      amount: 100,
      purpose: '100_REGISTRATION_FEE',
      status: 'Success',
      date: '2026-08-25 02:15 PM',
      reviewedBy: 'Admin Team',
    },
    {
      id: 'led_3',
      trxId: 'RK48210984',
      senderName: 'মংনু মারমা',
      senderPhone: '01812-345892',
      paymentMethod: 'Rocket',
      amount: 100,
      purpose: '100_REGISTRATION_FEE',
      status: 'Success',
      date: '2026-08-20 11:00 AM',
      reviewedBy: 'System Auto-Approval',
    }
  ];

  // Admin APIs (Protected by requireAdminAuth)
  app.get('/api/admin/verifications', requireAdminAuth, (req, res) => {
    const totalApplications = livePendingVerifications.length;
    const pendingCount = livePendingVerifications.filter(v => v.status === 'pending').length;
    const approvedCount = livePendingVerifications.filter(v => v.status === 'approved' || v.status === 'verified').length;
    const rejectedCount = livePendingVerifications.filter(v => v.status === 'rejected').length;
    const totalRevenue = livePaymentLedger.reduce((sum, item) => sum + item.amount, 0);

    res.json({
      success: true,
      stats: {
        totalApplications,
        pendingCount,
        approvedCount,
        rejectedCount,
        totalRevenue,
      },
      verifications: livePendingVerifications,
    });
  });

  app.post('/api/admin/verifications/:id/approve', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const { adminNotes } = req.body;
    const item = livePendingVerifications.find(v => v.id === id);

    if (!item) {
      return res.status(404).json({ success: false, message: 'আবেদন পাওয়া যায়নি।' });
    }

    item.status = 'approved';
    item.adminNotes = adminNotes || 'প্রোফাইল তথ্য ও এনআইডি সফলভাবে ভেরিফাই করা হয়েছে।';
    item.reviewedAt = new Date().toISOString();

    // Activate Pro Verified Badge in live users
    if (item.phone && liveUsers[item.phone]) {
      liveUsers[item.phone].isPaidMember = true;
      liveUsers[item.phone].isNidVerified = true;
      liveUsers[item.phone].verificationStatus = 'verified';
    }

    // Add or update to live freelancers
    const existingProv = liveFreelancers.find((f: any) => f.realPhone === item.phone);
    if (existingProv) {
      existingProv.nidVerified = true;
      existingProv.blueTickActive = true;
      existingProv.isPaidProPartner = true;
    } else {
      liveFreelancers.unshift({
        id: 'prov_' + Date.now(),
        name: item.name,
        avatar: item.selfieUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        categoryBn: item.profession,
        categoryEn: item.profession,
        subCategory: item.subCategory || 'General Service',
        rating: 5.0,
        jobsCompleted: 1,
        experienceYears: 5,
        hourlyRate: item.rateAmount || 400,
        dailyRate: (item.rateAmount || 400) * 6,
        rateType: item.rateType || 'Hourly',
        phoneHidden: item.phone ? `${item.phone.substring(0, 5)}***${item.phone.substring(8)}` : '+880 18XX-XXX000',
        realPhone: item.phone || '+880 1800-000000',
        district: item.district || 'Rangamati',
        upazila: item.upazila || 'Rangamati Sadar',
        mahalla: item.mahalla || 'সদর',
        nidVerified: true,
        selfieVerified: true,
        blueTickActive: true,
        isAvailableNow: true,
        distanceKm: 1.0,
        skills: item.skills || [],
        bioBn: item.bio || 'ঝাদিমাটি ভেরিফাইড প্রফেশনাল পার্টনার।',
        bioEn: item.bio || 'Verified professional partner.',
        isPaidProPartner: true,
        nidNumber: item.nidNumber,
      });
    }

    res.json({
      success: true,
      message: `🎉 ${item.name}-এর প্রোফাইল ভেরিফাই ও ব্লু-টিক [✓] অ্যাক্টিভ করা হয়েছে!`,
      item,
    });
  });

  app.post('/api/admin/verifications/:id/reject', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const { adminNotes } = req.body;
    const item = livePendingVerifications.find(v => v.id === id);

    if (!item) {
      return res.status(404).json({ success: false, message: 'আবেদন পাওয়া যায়নি।' });
    }

    item.status = 'rejected';
    item.adminNotes = adminNotes || 'এনআইডি ছবি অস্পষ্ট অথবা তথ্যে অসঙ্গতি রয়েছে।';
    item.reviewedAt = new Date().toISOString();

    if (item.phone && liveUsers[item.phone]) {
      liveUsers[item.phone].verificationStatus = 'rejected';
      liveUsers[item.phone].adminNotes = item.adminNotes;
    }

    res.json({
      success: true,
      message: `${item.name}-এর আবেদন প্রত্যাখ্যান করা হয়েছে।`,
      item,
    });
  });

  app.post('/api/admin/verifications/:id/request-revision', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const { adminNotes } = req.body;
    const item = livePendingVerifications.find(v => v.id === id);

    if (!item) {
      return res.status(404).json({ success: false, message: 'আবেদন পাওয়া যায়নি।' });
    }

    item.status = 'revision_requested';
    item.adminNotes = adminNotes || 'দয়া করে পরিষ্কার এনআইডি ও সার্টিফিকেটের ছবি পুনরায় আপলোড করুন।';
    item.reviewedAt = new Date().toISOString();

    if (item.phone && liveUsers[item.phone]) {
      liveUsers[item.phone].verificationStatus = 'revision_requested';
      liveUsers[item.phone].adminNotes = item.adminNotes;
    }

    res.json({
      success: true,
      message: `${item.name}-কে তথ্য সংশোধনের অনুরোধ পাঠানো হয়েছে।`,
      item,
    });
  });

  app.get('/api/admin/ledger', requireAdminAuth, (req, res) => {
    const totalCollected = livePaymentLedger.reduce((sum, item) => sum + item.amount, 0);
    res.json({
      success: true,
      totalCollected,
      ledger: livePaymentLedger,
    });
  });

  app.get('/api/verifications/pending', requireAdminAuth, (req, res) => {
    res.json({ success: true, verifications: livePendingVerifications });
  });

  app.post('/api/verifications/submit', (req, res) => {
    const { 
      name, phone, email, profession, subCategory, rateType, rateAmount, 
      division, district, upazila, mahalla, nidNumber, nidFrontUrl, 
      nidBackUrl, selfieUrl, certificates, portfolioImages, skills, bio,
      paymentMethod, trxId, feeAmount 
    } = req.body;

    const verificationRecord = {
      id: 'vrf_' + Date.now(),
      name: name || 'মেম্বার',
      phone: phone || '01812345678',
      email: email || '',
      profession: profession || 'সার্ভিস প্রোভাইডার',
      subCategory: subCategory || 'General',
      rateType: rateType || 'Hourly',
      rateAmount: Number(rateAmount) || 300,
      division: division || 'Chittagong Division (চট্টগ্রাম)',
      district: district || 'Rangamati',
      upazila: upazila || 'Rangamati Sadar',
      mahalla: mahalla || 'বনরুপা',
      nidNumber: nidNumber || '1990000000000',
      nidFrontUrl: nidFrontUrl || 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80',
      nidBackUrl: nidBackUrl || 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80',
      selfieUrl: selfieUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      certificates: certificates || [],
      portfolioImages: portfolioImages || [],
      skills: skills || [],
      bio: bio || '',
      feeAmount: feeAmount || 100,
      paymentMethod: paymentMethod || 'bKash',
      trxId: trxId || 'TRX_' + Math.floor(100000 + Math.random() * 900000),
      status: 'pending',
      adminNotes: '',
      submittedAt: new Date().toLocaleDateString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
    };

    livePendingVerifications.unshift(verificationRecord);

    // Also add to Payment Ledger
    livePaymentLedger.unshift({
      id: 'led_' + Date.now(),
      trxId: verificationRecord.trxId,
      senderName: verificationRecord.name,
      senderPhone: verificationRecord.phone,
      paymentMethod: verificationRecord.paymentMethod,
      amount: 100,
      purpose: '100_REGISTRATION_FEE',
      status: 'Success',
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      reviewedBy: 'Pending Admin Verification',
    });

    if (phone && liveUsers[phone]) {
      liveUsers[phone].verificationStatus = 'pending_admin_approval';
      liveUsers[phone].membershipTrxId = verificationRecord.trxId;
    }

    res.json({ 
      success: true, 
      verification: verificationRecord, 
      message: '🎉 আপনার আবেদন ও ৳১০০ ফি জমা হয়েছে। অ্যাডমিন ভেরিফিকেশনের পর প্রোফাইলে ব্লু-টিক [✓] অ্যাক্টিভ হবে।' 
    });
  });

  app.post('/api/membership/pay', (req, res) => {
    const { phone, paymentMethod, trxId } = req.body;
    if (!phone) return res.status(400).json({ success: false, message: 'মোবাইল নম্বর আবশ্যক।' });

    if (liveUsers[phone]) {
      liveUsers[phone].isPaidMember = true;
      liveUsers[phone].membershipTrxId = trxId || 'TRX' + Date.now();
      liveUsers[phone].membershipPaymentMethod = paymentMethod || 'bKash';
    }

    const verificationRecord = {
      id: 'vrf_' + Date.now(),
      phone,
      paymentMethod: paymentMethod || 'bKash',
      trxId: trxId || 'TRX' + Date.now(),
      fee: 100,
      status: 'verified',
      submittedAt: new Date().toISOString(),
    };
    livePendingVerifications.unshift(verificationRecord);

    res.json({
      success: true,
      message: '🎉 ৳১০০ বার্ষিক সাবস্ক্রিপশন সফলভাবে সম্পন্ন হয়েছে! আপনার "Verified Pro Partner [✓]" ব্যাজ অ্যাক্টিভ হয়েছে।',
      trxId: trxId || 'TRX' + Date.now(),
    });
  });

  // 4. SOS BROADCAST ENDPOINT
  app.post('/api/sos/broadcast', (req, res) => {
    const { emergencyType, location, contactPhone, details, district, upazila } = req.body;
    const sosRecord = {
      id: 'SOS_' + Date.now(),
      emergencyType: emergencyType || 'Police 999',
      location: location || 'Rangamati Sadar',
      district: district || 'Rangamati',
      upazila: upazila || 'Rangamati Sadar',
      contactPhone: contactPhone || '01812345678',
      details,
      status: 'Active Alert',
      timestamp: new Date().toISOString(),
    };
    liveSOSBroadcasts.unshift(sosRecord);
    res.json({ success: true, record: sosRecord, message: '🚨 জরুরি বার্তা স্থানীয় সাপোর্ট টিমে সম্প্রচারিত হয়েছে!' });
  });

  // 5. LIVE BOOKING ENDPOINTS
  app.get('/api/bookings', (req, res) => {
    res.json({ success: true, bookings: liveBookings });
  });

  app.post('/api/bookings', (req, res) => {
    const totalAmount = Number(req.body.totalAmount) || 500;
    const platformCommission = Math.round(totalAmount * 0.10);
    const workerNetEarning = totalAmount - platformCommission;

    const booking = {
      id: 'bk_' + Date.now(),
      ...req.body,
      totalAmount,
      clientPaidAmount: totalAmount,
      platformCommission,
      workerNetEarning,
      escrowStatus: 'HELD_IN_ESCROW',
      status: req.body.status || 'Pending',
      createdAt: new Date().toISOString(),
    };
    liveBookings.unshift(booking);
    res.json({ success: true, booking, message: 'বুকিং সফলভাবে গ্রহণ করা হয়েছে!' });
  });

  // AI Moderation, Grammar/Spell Check, and Image Generation Route
  app.post('/api/moderate-and-enrich-post', async (req, res) => {
    try {
      const { title, content, category, postType, hasUserImage, imageUrl } = req.body;

      if (!title || !content) {
        return res.status(400).json({ success: false, message: 'শিরোনাম ও বিবরণ আবশ্যক।' });
      }

      console.log(`[Gemini AI] Moderating post: "${title}"`);

      // 1. Text Moderation & Grammar/Spell Correction
      const prompt = `You are the AI Content Moderator & Editor for "Jhadimadi.com" (ঝাদিমাটি ডট কম), a Bangladesh CHT hyperlocal super-app platform.
      Analyze the following user-submitted post:

      Category: ${category || 'General'}
      Listing Type: ${postType || 'ECommerce'}
      Title: ${title}
      Description: ${content}

      Tasks:
      1. Profanity & Abusive Language Check: Scan for explicit adult content, hate speech, illegal activities, or abusive language in Bengali or English. If present, set "isFlagged": true and "flagReason": "আপনার পোস্টের লেখায় অশালীন শব্দ রয়েছে, অনুগ্রহ করে সংশোধন করুন।".
      2. Auto Grammar & Spelling Correction: If NOT flagged, rewrite the title and description into clear, polished, grammatically correct standard Bengali sentences while preserving original details (location, phone, price).
      3. Topic Extraction: Extract a short 2-3 word topic key describing the product or service (e.g. "ফ্যান মেরামত", "বাচ্চার খেলনা", "৩ রুমের ফ্ল্যাট", "পাহাড়ি শুটকি", "বাইক রাইড").

      Return strict JSON matching the schema provided.`;

      let aiResult;
      const ai = getGeminiClient();

      if (ai) {
        try {
          const response = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: prompt,
            config: {
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  isFlagged: { type: Type.BOOLEAN },
                  flagReason: { type: Type.STRING },
                  correctedTitle: { type: Type.STRING },
                  correctedContent: { type: Type.STRING },
                  topicKey: { type: Type.STRING },
                },
                required: ['isFlagged', 'correctedTitle', 'correctedContent', 'topicKey'],
              },
            },
          });

          aiResult = JSON.parse(response.text || '{}');
        } catch (genErr) {
          console.warn('[Gemini AI] Moderation fallback to rule check:', (genErr as Error).message);
        }
      }

      if (!aiResult) {
        // Fallback rule check for profanity
        const badWords = ['খারাপ', 'অশ্লীল', 'abusive'];
        const isBad = badWords.some(w => (title + ' ' + content).includes(w));
        aiResult = {
          isFlagged: isBad,
          flagReason: isBad ? 'আপনার পোস্টের লেখায় অননুমোদিত শব্দ রয়েছে।' : '',
          correctedTitle: title,
          correctedContent: content,
          topicKey: category || 'General',
        };
      }

      // Check for Abusive / Profanity flagging
      if (aiResult.isFlagged) {
        return res.json({
          success: false,
          flagged: true,
          message: aiResult.flagReason || 'আপনার পোস্টের লেখায় অশালীন শব্দ রয়েছে, অনুগ্রহ করে সংশোধন করুন।',
        });
      }

      // Determine final image
      let finalImageUrl = imageUrl;

      // If user did not attach a custom image, generate or select a relevant high-quality promo thumbnail
      if (!hasUserImage || !imageUrl || imageUrl.includes('placeholder') || imageUrl.length < 10) {
        const topic = aiResult.topicKey || title;
        console.log(`[Gemini AI] Selecting relevant promo image thumbnail for topic: "${topic}"`);

        // Topic-based image curation mapping as reliable high-res promo thumbnails
        const lowerTopic = topic.toLowerCase();
        if (lowerTopic.includes('ফ্যান') || lowerTopic.includes('ইলেকট্রিক') || lowerTopic.includes('ওয়্যারিং') || lowerTopic.includes('এসি')) {
          finalImageUrl = 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80';
        } else if (lowerTopic.includes('খেলনা') || lowerTopic.includes('বাচ্চা') || lowerTopic.includes('পোশাক')) {
          finalImageUrl = 'https://images.unsplash.com/photo-1566454825481-4e48f80aa4d7?auto=format&fit=crop&w=600&q=80';
        } else if (lowerTopic.includes('ফ্ল্যাট') || lowerTopic.includes('বাসা') || lowerTopic.includes('ঘর') || lowerTopic.includes('রুম') || lowerTopic.includes('জমি')) {
          finalImageUrl = 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=600&q=80';
        } else if (lowerTopic.includes('শুটকি') || lowerTopic.includes('সিদোল') || lowerTopic.includes('মধু') || lowerTopic.includes('অর্গানিক') || lowerTopic.includes('আম')) {
          finalImageUrl = 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80';
        } else if (lowerTopic.includes('বাইক') || lowerTopic.includes('গাড়ি') || lowerTopic.includes('মেকানিক') || lowerTopic.includes('রাইড')) {
          finalImageUrl = 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80';
        } else if (lowerTopic.includes('ডাক্তার') || lowerTopic.includes('মেডিকেল') || lowerTopic.includes('নার্স') || lowerTopic.includes('স্বাস্থ্য')) {
          finalImageUrl = 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=600&q=80';
        } else if (lowerTopic.includes('খাবার') || lowerTopic.includes('বাজার') || lowerTopic.includes('রেস্টুরেন্ট')) {
          finalImageUrl = 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=600&q=80';
        } else {
          finalImageUrl = 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=600&q=80';
        }

        // Try generating an image via Gemini if available
        if (ai) {
          try {
            const imgGenResponse = await ai.models.generateContent({
              model: 'gemini-3.1-flash-lite-image',
              contents: `A clean, professional ecommerce promo product banner image for: ${topic}, bangladesh hill tracts style, high resolution, soft lighting`,
              config: {
                imageConfig: {
                  aspectRatio: '4:3',
                },
              },
            });

            if (imgGenResponse.candidates?.[0]?.content?.parts) {
              for (const part of imgGenResponse.candidates[0].content.parts) {
                if (part.inlineData && part.inlineData.data) {
                  finalImageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
                  console.log(`[Gemini AI] Successfully generated inline image for topic: ${topic}`);
                  break;
                }
              }
            }
          } catch (imgErr) {
            console.log('[Gemini AI] Image generation fallback used:', (imgErr as Error).message);
          }
        }
      }

      return res.json({
        success: true,
        flagged: false,
        correctedTitle: aiResult.correctedTitle || title,
        correctedContent: aiResult.correctedContent || content,
        topicKey: aiResult.topicKey || category,
        imageUrl: finalImageUrl,
      });
    } catch (err) {
      console.error('[Gemini AI Endpoint Error]:', (err as Error)?.message || 'Processing error');
      return res.json({
        success: true,
        flagged: false,
        correctedTitle: req.body.title,
        correctedContent: req.body.content,
        imageUrl: req.body.imageUrl || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=600&q=80',
      });
    }
  });

  // Dedicated Gemini AI Smart Assistant Endpoint with Intelligent Domain Fallback
  app.post('/api/gemini/assistant', async (req, res) => {
    const { userQuery, mode, context } = req.body;

    if (!userQuery) {
      return res.status(400).json({ success: false, message: 'ইউজারের প্রশ্ন বা রিকোয়েস্ট প্রদান করুন।' });
    }

    console.log(`[Gemini Assistant API] Processing query: "${userQuery}", mode: ${mode || 'general'}`);

    const loc = context?.location || 'রাঙ্গামাটি';

    try {
      const ai = getGeminiClient();

      if (ai) {
        const systemPrompt = `You are the Official AI Intelligence Engine of "Jhadimadi.com" (ঝাদিম মাটি ডট কম), Bangladesh's premier hyperlocal in-person freelancing, asset marketplace & services super-app.
Your purpose is to assist users across Chittagong Hill Tracts (Rangamati, Khagrachhari, Bandarban) and all 64 districts of Bangladesh.

Capabilities:
1. "smart_search" & Intent Parsing: Understand natural language inquiries for local workers (e.g. "আমার কাল সকালে ৩ জন অভিজ্ঞ রাজমিস্ত্রি লাগবে কাপ্তাই রোডে", "জরুরি সিএনজি বা চাঁদের গাড়ি ভাড়া চাই", "পাহাড়ি আম্রপালি বা পেঁপে বাগান লিজ চাই") and return structured filter advice + helpful response in clear, friendly Bengali.
2. "labor_wage_estimator": Provide realistic market daily/hourly rates for Bangladeshi skilled workers (Masons: ৳800-1200/day, Electricians: ৳400-800/job, Plumbers: ৳350-700/job, Daily labourers: ৳600-800/day, Doctors: ৳500-1000/consultation, Caretakers: ৳12000-18000/mo, CNG fares in hill roads).
3. "agriculture_advisor": Provide scientific, hill-tracts-adapted agricultural guidance for fruit orchards (Red Lady Papaya, Banana, Amrapali Mango, Pineapple, Ginger/Turmeric farming) including soil prep, irrigation, and natural pest control.
4. "general_helper": Explain platform policies (e.g., BDT 100 Annual Subscription with NID verification, BDT 600 min wallet balance / BDT 500 cashout to bKash/Nagad, 24/7 SOS Emergency Ambulance/Blood/Police 999).

User Inquiry: "${userQuery}"
Location Context: ${loc}
Context: ${JSON.stringify(context || {})}

Respond in structured JSON format with:
- "responseBn": Clear, helpful, polite, and well-structured Bengali explanation with bullet points and emojis.
- "recommendedCategory": The matching category ("mason", "electrician", "driver", "doctor", "tutor", "realestate", "hillfood", "mechanic", "plumber", "agri", or "all")
- "estimatedPriceRange": Suggested price in BDT (e.g. "৳৮০০ - ৳১,২০০ / দিন" or "৳১,৫০,০০০ / বছর")
- "suggestedActions": Array of 2-3 short clickable action buttons (e.g. ["সার্চে রাজমিস্ত্রি দেখুন", "সরাসরি কল করুন", "বুকিং জমা দিন"])
`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: systemPrompt,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                responseBn: { type: Type.STRING },
                recommendedCategory: { type: Type.STRING },
                estimatedPriceRange: { type: Type.STRING },
                suggestedActions: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
              },
              required: ['responseBn', 'recommendedCategory', 'suggestedActions'],
            },
          },
        });

        if (response && response.text) {
          const parsedResult = JSON.parse(response.text);
          return res.json({
            success: true,
            source: 'gemini-live',
            data: parsedResult,
          });
        }
      }
    } catch (err) {
      console.warn('[Gemini Assistant API] Live call failed, utilizing domain mock generator:', (err as Error).message);
    }

    // Fallback Mock Response Engine
    const mockData = generateMockAssistantResponse(userQuery, loc);
    return res.json({
      success: true,
      source: 'domain-fallback',
      data: mockData,
    });
  });

  // Dedicated Gemini AI Smart Search API (Natural Language Query to Structured Search Filters)
  app.post('/api/gemini/smart-search', async (req, res) => {
    const { query, location } = req.body;
    if (!query) {
      return res.status(400).json({ success: false, message: 'Search query required' });
    }

    try {
      const ai = getGeminiClient();
      if (ai) {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `Parse this natural language search query for Bangladesh hyperlocal service app "Jhadimadi.com":
Query: "${query}"
Location: "${location || 'Rangamati'}"

Extract search category, extracted keywords, detected intent, and estimated price range.
Return JSON:
{
  "category": "all" | "mason" | "electrician" | "tutor" | "realestate" | "driver" | "doctor" | "nurse" | "hillfood" | "mechanic" | "plumber",
  "cleanKeywords": "keywords in bengali/english",
  "explanation": "Short 1-sentence bengali summary of what was found",
  "estimatedRate": "Suggested BDT price",
  "tags": ["tag1", "tag2"]
}`,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                category: { type: Type.STRING },
                cleanKeywords: { type: Type.STRING },
                explanation: { type: Type.STRING },
                estimatedRate: { type: Type.STRING },
                tags: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
              },
              required: ['category', 'cleanKeywords', 'explanation', 'estimatedRate', 'tags'],
            },
          },
        });

        if (response && response.text) {
          const parsed = JSON.parse(response.text);
          return res.json({ success: true, source: 'gemini-live', ...parsed });
        }
      }
    } catch (e) {
      console.warn('[Gemini Smart Search] Using fallback parsing:', (e as Error).message);
    }

    // Fallback Mock Intent Parser for Search
    const fallback = generateMockAssistantResponse(query, location);
    return res.json({
      success: true,
      source: 'domain-fallback',
      category: fallback.recommendedCategory,
      cleanKeywords: query,
      explanation: `${fallback.recommendedCategory !== 'all' ? fallback.recommendedCategory : 'সার্ভিস'} সংক্রান্ত তথ্য ও ভেরিফাইড প্রোফাইল ফিল্টার করা হয়েছে।`,
      estimatedRate: fallback.estimatedPriceRange,
      tags: fallback.suggestedActions,
    });
  });

  // Registered NID Store for Duplicate Prevention
  const registeredNids: Record<string, { nidNumber: string; phone: string; name: string; verifiedAt: string }> = {};

  // Endpoint: Get Registered NIDs List (Admin Only)
  app.get('/api/nids/registered', requireAdminAuth, (req, res) => {
    res.json({ success: true, count: Object.keys(registeredNids).length, data: registeredNids });
  });

  // Dedicated Gemini AI Customer Support Chatbot Endpoint
  app.post('/api/gemini/chat', async (req, res) => {
    const { message, conversationHistory = [], language = 'bn', userContext } = req.body;

    if (!message) {
      return res.status(400).json({ success: false, message: 'Message is required' });
    }

    console.log(`[Gemini Support Chat] User query: "${message}"`);

    const supportSystemPrompt = `You are "ঝাদিমাধি এআই কাস্টমার সাপোর্ট ও শপিং অ্যাসিস্ট্যান্ট" (Jhadimadi AI Customer Support & Shopping Assistant), the official AI concierge of "Jhadimadi.com" (ঝাদিমাধি ডট কম).

Platform Identity & Mission:
- Jhadimadi.com is Bangladesh's #1 Hyperlocal Super-App and Hill-Tracts organic e-commerce marketplace (serving Rangamati, Khagrachhari, Bandarban, and all 64 districts).
- Slogan: "INTEGRITY IS OUR CAPITAL" (সততাই আমাদের মূলধন).

CONVERSATIONAL LOGIC & RULES:
1. GREETINGS & CASUAL TALK:
   - If the user says casual greetings like "হ্যালো", "হাই", "কেমন আছেন", "hi", "hello", "শুভ সকাল", reply warmly, politely, and naturally as Jhadimadi AI (e.g. "হ্যালো! আমি ঝাদিমাধি এআই। আমি ভালো আছি, ধন্যবাদ! আপনি কেমন আছেন? ঝাদিমাধির যেকোনো পণ্য, দাম বা সেবা সম্পর্কে আপনার যা জানার আছে নির্দ্বিধায় বলুন—আমি সাহায্য করতে প্রস্তুত।").
   - DO NOT recommend or attach any product cards for general greetings or casual conversation. Keep "recommendedProducts" empty [].

2. PRODUCTS & EXACT PRICES (STRICT DATA):
   - হলুদের গুঁড়া (Turmeric): "পাহাড়ি জুমের খাঁটি হলুদের গুঁড়া (৫০০ গ্রাম)" - মূল্য ৳১৮০ (পূর্বমূল্য ৳২২০)। রাঙামাটি বরকলের জুমের খাঁটি হলুদ, উচ্চ কারকিউমিন সমৃদ্ধ ও কেমিক্যালমুক্ত।
   - মরিচের গুঁড়া (Chili): "পাহাড়ি বোম্বাই ঝাল মরিচের গুঁড়া (২৫০ গ্রাম)" - মূল্য ৳১৬০ (পূর্বমূল্য ৳১৯৫)। বান্দরবান রোয়াংছড়ির জুমের রোদে শুকানো তীব্র ঝাঁঝালো আসল পাহাড়ি মরিচ।
   - ফ্রেশ আদা (Ginger): "সুগন্ধি পাহাড়ি ফ্রেশ কাঁচা আদা (১ কেজি)" - মূল্য ৳১৪০। খাগড়াছড়ির জুমের ফ্রেশ রসালো আদা।
   - পাহাড়ি মধু (Raw Honey): "বান্দরবানের পাহাড়ি চাকের খাঁটি কাঁচা মধু (১ কেজি)" - মূল্য ৳৯৫০ - ৳১২০০। গভীর অরণ্যের চাকের ১০০% কাঁচা মধু।
   - চালের গুঁড়া (Rice Flour): "খাঁটি পাহাড়ি চালের গুঁড়া (১ কেজি)" - মূল্য ৳১২০। ঢেঁকি ছাঁটা আতপ ও বিনি চালের গুঁড়া।
   - বিনি চাল (Bini Rice): "পাহাড়ি জুমের লাল ও কালো বিনি চাল (২ কেজি)" - মূল্য ৳২৪০। পাহাড়ি আঠালো জুমি চাল।
   - শুঁটকি (Dried Fish): "রাঙ্গামাটি স্পেশাল বোম্বাই ও কাচকি শুঁটকি (২৫০ গ্রাম)" - মূল্য ৳৩৫০; প্রিমিয়াম ছুরি শুঁটকি - ৳৪৫০।
   - সিদল (Sidol): "পাহাড়ি খাঁটি অর্গানিক সিদল পেস্ট ও চাপড়ি (৫০০ গ্রাম)" - মূল্য ৳৪৫০।
   - বাঁশ কোড়ল (Bamboo Shoots): "সিজনাল পাহাড়ি ফ্রেশ মিষ্টি বাঁশ কোড়ল (১ কেজি)" - মূল্য ৳১৮০।
   - তাঁতের পোশাক (Handloom): "পাহাড়ি খাঁটি হস্তচালিত তাঁতের পিনন-হাদি ও থামি সেট" - মূল্য ৳১৮৫০।
   - When user asks for a product or price, provide the exact details and include that product in "recommendedProducts".

3. LOCAL SERVICES & VERIFIED FREELANCERS:
   - ইলেকট্রিশিয়ান (Electrician): ৳৪০০ - ৳৮০০ / কাজ।
   - প্লাম্বার (Plumber): ৳৩৫০ - ৳৭০০ / কাজ।
   - রাজমিস্ত্রি (Mason): ৳৮০০ - ৳১২০০ / দিন।
   - সাজেক ভ্যালি চান্দের গাড়ি (4x4 Jeep Reserve): ৳৭,৫০০ - ৳১০,৫০০।
   - হোম টিউটর (Home Tutor): ৳৩,০০০ - ৳৬,০০০ / মাস।

4. DELIVERY & PAYMENT:
   - ডেলিভারি: লোকাল পাহাড়ি এলাকায় ২-৪ ঘণ্টা (চার্জ ৳৪০), জেলা সদরে হোম ডেলিভারি (চার্জ ৳৬০), সারাদেশে ২৪-৪৮ ঘণ্টায় কুরিয়ারে ক্যাশ অন ডেলিভারি (চার্জ ৳১০০-১২০)।
   - পেমেন্ট: ক্যাশ অন ডেলিভারি (COD), বিকাশ (bKash), নগদ (Nagad), রকেট ও ব্যাংক।

User Query: "${message}"
User Context: ${JSON.stringify(userContext || {})}
Recent History: ${JSON.stringify(conversationHistory.slice(-4))}

Return strict JSON:
{
  "replyBn": "Polite, helpful, and formatted Bengali markdown response with emojis and bullet points",
  "replyEn": "English version of the reply",
  "recommendedProducts": [
    {
      "id": "prod_turmeric_powder",
      "name": "পাহাড়ি জুমের খাঁটি হলুদের গুঁড়া (৫০০ গ্রাম)",
      "price": "৳ ১৮০",
      "category": "SpicesGrains",
      "image": "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80"
    }
  ],
  "quickReplyChips": ["হলুদের দাম", "মরিচের দাম", "পাহাড়ি মধু", "ডেলিভারি চার্জ", "মিস্ত্রি সেবা"]
}`;

    try {
      const ai = getGeminiClient();
      if (ai) {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: supportSystemPrompt,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                replyBn: { type: Type.STRING },
                replyEn: { type: Type.STRING },
                recommendedProducts: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      name: { type: Type.STRING },
                      price: { type: Type.STRING },
                      category: { type: Type.STRING },
                      image: { type: Type.STRING },
                    },
                    required: ['name', 'price'],
                  },
                },
                quickReplyChips: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
              },
              required: ['replyBn'],
            },
          },
        });

        if (response && response.text) {
          const parsed = JSON.parse(response.text);
          return res.json({
            success: true,
            source: 'gemini-3.8-flash',
            ...parsed,
          });
        }
      }
    } catch (err) {
      console.warn('[Gemini Support Chat Error]:', (err as Error).message);
    }

    // Contextual Fallback response generator for support chat based on Jhadimadi data
    const qLower = message.toLowerCase();
    let replyBn = '';
    let recommendedProducts: any[] = [];
    let quickReplyChips: string[] = ['হলুদের দাম', 'মরিচের দাম', 'খাঁটি মধু', 'ডেলিভারি নিয়ম', 'মিস্ত্রি সেবা'];

    // 1. General Greetings & Casual questions
    if (/^(হ্যালো|হাই|সালাম|আসসালামু|নমস্কার|কেমন আছেন|hello|hi|hey|kemon achen)/i.test(qLower) || 
        qLower === 'হ্যালো' || qLower === 'হাই' || qLower === 'কেমন আছেন' || qLower === 'ভালো আছেন') {
      replyBn = `👋 **হ্যালো! আমি ঝাদিমাধি এআই।**\n\nআমি ভালো আছি, ধন্যবাদ! আপনি কেমন আছেন? ঝাদিমাধির পাহাড়ি খাঁটি পণ্য (যেমন: হলুদ, মরিচ, মধু, শুটকি), পণ্যের দাম, ডেলিভারি বা লোকাল কোনো সেবা সম্পর্কে কী জানতে চান বলুন?`;
      recommendedProducts = []; // STRICT: No product cards on greetings
    }
    // 2. Turmeric (হলুদ)
    else if (qLower.includes('হলুদ') || qLower.includes('turmeric') || qLower.includes('holud')) {
      replyBn = `🌿 **পাহাড়ি জুমের খাঁটি হলুদের গুঁড়া (৫০০ গ্রাম):**\n\n• **দাম:** মাত্র **৳১৮০** (পূর্বমূল্য ৳২২০)\n• **উৎস:** রাঙামাটি বরকলের পাহাড়ি জুম\n• **বৈশিষ্ট্য:** উচ্চ কারকিউমিন সমৃদ্ধ, গাঢ় প্রাকৃতিক সোনালী রঙ ও কাঁচা হলুদের তীব্র সুবাস। কোনো কৃত্রিম প্রিজারভেটিভ বা রঙ নেই।\n• **স্টক:** বর্তমানে স্টকে উপলব্ধ রয়েছে।`;
      recommendedProducts = [
        {
          id: 'prod_turmeric_powder',
          name: 'পাহাড়ি জুমের খাঁটি হলুদের গুঁড়া (৫০০ গ্রাম)',
          price: '৳ ১৮০',
          category: 'SpicesGrains',
          image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80'
        }
      ];
    }
    // 3. Chili (মরিচ)
    else if (qLower.includes('মরিচ') || qLower.includes('chili') || qLower.includes('chilli') || qLower.includes('morich')) {
      replyBn = `🌶️ **পাহাড়ি বোম্বাই ঝাল মরিচের গুঁড়া (২৫০ গ্রাম):**\n\n• **দাম:** মাত্র **৳১৬০** (পূর্বমূল্য ৳১৯৫)\n• **উৎস:** বান্দরবান রোয়াংছড়ি\n• **বৈশিষ্ট্য:** পাহাড়ি জুমের রোদে শুকানো আসল নাগা ও বোম্বাই মরিচের খাঁটি গুঁড়া। তীব্র ঝাঁঝালো ও প্রাকৃতিক লাল রঙ।\n• **স্টক:** বর্তমানে স্টকে উপলব্ধ রয়েছে।`;
      recommendedProducts = [
        {
          id: 'prod_chili_powder',
          name: 'পাহাড়ি বোম্বাই ঝাল মরিচের গুঁড়া (২৫০ গ্রাম)',
          price: '৳ ১৬০',
          category: 'SpicesGrains',
          image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80'
        }
      ];
    }
    // 4. Honey (মধু)
    else if (qLower.includes('মধু') || qLower.includes('honey') || qLower.includes('modhu')) {
      replyBn = `🍯 **বান্দরবানের পাহাড়ি চাকের খাঁটি কাঁচা মধু (১ কেজি):**\n\n• **দাম:** **৳৯৫০** (১ কেজি গ্লাস জার)\n• **উৎস:** বান্দরবান রুমা ও থানচির গভীর অরণ্য\n• **বৈশিষ্ট্য:** ১০০% চাকের কাঁচা মধু, কোনো চিনি বা কেমিক্যাল নেই, প্রাকৃতিক অ্যান্টিঅক্সিডেন্ট সমৃদ্ধ।`;
      recommendedProducts = [
        {
          id: 'prod_wild_honey',
          name: 'বান্দরবানের পাহাড়ি চাকের খাঁটি কাঁচা মধু (১ কেজি)',
          price: '৳ ৯৫০',
          category: 'CraftsHoney',
          image: 'https://images.unsplash.com/photo-1587049352847-4a222e784d38?auto=format&fit=crop&w=600&q=80'
        }
      ];
    }
    // 5. Ginger (আদা)
    else if (qLower.includes('আদা') || qLower.includes('ginger') || qLower.includes('ada')) {
      replyBn = `🧄 **সুগন্ধি পাহাড়ি ফ্রেশ কাঁচা আদা (১ কেজি):**\n\n• **দাম:** **৳১৪০**\n• **উৎস:** খাগড়াছড়ি পানছড়ির জুম জমি\n• **বৈশিষ্ট্য:** সরাসরি পাহাড়ি মাটি থেকে সংগ্রহ করা রসালো ও তীব্র সুবাসযুক্ত খাঁটি আদা।`;
      recommendedProducts = [
        {
          id: 'prod_hill_ginger',
          name: 'সুগন্ধি পাহাড়ি ফ্রেশ কাঁচা আদা (১ কেজি)',
          price: '৳ ১৪০',
          category: 'SpicesGrains',
          image: 'https://images.unsplash.com/photo-1615485500704-8e990f9900f7?auto=format&fit=crop&w=600&q=80'
        }
      ];
    }
    // 6. Rice & Flour (চাল ও চালের গুঁড়া)
    else if (qLower.includes('চাল') || qLower.includes('rice') || qLower.includes('গুঁড়া') || qLower.includes('বিনি')) {
      replyBn = `🌾 **পাহাড়ি চাল ও চালের গুঁড়ার তথ্য:**\n\n• **খাঁটি পাহাড়ি চালের গুঁড়া (১ কেজি):** ৳১২০\n• **পাহাড়ি জুমের লাল ও কালো বিনি চাল (২ কেজি):** ৳২৪০\n• **বৈশিষ্ট্য:** পিঠা ও পাহাড়ি পায়েসের জন্য ঢেঁকিতে ভাঙানো শতভাগ খাঁটি ও ফ্রেশ।`;
      recommendedProducts = [
        {
          id: 'prod_rice_flour',
          name: 'খাঁটি পাহাড়ি চালের গুঁড়া (১ কেজি)',
          price: '৳ ১২০',
          category: 'SpicesGrains',
          image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80'
        }
      ];
    }
    // 7. Bamboo Shoot (বাঁশ কোড়ল)
    else if (qLower.includes('বাঁশ') || qLower.includes('কোড়ল') || qLower.includes('bamboo')) {
      replyBn = `🎋 **সিজনাল পাহাড়ি ফ্রেশ মিষ্টি বাঁশ কোড়ল (১ কেজি):**\n\n• **দাম:** **৳১৮০**\n• **উৎস:** খাগড়াছড়ি দীঘিনালা\n• **বৈশিষ্ট্য:** সম্পূর্ণ অর্গানিক কচি বাঁশ কোড়ল, হাই ফাইবার ও পাহাড়ি সুস্বাদু রান্নার সেরা উপাদান।`;
      recommendedProducts = [
        {
          id: 'prod_bamboo_shoot',
          name: 'সিজনাল পাহাড়ি ফ্রেশ মিষ্টি বাঁশ কোড়ল (১ কেজি)',
          price: '৳ ১৮০',
          category: 'SpicesGrains',
          image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80'
        }
      ];
    }
    // 8. Shutki & Sidol (শুটকি ও সিদল)
    else if (qLower.includes('শুটকি') || qLower.includes('শুঁটকি') || qLower.includes('সিদল') || qLower.includes('মাছ')) {
      replyBn = `🐟 **পাহাড়ি স্পেশাল কেমিক্যালমুক্ত শুঁটকি ও সিদল:**\n\n• **বোম্বাই ও কাচকি শুঁটকি (২৫০ গ্রাম):** ৳৩৫০\n• **পাহাড়ি প্রাকৃতিক খাঁটি সিদল পেস্ট (৫০০ গ্রাম):** ৳৪৫০\n• **প্রিমিয়াম ছুরি শুঁটকি (২০০ গ্রাম):** ৳৪৫০\n• **প্যাকেজিং:** এয়ার-টাইট জার প্যাকেজিংয়ে নিরাপদে পাঠানো হয়।`;
      recommendedProducts = [
        {
          id: 'prod_shutki_sp',
          name: 'রাঙ্গামাটি স্পেশাল বোম্বাই শুটকি (২৫০ গ্রাম)',
          price: '৳ ৩৫০',
          category: 'ShutkiSidol',
          image: 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=300'
        }
      ];
    }
    // 9. Traditional Clothing (তাঁতের পোশাক / থামি / পিনন)
    else if (qLower.includes('পোশাক') || qLower.includes('ড্রেস') || qLower.includes('তাঁত') || qLower.includes('পিনন') || qLower.includes('থামি')) {
      replyBn = `👗 **পাহাড়ি ঐতিহ্যবাহী তাঁত ও পোশাক:**\n\n• **হস্তচালিত তাঁতের পিনন-হাদি ও থামি সেট:** ৳১,৮৫০\n• **চাকমা ও ত্রিপুরা কটন ওড়না ও শীতের শাল:** ৳৮৫০\n• **বৈশিষ্ট্য:** ১০০% খাঁটি কটন সুতায় বোনা, অত্যন্ত আরামদায়ক ও এথনিক ডিজাইন।`;
      recommendedProducts = [
        {
          id: 'prod_pinon_hadi',
          name: 'পাহাড়ি খাঁটি হস্তচালিত তাঁতের পিনন-হাদি ও থামি সেট',
          price: '৳ ১৮৫০',
          category: 'Clothing',
          image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=300'
        }
      ];
    }
    // 10. Local Worker & Services (মিস্ত্রি, সার্ভিস, ড্রাইভার)
    else if (qLower.includes('মিস্ত্রি') || qLower.includes('সার্ভিস') || qLower.includes('ইলেকট্রিশিয়ান') || qLower.includes('প্লাম্বার') || qLower.includes('worker') || qLower.includes('সাজেক') || qLower.includes('গাড়ি')) {
      replyBn = `🛠️ **ঝাদিমাধি ভেরিফায়েড লোকাল সার্ভিস ও রেট:**\n\n• **ইলেকট্রিশিয়ান:** ৳৪০০ - ৳৮০০ / কাজ\n• **প্লাম্বার:** ৳৩৫০ - ৳৭০০ / কাজ\n• **রাজমিস্ত্রি:** ৳৮০০ - ৳১২০০ / দিন\n• **সাজেক ভ্যালি চান্দের গাড়ি (৪x৪ জীপ) রিজার্ভ:** ৳৮,৫০০\n• **হোম টিউটর:** ৳৩০০০ - ৳৬০০০ / মাস\n• **বুকিং:** আপনি সরাসরি চ্যাট বা হটলাইনে (01800000000) কল দিয়ে বুক করতে পারেন।`;
      recommendedProducts = [];
    }
    // 11. Delivery & Payment (ডেলিভারি ও পেমেন্ট)
    else if (qLower.includes('ডেলিভারি') || qLower.includes('পেমেন্ট') || qLower.includes('টাকা') || qLower.includes('বিকাশ') || qLower.includes('চার্জ')) {
      replyBn = `🚚 **ডেলিভারি সময় ও পেমেন্ট নিয়ম:**\n\n• **পাহাড়ি স্থানীয় এলাকা:** ২-৪ ঘণ্টার মধ্যে সুপারফাস্ট ডেলিভারি (চার্জ মাত্র ৳৪০)।\n• **জেলা সদরে:** হোম ডেলিভারি (চার্জ ৳৬০)।\n• **সারাদেশে (৬৪ জেলায়):** ২৪-৪৮ ঘণ্টার মধ্যে কুরিয়ারে ক্যাশ অন ডেলিভারি (চার্জ ৳১০০-১২০)।\n• **পেমেন্ট পদ্ধতি:** বিকাশ, নগদ, রকেট এবং ক্যাশ অন ডেলিভারি (COD)।`;
      recommendedProducts = [];
    }
    // 12. Default overview
    else {
      replyBn = `✨ **ঝাদিমাধি এআই সহায়তা:**\n\nআপনার প্রশ্নের জন্য ধন্যবাদ! ঝাদিমাধি ডট কম-এ আপনি পাহাড়ের ১০০% খাঁটি অর্গানিক পণ্য (হলুদ, মরিচ, মধু, আদা, শুটকি) এবং বিশ্বস্ত লোকাল সার্ভিস (মিস্ত্রি, ড্রাইভার, টিউটর) পাবেন।\n\nনির্দিষ্ট পণ্যের দাম জানতে পণ্যের নাম লিখে মেসেজ করুন (যেমন: "হলুদের দাম কত?" বা "মরিচের দাম কত?")।`;
      recommendedProducts = [];
    }

    return res.json({
      success: true,
      source: 'domain-contextual',
      replyBn,
      replyEn: 'Here is your assistance from Jhadimadi support.',
      recommendedProducts,
      quickReplyChips
    });
  });

  // Dedicated Gemini Vision API NID Verification Endpoint
  app.post('/api/nid-verify-gemini', async (req, res) => {
    try {
      const { imageBase64, backImageBase64, phone, userName, selfieBase64 } = req.body;

      if (!imageBase64) {
        return res.status(400).json({
          success: false,
          message: 'এনআইডি কার্ডের ছবি প্রদান করুন।',
        });
      }

      console.log(`[Gemini Vision NID] Processing NID verification request for phone: ${phone || 'Unknown'}, user: ${userName || 'Anonymous'}`);

      // Clean base64 string and extract MIME type
      let mimeType = 'image/jpeg';
      let cleanData = imageBase64;

      if (imageBase64.includes(';base64,')) {
        const parts = imageBase64.split(';base64,');
        const mimeMatch = parts[0].match(/data:(.*?);/);
        if (mimeMatch) mimeType = mimeMatch[1];
        cleanData = parts[1];
      }

      const nidVisionPrompt = `You are the official National ID (NID) Card Verification, OCR & Forensic Anti-Fraud Analysis Engine for Bangladesh (Government of the People's Republic of Bangladesh / গণপ্রজাতন্ত্রী বাংলাদেশ সরকার).
Inspect the provided Bangladesh National ID Card image thoroughly (Smart NID Card or Traditional Laminated NID).

Extract all card data accurately:
1. "nidNumber": The NID number string (10 digits for Smart NID Card, 13 digits or 17 digits for Old NID). Strip any extra whitespace.
2. "nameBangla": Cardholder's full name in Bengali (নাম).
3. "nameEnglish": Cardholder's full name in English (Name).
4. "fatherName": Father's Name in Bengali (পিতা).
5. "motherName": Mother's Name in Bengali (মাতা).
6. "dateOfBirth": Date of Birth string (জন্ম তারিখ e.g., "15 Jan 1992" or "15/01/1992").
7. "bloodGroup": Blood group if printed on card (e.g., "B+", "A+", "O+", "AB+").
8. "address": Address if visible.
9. "nidType": "Smart NID Card" | "Old Laminated NID" | "Unknown / Non-NID".

Forensic & Fake/Tampering Detection:
10. "authenticityScore": Confidence score from 0 to 100 on the legitimacy and non-edited status of the document.
11. "isFakeDetected": Boolean. Set to true if there is any evidence of:
    - Font mismatch, unnatural character thickness, digital text superimposition or Photoshop clone stamping.
    - Missing or corrupted Bangladesh National Emblem (স্মৃতিসৌধ / শাপলা প্রতীক), hologram patterns, or microtext.
    - Invalid digit count (must be 10, 13, or 17 digits).
    - Image is a cartoon, unrelated photo, or completely illegible placeholder.
12. "tamperWarnings": Array of detected issues or discrepancies in Bengali (e.g. ["ফন্ট সাইজ ও সারিবদ্ধতায় অসামঞ্জস্য", "সরকারি লোগো ওয়াটারমার্ক অনুপস্থিত", "ডিজিটাল এডিটিং এর চিহ্ন"]) or empty array if genuine.
13. "verificationSummaryBn": Professional Bengali summary explaining whether the NID passed forensic verification.

Return strict JSON matching the schema.`;

      let visionResult: any = null;
      const ai = getGeminiClient();

      if (ai) {
        try {
          const contents: any[] = [
            {
              inlineData: {
                mimeType: mimeType,
                data: cleanData,
              },
            },
            {
              text: nidVisionPrompt,
            },
          ];

          // If back image is also provided, add it as a secondary vision part
          if (backImageBase64) {
            let backMime = 'image/jpeg';
            let cleanBack = backImageBase64;
            if (backImageBase64.includes(';base64,')) {
              const backParts = backImageBase64.split(';base64,');
              const backMimeMatch = backParts[0].match(/data:(.*?);/);
              if (backMimeMatch) backMime = backMimeMatch[1];
              cleanBack = backParts[1];
            }
            contents.push({
              inlineData: {
                mimeType: backMime,
                data: cleanBack,
              },
            });
          }

          const response = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: contents,
            config: {
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  nidNumber: { type: Type.STRING },
                  nameBangla: { type: Type.STRING },
                  nameEnglish: { type: Type.STRING },
                  fatherName: { type: Type.STRING },
                  motherName: { type: Type.STRING },
                  dateOfBirth: { type: Type.STRING },
                  bloodGroup: { type: Type.STRING },
                  address: { type: Type.STRING },
                  nidType: { type: Type.STRING },
                  authenticityScore: { type: Type.NUMBER },
                  isFakeDetected: { type: Type.BOOLEAN },
                  tamperWarnings: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  verificationSummaryBn: { type: Type.STRING },
                },
                required: [
                  'nidNumber',
                  'nameBangla',
                  'nameEnglish',
                  'dateOfBirth',
                  'nidType',
                  'authenticityScore',
                  'isFakeDetected',
                  'tamperWarnings',
                  'verificationSummaryBn',
                ],
              },
            },
          });

          if (response && response.text) {
            visionResult = JSON.parse(response.text);
            console.log('[Gemini Vision NID] OCR & Forensic Analysis Result:', visionResult.nidNumber, 'Authenticity:', visionResult.authenticityScore);
          }
        } catch (visionErr) {
          console.warn('[Gemini Vision NID] Vision call fallback:', (visionErr as Error).message);
        }
      }

      // Security Check: Never auto-approve unverified documents or hallucinate fake approvals
      if (!visionResult || !visionResult.nidNumber) {
        return res.status(422).json({
          success: false,
          isDuplicate: false,
          isFakeDetected: false,
          requiresManualReview: true,
          message: 'এনআইডি কার্ড থেকে তথ্য নির্ভুলভাবে রিড করা সম্ভব হয়নি। অনুগ্রহ করে পরিষ্কার, ভালো আলোর মধ্যে তোলা আসল NID কার্ডের ছবি আপলোড করুন অথবা অ্যাডমিন পর্যালোচনার জন্য জমা দিন।',
        });
      }

      const extractedNid = (visionResult.nidNumber || '').trim().replace(/\D/g, '');

      // 1. Duplicate Registration Prevention Check
      const existingRegistration = registeredNids[extractedNid];
      const isDuplicate = Boolean(
        existingRegistration && 
        phone && 
        existingRegistration.phone !== phone
      );

      if (isDuplicate) {
        console.warn(`[Gemini NID Anti-Fraud] Duplicate NID registration attempt blocked! NID: ${extractedNid}, Registered Phone: ${existingRegistration.phone}, Attempter: ${phone}`);
        return res.json({
          success: false,
          isDuplicate: true,
          isFakeDetected: true,
          authenticityScore: Math.min(visionResult.authenticityScore, 30),
          duplicateWarning: `⚠️ সতর্কবার্তা: এই NID নম্বরটি (${extractedNid}) ইতিমধ্যে অন্য একটি অ্যাকাউন্টে (${existingRegistration.phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')}) নিবন্ধিত রয়েছে। একই NID দিয়ে একাধিক অ্যাকাউন্ট তৈরি কঠোরভাবে নিষিদ্ধ।`,
          extractedData: visionResult,
          message: 'ডুপ্লিকেট NID শনাক্ত হয়েছে। রেজিস্ট্রেশন বাতিল করা হলো।',
        });
      }

      // 2. Fake / Tampered NID Check
      if (visionResult.isFakeDetected || visionResult.authenticityScore < 60) {
        return res.json({
          success: false,
          isDuplicate: false,
          isFakeDetected: true,
          authenticityScore: visionResult.authenticityScore,
          tamperWarnings: visionResult.tamperWarnings && visionResult.tamperWarnings.length > 0 
            ? visionResult.tamperWarnings 
            : ['ফন্ট বা লেআউটে ডিজিটাল এডিটিং এর সন্দেহজনক চিহ্ন রয়েছে', 'ওয়াটারমার্ক অস্পষ্ট বা অনুপস্থিত'],
          extractedData: visionResult,
          message: 'জাল বা এডিট করা এনআইডি কার্ডের সন্দেহ রয়েছে। অনুগ্রহ করে আপনার আসল NID কার্ডের পরিষ্কার ছবি আপলোড করুন।',
        });
      }

      // 3. Successful Verification -> Register in Database
      registeredNids[extractedNid] = {
        nidNumber: extractedNid,
        phone: phone || '01812345678',
        name: visionResult.nameBangla || visionResult.nameEnglish || userName || 'Verified Citizen',
        verifiedAt: new Date().toISOString(),
      };

      if (phone && liveUsers[phone]) {
        liveUsers[phone].isNidVerified = true;
        liveUsers[phone].nidNumber = extractedNid;
        liveUsers[phone].nidName = visionResult.nameBangla || visionResult.nameEnglish;
        liveUsers[phone].nidDob = visionResult.dateOfBirth;
      }

      return res.json({
        success: true,
        isDuplicate: false,
        isFakeDetected: false,
        authenticityScore: visionResult.authenticityScore || 98,
        extractedData: {
          ...visionResult,
          nidNumber: extractedNid,
        },
        verifiedBadge: 'VERIFIED_BANGLADESH_CITIZEN_V3',
        message: '🎉 অভিনন্দন! আপনার জাতীয় পরিচয়পত্র (NID) সফলভাবে যাচাই ও ভেরিফাই হয়েছে।',
      });
    } catch (error) {
      console.error('[Gemini Vision NID Error]:', (error as Error)?.message || 'Verification error');
      return res.status(500).json({
        success: false,
        message: 'সার্ভার প্রক্রিয়াকরণে সমস্যা হয়েছে। পুনরায় চেষ্টা করুন।',
      });
    }
  });

  // Global Secure Error Handling (Prevents leaking stack traces, database internals, server paths, or secrets)
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (res.headersSent) {
      return next(err);
    }
    console.error('[ServerError]', err?.name || 'Error', err?.message || 'Unknown error');
    const statusCode = typeof err?.status === 'number' ? err.status : typeof err?.statusCode === 'number' ? err.statusCode : 500;
    res.status(statusCode).json({
      success: false,
      message: statusCode >= 400 && statusCode < 500
        ? (err?.message || 'অনুরোধটি সম্পন্ন করা যায়নি।')
        : 'সার্ভারে একটি সাময়িক সমস্যা হয়েছে। অনুগ্রহ করে কিছুক্ষণ পর পুনরায় চেষ্টা করুন।'
    });
  });

  // Serve public static assets with priority
  app.use(express.static(path.join(process.cwd(), 'public')));

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Jhadimadi Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
