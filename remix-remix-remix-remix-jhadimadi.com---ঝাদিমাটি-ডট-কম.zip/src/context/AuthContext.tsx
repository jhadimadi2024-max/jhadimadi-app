import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { RegisteredProfessional } from '../components/ProfessionalRegistrationWizard';
import { offlineStorage, OFFLINE_KEYS } from '../utils/offlineStorage';
import { performSignOut } from '../services/authService';

export type UserRole = 'seller' | 'professional' | 'buyer';
export type AuthMode = 'signin' | 'signup';

interface AuthContextType {
  currentUser: UserProfile | null;
  userRole: UserRole | null;
  userProfessionalProfile: RegisteredProfessional | null;
  isAuthModalOpen: boolean;
  authNoticeMessage: string;
  authModalInitialMode: AuthMode;
  isRoleModalOpen: boolean;
  activeProfileTab: 'overview' | 'seller' | 'professional';
  setActiveProfileTab: (tab: 'overview' | 'seller' | 'professional') => void;
  openAuthModal: (notice?: string, initialMode?: AuthMode) => void;
  closeAuthModal: () => void;
  openRoleModal: () => void;
  closeRoleModal: () => void;
  login: (user: UserProfile, isNewSignUp?: boolean) => void;
  logout: () => void;
  updateUser: (user: UserProfile) => void;
  selectRole: (role: 'seller' | 'professional' | 'buyer') => void;
  saveProfessionalProfile: (pro: RegisteredProfessional) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial user state from offline cache
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    return offlineStorage.getItem<UserProfile | null>(OFFLINE_KEYS.USER, null);
  });

  const [userRole, setUserRole] = useState<UserRole | null>(() => {
    const saved = offlineStorage.getItem<string | null>('jhadimadi_user_role_v1', null);
    return (saved as UserRole) || null;
  });

  const [userProfessionalProfile, setUserProfessionalProfile] = useState<RegisteredProfessional | null>(() => {
    return offlineStorage.getItem<RegisteredProfessional | null>(OFFLINE_KEYS.PRO_PROFILE, null);
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authNoticeMessage, setAuthNoticeMessage] = useState('');
  const [authModalInitialMode, setAuthModalInitialMode] = useState<AuthMode>('signin');
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [activeProfileTab, setActiveProfileTab] = useState<'overview' | 'seller' | 'professional'>('overview');

  // Sync to local storage
  useEffect(() => {
    offlineStorage.saveItem(OFFLINE_KEYS.USER, currentUser);
  }, [currentUser]);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_user_role_v1', userRole);
  }, [userRole]);

  useEffect(() => {
    offlineStorage.saveItem(OFFLINE_KEYS.PRO_PROFILE, userProfessionalProfile);
  }, [userProfessionalProfile]);

  const openAuthModal = (notice?: string, initialMode: AuthMode = 'signin') => {
    setAuthNoticeMessage(notice || '');
    setAuthModalInitialMode(initialMode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
    setAuthNoticeMessage('');
    setAuthModalInitialMode('signin');
  };

  const openRoleModal = () => {
    setIsRoleModalOpen(true);
  };

  const closeRoleModal = () => {
    setIsRoleModalOpen(false);
  };

  const login = (user: UserProfile, isNewSignUp: boolean = false) => {
    setCurrentUser(user);
    setIsAuthModalOpen(false);
    if (user.role && (user.role === 'seller' || user.role === 'professional')) {
      setUserRole(user.role as UserRole);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setUserRole(null);
    setActiveProfileTab('overview');
    offlineStorage.saveItem(OFFLINE_KEYS.USER, null);
    offlineStorage.saveItem('jhadimadi_user_role_v1', null);
    performSignOut().catch(() => {});
  };

  const updateUser = (user: UserProfile) => {
    setCurrentUser(user);
  };

  const selectRole = (role: 'seller' | 'professional' | 'buyer') => {
    setUserRole(role);
    setIsRoleModalOpen(false);
    if (role === 'seller') {
      setActiveProfileTab('seller');
    } else if (role === 'professional') {
      setActiveProfileTab('professional');
    } else {
      setActiveProfileTab('overview');
    }
    if (currentUser) {
      const updated = { ...currentUser, role: role === 'buyer' ? 'customer' as const : role };
      setCurrentUser(updated);
    }
  };

  const saveProfessionalProfile = (pro: RegisteredProfessional) => {
    setUserProfessionalProfile(pro);
    setUserRole('professional');
    if (currentUser) {
      const updatedUser: UserProfile = {
        ...currentUser,
        name: pro.name || currentUser.name,
        phone: pro.phone || currentUser.phone,
        district: pro.district || currentUser.district,
        upazila: pro.upazila || currentUser.upazila,
        mahalla: pro.area || currentUser.mahalla,
        isNidVerified: pro.verified ?? currentUser.isNidVerified,
        isPaidMember: pro.verified ? true : currentUser.isPaidMember
      };
      setCurrentUser(updatedUser);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userRole,
        userProfessionalProfile,
        isAuthModalOpen,
        authNoticeMessage,
        authModalInitialMode,
        isRoleModalOpen,
        activeProfileTab,
        setActiveProfileTab,
        openAuthModal,
        closeAuthModal,
        openRoleModal,
        closeRoleModal,
        login,
        logout,
        updateUser,
        selectRole,
        saveProfessionalProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
