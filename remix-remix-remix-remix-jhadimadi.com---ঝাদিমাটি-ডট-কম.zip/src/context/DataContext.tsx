import React, { createContext, useContext, useState, useEffect } from 'react';
import { STORE_PRODUCTS, StoreProduct } from '../data/productsData';
import { RegisteredProfessional } from '../components/ProfessionalRegistrationWizard';
import { offlineStorage, OFFLINE_KEYS } from '../utils/offlineStorage';
import { databaseService } from '../services/databaseService';

export interface AdminUserRecord {
  id: string | number;
  name: string;
  role: 'professional' | 'seller' | 'buyer' | 'blood_donor';
  roleLabelBn: string;
  phone: string;
  email?: string;
  district: string;
  upazila: string;
  area?: string;
  bloodGroup?: string; // 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-'
  lastDonationDate?: string;
  totalDonations?: number;
  status: 'Approved' | 'Pending' | 'Rejected';
  createdAt: string;
  avatar?: string;
  nid?: string;
  tradeLicense?: string;
  notes?: string;
  professionalProfile?: RegisteredProfessional;
}

export interface AdminOrderItem {
  productId: string;
  nameBn: string;
  price: number;
  quantity: number;
  image?: string;
}

export interface AdminOrder {
  id: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  items: AdminOrderItem[];
  totalAmount: number;
  paymentMethod: 'COD' | 'bKash' | 'Nagad' | 'Upay';
  status: 'Pending' | 'Processing' | 'Delivered' | 'Cancelled';
  date: string;
  notes?: string;
}

// ================= 📢 ব্যানার ও বিজ্ঞাপন মডেল =================
export interface AdminBanner {
  id: string;
  title: string;
  subtitle: string;
  tag: string;
  imageUrl: string;
  targetLink: string;
  placement: 'homepage_hero' | 'directory_top' | 'vendor_spotlight' | 'popup_ad';
  isActive: boolean;
  order: number;
  createdAt: string;
}

// ================= 📢 হোমপেজ ও ঘোষণা মডেল =================
export interface AdminAnnouncement {
  id: string;
  title: string;
  content: string;
  tag: 'জরুরি বিজ্ঞপ্তি' | 'বিশেষ অফার' | 'নোটিশ' | 'আপডেট';
  isPublished: boolean;
  priority: 'high' | 'normal' | 'low';
  createdAt: string;
  expiresAt?: string;
}

export interface AdminHomepageContent {
  announcementTicker: {
    enabled: boolean;
    text: string;
    tag: string;
    speed: 'normal' | 'slow' | 'fast';
  };
  heroBanner: {
    title: string;
    subtitle: string;
    badge: string;
    primaryBtnText: string;
  };
  helpline: {
    phone: string;
    whatsapp: string;
    emergencyAmbulance: string;
    supportEmail: string;
  };
  operationalSettings: {
    maintenanceMode: boolean;
    registrationOpen: boolean;
    codEnabled: boolean;
    minOrderAmount: number;
    defaultDeliveryCharge: number;
    platformCommissionPercent: number;
  };
}

export interface AdminMediaItem {
  id: string;
  title: string;
  url: string;
  tag: 'product' | 'banner' | 'category' | 'avatar' | 'other';
  uploadedAt: string;
  sizeKb?: number;
}

// ================= 🩸 রক্তদাতা ডিরেক্টরি মডেল =================
export interface AdminBloodDonor {
  id: string;
  name: string;
  bloodGroup: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  phone: string;
  district: string;
  upazila: string;
  area: string;
  lastDonationDate: string;
  totalDonations: number;
  isAvailable: boolean;
  verified: boolean;
  emergencyContact?: string;
  age?: number;
}

// ================= 💬 কমপ্লেন ও রিভিউ মোডারেশন মডেল =================
export interface AdminComplaint {
  id: string;
  complainantName: string;
  complainantPhone: string;
  targetType: 'service' | 'product' | 'seller' | 'rider';
  targetName: string;
  category: 'দেরিতে ডেলিভারি' | 'পণ্যের মান সমস্যা' | 'অতিরিক্ত মূল্য দাবি' | 'খারাপ আচরণ' | 'অন্যান্য';
  subject: string;
  description: string;
  status: 'Pending' | 'Under Review' | 'Resolved' | 'Dismissed';
  rating?: number;
  reportedDate: string;
  resolvedDate?: string;
  resolutionNotes?: string;
}

// ================= 📍 এলাকা ও ক্যাটাগরি মডেল =================
export interface AdminLocation {
  id: string;
  districtBn: string;
  districtEn: string;
  upazilasBn: string[];
  isActive: boolean;
  totalPros?: number;
}

export interface AdminServiceCategory {
  id: string;
  nameBn: string;
  nameEn: string;
  iconName: string;
  totalProfessionals: number;
  isFeatured: boolean;
  commissionRate: number;
}

const INITIAL_PROFESSIONALS_DATA: RegisteredProfessional[] = [];

const INITIAL_ORDERS_DATA: AdminOrder[] = [];

export const INITIAL_USERS_DATA: AdminUserRecord[] = [
  {
    id: 'USR-101',
    name: 'মং মারমা',
    role: 'seller',
    roleLabelBn: 'খাঁটি জুম পণ্য বিক্রেতা',
    phone: '01812-345678',
    email: 'mong.marma@example.com',
    district: 'খাগড়াছড়ি',
    upazila: 'খাগড়াছড়ি সদর',
    area: 'পৌরসভা বাজার',
    status: 'Approved',
    createdAt: '২০২৬-০৭-১০',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    tradeLicense: 'TRD-KHG-2026-894',
    nid: '1992491283000012',
    notes: 'অর্গানিক জুম চাল, হলুদ ও বিন্নি চাল সরবরাহকারী।'
  },
  {
    id: 'USR-102',
    name: 'সুপ্রিয় চাকমা',
    role: 'professional',
    roleLabelBn: 'ইলেকট্রিশিয়ান ও সোলার টেকনিশিয়ান',
    phone: '01823-456789',
    email: 'supriyo.chakma@example.com',
    district: 'রাঙ্গামাটি',
    upazila: 'রাঙ্গামাটি সদর',
    area: 'তবলছড়ি',
    status: 'Approved',
    createdAt: '২০২৬-০৭-১৫',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    nid: '1989491283000045',
    notes: 'পাহাড়ি সোলার প্যানেল ওয়্যারিং ও ইনভার্টার সার্ভিস এক্সপার্ট।'
  },
  {
    id: 'USR-103',
    name: 'বিভাস ত্রিপুরা',
    role: 'seller',
    roleLabelBn: 'পাহাড়ি ফল ও কাজুবাদাম উদ্যোক্তা',
    phone: '01834-567890',
    email: 'bibhas.tripura@example.com',
    district: 'বান্দরবান',
    upazila: 'রোয়াংছড়ি',
    area: 'রোয়াংছড়ি বাজার',
    status: 'Approved',
    createdAt: '২০২৬-০৭-১৮',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    tradeLicense: 'TRD-BDB-2026-312',
    nid: '1995491283000078',
    notes: 'সরাসরি নিজস্ব বাগান থেকে সংগৃহীত আনারস, ড্রাগন ফল ও কাঁচা কাজুবাদাম।'
  },
  {
    id: 'USR-104',
    name: 'তানিয়া চাকমা',
    role: 'seller',
    roleLabelBn: 'আদিবাসী ঐতিহ্যবাহী তাঁতশিল্পী',
    phone: '01845-678901',
    email: 'tania.chakma@example.com',
    district: 'রাঙ্গামাটি',
    upazila: 'নানিয়ারচর',
    area: 'বুড়িঘাট',
    status: 'Approved',
    createdAt: '২০২৬-০৭-২২',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    tradeLicense: 'TRD-RNG-2026-104',
    nid: '1998491283000099',
    notes: 'চাকমা পিনন-হাদি, খাদি ও ঐতিহ্যবাহী শাল প্রস্তুতকারক।'
  },
  {
    id: 'USR-105',
    name: 'আরিফুল ইসলাম',
    role: 'professional',
    roleLabelBn: 'প্লাম্বার ও স্যানিটারি মিস্ত্রি',
    phone: '01856-789012',
    email: 'ariful.plumber@example.com',
    district: 'চট্টগ্রাম',
    upazila: 'হাটহাজারী',
    area: 'কলেজ গেট',
    status: 'Approved',
    createdAt: '২০২৬-০৭-২৫',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    nid: '1991491283000122',
    notes: 'বাসা-বাড়ি ও অফিস পাইপ ফিটিংস এবং ডিপ টিউবওয়েল মেরামত।'
  },
  {
    id: 'USR-106',
    name: 'কাজী শাহেদ হোসেন',
    role: 'buyer',
    roleLabelBn: 'রেগুলার কাস্টমার',
    phone: '01867-890123',
    email: 'shahed.buyer@example.com',
    district: 'ঢাকা',
    upazila: 'ধানমন্ডি',
    area: 'রোড ৭/এ',
    status: 'Approved',
    createdAt: '২০২৬-০৭-২৮',
    notes: 'পাহাড়ি অর্গানিক চাল ও শুঁটকির নিয়মিত গ্রাহক।'
  },
  {
    id: 'USR-107',
    name: 'ডা. প্রবীর তঞ্চঙ্গ্যা',
    role: 'blood_donor',
    roleLabelBn: 'জরুরি রক্তদাতা (O+)',
    phone: '01878-901234',
    email: 'dr.probir@example.com',
    district: 'রাঙ্গামাটি',
    upazila: 'কাপ্তাই',
    area: 'চন্দ্রঘোনা',
    bloodGroup: 'O+',
    totalDonations: 8,
    lastDonationDate: '২০২৬-০৬-১০',
    status: 'Approved',
    createdAt: '২০২৬-০৮-০১',
    notes: 'জরুরি প্রয়োজনে রাঙ্গামাটি ও চট্টগ্রামে রক্তদানে প্রস্তুত।'
  },
  {
    id: 'USR-108',
    name: 'রুপম বড়ুয়া',
    role: 'professional',
    roleLabelBn: 'রাজমিস্ত্রি ও টাইলস স্পেশালিস্ট',
    phone: '01889-012345',
    email: 'rupam.barua@example.com',
    district: 'খাগড়াছড়ি',
    upazila: 'দীঘিনালা',
    area: 'বোয়ালখালী',
    status: 'Approved',
    createdAt: '২০২৬-০৮-০৫',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    nid: '1993491283000155',
    notes: 'বিল্ডিং কনস্ট্রাকশন, রিটেইনিং ওয়াল ও টাইলস ফিটিং।'
  },
  {
    id: 'USR-109',
    name: 'ফারজানা আক্তার',
    role: 'buyer',
    roleLabelBn: 'অনলাইন ক্রেতা',
    phone: '01890-123456',
    email: 'farzana.akhtar@example.com',
    district: 'চট্টগ্রাম',
    upazila: 'সীতাকুণ্ড',
    area: 'পৌরসভা',
    status: 'Approved',
    createdAt: '২০২৬-০৮-০৭',
    notes: 'পাহাড়ি ভেষজ ও রান্নার মসলা ক্রেতা।'
  },
  {
    id: 'USR-110',
    name: 'চিংশৈপ্রু মারমা',
    role: 'seller',
    roleLabelBn: 'পাহাড়ি শুঁটকি ও নাপ্পি সরবরাহকারী',
    phone: '01811-223344',
    email: 'chingshai@example.com',
    district: 'বান্দরবান',
    upazila: 'বান্দরবান সদর',
    area: 'বালাঘাটা',
    status: 'Pending',
    createdAt: '২০২৬-০৮-১০',
    tradeLicense: 'TRD-BDB-2026-908',
    nid: '1997491283000188',
    notes: 'নতুন আবেদন: ভেরিফিকেশন ও এনআইডি পর্যালোচনা প্রয়োজন।'
  },
  {
    id: 'USR-111',
    name: 'সোহেল রানা',
    role: 'professional',
    roleLabelBn: 'মোটরসাইকেল ও জীপ মেকানিক',
    phone: '01822-334455',
    district: 'খাগড়াছড়ি',
    upazila: 'মাটিরাঙ্গা',
    area: 'নতুন বাজার',
    status: 'Pending',
    createdAt: '২০২৬-০৮-১২',
    nid: '1994491283000211',
    notes: 'চান্দের গাড়ি ও পাহাড়ি রোডের জীপ মেরামত টেকনিশিয়ান।'
  },
  {
    id: 'USR-112',
    name: 'ঝর্ণা ত্রিপুরা',
    role: 'blood_donor',
    roleLabelBn: 'জরুরি রক্তদাতা (B+)',
    phone: '01833-445566',
    district: 'খাগড়াছড়ি',
    upazila: 'পানছড়ি',
    area: 'লোগাং',
    bloodGroup: 'B+',
    totalDonations: 4,
    lastDonationDate: '২০২৬-০৫-১৫',
    status: 'Approved',
    createdAt: '২০২৬-০৮-১৫',
    notes: 'পানছড়ি ও খাগড়াছড়ি সদরে স্বেচ্ছায় রক্তদাতা।'
  },
  {
    id: 'USR-113',
    name: 'ক্যালেন্ডার খিসা',
    role: 'seller',
    roleLabelBn: 'পাহাড়ি জুম চাল ও আদা-হলুদ বিক্রেতা',
    phone: '01844-556677',
    district: 'রাঙ্গামাটি',
    upazila: 'বাঘাইছড়ি',
    area: 'মারিশ্যা বাজার',
    status: 'Approved',
    createdAt: '২০২৬-০৮-১৮',
    tradeLicense: 'TRD-RNG-2026-612',
    notes: 'সাজেক ও বাঘাইছড়ির শতভাগ প্রাকৃতিক জুম পণ্য বিক্রেতা।'
  },
  {
    id: 'USR-114',
    name: 'মাহবুব আলম',
    role: 'buyer',
    roleLabelBn: 'গ্রাহক',
    phone: '01855-667788',
    district: 'ঢাকা',
    upazila: 'মিরপুর',
    area: 'সেকশন ১০',
    status: 'Approved',
    createdAt: '২০২৬-০৮-২০',
    notes: 'হস্তশিল্প ও ঐতিহ্যবাহী পিনন-হাদি অর্ডারকারী।'
  },
  {
    id: 'USR-115',
    name: 'অংপ্রু মারমা',
    role: 'professional',
    roleLabelBn: 'কাঠমিস্ত্রি ও ফার্নিচার কারিগর',
    phone: '01866-778899',
    district: 'বান্দরবান',
    upazila: 'রুমা',
    area: 'রুমা বাজার',
    status: 'Approved',
    createdAt: '২০২৬-০৮-২২',
    notes: 'পাহাড়ি সেগুন ও গামারি কাঠের আসবাবপত্র প্রস্তুতকারক।'
  },
  {
    id: 'USR-116',
    name: 'নিলয় দেওয়ান',
    role: 'blood_donor',
    roleLabelBn: 'জরুরি রক্তদাতা (AB+)',
    phone: '01877-889900',
    district: 'রাঙ্গামাটি',
    upazila: 'বরকল',
    area: 'উপজেলা গেট',
    bloodGroup: 'AB+',
    totalDonations: 6,
    lastDonationDate: '২০২৬-০৭-০১',
    status: 'Approved',
    createdAt: '২০২৬-০৮-২৫',
    notes: 'জরুরি রক্তের গ্রুপের জন্য কল রিসিভ করেন।'
  }
];

// ================= 📣 টেক্সট ও নোটিশ ডিফল্ট ডাটা =================
export const INITIAL_ANNOUNCEMENTS_DATA: AdminAnnouncement[] = [
  {
    id: 'ANN-101',
    title: 'পাহাড়ি অর্গানিক জুম ফসল ও আম-আনারসের বিশেষ কালেকশন লাইভ',
    content: 'সম্মানিত গ্রাহকবৃন্দ, পাহাড়ের নিজস্ব বাগান থেকে সংগৃহীত রাসায়নিকমুক্ত ফলমূল সরাসরি খাগড়াছড়ি ও রাঙ্গামাটি থেকে সারা দেশে হোম ডেলিভারি শুরু হয়েছে।',
    tag: 'বিশেষ অফার',
    isPublished: true,
    priority: 'high',
    createdAt: '২০২৬-০৮-০১'
  },
  {
    id: 'ANN-102',
    title: 'পার্বত্য টেকনিশিয়ান ও সার্ভিস প্রোভাইডারদের জন্য নতুন নির্দেশিকা',
    content: 'সকল ইলেকট্রিশিয়ান, প্লাম্বার ও মেকানিকদের NID ভেরিফিকেশন ও নিরাপত্তা যাচাই সম্পন্ন করার অনুরোধ করা হচ্ছে। গ্রাহকদের নিরাপদ সেবা নিশ্চিত করাই আমাদের অগ্রাধিকার।',
    tag: 'জরুরি বিজ্ঞপ্তি',
    isPublished: true,
    priority: 'high',
    createdAt: '২০২৬-০৮-১০'
  },
  {
    id: 'ANN-103',
    title: '২৪/৭ জরুরি রক্তদাতা ও অ্যাম্বুলেন্স সার্ভিস ডিরেক্টরি উন্মুক্ত',
    content: 'পার্বত্য ৩ জেলা ও চট্টগ্রামের যেকোনো জরুরি রক্তের প্রয়োজনে নিকটস্থ রক্তদাতার সাথে সরাসরি যোগাযোগ করতে পারবেন কোনো ফি ছাড়াই।',
    tag: 'নোটিশ',
    isPublished: true,
    priority: 'normal',
    createdAt: '২০২৬-০৮-১৫'
  }
];

// ================= 📢 হোমপেজ কনটেন্ট ডিফল্ট ডাটা =================
export const INITIAL_HOMEPAGE_CONTENT: AdminHomepageContent = {
  announcementTicker: {
    enabled: true,
    text: '🎉 পার্বত্য জুম ফসল ও অর্গানিক ফ্রুটসের স্পেশাল কালেকশন লাইভ! হোম ডেলিভারিতে ১০০% মানসম্মত ও সতেজ পণ্য।',
    tag: 'জরুরি বিজ্ঞপ্তি',
    speed: 'normal'
  },
  heroBanner: {
    title: 'পাহাড়ের সেরা অর্গানিক পণ্য ও দক্ষ কারিগর এক ছাদের নিচে',
    subtitle: 'রাঙ্গামাটি, খাগড়াছড়ি ও বান্দরবানের শতভাগ খাঁটি জুম ফসল, হস্তশিল্প ও বিশ্বস্ত টেকনিশিয়ানদের ডিজিটাল প্ল্যাটফর্ম।',
    badge: 'পার্বত্য ডিজিটাল হাব ২০২৬',
    primaryBtnText: 'পণ্য এক্সপ্লোর করুন'
  },
  helpline: {
    phone: '01800-000000',
    whatsapp: '01800-000000',
    emergencyAmbulance: '01800-999999',
    supportEmail: 'support@jhadimadi.com'
  },
  operationalSettings: {
    maintenanceMode: false,
    registrationOpen: true,
    codEnabled: true,
    minOrderAmount: 100,
    defaultDeliveryCharge: 60,
    platformCommissionPercent: 5
  }
};

// ================= 🖼️ ইমেজ ও মিডিয়া গ্যালারি ডিফল্ট ডাটা =================
export const INITIAL_MEDIA_DATA: AdminMediaItem[] = [
  {
    id: 'MED-101',
    title: 'পাহাড়ি চাল ও শস্য',
    url: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80',
    tag: 'product',
    uploadedAt: '২০২৬-০৮-০১',
    sizeKb: 340
  },
  {
    id: 'MED-102',
    title: 'পাহাড়ি হলুদ ও মসলা',
    url: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80',
    tag: 'product',
    uploadedAt: '২০২৬-০৮-০৫',
    sizeKb: 420
  },
  {
    id: 'MED-103',
    title: 'খাঁটি বনজ মধু',
    url: 'https://images.unsplash.com/photo-1587049352847-4a222e784d38?auto=format&fit=crop&w=800&q=80',
    tag: 'product',
    uploadedAt: '২০২৬-০৮-০৮',
    sizeKb: 290
  },
  {
    id: 'MED-104',
    title: 'পাহাড়ি আনারস ও ফল',
    url: 'https://images.unsplash.com/photo-1550258987-190a2d41a8ba?auto=format&fit=crop&w=800&q=80',
    tag: 'product',
    uploadedAt: '২০২৬-০৮-১০',
    sizeKb: 380
  },
  {
    id: 'MED-105',
    title: 'তাঁত ও হস্তশিল্প',
    url: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
    tag: 'banner',
    uploadedAt: '২০২৬-০৮-১২',
    sizeKb: 510
  },
  {
    id: 'MED-106',
    title: 'জরুরি রক্তদাতা ও অ্যাম্বুলেন্স',
    url: 'https://images.unsplash.com/photo-1615461066841-6116e61058f4?auto=format&fit=crop&w=800&q=80',
    tag: 'banner',
    uploadedAt: '২০২৬-০৮-১৫',
    sizeKb: 460
  }
];

// ================= 📢 ব্যানার ও বিজ্ঞাপন ডিফল্ট ডাটা =================
export const INITIAL_BANNERS_DATA: AdminBanner[] = [
  {
    id: 'BAN-101',
    title: 'পাহাড়ি অর্গানিক ফ্রুটস ও জুম ফসল',
    subtitle: 'রাসায়নিক ও কীটনাশক মুক্ত ১০০% সতেজ পাহাড়ি ফলমূল সরাসরি বাগান থেকে',
    tag: 'স্পেশাল অফার',
    imageUrl: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=1200&q=80',
    targetLink: 'auto_directory',
    placement: 'homepage_hero',
    isActive: true,
    order: 1,
    createdAt: '২০২৬-০৮-০১'
  },
  {
    id: 'BAN-102',
    title: 'স্মার্ট অটো-ক্যাটাগরি ডিরেক্টরি মার্কেটপ্লেস',
    subtitle: 'উদ্যোক্তা সেল্ফ-সার্ভিস ড্যাশবোর্ড ও ৮টি স্বয়ংক্রিয় ক্যাটালগ সমাহার',
    tag: 'AI Powered',
    imageUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80',
    targetLink: 'auto_directory',
    placement: 'homepage_hero',
    isActive: true,
    order: 2,
    createdAt: '২০২৬-০৮-০৫'
  },
  {
    id: 'BAN-103',
    title: 'ভেরিফাইড পাহাড়ি তাঁত ও আদিবাসী হস্তশিল্প',
    subtitle: 'চাকমা, মারমা ও ত্রিপুরা সম্প্রদায়ের নিখুঁত কারুকাজ ও ঐতিহ্যবাহী পিনন-হাদি',
    tag: 'হস্তশিল্প',
    imageUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1200&q=80',
    targetLink: 'track_a_vendor',
    placement: 'vendor_spotlight',
    isActive: true,
    order: 3,
    createdAt: '২০২৬-০৮-১০'
  },
  {
    id: 'BAN-104',
    title: 'জরুরি রক্তদাতা ও অ্যাম্বুলেন্স সেবা ২৪/৭',
    subtitle: 'পার্বত্য অঞ্চলের যেকোনো জরুরি মুহূর্তে নিকটস্থ রক্তদাতার সাথে সরাসরি যোগাযোগ করুন',
    tag: 'জরুরি সেবা',
    imageUrl: 'https://images.unsplash.com/photo-1615461066841-6116e61058f4?auto=format&fit=crop&w=1200&q=80',
    targetLink: 'services',
    placement: 'directory_top',
    isActive: true,
    order: 4,
    createdAt: '২০২৬-০৮-১৫'
  }
];

// ================= 🩸 রক্তদাতা ডিরেক্টরি ডিফল্ট ডাটা =================
export const INITIAL_BLOOD_DONORS_DATA: AdminBloodDonor[] = [];

// ================= 💬 কমপ্লেন ও রিভিউ মোডারেশন ডিফল্ট ডাটা =================
export const INITIAL_COMPLAINTS_DATA: AdminComplaint[] = [];

// ================= 📍 এলাকা ও ক্যাটাগরি ডিফল্ট ডাটা =================
export const INITIAL_LOCATIONS_DATA: AdminLocation[] = [
  {
    id: 'LOC-KHG',
    districtBn: 'খাগড়াছড়ি',
    districtEn: 'Khagrachhari',
    upazilasBn: ['খাগড়াছড়ি সদর', 'পানছড়ি', 'দীঘিনালা', 'মাটিরাঙ্গা', 'মহালছড়ি', 'মানিকছড়ি', 'রামগড়', 'লক্ষ্মীছড়ি', 'গুইমারা'],
    isActive: true,
    totalPros: 0
  },
  {
    id: 'LOC-RNG',
    districtBn: 'রাঙ্গামাটি',
    districtEn: 'Rangamati',
    upazilasBn: ['রাঙ্গামাটি সদর', 'বাঘাইছড়ি', 'কাপ্তাই', 'বরকল', 'নানিয়ারচর', 'রাজস্থলী', 'জুরাছড়ি', 'কাউখালী', 'বিলাইছড়ি', 'লংগদু'],
    isActive: true,
    totalPros: 0
  },
  {
    id: 'LOC-BDB',
    districtBn: 'বান্দরবান',
    districtEn: 'Bandarban',
    upazilasBn: ['বান্দরবান সদর', 'রুমা', 'থানচি', 'রোয়াংছড়ি', 'লামা', 'আলীকদম', 'নাইক্ষ্যংছড়ি'],
    isActive: true,
    totalPros: 0
  },
  {
    id: 'LOC-CTG',
    districtBn: 'চট্টগ্রাম',
    districtEn: 'Chittagong',
    upazilasBn: ['চট্টগ্রাম সদর', 'হাটহাজারী', 'রাউজান', 'সীতাকুণ্ড', 'ফটিকছড়ি', 'মীরসরাই', 'পটিয়া', 'বোয়ালখালী', 'চন্দনাইশ'],
    isActive: true,
    totalPros: 0
  },
  {
    id: 'LOC-DHK',
    districtBn: 'ঢাকা',
    districtEn: 'Dhaka',
    upazilasBn: ['ধানমন্ডি', 'মিরপুর', 'গুলশান', 'উত্তরা', 'সাভার', 'মোহাম্মদপুর', 'বাড্ডা', 'যাত্রাবাড়ী'],
    isActive: true,
    totalPros: 0
  }
];

export const INITIAL_SERVICE_CATEGORIES_DATA: AdminServiceCategory[] = [
  {
    id: 'CAT-ELEC',
    nameBn: 'ইলেকট্রিশিয়ান ও ওয়্যারিং',
    nameEn: 'Electrician & Wiring',
    iconName: 'Zap',
    totalProfessionals: 0,
    isFeatured: true,
    commissionRate: 5
  },
  {
    id: 'CAT-PLUMB',
    nameBn: 'প্লাম্বার ও পাইপ ফিটিংস',
    nameEn: 'Plumber & Sanitary',
    iconName: 'Wrench',
    totalProfessionals: 0,
    isFeatured: true,
    commissionRate: 5
  },
  {
    id: 'CAT-MASON',
    nameBn: 'রাজমিস্ত্রি ও টাইলস মিস্ত্রি',
    nameEn: 'Mason & Tiles Work',
    iconName: 'Hammer',
    totalProfessionals: 0,
    isFeatured: true,
    commissionRate: 4
  },
  {
    id: 'CAT-FRUIT',
    nameBn: 'পাহাড়ি ফল ও অর্গানিক জুম ফসল',
    nameEn: 'Hill Fruits & Organic Crops',
    iconName: 'ShoppingBag',
    totalProfessionals: 0,
    isFeatured: true,
    commissionRate: 3
  },
  {
    id: 'CAT-CARP',
    nameBn: 'কাঠমিস্ত্রি ও ফার্নিচার কারিগর',
    nameEn: 'Carpenter & Furniture',
    iconName: 'PenTool',
    totalProfessionals: 0,
    isFeatured: false,
    commissionRate: 5
  },
  {
    id: 'CAT-DOC',
    nameBn: 'ডাক্তার ও স্বাস্থ্য বিশেষজ্ঞ',
    nameEn: 'Doctor & Health Specialist',
    iconName: 'HeartPulse',
    totalProfessionals: 0,
    isFeatured: true,
    commissionRate: 2
  },
  {
    id: 'CAT-RENT',
    nameBn: 'চান্দের গাড়ি ও জীপ রেন্টাল',
    nameEn: 'Vehicle & Jeep Rental',
    iconName: 'Truck',
    totalProfessionals: 0,
    isFeatured: true,
    commissionRate: 5
  },
  {
    id: 'CAT-WEAVE',
    nameBn: 'পাহাড়ি তাঁত ও হস্তশিল্প',
    nameEn: 'Indigenous Handloom & Crafts',
    iconName: 'Sparkles',
    totalProfessionals: 0,
    isFeatured: true,
    commissionRate: 3
  },
  {
    id: 'CAT-AC',
    nameBn: 'এসি ও ফ্রিজ মেকানিক',
    nameEn: 'AC & Fridge Repair',
    iconName: 'Cpu',
    totalProfessionals: 0,
    isFeatured: false,
    commissionRate: 6
  },
  {
    id: 'CAT-BLOOD',
    nameBn: 'রক্তদাতা ও অ্যাম্বুলেন্স জরুরি সার্ভিস',
    nameEn: 'Blood Donors & Ambulance',
    iconName: 'Droplet',
    totalProfessionals: 0,
    isFeatured: true,
    commissionRate: 0
  }
];

interface DataContextType {
  products: StoreProduct[];
  addProduct: (product: Partial<StoreProduct> & { nameBn: string; price: number }) => StoreProduct;
  updateProduct: (id: string, updated: Partial<StoreProduct>) => void;
  deleteProduct: (id: string) => void;
  toggleProductPublishStatus: (id: string) => void;
  
  professionals: RegisteredProfessional[];
  addProfessional: (pro: RegisteredProfessional) => void;
  updateProfessional: (id: string | number, updated: Partial<RegisteredProfessional>) => void;
  approveProfessional: (id: string | number) => void;
  rejectProfessional: (id: string | number, reason?: string) => void;
  deleteProfessional: (id: string | number) => void;
  
  users: AdminUserRecord[];
  approveUser: (id: string | number) => void;
  rejectUser: (id: string | number, reason?: string) => void;
  deleteUser: (id: string | number) => void;
  addUser: (user: Partial<AdminUserRecord> & { name: string; phone: string; role: AdminUserRecord['role'] }) => AdminUserRecord;
  updateUserRole: (id: string | number, newRole: AdminUserRecord['role'], roleLabelBn?: string) => void;
  updateUserStatus: (id: string | number, newStatus: AdminUserRecord['status']) => void;
  updateUserRecord: (id: string | number, updated: Partial<AdminUserRecord>) => void;
  
  orders: AdminOrder[];
  addOrder: (order: Omit<AdminOrder, 'id' | 'date'> & { id?: string; date?: string }) => AdminOrder;
  updateOrderStatus: (orderId: string, status: AdminOrder['status']) => void;
  deleteOrder: (orderId: string) => void;

  // 📢 ব্যানার ও বিজ্ঞাপন
  banners: AdminBanner[];
  addBanner: (banner: Omit<AdminBanner, 'id' | 'createdAt'> & { id?: string }) => AdminBanner;
  updateBanner: (id: string, updated: Partial<AdminBanner>) => void;
  deleteBanner: (id: string) => void;
  toggleBannerStatus: (id: string) => void;

  // 📢 হোমপেজ কনটেন্ট ও সেটিংস
  homepageContent: AdminHomepageContent;
  updateHomepageContent: (content: Partial<AdminHomepageContent>) => void;

  // 📣 টেক্সট ও নোটিশ ঘোষণা
  announcements: AdminAnnouncement[];
  addAnnouncement: (announcement: Omit<AdminAnnouncement, 'id' | 'createdAt'> & { id?: string }) => AdminAnnouncement;
  updateAnnouncement: (id: string, updated: Partial<AdminAnnouncement>) => void;
  deleteAnnouncement: (id: string) => void;
  toggleAnnouncementPublish: (id: string) => void;

  // 🖼️ ইমেজ ও মিডিয়া গ্যালারি
  mediaLibrary: AdminMediaItem[];
  addMediaItem: (item: Omit<AdminMediaItem, 'id' | 'uploadedAt'> & { id?: string }) => AdminMediaItem;
  deleteMediaItem: (id: string) => void;

  // 🩸 রক্তদাতা ডিরেক্টরি
  bloodDonors: AdminBloodDonor[];
  addBloodDonor: (donor: Omit<AdminBloodDonor, 'id'> & { id?: string }) => AdminBloodDonor;
  updateBloodDonor: (id: string, updated: Partial<AdminBloodDonor>) => void;
  deleteBloodDonor: (id: string) => void;
  toggleBloodDonorStatus: (id: string) => void;

  // 💬 কমপ্লেন ও রিভিউ
  complaints: AdminComplaint[];
  addComplaint: (complaint: Omit<AdminComplaint, 'id' | 'reportedDate'> & { id?: string }) => AdminComplaint;
  updateComplaint: (id: string, updated: Partial<AdminComplaint>) => void;
  deleteComplaint: (id: string) => void;
  resolveComplaint: (id: string, resolutionNotes: string) => void;

  // 📍 এলাকা ও জেলা
  locations: AdminLocation[];
  addLocation: (loc: Omit<AdminLocation, 'id'> & { id?: string }) => AdminLocation;
  updateLocation: (id: string, updated: Partial<AdminLocation>) => void;
  deleteLocation: (id: string) => void;
  addUpazilaToLocation: (districtId: string, upazilaName: string) => void;
  deleteUpazilaFromLocation: (districtId: string, upazilaName: string) => void;

  // 🏷️ ক্যাটাগরি সেটিংস
  serviceCategories: AdminServiceCategory[];
  addServiceCategory: (cat: Omit<AdminServiceCategory, 'id'> & { id?: string }) => AdminServiceCategory;
  updateServiceCategory: (id: string, updated: Partial<AdminServiceCategory>) => void;
  deleteServiceCategory: (id: string) => void;
  
  resetToDefaults: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // ১. পণ্য তালিকা (Store Products)
  const [products, setProducts] = useState<StoreProduct[]>(() => {
    return offlineStorage.getItem<StoreProduct[]>(OFFLINE_KEYS.PRODUCTS, STORE_PRODUCTS);
  });

  // ২. পেশাজীবী তালিকা (Registered Professionals - Real Data Only)
  const [professionals, setProfessionals] = useState<RegisteredProfessional[]>(() => {
    const saved = offlineStorage.getItem<RegisteredProfessional[]>('jhadimadi_offline_professionals_v2', INITIAL_PROFESSIONALS_DATA);
    return saved.filter(p => p && p.name && !String(p.memberId || '').startsWith('JDM-2026-1011'));
  });

  // ৩. ইউজার ও সেলার রেকর্ডস (Admin User Records)
  const [users, setUsers] = useState<AdminUserRecord[]>(() => {
    return offlineStorage.getItem<AdminUserRecord[]>('jhadimadi_admin_users_v2', INITIAL_USERS_DATA);
  });

  // ৪. অর্ডার তালিকা (Orders)
  const [orders, setOrders] = useState<AdminOrder[]>(() => {
    return offlineStorage.getItem<AdminOrder[]>('jhadimadi_admin_orders_v2', INITIAL_ORDERS_DATA);
  });

  // ৫. ব্যানার ও বিজ্ঞাপন (Banners)
  const [banners, setBanners] = useState<AdminBanner[]>(() => {
    return offlineStorage.getItem<AdminBanner[]>('jhadimadi_admin_banners_v1', INITIAL_BANNERS_DATA);
  });

  // ৬. রক্তদাতা ডিরেক্টরি (Blood Donors - Real Data Only)
  const [bloodDonors, setBloodDonors] = useState<AdminBloodDonor[]>(() => {
    const saved = offlineStorage.getItem<AdminBloodDonor[]>('jhadimadi_admin_blood_donors_v2', INITIAL_BLOOD_DONORS_DATA);
    return saved.filter(d => d && d.name && !String(d.id || '').startsWith('BLD-10'));
  });

  // ৭. কমপ্লেন ও রিভিউ মোডারেশন (Complaints)
  const [complaints, setComplaints] = useState<AdminComplaint[]>(() => {
    return offlineStorage.getItem<AdminComplaint[]>('jhadimadi_admin_complaints_v2', INITIAL_COMPLAINTS_DATA);
  });

  // ৮. এলাকা ও উপজেলা সেটিংস (Locations)
  const [locations, setLocations] = useState<AdminLocation[]>(() => {
    return offlineStorage.getItem<AdminLocation[]>('jhadimadi_admin_locations_v2', INITIAL_LOCATIONS_DATA);
  });

  // ৯. সার্ভিস ক্যাটাগরি তালিকা (Service Categories)
  const [serviceCategories, setServiceCategories] = useState<AdminServiceCategory[]>(() => {
    return offlineStorage.getItem<AdminServiceCategory[]>('jhadimadi_admin_categories_v2', INITIAL_SERVICE_CATEGORIES_DATA);
  });

  // ১০. হোমপেজ কনটেন্ট ও সেটিংস
  const [homepageContent, setHomepageContent] = useState<AdminHomepageContent>(() => {
    return offlineStorage.getItem<AdminHomepageContent>('jhadimadi_admin_homepage_content_v2', INITIAL_HOMEPAGE_CONTENT);
  });

  // ১১. টেক্সট ও নোটিশ ঘোষণা (Announcements)
  const [announcements, setAnnouncements] = useState<AdminAnnouncement[]>(() => {
    return offlineStorage.getItem<AdminAnnouncement[]>('jhadimadi_admin_announcements_v2', INITIAL_ANNOUNCEMENTS_DATA);
  });

  // ১২. মিডিয়া ও ইমেজ গ্যালারি (Media Library)
  const [mediaLibrary, setMediaLibrary] = useState<AdminMediaItem[]>(() => {
    return offlineStorage.getItem<AdminMediaItem[]>('jhadimadi_admin_media_v2', INITIAL_MEDIA_DATA);
  });

  // Fetch backend homepage content if available
  useEffect(() => {
    fetch('/api/admin/homepage-content')
      .then(res => res.json())
      .then(data => {
        if (data && data.success && data.content) {
          setHomepageContent(data.content);
          offlineStorage.saveItem('jhadimadi_admin_homepage_content_v2', data.content);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_admin_announcements_v2', announcements);
  }, [announcements]);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_admin_media_v2', mediaLibrary);
  }, [mediaLibrary]);

  // Live Firestore database synchronization for real registered users & profiles
  useEffect(() => {
    const syncFromDb = () => {
      try {
        const dbUsers = databaseService.getAllUserProfiles();
        if (dbUsers && dbUsers.length > 0) {
          setUsers(prev => {
            const merged = [...prev];
            dbUsers.forEach(dbU => {
              const idx = merged.findIndex(u => String(u.id) === String(dbU.id) || (u.phone && dbU.phone && u.phone === dbU.phone));
              const adminRec: AdminUserRecord = {
                id: dbU.id,
                name: dbU.fullName || dbU.name || "ব্যবহারকারী",
                role: (dbU.role as any) || "customer",
                roleLabelBn: dbU.professionBn || dbU.profession || "সাধারণ গ্রাহক",
                phone: dbU.phone || "",
                email: dbU.email || "",
                district: dbU.district || "",
                upazila: dbU.upazila || "",
                area: dbU.mahalla || "",
                bloodGroup: dbU.bloodGroup || "",
                status: dbU.isNidVerified ? "Approved" : "Pending",
                createdAt: dbU.createdAt ? String(dbU.createdAt).split("T")[0] : new Date().toISOString().split("T")[0],
                avatar: dbU.avatar || "",
                nid: dbU.nidNumber || "",
                notes: dbU.bio || "",
                professionalProfile: dbU.role === "professional" ? {
                  id: dbU.id,
                  name: dbU.fullName || dbU.name || "",
                  phone: dbU.phone || "",
                  job: dbU.professionBn || dbU.profession || "",
                  district: dbU.district || "",
                  upazila: dbU.upazila || "",
                  area: dbU.mahalla || "",
                  verified: Boolean(dbU.isNidVerified),
                  available: Boolean(dbU.isAvailable ?? true),
                  experience: dbU.experienceYears ? `${dbU.experienceYears} বছর` : "০ বছর",
                  dailyRate: dbU.dailyRate ? `${dbU.dailyRate} টাকা` : "০ টাকা",
                  memberId: dbU.memberId || dbU.id,
                  skills: dbU.skills || [],
                  rating: dbU.rating || 0,
                  completedJobs: dbU.completedJobs || 0,
                  bloodGroup: dbU.bloodGroup || "",
                  isBloodDonor: Boolean(dbU.isBloodDonor),
                  bio: dbU.bio || ""
                } : undefined
              };
              if (idx >= 0) {
                merged[idx] = { ...merged[idx], ...adminRec };
              } else {
                merged.push(adminRec);
              }
            });
            return merged;
          });

          setProfessionals(prev => {
            const proUsers = dbUsers.filter(u => u.role === "professional" || (u.profession && u.profession !== "সাধারন নাগরিক"));
            const mergedPros = [...prev];
            proUsers.forEach(pu => {
              const idx = mergedPros.findIndex(p => String(p.id) === String(pu.id) || (p.phone && pu.phone && p.phone === pu.phone));
              const proRecord: RegisteredProfessional = {
                id: pu.id,
                name: pu.fullName || pu.name || "",
                phone: pu.phone || "",
                job: pu.professionBn || pu.profession || "",
                district: pu.district || "",
                upazila: pu.upazila || "",
                area: pu.mahalla || "",
                verified: Boolean(pu.isNidVerified),
                available: Boolean(pu.isAvailable ?? true),
                experience: pu.experienceYears ? `${pu.experienceYears} বছর` : "০ বছর",
                dailyRate: pu.dailyRate ? `${pu.dailyRate} টাকা` : "০ টাকা",
                memberId: pu.memberId || pu.id,
                skills: pu.skills || [],
                rating: pu.rating || 0,
                completedJobs: pu.completedJobs || 0,
                bloodGroup: pu.bloodGroup || "",
                isBloodDonor: Boolean(pu.isBloodDonor),
                bio: pu.bio || ""
              };
              if (idx >= 0) {
                mergedPros[idx] = { ...mergedPros[idx], ...proRecord };
              } else {
                mergedPros.push(proRecord);
              }
            });
            return mergedPros;
          });
        }
      } catch (err) {
        console.warn("Error syncing users from databaseService:", err);
      }
    };

    syncFromDb();
    const unsubscribe = databaseService.subscribe(syncFromDb);
    return () => {
      unsubscribe();
    };
  }, []);

  // Sync state changes to offline storage
  useEffect(() => {
    offlineStorage.saveItem(OFFLINE_KEYS.PRODUCTS, products);
  }, [products]);

  useEffect(() => {
    offlineStorage.saveItem(OFFLINE_KEYS.PROFESSIONALS, professionals);
  }, [professionals]);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_admin_users_v2', users);
  }, [users]);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_admin_orders_v2', orders);
  }, [orders]);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_admin_banners_v1', banners);
  }, [banners]);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_admin_blood_donors_v1', bloodDonors);
  }, [bloodDonors]);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_admin_complaints_v2', complaints);
  }, [complaints]);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_admin_locations_v2', locations);
  }, [locations]);

  useEffect(() => {
    offlineStorage.saveItem('jhadimadi_admin_categories_v2', serviceCategories);
  }, [serviceCategories]);

  // Product Operations
  const addProduct = (prodData: Omit<StoreProduct, 'id'> & { id?: string }): StoreProduct => {
    const newProduct: StoreProduct = {
      ...prodData,
      id: prodData.id || `prod_${Date.now()}`,
      rating: prodData.rating || 5.0,
      reviewsCount: prodData.reviewsCount || 1,
      features: prodData.features || ['১০০% খাঁটি পাহাড়ি পণ্য', 'দ্রুত হোম ডেলিভারি'],
      originalPrice: prodData.originalPrice || Math.round(prodData.price * 1.2),
      unit: prodData.unit || '১ প্যাক',
      origin: prodData.origin || 'পার্বত্য চট্টগ্রাম'
    };
    setProducts(prev => [newProduct, ...prev]);
    return newProduct;
  };

  const updateProduct = (id: string, updated: Partial<StoreProduct>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updated } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const toggleProductPublishStatus = (id: string) => {
    setProducts(prev => prev.map(p => {
      if (p.id === id) {
        const current = p.isPublished !== false;
        return { ...p, isPublished: !current };
      }
      return p;
    }));
  };

  // Professional Operations
  const addProfessional = (pro: RegisteredProfessional) => {
    setProfessionals(prev => {
      const idx = prev.findIndex(p => p.id === pro.id || (p.phone && p.phone === pro.phone));
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = pro;
        return copy;
      }
      return [pro, ...prev];
    });

    // Also add/update in users table
    setUsers(prev => {
      const existing = prev.find(u => u.phone === pro.phone || String(u.id) === String(pro.id));
      if (existing) {
        return prev.map(u => (u.phone === pro.phone || String(u.id) === String(pro.id)) ? {
          ...u,
          name: pro.name,
          roleLabelBn: pro.job,
          district: pro.district,
          upazila: pro.upazila,
          status: pro.verified ? 'Approved' : 'Pending',
          avatar: pro.img,
          nid: pro.nid,
          professionalProfile: pro
        } : u);
      }
      const newUser: AdminUserRecord = {
        id: pro.id || `usr_pro_${Date.now()}`,
        name: pro.name,
        role: 'professional',
        roleLabelBn: pro.job,
        phone: pro.phone,
        email: pro.email,
        district: pro.district,
        upazila: pro.upazila,
        status: pro.verified ? 'Approved' : 'Pending',
        createdAt: new Date().toISOString().split('T')[0],
        avatar: pro.img,
        nid: pro.nid,
        notes: pro.bio,
        professionalProfile: pro
      };
      return [newUser, ...prev];
    });
  };

  const updateProfessional = (id: string | number, updated: Partial<RegisteredProfessional>) => {
    setProfessionals(prev => prev.map(p => String(p.id) === String(id) ? { ...p, ...updated } : p));
  };

  const approveProfessional = (id: string | number) => {
    setProfessionals(prev => prev.map(p => {
      if (String(p.id) === String(id)) {
        return { ...p, verified: true };
      }
      return p;
    }));

    setUsers(prev => prev.map(u => {
      if (String(u.id) === String(id) || (u.professionalProfile && String(u.professionalProfile.id) === String(id))) {
        return { 
          ...u, 
          status: 'Approved',
          professionalProfile: u.professionalProfile ? { ...u.professionalProfile, verified: true } : undefined
        };
      }
      return u;
    }));
  };

  const rejectProfessional = (id: string | number, reason?: string) => {
    setProfessionals(prev => prev.map(p => {
      if (String(p.id) === String(id)) {
        return { ...p, verified: false };
      }
      return p;
    }));

    setUsers(prev => prev.map(u => {
      if (String(u.id) === String(id) || (u.professionalProfile && String(u.professionalProfile.id) === String(id))) {
        return { 
          ...u, 
          status: 'Rejected',
          notes: reason ? `বাতিলের কারণ: ${reason}` : u.notes,
          professionalProfile: u.professionalProfile ? { ...u.professionalProfile, verified: false } : undefined
        };
      }
      return u;
    }));
  };

  const deleteProfessional = (id: string | number) => {
    setProfessionals(prev => prev.filter(p => String(p.id) !== String(id)));
    setUsers(prev => prev.filter(u => String(u.id) !== String(id)));
  };

  // User Operations
  const approveUser = (id: string | number) => {
    setUsers(prev => prev.map(u => {
      if (String(u.id) === String(id)) {
        return { ...u, status: 'Approved' };
      }
      return u;
    }));

    // If it is also a professional, verify them
    setProfessionals(prev => prev.map(p => {
      if (String(p.id) === String(id)) {
        return { ...p, verified: true };
      }
      return p;
    }));
  };

  const rejectUser = (id: string | number, reason?: string) => {
    setUsers(prev => prev.map(u => {
      if (String(u.id) === String(id)) {
        return { ...u, status: 'Rejected', notes: reason ? `বাতিলের কারণ: ${reason}` : u.notes };
      }
      return u;
    }));

    setProfessionals(prev => prev.map(p => {
      if (String(p.id) === String(id)) {
        return { ...p, verified: false };
      }
      return p;
    }));
  };

  const deleteUser = (id: string | number) => {
    setUsers(prev => prev.filter(u => String(u.id) !== String(id)));
  };

  const addUser = (userData: Partial<AdminUserRecord> & { name: string; phone: string; role: AdminUserRecord['role'] }): AdminUserRecord => {
    const newUser: AdminUserRecord = {
      ...userData,
      id: userData.id || `USR-${Math.floor(200 + Math.random() * 800)}`,
      district: userData.district || 'খাগড়াছড়ি',
      upazila: userData.upazila || 'খাগড়াছড়ি সদর',
      createdAt: userData.createdAt || new Date().toISOString().split('T')[0],
      status: userData.status || 'Approved',
      roleLabelBn: userData.roleLabelBn || (userData.role === 'seller' ? 'বিক্রেতা' : userData.role === 'professional' ? 'পেশাজীবী' : userData.role === 'blood_donor' ? 'রক্তদাতা' : 'সাধারণ গ্রাহক')
    };
    setUsers(prev => [newUser, ...prev]);
    return newUser;
  };

  const updateUserRole = (id: string | number, newRole: AdminUserRecord['role'], roleLabelBn?: string) => {
    setUsers(prev => prev.map(u => String(u.id) === String(id) ? {
      ...u,
      role: newRole,
      roleLabelBn: roleLabelBn || (newRole === 'seller' ? 'বিক্রেতা' : newRole === 'professional' ? 'পেশাজীবী' : newRole === 'blood_donor' ? 'রক্তদাতা' : 'সাধারণ গ্রাহক')
    } : u));
  };

  const updateUserStatus = (id: string | number, newStatus: AdminUserRecord['status']) => {
    setUsers(prev => prev.map(u => String(u.id) === String(id) ? { ...u, status: newStatus } : u));
  };

  const updateUserRecord = (id: string | number, updated: Partial<AdminUserRecord>) => {
    setUsers(prev => prev.map(u => String(u.id) === String(id) ? { ...u, ...updated } : u));
  };

  // 📢 হোমপেজ কনটেন্ট মেথডস
  const updateHomepageContent = (content: Partial<AdminHomepageContent>) => {
    setHomepageContent(prev => {
      const merged = { ...prev, ...content };
      offlineStorage.saveItem('jhadimadi_admin_homepage_content_v2', merged);
      
      const token = typeof window !== 'undefined' ? sessionStorage.getItem('jhadimadi_admin_token') : null;
      if (token) {
        fetch('/api/admin/homepage-content', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-token': token
          },
          body: JSON.stringify(merged)
        }).catch(err => console.warn('Failed to sync homepage content with backend:', err));
      }
      return merged;
    });
  };

  // 📣 ঘোষণা মেথডস
  const addAnnouncement = (annData: Omit<AdminAnnouncement, 'id' | 'createdAt'> & { id?: string }): AdminAnnouncement => {
    const newAnn: AdminAnnouncement = {
      ...annData,
      id: annData.id || `ANN-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setAnnouncements(prev => [newAnn, ...prev]);
    return newAnn;
  };

  const updateAnnouncement = (id: string, updated: Partial<AdminAnnouncement>) => {
    setAnnouncements(prev => prev.map(a => a.id === id ? { ...a, ...updated } : a));
  };

  const deleteAnnouncement = (id: string) => {
    setAnnouncements(prev => prev.filter(a => a.id !== id));
  };

  const toggleAnnouncementPublish = (id: string) => {
    setAnnouncements(prev => prev.map(a => a.id === id ? { ...a, isPublished: !a.isPublished } : a));
  };

  // 🖼️ মিডিয়া লাইব্রেরি মেথডস
  const addMediaItem = (itemData: Omit<AdminMediaItem, 'id' | 'uploadedAt'> & { id?: string }): AdminMediaItem => {
    const newItem: AdminMediaItem = {
      ...itemData,
      id: itemData.id || `MED-${Date.now()}`,
      uploadedAt: new Date().toISOString().split('T')[0]
    };
    setMediaLibrary(prev => [newItem, ...prev]);
    return newItem;
  };

  const deleteMediaItem = (id: string) => {
    setMediaLibrary(prev => prev.filter(m => m.id !== id));
  };

  // Order Operations
  const addOrder = (orderData: Omit<AdminOrder, 'id' | 'date'> & { id?: string; date?: string }): AdminOrder => {
    const newOrder: AdminOrder = {
      ...orderData,
      id: orderData.id || `JDM-ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      date: orderData.date || new Date().toISOString().split('T')[0],
      status: orderData.status || 'Pending'
    };
    setOrders(prev => [newOrder, ...prev]);
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: AdminOrder['status']) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  };

  const deleteOrder = (orderId: string) => {
    setOrders(prev => prev.filter(o => o.id !== orderId));
  };

  // 📢 ব্যানার ও বিজ্ঞাপন অপারেশন্স
  const addBanner = (bannerData: Omit<AdminBanner, 'id' | 'createdAt'> & { id?: string }): AdminBanner => {
    const newBanner: AdminBanner = {
      ...bannerData,
      id: bannerData.id || `BAN-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setBanners(prev => [newBanner, ...prev]);
    return newBanner;
  };

  const updateBanner = (id: string, updated: Partial<AdminBanner>) => {
    setBanners(prev => prev.map(b => b.id === id ? { ...b, ...updated } : b));
  };

  const deleteBanner = (id: string) => {
    setBanners(prev => prev.filter(b => b.id !== id));
  };

  const toggleBannerStatus = (id: string) => {
    setBanners(prev => prev.map(b => b.id === id ? { ...b, isActive: !b.isActive } : b));
  };

  // 🩸 রক্তদাতা অপারেশন্স
  const addBloodDonor = (donorData: Omit<AdminBloodDonor, 'id'> & { id?: string }): AdminBloodDonor => {
    const newDonor: AdminBloodDonor = {
      ...donorData,
      id: donorData.id || `BLD-${Date.now()}`
    };
    setBloodDonors(prev => [newDonor, ...prev]);
    return newDonor;
  };

  const updateBloodDonor = (id: string, updated: Partial<AdminBloodDonor>) => {
    setBloodDonors(prev => prev.map(d => d.id === id ? { ...d, ...updated } : d));
  };

  const deleteBloodDonor = (id: string) => {
    setBloodDonors(prev => prev.filter(d => d.id !== id));
  };

  const toggleBloodDonorStatus = (id: string) => {
    setBloodDonors(prev => prev.map(d => d.id === id ? { ...d, isAvailable: !d.isAvailable } : d));
  };

  // 💬 কমপ্লেন ও রিভিউ অপারেশন্স
  const addComplaint = (compData: Omit<AdminComplaint, 'id' | 'reportedDate'> & { id?: string }): AdminComplaint => {
    const newComplaint: AdminComplaint = {
      ...compData,
      id: compData.id || `CMP-${Date.now()}`,
      reportedDate: new Date().toISOString().split('T')[0]
    };
    setComplaints(prev => [newComplaint, ...prev]);
    return newComplaint;
  };

  const updateComplaint = (id: string, updated: Partial<AdminComplaint>) => {
    setComplaints(prev => prev.map(c => c.id === id ? { ...c, ...updated } : c));
  };

  const deleteComplaint = (id: string) => {
    setComplaints(prev => prev.filter(c => c.id !== id));
  };

  const resolveComplaint = (id: string, resolutionNotes: string) => {
    setComplaints(prev => prev.map(c => c.id === id ? {
      ...c,
      status: 'Resolved',
      resolvedDate: new Date().toISOString().split('T')[0],
      resolutionNotes
    } : c));
  };

  // 📍 এলাকা ও জেলা অপারেশন্স
  const addLocation = (locData: Omit<AdminLocation, 'id'> & { id?: string }): AdminLocation => {
    const newLoc: AdminLocation = {
      ...locData,
      id: locData.id || `LOC-${Date.now()}`
    };
    setLocations(prev => [...prev, newLoc]);
    return newLoc;
  };

  const updateLocation = (id: string, updated: Partial<AdminLocation>) => {
    setLocations(prev => prev.map(l => l.id === id ? { ...l, ...updated } : l));
  };

  const deleteLocation = (id: string) => {
    setLocations(prev => prev.filter(l => l.id !== id));
  };

  const addUpazilaToLocation = (districtId: string, upazilaName: string) => {
    if (!upazilaName.trim()) return;
    setLocations(prev => prev.map(l => {
      if (l.id === districtId && !l.upazilasBn.includes(upazilaName.trim())) {
        return { ...l, upazilasBn: [...l.upazilasBn, upazilaName.trim()] };
      }
      return l;
    }));
  };

  const deleteUpazilaFromLocation = (districtId: string, upazilaName: string) => {
    setLocations(prev => prev.map(l => {
      if (l.id === districtId) {
        return { ...l, upazilasBn: l.upazilasBn.filter(u => u !== upazilaName) };
      }
      return l;
    }));
  };

  // 🏷️ ক্যাটাগরি অপারেশন্স
  const addServiceCategory = (catData: Omit<AdminServiceCategory, 'id'> & { id?: string }): AdminServiceCategory => {
    const newCat: AdminServiceCategory = {
      ...catData,
      id: catData.id || `CAT-${Date.now()}`
    };
    setServiceCategories(prev => [...prev, newCat]);
    return newCat;
  };

  const updateServiceCategory = (id: string, updated: Partial<AdminServiceCategory>) => {
    setServiceCategories(prev => prev.map(c => c.id === id ? { ...c, ...updated } : c));
  };

  const deleteServiceCategory = (id: string) => {
    setServiceCategories(prev => prev.filter(c => c.id !== id));
  };

  const resetToDefaults = () => {
    setProducts(STORE_PRODUCTS);
    setProfessionals(INITIAL_PROFESSIONALS_DATA);
    setUsers(INITIAL_USERS_DATA);
    setOrders(INITIAL_ORDERS_DATA);
    setBanners(INITIAL_BANNERS_DATA);
    setBloodDonors(INITIAL_BLOOD_DONORS_DATA);
    setComplaints(INITIAL_COMPLAINTS_DATA);
    setLocations(INITIAL_LOCATIONS_DATA);
    setServiceCategories(INITIAL_SERVICE_CATEGORIES_DATA);
    setHomepageContent(INITIAL_HOMEPAGE_CONTENT);
    setAnnouncements(INITIAL_ANNOUNCEMENTS_DATA);
    setMediaLibrary(INITIAL_MEDIA_DATA);
    offlineStorage.saveItem(OFFLINE_KEYS.PRODUCTS, STORE_PRODUCTS);
    offlineStorage.saveItem(OFFLINE_KEYS.PROFESSIONALS, INITIAL_PROFESSIONALS_DATA);
    offlineStorage.saveItem('jhadimadi_admin_users_v2', INITIAL_USERS_DATA);
    offlineStorage.saveItem('jhadimadi_admin_orders_v2', INITIAL_ORDERS_DATA);
    offlineStorage.saveItem('jhadimadi_admin_banners_v1', INITIAL_BANNERS_DATA);
    offlineStorage.saveItem('jhadimadi_admin_blood_donors_v1', INITIAL_BLOOD_DONORS_DATA);
    offlineStorage.saveItem('jhadimadi_admin_complaints_v2', INITIAL_COMPLAINTS_DATA);
    offlineStorage.saveItem('jhadimadi_admin_locations_v2', INITIAL_LOCATIONS_DATA);
    offlineStorage.saveItem('jhadimadi_admin_categories_v2', INITIAL_SERVICE_CATEGORIES_DATA);
    offlineStorage.saveItem('jhadimadi_admin_homepage_content_v2', INITIAL_HOMEPAGE_CONTENT);
    offlineStorage.saveItem('jhadimadi_admin_announcements_v2', INITIAL_ANNOUNCEMENTS_DATA);
    offlineStorage.saveItem('jhadimadi_admin_media_v2', INITIAL_MEDIA_DATA);
  };

  return (
    <DataContext.Provider
      value={{
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        toggleProductPublishStatus,
        professionals,
        addProfessional,
        updateProfessional,
        approveProfessional,
        rejectProfessional,
        deleteProfessional,
        users,
        approveUser,
        rejectUser,
        deleteUser,
        addUser,
        updateUserRole,
        updateUserStatus,
        updateUserRecord,
        orders,
        addOrder,
        updateOrderStatus,
        deleteOrder,
        banners,
        addBanner,
        updateBanner,
        deleteBanner,
        toggleBannerStatus,
        homepageContent,
        updateHomepageContent,
        announcements,
        addAnnouncement,
        updateAnnouncement,
        deleteAnnouncement,
        toggleAnnouncementPublish,
        mediaLibrary,
        addMediaItem,
        deleteMediaItem,
        bloodDonors,
        addBloodDonor,
        updateBloodDonor,
        deleteBloodDonor,
        toggleBloodDonorStatus,
        complaints,
        addComplaint,
        updateComplaint,
        deleteComplaint,
        resolveComplaint,
        locations,
        addLocation,
        updateLocation,
        deleteLocation,
        addUpazilaToLocation,
        deleteUpazilaFromLocation,
        serviceCategories,
        addServiceCategory,
        updateServiceCategory,
        deleteServiceCategory,
        resetToDefaults
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = (): DataContextType => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
