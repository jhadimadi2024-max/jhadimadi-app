/**
 * Offline Local Storage Management for Jhadimadi.com
 * Automatically caches products, cart items, professional registrations,
 * and user session state to allow uninterrupted browsing in offline/low connectivity.
 */

export const OFFLINE_KEYS = {
  CART: 'jhadimadi_offline_cart_v1',
  PRODUCTS: 'jhadimadi_offline_products_v1',
  PROFESSIONALS: 'jhadimadi_offline_professionals_v1',
  USER: 'jhadimadi_offline_user_v1',
  PRO_PROFILE: 'jhadimadi_offline_pro_profile_v1',
  CACHED_AT: 'jhadimadi_offline_timestamp_v1',
};

export const offlineStorage = {
  saveItem: <T>(key: string, data: T): void => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(key, JSON.stringify(data));
        localStorage.setItem(OFFLINE_KEYS.CACHED_AT, new Date().toISOString());
      }
    } catch (e) {
      console.warn('[Offline Storage] Failed to save item to localStorage:', key, e);
    }
  },

  getItem: <T>(key: string, fallback: T): T => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const item = localStorage.getItem(key);
        if (item) {
          return JSON.parse(item) as T;
        }
      }
    } catch (e) {
      console.warn('[Offline Storage] Failed to parse item from localStorage:', key, e);
    }
    return fallback;
  },

  getLastCachedTime: (): string | null => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return localStorage.getItem(OFFLINE_KEYS.CACHED_AT);
      }
    } catch {
      return null;
    }
    return null;
  },

  clearAllOfflineData: (): void => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        Object.values(OFFLINE_KEYS).forEach((k) => localStorage.removeItem(k));
      }
    } catch (e) {
      console.warn('[Offline Storage] Failed to clear offline data:', e);
    }
  },
};
