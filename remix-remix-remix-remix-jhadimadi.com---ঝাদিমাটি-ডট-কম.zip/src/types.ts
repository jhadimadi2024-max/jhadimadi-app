export type AppMode = 'customer' | 'partner';

export type Language = 'bn' | 'en';

export type Division = 
  | 'Chittagong Division (চট্টগ্রাম)' 
  | 'Dhaka Division (ঢাকা)' 
  | 'Sylhet Division (সিলেট)' 
  | 'Rajshahi Division (রাজশাহী)' 
  | 'Khulna Division (খুলনা)' 
  | 'Barishal Division (বরিশাল)' 
  | 'Rangpur Division (রংপুর)' 
  | 'Mymensingh Division (ময়মনসিংহ)';

export type District = 'Rangamati' | 'Khagrachhari' | 'Bandarban' | 'Chittagong' | 'Dhaka' | 'Sylhet' | 'All Bangladesh';

export interface HyperlocalLocation {
  division: string;
  district: string;
  upazila: string;
  mahalla: string;
}

export interface LocationItem {
  district: District;
  upazila: string;
  address: string;
  lat: number;
  lng: number;
}

export type ServiceModuleId = 
  | 'organic_ecommerce' 
  | 'home_healthcare' 
  | 'freelance_technician' 
  | 'home_chores' 
  | 'hyperlocal_logistics' 
  | 'rental_realestate'
  | 'creative_event';

export interface ServiceModule {
  id: ServiceModuleId;
  titleBn: string;
  titleEn: string;
  descBn: string;
  descEn: string;
  iconName: string;
  badgeBn?: string;
  badgeEn?: string;
  color: string;
}

export interface OrganicProduct {
  id: string;
  nameBn: string;
  nameEn: string;
  category: 'Shutki' | 'Spices' | 'Fruits' | 'PreHarvest' | 'Specialty' | 'Sidol' | 'Food' | 'Clothing' | 'Electronics' | 'Car' | 'Toys' | 'General';
  price: number;
  unit: string;
  origin: string;
  image: string;
  rating: number;
  reviewsCount: number;
  stock: number;
  inStock?: boolean;
  isPreHarvest?: boolean;
  isOrganic?: boolean;
  sellerName?: string;
  originLocation?: string;
  harvestDate?: string;
  descriptionBn: string;
  descriptionEn: string;
}

export interface EducationEntry {
  id?: string;
  degree: string;
  institution?: string;
  institute?: string;
  passingYear?: string;
  passYear?: string;
  fieldOfStudy?: string;
  grade?: string;
}

export interface EmploymentEntry {
  id?: string;
  company: string;
  designation: string;
  duration: string;
  description?: string;
  location?: string;
  isCurrentJob?: boolean;
}

export interface CertificationEntry {
  id?: string;
  title?: string;
  certificateName?: string;
  issuer?: string;
  issuingOrg?: string;
  year: string;
  certificateUrl?: string;
  credentialId?: string;
  verified?: boolean;
}

export interface PortfolioItem {
  id?: string;
  title: string;
  description: string;
  imageUrl: string;
  projectUrl?: string;
  completionDate?: string;
  tags?: string[];
  clientFeedback?: string;
}

export interface OtherExperienceEntry {
  id?: string;
  title: string;
  category?: string;
  description?: string;
  details?: string;
}

export interface ServiceProvider {
  id: string;
  uniqueId?: string; // S-[District Code]-[Serial] (e.g. S-RNG-001)
  name: string;
  fatherName?: string;
  motherName?: string;
  dateOfBirth?: string;
  gender?: 'পুরুষ' | 'নারী' | 'অন্যান্য';
  professionalHeadline?: string;
  avatar: string;
  categoryBn: string;
  categoryEn: string;
  subCategory: string;
  rating: number;
  jobsCompleted: number;
  hourlyRate: number;
  phoneHidden?: string;
  maskedPhone?: string;
  realPhone: string;
  email?: string;
  district: District;
  upazila: string;
  mahalla?: string;
  nidVerified: boolean;
  selfieVerified?: boolean;
  blueTickActive: boolean;
  isAvailableNow?: boolean;
  isAvailable?: boolean;
  distanceKm: number;
  bioBn: string;
  bioEn?: string;
  bio?: string;
  reviewsCount?: number;
  rateAmount?: string;
  selectedSkillsList?: string[];
  verificationFeePaid?: boolean;

  // Hourly / Daily / Fixed Rate breakdown
  rateType?: 'Hourly' | 'Daily' | 'Fixed' | 'দৈনিক' | 'ঘণ্টাভিত্তিক' | 'চুক্তিভিত্তিক' | 'ভিজিট ফি' | string;
  dailyRate?: number;
  fixedRate?: number;

  // Google Maps Coordinates & Service Area Pinning
  serviceArea?: string;
  coveredAreas?: string[]; // Specific Mahallas, Upazilas, Districts physically covered
  coverageRadiusKm?: number;
  latitude?: number;
  longitude?: number;
  mapPinAddress?: string;
  googleMapsEmbedUrl?: string;

  // Public Freelancer / Upwork / Fiverr Profile Fields
  professionKey?: string;
  serviceCategory?: string;
  portfolioImages?: string[];
  skills?: string[];
  skillsDetails?: string; // Comprehensive text area listing all skills, services offered, and past work background
  experienceYears?: number;
  workGallery?: string[];
  portfolioItems?: PortfolioItem[];
  verifiedCertificates?: string[];
  certificatesList?: CertificationEntry[];
  educations?: EducationEntry[];
  employments?: EmploymentEntry[];
  otherExperiences?: OtherExperienceEntry[];
  customerReviews?: {
    id: string;
    customerName: string;
    rating: number;
    comment: string;
    date: string;
  }[];

  // Private Admin & Worker Dashboard Fields (Hidden on Public View)
  nidNumber?: string;
  nidFrontUrl?: string;
  nidBackUrl?: string;
  selfieUrl?: string;
  detailedAddress?: string;
  isPaidProPartner?: boolean; // BDT 100 Verified Pro Partner [✓]
  activationFeePaid?: boolean;
  paymentMethod?: 'bKash' | 'Nagad' | 'Upay';
  trxId?: string;
  
  // Private Wallet & Lifetime Earnings (STRICTLY HIDDEN on Public View)
  privateWallet?: {
    walletBalance: number;
    totalEarnings: number;
    completedJobs: number;
    pendingPayouts: number;
    pendingEscrow: number;
  };
}

export interface WorkerPortfolioRegistration {
  fullName: string;
  phone: string;
  profilePhotoUrl: string;
  profession: string;
  subCategory?: string;
  rateType: 'Hourly' | 'Daily' | 'Fixed';
  rateAmount: number;
  bio: string;
  skills: string[];
  skillsDetails?: string; // Comprehensive text area listing all skills, services offered, and past work background
  experienceYears?: number;
  coveredAreas?: string[]; // Para/Mahallas, Thanas & Districts physically covered
  coverageRadiusKm?: number;
  portfolioImages: string[];
  certificates: string[];
  nidNumber: string;
  nidFrontUrl: string;
  nidBackUrl: string;
  selfieUrl?: string;
  division: string;
  district: District;
  upazila: string;
  mahalla: string;
  mapPinAddress?: string;
  googleMapsEmbedUrl?: string;
  latitude?: number;
  longitude?: number;
}

export interface PrivateWorkerWallet {
  workerId: string;
  walletBalance: number;
  totalEarnings: number;
  completedJobsCount: number;
  pendingPayoutsCount: number;
  pendingEscrowAmount: number;
  payoutHistory: {
    id: string;
    amount: number;
    method: 'bKash' | 'Nagad' | 'Bank';
    accountNumber: string;
    date: string;
    status: 'Pending' | 'Completed' | 'Rejected';
    trxId?: string;
  }[];
}

export interface PropertyListing {
  id: string;
  titleBn: string;
  titleEn: string;
  type: 'Rent' | 'Sale';
  propertyCategory: 'House' | 'Apartment' | 'Land' | 'Commercial';
  price: number;
  priceUnitBn: string;
  priceUnitEn: string;
  district: District;
  upazila: string;
  area: string;
  bedrooms?: number;
  bathrooms?: number;
  sizeSqft?: number;
  landDecimal?: number;
  images: string[];
  ownerName: string;
  ownerPhoneHidden: string;
  isVerifiedProperty: boolean;
  descriptionBn: string;
}

export interface FeedPost {
  id: string;
  authorName: string;
  authorRole: 'User' | 'Provider' | 'Admin';
  authorAvatar?: string;
  postType: 'Service' | 'Property' | 'ECommerce' | 'NeedWork' | 'General';
  title: string;
  titleEn?: string;
  content: string;
  division: string;
  district: string;
  upazila: string;
  mahalla: string;
  category: string;
  price?: number;
  contactPhoneHidden: string;
  realPhone?: string;
  isContactUnlocked?: boolean;
  status: 'Pending' | 'Approved' | 'Rejected';
  createdAt: string;
  likes: number;
  commentsCount: number;
  image?: string;
  isVerifiedUser?: boolean;
}

export interface Booking {
  id: string;
  customerName: string;
  customerPhone: string;
  serviceTitleBn: string;
  serviceTitleEn: string;
  moduleId: ServiceModuleId;
  provider?: ServiceProvider;
  status: 'Pending' | 'Accepted' | 'EnRoute' | 'InProgress' | 'Completed' | 'Cancelled';
  totalAmount: number;
  contactUnlockFee: number;
  // Escrow & 10% Platform Commission
  escrowStatus?: 'HeldInEscrow' | 'ReleasedToWorker' | 'Refunded';
  clientPaidAmount?: number;
  platformCommission?: number; // 10%
  workerNetEarning?: number; // 90%
  createdAt: string;
  location: string;
  notes?: string;
  isContactUnlocked?: boolean;
}

export interface CartItem {
  product: OrganicProduct;
  quantity: number;
}

export interface WalletState {
  balance: number;
  membershipActive: boolean;
  membershipExpiry: string;
  totalEarnings: number;
  totalCommissionsPaid: number;
  contactUnlockFeesPaid: number;
  transactions: {
    id: string;
    type: 'ContactUnlock' | 'Commission' | 'MembershipFee' | 'Cashout' | 'Earning';
    amount: number;
    descriptionBn: string;
    descriptionEn: string;
    date: string;
    status: 'Success' | 'Pending';
  }[];
}

export interface PartnerVerification {
  nidNumber: string;
  nidFrontImage?: string;
  nidBackImage?: string;
  selfieImage?: string;
  status: 'Unverified' | 'Pending' | 'Verified' | 'Rejected';
  blueTick: boolean;
}

export interface ChatMessage {
  id: string;
  senderName: string;
  senderRole: 'User' | 'Provider';
  message: string;
  timestamp: string;
  isMe: boolean;
}

export interface UserProfile {
  id: string;
  uniqueId?: string;
  memberUID?: string; // [DivCode]-[DistCode]-[UpazilaCode]-[4-Digit Sequence] (e.g., CG-KHG-DGH-0001)
  memberId?: string;
  name: string;
  fullName?: string; // Full Name (পুরো নাম)
  phone?: string; // Phone Number (মোবাইল নম্বর)
  email?: string;
  password?: string;
  role?: 'customer' | 'partner' | 'professional' | 'vendor' | 'admin' | string;
  fatherName?: string;
  motherName?: string;
  dateOfBirth?: string;
  gender?: string;
  division: string;
  district: string; // District (জেলা)
  upazila: string; // Upazila / Thana (উপজেলা/থানা)
  thana?: string;
  mahalla: string; // Para / Mahalla (পাড়া/মহল্লা)
  para?: string;
  paraMahalla?: string;
  divisionCode?: string;
  districtCode?: string;
  upazilaCode?: string;
  avatar: string;
  
  // ব্লাড গ্রুপ ও ডোনেশন স্ট্যাটাস
  bloodGroup?: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-' | string; // Blood Group (ব্লাড গ্রুপ)
  isBloodDonor?: boolean;
  isBloodDonorAvailable?: boolean;
  lastDonationDate?: string;

  // পেশা ও সেবা তথ্য
  profession?: string; // Profession / Service (পেশা / সার্ভিস)
  professionBn?: string;
  serviceCategory?: string;
  experienceYears?: number;
  dailyRate?: string | number;
  hourlyRate?: string | number;
  rateType?: 'দৈনিক' | 'ঘণ্টাভিত্তিক' | 'চুক্তিভিত্তিক' | 'ভিজিট ফি' | 'Daily' | 'Hourly' | 'Fixed' | string;
  isAvailable?: boolean;

  // Merchant / Seller Specific Fields
  shopName?: string;
  ownerName?: string;
  businessCategory?: string;
  tradeLicenseOrNid?: string;

  // Additional dynamic properties
  [key: string]: any;

  // Public Worker/Freelancer Profile Fields
  categorySkill?: string;
  rating?: number;
  completedJobs?: number;
  workGallery?: string[];
  verifiedCertificates?: string[];
  customerReviews?: {
    id: string;
    customerName: string;
    rating: number;
    comment: string;
    date: string;
  }[];

  // Private Admin & Compliance Fields
  nidNumber?: string;
  nidFrontUrl?: string;
  nidBackUrl?: string;
  selfieUrl?: string;
  detailedAddress?: string;
  isNidVerified: boolean;

  // BDT 100 Annual Membership State
  isPaidMember: boolean; // BDT 100 Verified Pro Partner [✓]
  membershipExpiryDate?: string;
  membershipTrxId?: string;
  membershipPaymentMethod?: 'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'AdminApproval';
  verificationStatus?: 'Unverified' | 'pending_admin_approval' | 'verified' | 'rejected' | 'revision_requested';
  adminNotes?: string;

  createdAt?: string;
}

export interface AdminVerificationItem {
  id: string;
  userId?: string;
  name: string;
  phone: string;
  email?: string;
  profession: string;
  subCategory?: string;
  rateType?: 'Hourly' | 'Daily' | 'Fixed';
  rateAmount?: number;
  division: string;
  district: string;
  upazila: string;
  mahalla: string;
  nidNumber: string;
  nidFrontUrl?: string;
  nidBackUrl?: string;
  selfieUrl?: string;
  certificates?: string[];
  portfolioImages?: string[];
  skills?: string[];
  bio?: string;
  feeAmount: number;
  paymentMethod: 'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'AdminApproval';
  trxId: string;
  status: 'pending' | 'approved' | 'rejected' | 'revision_requested';
  adminNotes?: string;
  submittedAt: string;
  reviewedAt?: string;
}

export interface PaymentLedgerItem {
  id: string;
  trxId: string;
  senderName: string;
  senderPhone: string;
  paymentMethod: 'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'Card';
  amount: number;
  purpose: '100_REGISTRATION_FEE' | 'COMMISSION' | 'CONTACT_UNLOCK';
  status: 'Success' | 'Pending' | 'Refunded';
  date: string;
  reviewedBy?: string;
}

export interface BloodDonor {
  id: string;
  name: string;
  bloodGroup: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  phone: string;
  district: string;
  upazila: string;
  area: string;
  lastDonationDate: string;
  totalDonations: number;
  isAvailable: boolean;
  verified: boolean;
  emergencyContact?: string;
  age?: number;
}

export interface ProductOrder {
  id: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  items: {
    productId: string;
    nameBn: string;
    price: number;
    quantity: number;
    image?: string;
  }[];
  totalAmount: number;
  paymentMethod: 'COD' | 'bKash' | 'Nagad' | 'Upay';
  status: 'Pending' | 'Processing' | 'Delivered' | 'Cancelled';
  date: string;
  notes?: string;
}

export interface NidVerificationData {
  nidNumber: string;
  fullName: string;
  fatherName?: string;
  motherName?: string;
  dateOfBirth?: string;
  gender?: string;
  address?: string;
  frontImageUri?: string;
  backImageUri?: string;
  selfieImageUri?: string;
  isVerified: boolean;
  verifiedAt?: string;
}

export interface PujaGiftApplication {
  id: string; // e.g., 'PUJA-2026-89234'
  applicantUid?: string;
  userId?: string;
  passportPhoto: string; // Base64 data URL
  fullName: string;
  fatherOrHusbandName: string;
  motherName: string;
  dateOfBirth: string; // DD/MM/YYYY
  gender: 'Male' | 'Female' | 'Other';
  bloodGroup: string; // 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-'
  nidOrBirthCertificate: string;
  contactNumber: string;
  presentAddress: {
    villageArea: string;
    thanaUpazila: string;
    district: string;
  };
  permanentAddress: {
    villageArea: string;
    thanaUpazila: string;
    district: string;
  };
  declarationNotes?: string;
  status: 'Pending' | 'Approved' | 'Delivered' | 'Rejected';
  appliedAt: string;
  createdAt?: string;
}

export interface UserSearchFilterParams {
  district?: string;
  thana?: string;
  bloodGroup?: string;
  profession?: string;
  keyword?: string;
  para?: string;
}

