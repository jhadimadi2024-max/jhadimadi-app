export interface StoreProduct {
  id: string;
  nameBn: string;
  nameEn: string;
  category: 'SpicesGrains' | 'ShutkiSidol' | 'Electronics' | 'Clothing' | 'CraftsHoney' | 'RealEstate' | 'Vehicles' | 'Jewelry' | 'HouseRent' | 'Education' | 'Agri' | 'Tour' | 'Livestock' | 'Health' | 'Services' | string;
  categoryLabelBn: string;
  price: number;
  originalPrice: number;
  unit: string;
  origin: string;
  image: string;
  images?: string[];
  rating: number;
  reviewsCount: number;
  stock: number;
  badge?: string;
  badgeColor?: string;
  descriptionBn: string;
  descriptionEn: string;
  features: string[];
  isPublished?: boolean;
  verifiedSeller?: boolean;
  sellerName?: string;
  sellerPhone?: string;
  sellerPhoneMasked?: string;
  sellerUniqueId?: string;
}

export const STORE_PRODUCTS: StoreProduct[] = [
  // ১. চালের গুঁড়া (Rice Flour)
  {
    id: 'prod_rice_flour',
    nameBn: 'খাঁটি পাহাড়ি চালের গুঁড়া (১ কেজি)',
    nameEn: 'Pure Hill Aromatic Rice Flour (1kg)',
    category: 'SpicesGrains',
    categoryLabelBn: 'পাহাড়ি মশলা ও শস্য',
    price: 120,
    originalPrice: 150,
    unit: '১ কেজি প্যাকেট',
    origin: 'খাগড়াছড়ি সদর',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 94,
    stock: 45,
    badge: '১০০% খাঁটি',
    badgeColor: 'bg-emerald-600',
    descriptionBn: 'পাহাড়ি পাহাড়ি আতপ ও বিনি চাল ঢেঁকিতে ভাঙানো সম্পূর্ণ প্রিজারভেটিভমুক্ত খাঁটি চালের গুঁড়া। চিতই, ভাপা পিঠা ও পাহাড়ি পিঠার জন্য সেরা।',
    descriptionEn: 'Chemical-free traditional stone-ground hill rice flour for authentic homemade traditional pitha.',
    features: ['ভেজালমুক্ত শতভাগ খাঁটি', 'ঘরোয়া ঢেঁকি ছাঁটা সুবাস', 'পিঠা ও পায়েসের জন্য আদর্শ']
  },

  // ২. মরিচের গুঁড়া (Chili Powder)
  {
    id: 'prod_chili_powder',
    nameBn: 'পাহাড়ি বোম্বাই ঝাল মরিচের গুঁড়া (২৫০ গ্রাম)',
    nameEn: 'Hill Naga Hot Red Chili Powder (250g)',
    category: 'SpicesGrains',
    categoryLabelBn: 'পাহাড়ি মশলা ও শস্য',
    price: 160,
    originalPrice: 195,
    unit: '২৫০ গ্রাম জার',
    origin: 'বান্দরবান রোয়াংছড়ি',
    image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 128,
    stock: 60,
    badge: 'তীব্র ঝাল ও রঙ',
    badgeColor: 'bg-red-600',
    descriptionBn: 'বান্দরবানের পাহাড়ি জুমের রোদে শুকানো বোম্বাই ও নাগা মরিচের খাঁটি গুঁড়া। প্রাকৃতিক রঙ ও ঝাঁঝালো সুবাসে অনন্য।',
    descriptionEn: 'Naturally sun-dried fire-hot authentic mountain chili powder from Bandarban.',
    features: ['কোনো কৃত্রিম রঙ নেই', 'পাহাড়ি জুমের তাজা মরিচ', 'তীব্র সুবাস ও খাঁটি ঝাঁঝ']
  },

  // ৩. হলুদের গুঁড়া (Turmeric Powder)
  {
    id: 'prod_turmeric_powder',
    nameBn: 'পাহাড়ি জুমের খাঁটি হলুদের গুঁড়া (৫০০ গ্রাম)',
    nameEn: 'Pure Hill Jhum Turmeric Powder (500g)',
    category: 'SpicesGrains',
    categoryLabelBn: 'পাহাড়ি মশলা ও শস্য',
    price: 180,
    originalPrice: 220,
    unit: '৫০০ গ্রাম প্যাক',
    origin: 'রাঙামাটি বরকল',
    image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 165,
    stock: 50,
    badge: 'জুমের অর্গানিক',
    badgeColor: 'bg-amber-600',
    descriptionBn: 'উঁচু পাহাড়ের খাঁড়া ঢালে ফলানো গভীর সোনালী পাহাড়ি জুমের হলুদ। উচ্চ কারকিউমিন সমৃদ্ধ ও ঔষধি গুণসম্পন্ন।',
    descriptionEn: 'High-curcumin golden wild hill turmeric stone-powdered with zero chemicals.',
    features: ['উচ্চ কারকিউমিন সমৃদ্ধ', 'গাঢ় প্রাকৃতিক সোনালী রঙ', 'আসল পাহাড়ি কাঁচা হলুদের ঘ্রাণ']
  },

  // ৪. পাহাড়ি আদা (Hill Ginger)
  {
    id: 'prod_hill_ginger',
    nameBn: 'সুগন্ধি পাহাড়ি ফ্রেশ কাঁচা আদা (১ কেজি)',
    nameEn: 'Fresh Hill Organic Aromatic Ginger (1kg)',
    category: 'SpicesGrains',
    categoryLabelBn: 'পাহাড়ি মশলা ও শস্য',
    price: 220,
    originalPrice: 260,
    unit: '১ কেজি নেট ব্যাগ',
    origin: 'খাগড়াছড়ি পানছড়ি',
    image: 'https://images.unsplash.com/photo-1615485500704-8e990f9900f7?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 82,
    stock: 35,
    badge: 'ফ্রেশ ফার্ম কালেকশন',
    badgeColor: 'bg-emerald-700',
    descriptionBn: 'পাহাড়ের কালো মাটিতে উৎপাদিত তীব্র রসাল ও সুগন্ধযুক্ত খাঁটি পাহাড়ি আদা। সরাসরি খেত থেকে সংগ্রহ করা।',
    descriptionEn: 'Freshly harvested fibrous and spicy authentic mountain ginger from Panbari hills.',
    features: ['সরাসরি খেত থেকে তোলা', 'তীব্র সুগন্ধ ও স্বাদ', 'রান্না ও ভেষজ চায়ের জন্য সেরা']
  },

  // ৫. পাহাড়ি জুমের বিনি চাল (Hill Jhum Bini Rice)
  {
    id: 'prod_bini_rice',
    nameBn: 'পাহাড়ি জুমের লাল ও কালো বিনি চাল (২ কেজি)',
    nameEn: 'Hill Jhum Sticky Bini Rice (2kg)',
    category: 'SpicesGrains',
    categoryLabelBn: 'পাহাড়ি মশলা ও শস্য',
    price: 240,
    originalPrice: 290,
    unit: '২ কেজি ব্যাগ',
    origin: 'বান্দরবান রুমা',
    image: 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 142,
    stock: 40,
    badge: 'জুমের ঐতিহ্য',
    badgeColor: 'bg-purple-700',
    descriptionBn: 'পাহাড়ি জুমে কোনো রাসায়নিক সার ছাড়াই উৎপাদিত আঠালো লাল ও সাদা বিনি চাল। পাহাড়ি পায়েস ও পিঠার অনন্য স্বাদ।',
    descriptionEn: 'Nutrient-rich traditional sticky red Jhum Bini rice cultivated organically in hill slopes.',
    features: ['১০০% সার ও কীটনাশকমুক্ত', 'প্রাকৃতিক সুগন্ধ ও আঠালো ভাব', 'উচ্চ ফাইবার ও অ্যান্টিঅক্সিডেন্ট']
  },

  // ৬. শুকনা শুঁটকির মাংস (Dried Meat Shutki)
  {
    id: 'prod_dried_meat_shutki',
    nameBn: 'পাহাড়ি ট্র্যাডিশনাল শুকনা শুঁটকির মাংস (২৫০ গ্রাম)',
    nameEn: 'Traditional Hill Smoke-Dried Meat Shutki (250g)',
    category: 'ShutkiSidol',
    categoryLabelBn: 'শুঁটকি ও সিদল',
    price: 550,
    originalPrice: 650,
    unit: '২৫০ গ্রাম প্যাক',
    origin: 'খাগড়াছড়ি মহালছড়ি',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 76,
    stock: 25,
    badge: 'স্পেশাল পাহাড়ি আইটেম',
    badgeColor: 'bg-rose-700',
    descriptionBn: 'পাহাড়ি কাঠের ধোঁয়ায় ও রোদে ঐতিহ্যবাহী নিয়মে শুকানো প্রিজারভেটিভমুক্ত শুকনা মাংসের শুঁটকি। অতুলনীয় ভুনা ও ভর্তার স্বাদ।',
    descriptionEn: 'Wood-smoke cured authentic hill dried meat delicacy prepared in indigenous tradition.',
    features: ['কাঠের ধোঁয়ায় প্রাকৃতিক কিউরিং', 'কোনো কৃত্রিম রাসায়নিক নেই', 'দীর্ঘস্থায়ী সংরক্ষণযোগ্য']
  },

  // ৭. অর্গানিক শুঁটকি (Organic Shutki)
  {
    id: 'prod_organic_shutki',
    nameBn: 'বিষমুক্ত অর্গানিক বোম্বাই ও কাচকি শুঁটকি (২৫০ গ্রাম)',
    nameEn: 'Chemical-Free Organic Sun-Dried Fish Mix (250g)',
    category: 'ShutkiSidol',
    categoryLabelBn: 'শুঁটকি ও সিদল',
    price: 350,
    originalPrice: 420,
    unit: '২৫০ গ্রাম প্যাক',
    origin: 'রাঙামাটি কাপ্তাই লেক',
    image: 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 110,
    stock: 55,
    badge: 'ডিডিটি ও বিষমুক্ত',
    badgeColor: 'bg-emerald-600',
    descriptionBn: 'কাপ্তাই লেকের তাজা ছোট মাছ দিয়ে সম্পূর্ণ মাছি ও কীটনাশকমুক্ত নেট ড্রায়ারে রোদে শুকানো স্বাস্থ্যকর শুঁটকি।',
    descriptionEn: 'Hygienically solar net-dried sweet water fresh fish from pristine Kaptai Lake.',
    features: ['ডিডিটি ও পাউডার বিষমুক্ত', 'কাপ্তাই লেকের তাজা ছোট মাছ', 'বালুমুক্ত ও পরিচ্ছন্ন ড্রায়ারে প্রস্তুত']
  },

  // ৮. ছুরি শুঁটকি (Chhuri Shutki)
  {
    id: 'prod_chhuri_shutki',
    nameBn: 'প্রিমিয়াম গ্রেড-১ রূপালি ছুরি শুঁটকি (২০০ গ্রাম)',
    nameEn: 'Grade-A Premium Silver Ribbon Chhuri Shutki (200g)',
    category: 'ShutkiSidol',
    categoryLabelBn: 'শুঁটকি ও সিদল',
    price: 420,
    originalPrice: 490,
    unit: '২০০ গ্রাম প্যাক',
    origin: 'কক্সবাজার / কাপ্তাই সংযোগ',
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 88,
    stock: 30,
    badge: 'রূপালি চকচকে',
    badgeColor: 'bg-blue-600',
    descriptionBn: 'বাছাইকৃত রূপালি বড় ছুরি মাছের পেট পরিষ্কার করে সমুদ্রের হাওয়া ও কড়া রোদে শুকানো প্রথম শ্রেণির ছুরি শুঁটকি।',
    descriptionEn: 'Export-grade cleaned whole silver ribbon fish sun-dried to perfection.',
    features: ['আঁশ ও পেট পরিষ্কার করা', 'লোনা কম ও সুস্বাদু নরম মাংস', 'ভর্তা ও বেগুন-আলু রান্নায় সেরা']
  },

  // ৯. হাঙর শুঁটকি (Shark Shutki)
  {
    id: 'prod_shark_shutki',
    nameBn: 'সাদা খাঁটি নরম হাঙর শুঁটকি স্পেশাল (২৫০ গ্রাম)',
    nameEn: 'Boneless Soft Ocean Baby Shark Shutki (250g)',
    category: 'ShutkiSidol',
    categoryLabelBn: 'শুঁটকি ও সিদল',
    price: 480,
    originalPrice: 580,
    unit: '২৫০ গ্রাম প্যাক',
    origin: 'মহেশখালী উপকূল',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=600&q=80',
    rating: 4.7,
    reviewsCount: 64,
    stock: 22,
    badge: 'কাঁটামুক্ত মাংসল',
    badgeColor: 'bg-indigo-700',
    descriptionBn: 'কাঁটাহীন পুরু সাদা নরম মাংসল হাঙর মাছের শুঁটকি। পাহাড়ি কায়দায় বাটা রসুন ও কাঁচামরিচ দিয়ে ভুনা করার আদর্শ উপাদান।',
    descriptionEn: 'Tender boneless fleshy shark fillets naturally salt-free sun-dried.',
    features: ['কাঁটামুক্ত শক্ত মাংসের কিউব', 'তীব্র পাহাড়ি ভুনা স্বাদ', 'উচ্চ প্রোটিন সমৃদ্ধ']
  },

  // ১০. অর্গানিক সিদল (Organic Sidal)
  {
    id: 'prod_organic_sidal',
    nameBn: 'পাহাড়ি খাঁটি অর্গানিক সিদল পেস্ট ও চাপড়ি (৫০০ গ্রাম)',
    nameEn: 'Authentic Traditional Hill Fermented Sidol (500g)',
    category: 'ShutkiSidol',
    categoryLabelBn: 'শুঁটকি ও সিদল',
    price: 320,
    originalPrice: 380,
    unit: '৫০০ গ্রাম জার',
    origin: 'খাগড়াছড়ি দীঘিনালা',
    image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 135,
    stock: 45,
    badge: 'ঐতিহ্যবাহী মারমা রেসিপি',
    badgeColor: 'bg-teal-700',
    descriptionBn: 'ছোট মাছ ও পাহাড়ি লতাপাতার মিশ্রণে মাটির পাত্রে ফারমেন্টেশন করে প্রস্তুতকৃত খাঁটি পাহাড়ি সিদল। ভর্তা ও তরকারিতে তীব্র পাহাড়ি স্বাদ এনে দেয়।',
    descriptionEn: 'Traditional indigenous earthen-pot fermented Sidol paste for supreme tribal dishes.',
    features: ['শতবর্ষী পাহাড়ি আদিবাসী রেসিপি', 'মাটির পাত্রে প্রাকৃতিক ফারমেন্টেশন', 'পাহাড়ি বাঁশের কোড়ল রান্নায় অপরিহার্য']
  },

  // ১১. ইলেকট্রনিক্স - স্মার্টওয়াচ (Smartwatch)
  {
    id: 'prod_smartwatch',
    nameBn: 'ব্লুটুথ কলিং ও AMOLED ডিসপ্লে স্মার্টওয়াচ আল্ট্রা',
    nameEn: 'AMOLED Bluetooth Calling Smartwatch Ultra 2',
    category: 'Electronics',
    categoryLabelBn: 'স্মার্ট ইলেকট্রনিক্স',
    price: 1650,
    originalPrice: 2200,
    unit: '১টি বক্স সেট',
    origin: 'ঢাকা টেক ইম্পোর্ট',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 154,
    stock: 28,
    badge: '২৫% ছাড়',
    badgeColor: 'bg-blue-600',
    descriptionBn: '২.০২ ইঞ্চি উজ্জ্বল AMOLED ডিসপ্লে, সার্বক্ষণিক হার্ট রেট ও হেলথ ট্র্যাকিং, পানি নিরোধক IP68 ও শক্তিশালী ব্যাটারি ব্যাকআপ।',
    descriptionEn: 'Premium AMOLED HD touch smartwatch with crystal clear Bluetooth calls and battery longevity.',
    features: ['ব্লুটুথ ভয়েস কলিং ও ডায়ালপ্যাড', 'হার্ট রেট, SpO2 ও স্লিপ মনিটর', '৭ দিনের দীর্ঘ ব্যাটারি ব্যাকআপ']
  },

  // ১২. ইলেকট্রনিক্স - ইয়ারবাডস (TWS Earbuds)
  {
    id: 'prod_earbuds',
    nameBn: 'ANC নয়েজ ক্যান্সেলেশন TWS ওয়্যারলেস ইয়ারবাডস',
    nameEn: 'Active Noise Cancelling Wireless TWS Earbuds',
    category: 'Electronics',
    categoryLabelBn: 'স্মার্ট ইলেকট্রনিক্স',
    price: 980,
    originalPrice: 1350,
    unit: '১টি সেট',
    origin: 'গ্যাজেট পয়েন্ট',
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 210,
    stock: 35,
    badge: 'ডিপ বেস',
    badgeColor: 'bg-purple-600',
    descriptionBn: 'ক্রিস্টাল ক্লিয়ার কলিং মাইক, ডিপ বেস সাউন্ড কোয়ালিটি ও টাইপ-সি ফাস্ট চার্জিং সুবিধা সহ প্রিমিয়াম ইয়ারবাডস।',
    descriptionEn: 'Dynamic deep bass true wireless stereo earbuds with low latency gaming mode.',
    features: ['১৩ মিমি ডায়নামিক বাস ড্রাইভার', '২৮ ঘণ্টার টোটাল প্লেব্যাক', 'স্মার্ট টাচ কন্ট্রোল']
  },

  // ১৩. ইলেকট্রনিক্স - পাওয়ার ব্যাংক (Power Bank)
  {
    id: 'prod_powerbank',
    nameBn: '২০,০০০ mAh ফাস্ট চার্জিং পাওয়ার ব্যাংক (22.5W)',
    nameEn: '20000mAh 22.5W Two-Way Fast Power Bank',
    category: 'Electronics',
    categoryLabelBn: 'স্মার্ট ইলেকট্রনিক্স',
    price: 1450,
    originalPrice: 1850,
    unit: '১টি পিস',
    origin: 'ডিজিটাল জোন',
    image: 'https://images.unsplash.com/photo-1609592424368-232a537f5d9d?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 98,
    stock: 30,
    badge: '২২.৫ ওয়াট ফাস্ট',
    badgeColor: 'bg-emerald-600',
    descriptionBn: 'একসাথে ৩টি ডিভাইস চার্জিং সুবিধা, এলইডি ডিজিটাল ব্যাটারি ডিসপ্লে ও ওভার-ভোল্টেজ প্রটেকশন সমৃদ্ধ হেভি পাওয়ার ব্যাংক।',
    descriptionEn: 'High density polymer 20000mAh power bank compatible with QC3.0 and PD fast charging.',
    features: ['একসাথে ৩টি মোবাইল চার্জ', 'এলইডি শতকরা ব্যাটারি ইন্ডিকেটর', 'পাহাড়ি ট্যুরে নির্ভরযোগ্য ব্যাকআপ']
  },

  // ১৪. ইলেকট্রনিক্স - রিচার্জেবল মিনি ফ্যান (Mini Fan)
  {
    id: 'prod_mini_fan',
    nameBn: '৩-স্পিড পোর্টেবল রিচার্জেবল মিনি ফ্যান ও এলইডি লাইট',
    nameEn: '3-Speed Portable Rechargeable USB Desk Mini Fan',
    category: 'Electronics',
    categoryLabelBn: 'স্মার্ট ইলেকট্রনিক্স',
    price: 580,
    originalPrice: 750,
    unit: '১টি পিস',
    origin: 'হোম গ্যাজেটস',
    image: 'https://images.unsplash.com/photo-1618941716939-553df3c6c278?auto=format&fit=crop&w=600&q=80',
    rating: 4.7,
    reviewsCount: 114,
    stock: 45,
    badge: 'ইউএসবি রিচার্জেবল',
    badgeColor: 'bg-cyan-600',
    descriptionBn: 'হাতে বা টেবিলে রেখে ব্যবহারের উপযোগী শক্তিশালী বাতাস, ফোল্ডিং স্ট্যান্ড ও রাতের জন্য মৃদু এলইডি লাইট সুবিধা।',
    descriptionEn: 'Silent brushless motor portable desk/hand fan with built-in rechargeable battery.',
    features: ['ব্রাশলেস সাইলেন্ট মোটর', '৫-৭ ঘণ্টা একটানা ব্যাকআপ', 'ইউএসবি টাইপ-সি চার্জিং']
  },

  // ১৫. ইলেকট্রনিক্স - পোর্টেবল ব্লুটুথ স্পিকার (Bluetooth Speaker)
  {
    id: 'prod_bluetooth_speaker',
    nameBn: 'ওয়াটারপ্রুফ পোর্টেবল এক্সট্রা বেস ব্লুটুথ স্পিকার',
    nameEn: 'Rugged Waterproof Heavy Bass Bluetooth Speaker',
    category: 'Electronics',
    categoryLabelBn: 'স্মার্ট ইলেকট্রনিক্স',
    price: 850,
    originalPrice: 1150,
    unit: '১টি বক্স',
    origin: 'সাউন্ড গ্যাজেট',
    image: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 86,
    stock: 25,
    badge: 'আইপিএক্স৫ ওয়াটারপ্রুফ',
    badgeColor: 'bg-orange-600',
    descriptionBn: 'ট্যুর ও আউটিংয়ের জন্য সেরা শক্তিশালী ৩৬০ ডিগ্রি সারাউন্ড সাউন্ড ও ১২ ঘণ্টার দীর্ঘ ব্যাটারি ব্যাকআপ।',
    descriptionEn: 'Outdoor ready splash-resistant portable speaker with booming bass and FM radio.',
    features: ['৩৬০ ডিগ্রি স্টেরিও বেস', '১২ ঘণ্টার লং প্লেটাইম', 'মাইক্রো-এসডি ও ব্লুটুথ ৫.৩']
  },

  // ১৬. ইলেকট্রনিক্স - রিচার্জেবল পাহাড়ি হেডল্যাম্প (Headlamp)
  {
    id: 'prod_headlamp',
    nameBn: 'ওয়াটারপ্রুফ পাহাড়ি রিচার্জেবল এলইডি হেডল্যাম্প',
    nameEn: 'Waterproof High-Lumen Outdoor Trekking Headlamp',
    category: 'Electronics',
    categoryLabelBn: 'স্মার্ট ইলেকট্রনিক্স',
    price: 490,
    originalPrice: 650,
    unit: '১টি সেট',
    origin: 'বান্দরবান আউটডোর',
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 72,
    stock: 40,
    badge: 'ট্রেকিং স্পেশাল',
    badgeColor: 'bg-amber-600',
    descriptionBn: 'পাহাড়ে রাতে হাঁটা, মাছ ধরা বা ক্যাম্পিংয়ের জন্য মাথায় পরার আরামদায়ক অ্যাডজাস্টেবল লাইট ও ফ্লাশ মোড।',
    descriptionEn: 'Ultra bright lightweight hands-free outdoor camping & trekking rechargeable headlamp.',
    features: ['৩টি লাইটিং মোড (হাই, লো, এসওএস)', '২০০ মিটার দূরবর্তী ফোকাস', 'বৃষ্টি প্রতিরোধক বডি']
  },

  // ১৭. পোশাক - পাহাড়ি পিনন-হাদি ও থামি ড্রেস (Ethnic Wear)
  {
    id: 'prod_pinon_hadi',
    nameBn: 'পাহাড়ি খাঁটি হস্তচালিত তাঁতের পিনন-হাদি ও থামি সেট',
    nameEn: 'Handcrafted CHT Indigenous Pinon-Hadi Dress Set',
    category: 'Clothing',
    categoryLabelBn: 'পোশাক ও পাহাড়ি তাঁত',
    price: 2450,
    originalPrice: 2950,
    unit: '১ সেট (পিনন + হাদি)',
    origin: 'রাঙামাটি বয়নপল্লী',
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 105,
    stock: 18,
    badge: 'আদিবাসী তাঁতের শিল্প',
    badgeColor: 'bg-pink-700',
    descriptionBn: 'শতভাগ খাঁটি পাহাড়ি সুতা দিয়ে কোমরে বাঁধা ব্যাকস্ট্র্যাপ তাঁতে বোনা মারমা ও চাকমা সংস্কৃতির ঐতিহ্যবাহী জমকালো পোশাক সেট।',
    descriptionEn: 'Authentic pure cotton indigenous handwoven traditional two-piece dress set.',
    features: ['১০০% সুতি সুতার নিখুঁত বুনন', 'ঐতিহ্যবাহী চাকমা/মারমা নকশা', 'রং ওঠার ভয় নেই']
  },

  // ১৮. পোশাক - পাহাড়ি শীতের কটন শাল ও ওড়না (Traditional Shawl)
  {
    id: 'prod_ethnic_shawl',
    nameBn: 'ঐতিহ্যবাহী চাকমা ও ত্রিপুরা কটন ওড়না ও শীতের শাল',
    nameEn: 'Traditional Hand-Knitted CHT Winter Ethnic Shawl',
    category: 'Clothing',
    categoryLabelBn: 'পোশাক ও পাহাড়ি তাঁত',
    price: 980,
    originalPrice: 1250,
    unit: '১টি পিস',
    origin: 'খাগড়াছড়ি খাদি নিকেতন',
    image: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 68,
    stock: 25,
    badge: 'হাতে বোনা সুতা',
    badgeColor: 'bg-rose-600',
    descriptionBn: 'পাহাড়ের মিষ্টি শীত ও আধুনিক ফ্যাশনের মেলবন্ধনে তৈরি আরামদায়ক ও রুচিশীল হাতে বোনা ট্র্যাডিশনাল শাল।',
    descriptionEn: 'Warm and breathable artisanal ethnic patterned winter shawl woven with soft cotton.',
    features: ['উষ্ণ ও আরামদায়ক নরম সুতা', 'অনন্য জ্যামিতিক পাহাড়ি পাড় নকশা', 'সব বয়সের জন্য মানানসই']
  },

  // ১৯. পোশাক - এথনিক হ্যান্ডলুম কটন কুর্তি ও টপস (Ethnic Kurti & Tops)
  {
    id: 'prod_cotton_kurti',
    nameBn: 'আরামদায়ক এথনিক হ্যান্ডলুম কটন কুর্তি ও ডিজাইনার টপস',
    nameEn: 'Artisan Handloom Cotton Ethnic Kurti & Top',
    category: 'Clothing',
    categoryLabelBn: 'পোশাক ও পাহাড়ি তাঁত',
    price: 850,
    originalPrice: 1100,
    unit: '১টি পিস',
    origin: 'খাগড়াছড়ি টেক্সটাইল',
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 92,
    stock: 30,
    badge: 'ডিজাইনার কালেকশন',
    badgeColor: 'bg-violet-700',
    descriptionBn: 'গরমে সর্বোচ্চ আরাম দিতে প্রিমিয়াম কোয়ালিটি হ্যান্ডলুম খাদি কটন দিয়ে তৈরি আধুনিক কাট ও মার্জিত ডিজাইনের কুর্তি।',
    descriptionEn: 'Breathable hand-spun artisan cotton Kurti top designed for chic everyday comfort.',
    features: ['১০০% ব্রিদেবল খাদি কটন', 'আধুনিক প্রিন্ট ও এমব্রয়ডারি পাড়', 'সহজ ওয়াশ ও টেকসই']
  },

  // ২০. পোশাক - খাঁটি পাহাড়ি খাদি কটন পাঞ্জাবি (Khadi Panjabi)
  {
    id: 'prod_khadi_panjabi',
    nameBn: 'প্রিমিয়াম পাহাড়ি খাদি কটন পাঞ্জাবি (হ্যান্ডলুম)',
    nameEn: 'Exclusive Handloom Khadi Cotton Panjabi for Men',
    category: 'Clothing',
    categoryLabelBn: 'পোশাক ও পাহাড়ি তাঁত',
    price: 1250,
    originalPrice: 1550,
    unit: '১টি পিস',
    origin: 'খাগড়াছড়ি খাদি ঘর',
    image: 'https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 74,
    stock: 32,
    badge: 'উৎসবের সেরা পোশাক',
    badgeColor: 'bg-amber-700',
    descriptionBn: 'পাহাড়ি প্রাকৃতিক সুতা ও কাঠের বোতাম সংযোজনে তৈরি আভিজাত্যপূর্ণ ও আরামদায়ক খাদি সুতি পাঞ্জাবি।',
    descriptionEn: 'Refined ethnic aesthetic Khadi cotton Panjabi tailored with natural coconut buttons.',
    features: ['খাঁটি হ্যান্ডলুম খাদি সুতা', 'কাঠের প্রিমিয়াম বোতাম ফিনিশিং', 'মার্জিত পাহাড়ি টেক্সচার']
  },

  // ২১. পোশাক - ড্রপ-শোল্ডার প্রিমিয়াম টি-শার্ট (T-Shirt)
  {
    id: 'prod_oversized_tshirt',
    nameBn: '১০০% কম্বড কটন প্রিমিয়াম ড্রপ-শোল্ডার ক্যাজুয়াল টি-শার্ট',
    nameEn: '100% Combed Cotton Heavyweight Oversized T-Shirt',
    category: 'Clothing',
    categoryLabelBn: 'পোশাক ও পাহাড়ি তাঁত',
    price: 490,
    originalPrice: 650,
    unit: '১টি পিস',
    origin: 'চিটাগং ফ্যাশন হাব',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 145,
    stock: 50,
    badge: 'ক্যাজুয়াল ট্রেন্ড',
    badgeColor: 'bg-slate-800',
    descriptionBn: '২২০ জিএসএম প্রিমিয়াম কম্বড কটন, নিখুঁত ড্রপ-শোল্ডার কাটিং ও দীর্ঘস্থায়ী সফট আরামের নিশ্চয়তা।',
    descriptionEn: '220 GSM heavyweight combed cotton streetwear drop-shoulder casual tee.',
    features: ['২২০ জিএসএম প্রিমিয়াম ফেব্রিক', 'সফট বায়ো-ওয়াশ ফিনিশ', 'কালার গ্যারান্টি']
  },

  // ২২. পাহাড়ি প্রাকৃতিক মধু (Wild Honey)
  {
    id: 'prod_wild_honey',
    nameBn: 'বান্দরবানের পাহাড়ি চাকের খাঁটি কাঁচা মধু (১ কেজি)',
    nameEn: 'Bandarban Raw Deep Forest Wild Honey (1kg)',
    category: 'CraftsHoney',
    categoryLabelBn: 'কুটির শিল্প ও মধু',
    price: 950,
    originalPrice: 1150,
    unit: '১ কেজি গ্লাস জার',
    origin: 'বান্দরবান রুমা অরণ্য',
    image: 'https://images.unsplash.com/photo-1587049352847-4a222e784d38?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 180,
    stock: 25,
    badge: '১০০% পাহাড়ি চাকের মধু',
    badgeColor: 'bg-amber-600',
    descriptionBn: 'রুমা ও থানচির গভীর পাহাড়ি বন থেকে আদিবাসীদের দ্বারা সরাসরি সংগৃহীত অপ্রক্রিয়াজাত খাঁটি প্রাকৃতিক মধু।',
    descriptionEn: 'Pure raw unprocessed wild forest honey sustainably harvested from remote hill canopies.',
    features: ['কোনো চিনি বা কৃত্রিম উপাদান নেই', 'প্রাকৃতিক এনজাইম ও অ্যান্টিঅক্সিডেন্ট', 'শতভাগ ভেজালমুক্ত ল্যাব টেস্টেড']
  },

  // ২৩. পাহাড়ি বাঁশের কোড়ল (Fresh Bamboo Shoots)
  {
    id: 'prod_bamboo_shoot',
    nameBn: 'সিজনাল পাহাড়ি ফ্রেশ মিষ্টি বাঁশ কোড়ল (১ কেজি)',
    nameEn: 'Seasonal Mountain Fresh Bamboo Shoots (1kg)',
    category: 'SpicesGrains',
    categoryLabelBn: 'পাহাড়ি মশলা ও শস্য',
    price: 180,
    originalPrice: 220,
    unit: '১ কেজি প্যাকেট',
    origin: 'খাগড়াছড়ি দীঘিনালা',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 88,
    stock: 30,
    badge: 'সিজনাল সেরা',
    badgeColor: 'bg-emerald-600',
    descriptionBn: 'পাহাড়ের মাটি ফেটে বের হওয়া তাজা কচি বাঁশ কোড়ল। পাহাড়ি সবজি ও সিদল দিয়ে রান্নায় চমৎকার সুস্বাদু ও পুষ্টিকর।',
    descriptionEn: 'Crisp organic tender mountain bamboo shoots freshly harvested from hill forests.',
    features: ['সম্পূর্ণ প্রাকৃতিক ও অরগানিক', 'হাই ফাইবার ও লো ক্যালরি', 'পাহাড়ি ট্রেডিশনাল তরকারির প্রধান উপাদান']
  },

  // ২৪. পাহাড়ি বাঁশ ও বেতের বাস্কেট (Bamboo Craft Basket)
  {
    id: 'prod_bamboo_basket',
    nameBn: 'নিখুঁত কারুশিল্পের পাহাড়ি বাঁশ ও বেতের বাস্কেট',
    nameEn: 'Handmade Natural Bamboo & Cane Craft Storage Basket',
    category: 'CraftsHoney',
    categoryLabelBn: 'কুটির শিল্প ও মধু',
    price: 350,
    originalPrice: 450,
    unit: '১টি পিস',
    origin: 'রাঙামাটি কুটির শিল্প',
    image: 'https://images.unsplash.com/photo-1587654780291-39c9404d746b?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 52,
    stock: 35,
    badge: 'পরিবেশবান্ধব হস্তশিল্প',
    badgeColor: 'bg-teal-600',
    descriptionBn: 'স্থানীয় পাহাড়ি কারিগরদের নিখুঁত হাতে তৈরি দীর্ঘস্থায়ী ও নান্দনিক পরিবেশবান্ধব বাঁশ-বেতের ঝুড়ি।',
    descriptionEn: 'Eco-friendly sustainable handmade bamboo and cane utility basket crafted by indigenous artisans.',
    features: ['১০০% প্রাকৃতিক বাঁশ ও বেত', 'টেকসই ও হালকা ওজন', 'ফলমূল বা ঘরের ডেকোরেশনের জন্য উপযুক্ত']
  },

  // ২৫. রিয়েল এস্টেট - পাহাড়ি টিলা ও ফলের বাগান জমি (Real Estate)
  {
    id: 'prod_realestate_land',
    nameBn: 'খাগড়াছড়ি দীঘিনালা প্রধান সড়ক সংলগ্ন পাহাড়ি টিলা ও বাগান জমি (২ একর)',
    nameEn: 'Prime Roadside Hilltop Orchard Land in Dighinala (2 Acres)',
    category: 'RealEstate',
    categoryLabelBn: 'রিয়েল এস্টেট ও জমি',
    price: 3500000,
    originalPrice: 3800000,
    unit: '২ একর দাগ',
    origin: 'খাগড়াছড়ি দীঘিনালা',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 14,
    stock: 1,
    badge: 'ক্লিয়ার দলিল ও খতিয়ান',
    badgeColor: 'bg-emerald-700',
    descriptionBn: 'সরাসরি পিচঢালা সড়ক সংযোগ, পানির ঝিরি ও আম্রপালি আম-সেগুন বাগান সহ সম্পূর্ণ নিষ্কণ্টক জমি। রিসোর্ট বা খামার প্রকল্পের জন্য আদর্শ।',
    descriptionEn: 'Prime roadside freehold land with mango and teak plantation with perennial fresh stream water.',
    features: ['পাকা সড়ক সংলগ্ন ফ্রন্টেজ', 'বিদ্যুৎ ও পানি সংযোগের সুবিধা', 'নিষ্কণ্টক মালিকানা ও খতিয়ান']
  },

  // ২৬. গহনা ও অলংকার - পাহাড়ি রূপার ঐতিহ্যবাহী হাঁসুলি ও চন্দ্রহার (Jewelry)
  {
    id: 'prod_tribal_jewelry',
    nameBn: 'পাহাড়ি এথনিক খাঁটি রূপার নকশি চন্দ্রহার ও ঐতিহ্যবাহী হাঁসুলি সেট',
    nameEn: 'Authentic CHT Indigenous Silver Hasuli & Chokhar Necklace',
    category: 'Jewelry',
    categoryLabelBn: 'গহনা ও অলংকার',
    price: 3200,
    originalPrice: 3800,
    unit: '১টি সেট',
    origin: 'রাঙামাটি জুয়েলার্স',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 47,
    stock: 12,
    badge: 'হ্যান্ডক্রাফটেড রূপা',
    badgeColor: 'bg-purple-700',
    descriptionBn: 'মারমা ও চাকমা সংস্কৃতির ঐতিহ্যবাহী জ্যামিতিক নকশায় পাহাড়ি অভিজ্ঞ স্বর্ণকার দ্বারা তৈরি খাঁটি রূপার প্রলেপযুক্ত এথনিক জুয়েলারি।',
    descriptionEn: 'Artisanal indigenous handcrafted traditional silver ethnic choker for festive wear.',
    features: ['হাতে তৈরি নিখুঁত নকশা', 'টেকসই এন্টিক পলিশ', 'উপজাতীয় সাংস্কৃতিক ঐতিহ্য']
  },

  // ২৭. বাসা ভাড়া - খাগড়াছড়ি সদর মনোরম ২ রুমের ফ্যামিলি ফ্ল্যাট (House Rent)
  {
    id: 'prod_houserent_flat',
    nameBn: 'খাগড়াছড়ি সদর কলেজ রোড সংলগ্ন ২ বেডরুমের আলো-বাতাসপূর্ণ ফ্যামিলি বাসা',
    nameEn: '2-Bedroom Airy Family Apartment Near College Road',
    category: 'HouseRent',
    categoryLabelBn: 'বাসা ভাড়া ও ফ্ল্যাট',
    price: 8500,
    originalPrice: 9000,
    unit: 'মাসিক ভাড়া',
    origin: 'খাগড়াছড়ি সদর',
    image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 19,
    stock: 2,
    badge: '২৪ ঘণ্টা পানি ও গ্যাস',
    badgeColor: 'bg-amber-600',
    descriptionBn: 'শান্ত ও মনোরম পরিবেশে ৩য় তলায় ২ বেড, ২ বাথ, ডাইনিং এবং বারান্দা সহ সম্পূর্ণ টাইলস করা আধুনিক ফ্ল্যাট বাসা ভাড়া।',
    descriptionEn: 'Modern spacious 2-bed 2-bath family apartment with scenic hill view and 24/7 utilities.',
    features: ['২৪ ঘণ্টা নিরাপদ সুপেয় পানি', 'প্রাকৃতিক পাহাড়ি আলো-বাতাস', 'সিসিটিভি ও বাইক পার্কিং']
  },

  // ২৮. গাড়ি ও যানবাহন - সাজেক চান্দের গাড়ি ৪x৪ ট্রিপ বুকিং (Vehicles)
  {
    id: 'prod_chander_gari',
    nameBn: 'খাগড়াছড়ি থেকে সাজেক ভ্যালি ৪x৪ চান্দের গাড়ি (Mahindra 4WD) রিজার্ভ',
    nameEn: 'Khagrachhari to Sajek Valley 4x4 Jeep/Chander Gari Trip',
    category: 'Vehicles',
    categoryLabelBn: 'গাড়ি ও যানবাহন',
    price: 7500,
    originalPrice: 8500,
    unit: 'রাউন্ড ট্রিপ (১০-১২ জন)',
    origin: 'খাগড়াছড়ি জীপ সমিতি',
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 230,
    stock: 8,
    badge: 'অভিজ্ঞ পাহাড়ি ড্রাইভার',
    badgeColor: 'bg-red-700',
    descriptionBn: 'খাগড়াছড়ি শহর থেকে সাজেক ভ্যালি নিরাপদে যাওয়া-আসা, হ্যালিপ্যাড, কংলাক পাহাড় ও রিসোর্ট ড্রপ-অফ সহ পূর্ণ রিজার্ভ সেবা।',
    descriptionEn: 'Experienced mountain-certified 4WD open jeep tour package with trusted driver.',
    features: ['১০-১২ জন ধারণক্ষমতা', 'সাজেক ট্যুরিস্ট পুলিশ এসকর্ট সহায়তা', 'অন-টাইম পিকআপ ও ড্রপ']
  },

  // ২৯. টিউশনি ও শিক্ষা - পাহাড়ি ভাষা ও একাডেমিক হোম টিউটর (Education)
  {
    id: 'prod_tutor_education',
    nameBn: 'খাগড়াছড়ি সদর ও রাঙামাটি এলাকাভিত্তিক স্পেশালাইজড হোম টিউটর সার্ভিস',
    nameEn: 'Verified Specialized Home & Online Academic Tutor',
    category: 'Education',
    categoryLabelBn: 'টিউশনি ও শিক্ষা',
    price: 3500,
    originalPrice: 4000,
    unit: 'মাসিক টিউশন ফি',
    origin: 'খাগড়াছড়ি বিশ্ববিদ্যালয় শিক্ষার্থী অ্যাসো.',
    image: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 38,
    stock: 15,
    badge: 'ভেরিফাইড গ্র্যাজুয়েট',
    badgeColor: 'bg-cyan-700',
    descriptionBn: 'বিজ্ঞান, গণিত ও ইংরেজি বিষয়ে প্রাথমিক থেকে উচ্চমাধ্যমিক পর্যন্ত অভিজ্ঞ স্থানীয় বিশ্ববিদ্যালয়ের শিক্ষার্থীদের নিয়মিত হোম ও অনলাইন কেয়ার।',
    descriptionEn: 'Experienced verified home tutors for school, college science and math education.',
    features: ['সপ্তাহে ৩/৪ দিন পাঠদান', 'নিয়মিত মডেল টেস্ট ও মূল্যায়ন', 'ভেরিফাইড আইডেন্টিটি']
  },

  // ৩০. কৃষি ও পাহাড়ি ফসল - খাগড়াছড়ির বাগান ফ্রেশ আম্রপালি আম (Agri)
  {
    id: 'prod_amrapali_mango',
    nameBn: 'খাগড়াছড়ির বিখ্যাত পাহাড়ি মিষ্টি আম্রপালি আম (১০ কেজি কার্টন)',
    nameEn: 'Authentic Mountain Sweet Amrapali Mango Box (10kg)',
    category: 'Agri',
    categoryLabelBn: 'কৃষি ও পাহাড়ি ফসল',
    price: 1100,
    originalPrice: 1350,
    unit: '১০ কেজি পেয়ারি কার্টন',
    origin: 'খাগড়াছড়ি মহালছড়ি বাগান',
    image: 'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 310,
    stock: 120,
    badge: 'গাছপাকা ফরমালিনমুক্ত',
    badgeColor: 'bg-lime-700',
    descriptionBn: 'পাহাড়ের খাঁড়া ঢালে প্রাকৃতিক রোদে পাকা মিষ্টি রসে টইটম্বুর ও পাতলা আঁশের শতভাগ ফরমালিনমুক্ত খাগড়াছড়ির প্রিমিয়াম আম্রপালি আম।',
    descriptionEn: 'Tree-ripened organic sweet chemical-free hill Amrapali mangoes directly from orchards.',
    features: ['শতভাগ ফরমালিন ও কার্বাইডমুক্ত', 'গাছপাকা পাতলা আঁশের সুমিষ্ট স্বাদ', 'সরাসরি বাগান থেকে বাছাই']
  },

  // ৩১. ট্যুর ও ট্রাভেল - সাজেক ভ্যালি প্রিমিয়াম রিসোর্ট ও ট্রাভেল গাইড প্যাকেজ (Tour)
  {
    id: 'prod_sajek_tour_resort',
    nameBn: 'সাজেক ভ্যালি ২ দিন ১ রাত প্রিমিয়াম ক্লাউড ভিউ রিসোর্ট ও গাইড প্যাকেজ',
    nameEn: 'Sajek Valley 2D1N Cloud View Cottage & Tour Guide',
    category: 'Tour',
    categoryLabelBn: 'ট্যুর ও ট্রাভেল',
    price: 4800,
    originalPrice: 5500,
    unit: 'প্রতি কাপল/রুম',
    origin: 'সাজেক ভ্যালি রুংরাং',
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 165,
    stock: 6,
    badge: 'মেঘের ওপর কটেজ',
    badgeColor: 'bg-sky-700',
    descriptionBn: 'সকালের শুভ্র মেঘের চাদর বারান্দা থেকে দেখার সুবর্ণ সুযোগ, গরম পানি, জেনারেটর ব্যাকআপ ও স্থানীয় পাহাড়ি খাবার সহ প্রিমিয়াম প্যাকেজ।',
    descriptionEn: 'Breathtaking sunrise cottage overlooking rolling hill clouds with 24/7 hospitality.',
    features: ['প্যানোরামিক ক্লাউড ভিউ বারান্দা', 'সার্বক্ষণিক গরম পানি ও ওয়াইফাই', 'স্থানীয় পাহাড়ি খাবারের সুব্যবস্থা']
  },

  // ৩২. পশু-পাখি ও খামার - খাঁটি পাহাড়ি ব্ল্যাক বেঙ্গল খাসি ও দেশি মুরগি (Livestock)
  {
    id: 'prod_hill_livestock',
    nameBn: 'পাহাড়ের প্রাকৃতিক ঘাস-পাতায় লালিত ব্ল্যাক বেঙ্গল খাসি (১০-১২ কেজি)',
    nameEn: 'Authentic Free-Range Mountain Black Bengal Goat',
    category: 'Livestock',
    categoryLabelBn: 'পশু-পাখি ও খামার',
    price: 9500,
    originalPrice: 11000,
    unit: 'প্রতিটি জীবিত খাসি',
    origin: 'খাগড়াছড়ি মানিকছড়ি খামার',
    image: 'https://images.unsplash.com/photo-1527153857715-3908f2ae5e81?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 42,
    stock: 8,
    badge: 'প্রাকৃতিক অর্গানিক ঘাস খাওয়া',
    badgeColor: 'bg-amber-800',
    descriptionBn: 'পাহাড়ের উন্মুক্ত চারণভূমিতে লতাপাতা খেয়ে বেড়ে ওঠা রোগমুক্ত ও সুস্বাদু স্বাস্থ্যের খাঁটি ব্ল্যাক বেঙ্গল জাতের খাসি। হোম ডেলিভারি ও প্রসেসিং সুবিধা।',
    descriptionEn: 'Naturally grazed organic Black Bengal mountain livestock reared in village hill pastures.',
    features: ['কোনো স্টেরয়েড বা রাসায়নিক ওষুধ ছাড়া পালিত', 'সুস্বাদু ও স্বাস্থ্যসম্মত মাংস', 'সরাসরি খামার থেকে সরবরাহ']
  },

  // ৩৩. স্বাস্থ্য ও রূপচর্চা - পাহাড়ি ভেষজ তেল ও থানকুনি হেয়ার কেয়ার (Health)
  {
    id: 'prod_herbal_hair_oil',
    nameBn: '২১টি পাহাড়ি জংলি ভেষজ ও নিম-আমলকী সমৃদ্ধ খাঁটি হেয়ার অয়েল (২০০ মি.লি.)',
    nameEn: '21 Mountain Herbs Indigenous Pure Herbal Hair Oil (200ml)',
    category: 'Cosmetics',
    categoryLabelBn: 'কসমেটিক ও রূপচর্চা',
    price: 380,
    originalPrice: 480,
    unit: '২০০ মি.লি. বোতল',
    origin: 'রাঙামাটি আয়ুর্বেদিক',
    image: 'https://images.unsplash.com/photo-1608248597359-2a9c314eb441?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 88,
    stock: 60,
    badge: '১০০% আয়ুর্বেদিক ভেষজ',
    badgeColor: 'bg-teal-700',
    descriptionBn: 'পাহাড়ের দুর্গম অরণ্য থেকে সংগৃহীত ভৃঙ্গরাজ, থানকুনি, আমলকী, কালোজিরা ও তিলের খাঁটি কাঠের ঘানির তেলে জ্বাল দিয়ে তৈরি জাদুকরী হেয়ার অয়েল।',
    descriptionEn: 'Pure Ayurvedic mountain herb-infused root nourishing cold-pressed hair growth oil.',
    features: ['চুল পড়া বন্ধে কার্যকর সমাধান', 'কোনো কৃত্রিম রাসায়নিক বা সুগন্ধি নেই', 'মাথা ঠান্ডা রাখে ও প্রশান্তি দেয়']
  },

  // ৩৪. কসমেটিক - অর্গানিক পাহাড়ি চন্দন ও মুলতানি ফেসপ্যাক (Cosmetics)
  {
    id: 'prod_organic_facepack',
    nameBn: 'খাঁটি পাহাড়ি শ্বেত চন্দন ও মুলতানি ফেসপ্যাক গ্লো কিট (১০০ গ্রাম)',
    nameEn: 'Organic Wild Sandalwood & Multani Glow Facepack (100g)',
    category: 'Cosmetics',
    categoryLabelBn: 'কসমেটিক',
    price: 290,
    originalPrice: 380,
    unit: '১০০ গ্রাম জার',
    origin: 'খাগড়াছড়ি অর্গানিক',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 65,
    stock: 40,
    badge: '১০০% ন্যাচারাল গ্লো',
    badgeColor: 'bg-rose-600',
    descriptionBn: 'প্রাকৃতিক শ্বেত চন্দন, নিম ও মুলতানি মাটির নিখুঁত ভেষজ ব্লেন্ড। ত্বকের দাগ ও তৈলাক্ততা দূর করে ইনস্ট্যান্ট উজ্জ্বলতা দেয়।',
    descriptionEn: 'Pure organic herbal glowing facepack for natural skin radiance and oil balance.',
    features: ['সম্পূর্ণ কেমিক্যাল ও প্যারাবেনমুক্ত', 'ত্বকের রোদে পোড়া দাগ দূর করে', 'তৈলাক্ত ও সংবেদনশীল ত্বকে উপযুক্ত']
  },

  // ৩৫. কসমেটিক - খাঁটি পাহাড়ি ঘৃতকুমারী / অ্যালোভেরা জেল (Cosmetics)
  {
    id: 'prod_aloevera_gel',
    nameBn: '৯৯% খাঁটি পাহাড়ি ঘৃতকুমারী সুদিং অ্যালোভেরা জেল (২৫০ গ্রাম)',
    nameEn: '99% Pure Organic Mountain Aloe Vera Soothing Gel (250g)',
    category: 'Cosmetics',
    categoryLabelBn: 'কসমেটিক',
    price: 250,
    originalPrice: 320,
    unit: '২৫০ গ্রাম প্যাক',
    origin: 'বান্দরবান ফার্ম',
    image: 'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 92,
    stock: 55,
    badge: 'অর্গানিক স্কিন কেয়ার',
    badgeColor: 'bg-emerald-600',
    descriptionBn: 'পাহাড়ের বাগান থেকে তাজা কাটা ঘৃতকুমারীর নির্যাসে তৈরি নন-স্টিকি সুদিং জেল। ত্বক ও চুলের ডিপ ময়শ্চারাইজেশনের জন্য অসাধারণ।',
    descriptionEn: 'Ultra-hydrating 99% pure soothing aloe vera gel for face, hair and body.',
    features: ['কোনো কৃত্রিম সুগন্ধি বা আঠা নেই', 'ত্বক নরম ও কোমল রাখে', 'চুলের খুশকি ও রুক্ষতা দূর করে']
  },

  // ৩৬. ঔষধ ও স্বাস্থ্যসেবা - পাহাড়ি ভেষজ ফার্স্ট এইড ও ন্যাচারাল রিলিফ মলম (Medicines)
  {
    id: 'prod_herbal_balm',
    nameBn: 'পাহাড়ি নীলগিরি ইউক্যালিপটাস ও লবঙ্গ পেইন রিলিফ বাম (৫০ গ্রাম)',
    nameEn: 'Mountain Eucalyptus & Clove Fast Pain Relief Balm (50g)',
    category: 'Medicines',
    categoryLabelBn: 'ঔষধ',
    price: 180,
    originalPrice: 240,
    unit: '৫০ গ্রাম জার',
    origin: 'বান্দরবান আয়ুর্বেদ ল্যাব',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 110,
    stock: 70,
    badge: 'দ্রুত ব্যথা উপশম',
    badgeColor: 'bg-blue-700',
    descriptionBn: 'মাথাব্যথা, সর্দি, জয়েন্টের ব্যথা ও পেশির টানে দ্রুত আরামদায়ক খাঁটি ইউক্যালিপটাস ও পুদিনা পাতার ভেষজ ঔষধ।',
    descriptionEn: 'Fast acting organic herbal pain relief balm with pure eucalyptus and wintergreen oils.',
    features: ['১০ মিনিটে দ্রুত ব্যথা উপশম', 'শতভাগ পার্শ্বপ্রতিক্রিয়াহীন ভেষজ', 'মাথাব্যথা ও সর্দিতে কার্যকর']
  },

  // ৩৭. ঔষধ ও স্বাস্থ্যসেবা - ফ্যামিলি এসেনশিয়াল ফার্স্ট এইড কিট বক্স (Medicines)
  {
    id: 'prod_first_aid_box',
    nameBn: 'কমপ্লিট হোম ও ইমার্জেন্সি মেডিকেল ফার্স্ট এইড বক্স সেট',
    nameEn: 'Complete Emergency Home & Travel First Aid Medical Kit',
    category: 'Medicines',
    categoryLabelBn: 'ঔষধ',
    price: 650,
    originalPrice: 850,
    unit: '১টি পূর্ণাঙ্গ বক্স',
    origin: 'ঢাকা হেলথকেয়ার',
    image: 'https://images.unsplash.com/photo-1603398938378-e54eab446dde?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 78,
    stock: 35,
    badge: 'জরুরি প্রাথমিক চিকিৎসা',
    badgeColor: 'bg-red-600',
    descriptionBn: 'ব্যান্ডেজ, অ্যান্টিসেপটিক সলিউশন, গজ, থার্মোমিটার, বার্ন ক্রিম, কাঁচি ও প্রাথমিক ঔষধি সরঞ্জাম সহ পোর্টেবল ফার্স্ট এইড কিট।',
    descriptionEn: 'Comprehensive ISO certified emergency medical first aid box for home, school and travel.',
    features: ['১৮ ধরনের জরুরি প্রাথমিক চিকিৎসা সরঞ্জাম', 'ওয়াটারপ্রুফ কমপ্যাক্ট ক্যারি বক্স', 'পরিবারের সুরক্ষায় অপরিহার্য']
  },

  // ৩৮. আসবাবপত্র - খাঁটি সেগুন কাঠের ফোল্ডিং রিল্যাক্স রকিং ইজি চেয়ার (Furniture)
  {
    id: 'prod_wooden_easy_chair',
    nameBn: 'খাঁটি পাহাড়ি সেগুন কাঠের ফোল্ডিং ইজি চেয়ার ও রিলাক্স সিট',
    nameEn: 'Solid CHT Teak Wood Folding Armchair & Easy Lounger',
    category: 'Furniture',
    categoryLabelBn: 'আসবাবপত্র',
    price: 4500,
    originalPrice: 5500,
    unit: '১টি চেয়ার',
    origin: 'খাগড়াছড়ি কাঠশিল্প',
    image: 'https://images.unsplash.com/photo-1580481077197-0628e932b130?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 34,
    stock: 12,
    badge: '১০০% অরিজিনাল সেগুন',
    badgeColor: 'bg-amber-800',
    descriptionBn: 'পাহাড়ের পরিপক্ব সেগুন কাঠ ও ঐতিহ্যবাহী কারুকাজে তৈরি দীর্ঘস্থায়ী আরামদায়ক ফোল্ডিং ইজি চেয়ার। বারান্দা বা বসার ঘরের জন্য উপযুক্ত।',
    descriptionEn: 'Handcrafted solid mature teak wood foldable relaxation easy chair with natural polish.',
    features: ['ঘুণপোকা প্রতিরোধী সিজনড সেগুন কাঠ', 'সহজে ভাঁজ করে বহনযোগ্য', '২০ বছরের স্থায়িত্বের নিশ্চয়তা']
  },

  // ৩৯. আসবাবপত্র - প্রিমিয়াম সলিড উডেন ডাইনিং ও স্টাডি টেবিল (Furniture)
  {
    id: 'prod_solid_wood_table',
    nameBn: 'পাহাড়ি সেগুন ও গর্জন কাঠের আধুনিক স্টাডি ও অফিস ডেস্ক',
    nameEn: 'Modern Ergonomic Solid Wood Multi-Utility Study Desk',
    category: 'Furniture',
    categoryLabelBn: 'আসবাবপত্র',
    price: 7800,
    originalPrice: 9500,
    unit: '১টি সেট',
    origin: 'রাঙামাটি ফার্নিচার',
    image: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 22,
    stock: 8,
    badge: 'মিনিমালিস্ট ডিজাইন',
    badgeColor: 'bg-amber-900',
    descriptionBn: 'লেপটপ ড্রয়ার ও ক্যাবল ম্যানেজমেন্ট স্লট সহ নিখুঁত মসৃণ ফিনিশিংয়ের পরিবেশবান্ধব টেকসই কাঠের টেবিল।',
    descriptionEn: 'Premium hardwood ergonomic study and office table with storage drawers.',
    features: ['মসৃণ লেকার পলিশ ফিনিশ', 'শক্তিশালী লোড বেয়ারিং সক্ষমতা', 'স্মার্ট স্টোরেজ স্পেস']
  },

  // ৪০. নির্মাণাধীন সামগ্রী - BSRM 500W গ্রেড রড ও স্টিল (Construction Materials)
  {
    id: 'prod_construction_rod',
    nameBn: 'BSRM আল্ট্রামেগা 500W TMT প্রিমিয়াম গ্রেড কনস্ট্রাকশন রড (প্রতি টন)',
    nameEn: 'BSRM Ultima 500W TMT Grade High Strength Steel Rod (Per Ton)',
    category: 'Construction',
    categoryLabelBn: 'নির্মাণাধীন সামগ্রী',
    price: 88500,
    originalPrice: 92000,
    unit: '১ টন বান্ডিল',
    origin: 'চট্টগ্রাম স্টিল মিল',
    image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 46,
    stock: 200,
    badge: 'বুয়েট সার্টিফাইড 500W',
    badgeColor: 'bg-slate-800',
    descriptionBn: 'ভূমিকম্প সহনশীল উচ্চ নমনীয়তা ও সর্বোচ্চ শক্তির শতভাগ অথেনটিক BSRM রড। সরাসরি মিল থেকে সরবরাহযোগ্য।',
    descriptionEn: 'High yield strength earthquake-resistant TMT construction steel reinforcement bars.',
    features: ['সর্বোচ্চ প্রসার্য শক্তি ও নমনীয়তা', 'ভূমিকম্প প্রতিরোধক রিব স্ট্রাকচার', 'খাগড়াছড়ি ও রাঙামাটিতে দ্রুত সাইট ডেলিভারি']
  },

  // ৪১. নির্মাণাধীন সামগ্রী - লাফার্জহোলসিম প্রিমিয়াম সিমেন্ট ব্যাগ (Construction Materials)
  {
    id: 'prod_holcim_cement',
    nameBn: 'হোলসিম স্ট্রং স্ট্রাকচার পোর্টল্যান্ড কম্পোজিট সিমেন্ট (PCC)',
    nameEn: 'Holcim Strong Structure Premium PCC Cement (50kg Bag)',
    category: 'Construction',
    categoryLabelBn: 'নির্মাণাধীন সামগ্রী',
    price: 540,
    originalPrice: 580,
    unit: '৫০ কেজি ব্যাগ',
    origin: 'লাফার্জহোলসিম বাংলাদেশ',
    image: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 84,
    stock: 500,
    badge: 'উচ্চ বাঁধাই ক্ষমতা',
    badgeColor: 'bg-slate-700',
    descriptionBn: 'ছাদ ঢালাই, পিলার ও ফাউন্ডেশন তৈরিতে সর্বোচ্চ স্থায়িত্ব এবং দীর্ঘস্থায়ী মজবুতির জন্য প্রথম সারির প্রিমিয়াম সিমেন্ট।',
    descriptionEn: 'High early strength hydraulic blended cement suitable for heavy RCC foundations.',
    features: ['আর্দ্রতা প্রতিরোধী উন্নত প্যাকিং', 'দ্রুত সেটিং ও জমাট বাঁধা শক্তি', 'ফাটল প্রতিরোধী সক্ষমতা']
  },

  // ৪২. খেলনা - শিশুদের কাঠের এডুকেশনাল পাজল ও ট্রয় ট্রেন সেট (Toys)
  {
    id: 'prod_educational_wooden_toy',
    nameBn: 'পরিবেশবান্ধব কাঠের বর্ণমালা, সংখ্যা ও ট্রয় ট্রেন এডুকেশনাল টয় সেট',
    nameEn: 'Eco-Friendly Non-Toxic Wooden Educational Alphabet & Train Set',
    category: 'Toys',
    categoryLabelBn: 'খেলনা',
    price: 480,
    originalPrice: 650,
    unit: '১টি বক্স সেট',
    origin: 'খাগড়াছড়ি ক্রাফট',
    image: 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 58,
    stock: 40,
    badge: 'নন-টক্সিক ও নিরাপদ',
    badgeColor: 'bg-pink-600',
    descriptionBn: 'শিশুদের মস্তিষ্কের বিকাশ ও বর্ণমালার শেখার জন্য মসৃণ কাঠের তৈরি ক্ষতিকর রঙমুক্ত আকর্ষণীয় খেলনা সেট।',
    descriptionEn: 'Hand-sanded non-toxic water-based color wooden educational blocks and train set for toddlers.',
    features: ['ধারহীন মসৃণ গোল ফ্রেম', 'শিশুদের বুদ্ধিমত্তা ও সৃজনশীলতা বৃদ্ধি করে', '১০০% শিশুদের জন্য নিরাপদ রঙ']
  },

  // ৪৩. খেলনা - হাই-স্পিড ৪x৪ মাউন্টেন রিমোট কন্ট্রোল কার (Toys)
  {
    id: 'prod_rc_monster_truck',
    nameBn: 'রিচার্জেবল ৪x৪ অল-টেরেন অফ-রোড মাউন্টেন RC মনস্টার কার',
    nameEn: 'Rechargeable 4WD High-Speed All-Terrain RC Rock Crawler',
    category: 'Toys',
    categoryLabelBn: 'খেলনা',
    price: 1250,
    originalPrice: 1650,
    unit: '১টি কার সেট',
    origin: 'গ্যাজেট অ্যান্ড টয় জোন',
    image: 'https://images.unsplash.com/photo-1594787318286-3d835c1d207f?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 76,
    stock: 25,
    badge: 'শকপ্রুফ অফ-রোডার',
    badgeColor: 'bg-red-600',
    descriptionBn: 'পাহাড়ি উঁচু-নিচু রাস্তা ও ঘাসে সহজে চলতে সক্ষম শক্তিশালী স্প্রিং শক অ্যাবসর্বার ও রিচার্জেবল ব্যাটারি যুক্ত রিমোট কার।',
    descriptionEn: 'Durable 2.4GHz remote control 4WD crawler truck with high grip rubber tires.',
    features: ['৫০ মিটার রিমোট রেঞ্জ', 'পাহাড়ি ঢাল বেয়ে ওঠার ক্ষমতা', 'ইউএসবি ফাস্ট চার্জিং সুবিধা']
  },

  // ৪৪. বইপত্র - পার্বত্য চট্টগ্রামের ইতিহাস, ঐতিহ্য ও সংস্কৃতি বিশ্বকোষ (Books)
  {
    id: 'prod_cht_history_book',
    nameBn: 'পার্বত্য চট্টগ্রামের ইতিহাস, সংস্কৃতি ও লোকঐতিহ্য (হার্ডকভার সংকলন)',
    nameEn: 'Chronicles & Cultural Heritage of Chittagong Hill Tracts',
    category: 'Books',
    categoryLabelBn: 'বইপত্র',
    price: 520,
    originalPrice: 650,
    unit: '১টি হার্ডকভার বই',
    origin: 'খাগড়াছড়ি সাহিত্য পরিষদ',
    image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 42,
    stock: 50,
    badge: 'বেস্টসেলার গবেষণা গ্রন্থ',
    badgeColor: 'bg-indigo-800',
    descriptionBn: 'চাকমা, মারমা, ত্রিপুরা সহ ১১টি জাতিগোষ্ঠীর প্রাচীন ইতিহাস, ঐতিহ্য, ভাষা, উৎসব ও রাজকীয় সনদপত্রের প্রামাণ্য দলিল।',
    descriptionEn: 'Authentic illustrated historical and ethnographical documentation of CHT communities.',
    features: ['উন্নত আর্ট পেপার ও পূর্ণাঙ্গ রঙিন ছবি', 'বিরল নথিপত্র ও মানচিত্র সংযোজন', 'গবেষক ও পাঠকদের জন্য প্রামাণ্য বই']
  },

  // ৪৫. বইপত্র - শিক্ষার্থীদের একাডেমিক স্টাডি গাইড ও ইংলিশ গ্রামার স্পেশাল (Books)
  {
    id: 'prod_academic_english_book',
    nameBn: 'সহজ ভাষায় ইংরেজি ব্যাকরণ ও ভোকাবুলারি মাস্টার (কমপ্লিট গাইড)',
    nameEn: 'Essential English Grammar & Vocabulary Mastery Guide',
    category: 'Books',
    categoryLabelBn: 'বইপত্র',
    price: 340,
    originalPrice: 450,
    unit: '১টি বই',
    origin: 'ঢাকা পাবলিকেশন্স',
    image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 95,
    stock: 80,
    badge: 'সকল ক্লাসের উপযোগী',
    badgeColor: 'bg-teal-700',
    descriptionBn: 'বাংলা ভাষায় প্রতিটি নিয়ম সহজ ব্যাখ্যা ও হাজারো প্র্যাকটিস সেট সহ প্রস্তুতকৃত ইংরেজি শেখার বিশ্বস্ত বই।',
    descriptionEn: 'Comprehensive practical English grammar learning workbook with Bengali explanations.',
    features: ['সহজ উদাহরণ ও বাংলা উচ্চারণ', 'চাকরি ও ভর্তি পরীক্ষার বিশেষ অধ্যায়', 'সহজ টিপস ও শর্টকাট কৌশল']
  },

  // ৪৬. ঝাদিমাটি স্পেশাল - প্রিমিয়াম পাহাড়ি অর্গানিক গিফট বক্স (Jhadimadi Specials)
  {
    id: 'prod_jhadimadi_exclusive_box',
    nameBn: 'ঝাদিমাটি এক্সক্লুসিভ পাহাড়ি অর্গানিক স্পেশাল গিফট বক্স',
    nameEn: 'Jhadimadi Signature CHT Pure Organic Deluxe Gift Hamper',
    category: 'Jhadimadi',
    categoryLabelBn: 'ঝাদিমাটি স্পেশাল',
    price: 2450,
    originalPrice: 2950,
    unit: '১টি ভিআইপি কাঠের বক্স',
    origin: 'ঝাদিমাটি হেডকোয়ার্টার্স',
    image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 168,
    stock: 25,
    badge: 'ঝাদিমাটি সিগনেচার',
    badgeColor: 'bg-[#0A6A32]',
    descriptionBn: 'খাঁটি পাহাড়ি বনের চাকের মধু, জুমের সোনালী হলুদ, আদা, পাহাড়ি শাল ও এথনিক কাঠের বাস্কেট সমন্বয়ে তৈরি প্রিমিয়াম গিফট হ্যাম্পার।',
    descriptionEn: 'Curated premium organic gift hamper comprising raw forest honey, jhum turmeric and artisan craft.',
    features: ['শতভাগ খাঁটি পাহাড়ি পণ্যের সমাহার', 'আভিজাত্যপূর্ণ কাঠের পরিবেশন বক্স', 'বিশেষ উৎসব ও উপহারের জন্য সেরা']
  },

  // ৪৭. রিয়েল এস্টেট - খাগড়াছড়ি সদর সংলগ্ন টিলা ও আমবাগান প্লট (Real Estate)
  {
    id: 'prod_realestate_mango_orchard',
    nameBn: 'খাগড়াছড়ি সদরে ফলন্ত আমবাগান ও রিসোর্ট উপযোগী ৫ একর টিলা জমি',
    nameEn: '5-Acre Fruitful Mango Orchard & Eco-Resort Hill Plot in Khagrachhari',
    category: 'RealEstate',
    categoryLabelBn: 'রিয়েল এস্টেট',
    price: 3500000,
    originalPrice: 4000000,
    unit: '১টি পূর্ণাঙ্গ প্লট (৫ একর)',
    origin: 'খাগড়াছড়ি সদর',
    image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 19,
    stock: 1,
    badge: 'নিষ্কণ্টক কবুলিয়াত জমি',
    badgeColor: 'bg-emerald-800',
    descriptionBn: 'পাকা সড়ক ও সার্বক্ষণিক বিদ্যুৎ-পানি সুবিধা যুক্ত ফলন্ত আম্রপালি ও মাল্টা বাগান সহ রিসোর্ট, খামার বা কটেজ নির্মাণের জন্য আদর্শ পাহাড়ি জমি।',
    descriptionEn: 'Prime highland with 300+ fruiting mango trees, road connectivity and freehold hill ownership documents.',
    features: ['১০০% নিষ্কণ্টক ও ক্লিয়ার রেকর্ডস', 'সড়ক যোগাযোগ ও বিদ্যুৎ সংযোগ বিদ্যমান', 'ইকো-রিসোর্ট বা কৃষি খামারের জন্য আদর্শ']
  },

  // ৪৮. রিয়েল এস্টেট - রাঙামাটি লেক ভিউ প্রিমিয়াম রেসিডেন্সিয়াল প্লট (Real Estate)
  {
    id: 'prod_realestate_lakeview_plot',
    nameBn: 'রাঙামাটি কাপ্তাই লেক ভিউ প্রিমিয়াম রেসিডেন্সিয়াল হোমস্টে প্লট (৮ শতক)',
    nameEn: 'Rangamati Kaptai Lake-Facing Premium Residential Homestay Plot (8 Decimals)',
    category: 'RealEstate',
    categoryLabelBn: 'রিয়েল এস্টেট',
    price: 1850000,
    originalPrice: 2200000,
    unit: '৮ শতক প্লট',
    origin: 'রাঙামাটি তবলছড়ি',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 28,
    stock: 2,
    badge: 'কাপ্তাই লেক ভিউ',
    badgeColor: 'bg-sky-800',
    descriptionBn: 'লেকমুখী নয়নাভিরাম পরিবেশ, ড্রেনেজ ও প্রধান সড়ক সংলগ্ন ব্যক্তিগত অবকাশ যাপন বাড়ি অথবা হোমস্টে তৈরির আকর্ষণীয় প্লট।',
    descriptionEn: 'Scenic waterfront land plot overlooking Kaptai Lake with approved building clearance.',
    features: ['মনোরম লেক ফ্রন্ট লোকেশন', 'প্রাকৃতিক বাতাস ও শান্ত পরিবেশ', 'সব ধরণের নাগরিক সুবিধা সম্বলিত']
  }
];

