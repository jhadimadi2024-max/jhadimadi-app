import { District } from '../types';

export interface VendorStoreProduct {
  id: string;
  nameBn: string;
  nameEn: string;
  category: string;
  categoryLabelBn: string;
  price: number;
  originalPrice: number;
  unit: string;
  stock: number;
  origin: string; // Micro-location (e.g. খাগড়াছড়ি সদর > মধুপুর বাজার)
  district: string;
  upazila: string;
  mahalla: string;
  bazarName?: string;
  image: string;
  images: string[]; // 5 to 10 high-quality gallery images
  rating: number;
  reviewsCount: number;
  badge?: string;
  badgeColor?: string;
  descriptionBn: string;
  descriptionEn: string;
  features: string[];
  specifications: { labelBn: string; valueBn: string }[]; // Quality specs
  variants?: {
    sizes?: { nameBn: string; priceOffset: number }[];
    colors?: { nameBn: string; hex: string }[];
  };
  warranty?: string;
  qrCode?: string;
  barcode?: string;
  isOrganic?: boolean;
  featuredOnHome?: boolean;
  sellerId: string;
  sellerUniqueId: string; // e.g. V-KHG-001
  sellerShopName: string;
  sellerOwnerName: string;
  sellerAvatar?: string;
  sellerRating?: number;
  sellerPhoneMasked?: string;
  sellerRealPhone?: string;
  verifiedSeller?: boolean;
}

export interface VendorEscrowSettlement {
  id: string;
  orderId: string;
  productName: string;
  customerName: string;
  customerPhoneMasked: string;
  grossAmount: number;
  platformFee5Percent: number; // 5% Jhadimadi platform commission
  netPayout95Percent: number; // 95% Vendor net earnings
  date: string;
  status: 'Held_In_Escrow' | 'Delivered_Settled' | 'Disputed' | 'Refunded';
}

export interface VendorCashoutTransaction {
  id: string;
  amount: number;
  method: 'bKash' | 'Nagad' | 'Bank';
  accountNumber: string;
  bankName?: string;
  date: string;
  status: 'Completed' | 'Pending' | 'Rejected';
  trxId: string;
}

export interface VendorStore {
  id: string;
  uniqueId: string; // V-[District Code]-[Serial], e.g. V-KHG-001, V-RNG-001
  shopName: string;
  shopNameEn: string;
  ownerName: string;
  avatar: string;
  banner: string;
  coverBanner?: string;
  phone?: string;
  phoneMasked: string; // 018****-***78
  realPhone: string;
  division: string;
  district: string;
  upazila: string;
  mahalla: string;
  bazarName: string;
  detailedAddress: string;
  rating: number;
  reviewsCount: number;
  positiveRatingPercent: number; // e.g. 98%
  shipOnTimePercent: number; // e.g. 99%
  responseRatePercent: number; // e.g. 95%
  followersCount: number;
  isVerified: boolean;
  verifiedBadgeText: string;
  categories: string[];
  aboutBn: string;
  bio?: string;
  tradeLicenseNumber: string;
  nidNumberMasked: string;
  establishedYear: string;
  wallet: {
    grossSales: number;
    totalCommissionPaid?: number; // 5%
    availableBalance: number; // 95% net
    pendingEscrowBalance?: number;
    pendingPayouts?: number;
    completedPayouts?: number;
    totalOrdersCount?: number;
    cashouts: (VendorCashoutTransaction | any)[];
    escrowSettlements?: VendorEscrowSettlement[];
  };
  products: VendorStoreProduct[];
}

export const INITIAL_VENDOR_STORES: VendorStore[] = [
  // 1. খাগড়াছড়ি অর্গানিক ফার্ম ও মশলা বিতান (V-KHG-001)
  {
    id: 'vendor_khg_001',
    uniqueId: 'V-KHG-001',
    shopName: 'পাহাড়ি কৃষি ও অর্গানিক খামার',
    shopNameEn: 'Pahari Krishi & Organic Khamar',
    ownerName: 'বিপ্লব ত্রিপুরা (Biplob Tripura)',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    banner: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=1200&q=80',
    phoneMasked: '01812****-***89',
    realPhone: '01812345689',
    division: 'Chittagong Division (চট্টগ্রাম)',
    district: 'Khagrachhari',
    upazila: 'Khagrachhari Sadar',
    mahalla: 'মধুপুর বাজার',
    bazarName: 'মধুপুর কৃষি বাজার, দোকান নং ১৪',
    detailedAddress: 'দোকান নং ১৪, মধুপুর বাজার রোড, খাগড়াছড়ি সদর, খাগড়াছড়ি',
    rating: 0,
    reviewsCount: 0,
    positiveRatingPercent: 100,
    shipOnTimePercent: 100,
    responseRatePercent: 100,
    followersCount: 0,
    isVerified: true,
    verifiedBadgeText: 'অফিসিয়াল ভেরিফাইড মার্চেন্ট [✓]',
    categories: ['পাহাড়ি মশলা ও শস্য', 'জুমের অর্গানিক হলুদ ও আদা', 'খাঁটি চালের গুঁড়া'],
    aboutBn: 'আমরা খাগড়াছড়ির স্থানীয় জুম চাষীদের কাছ থেকে সরাসরি শতভাগ রাসায়নিকমুক্ত পাহাড়ি চালের গুঁড়া, বোম্বাই ঝাল মরিচের গুঁড়া, জুমের হলুদ ও কাঁচা আদা প্রক্রিয়াজাত করে দেশব্যাপী সরবরাহ করি।',
    tradeLicenseNumber: 'TRAD/KHG/SADAR/2024/0981',
    nidNumberMasked: '1988****-***45',
    establishedYear: '২০২১',
    wallet: {
      grossSales: 0,
      totalCommissionPaid: 0,
      availableBalance: 0,
      pendingEscrowBalance: 0,
      cashouts: [],
      escrowSettlements: []
    },
    products: [
      {
        id: 'vprod_khg_1',
        nameBn: 'খাঁটি পাহাড়ি চালের গুঁড়া (১ কেজি প্রিমিয়াম প্যাক)',
        nameEn: 'Pure Hill Aromatic Rice Flour (1kg)',
        category: 'SpicesGrains',
        categoryLabelBn: 'পাহাড়ি মশলা ও শস্য',
        price: 120,
        originalPrice: 150,
        unit: '১ কেজি প্যাকেট',
        stock: 65,
        origin: 'খাগড়াছড়ি সদর > মধুপুর বাজার',
        district: 'Khagrachhari',
        upazila: 'Khagrachhari Sadar',
        mahalla: 'মধুপুর বাজার',
        bazarName: 'মধুপুর কৃষি বাজার',
        image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
        images: [
          'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?auto=format&fit=crop&w=800&q=80',
        ],
        rating: 4.9,
        reviewsCount: 94,
        badge: '১০০% ঢেঁকি ছাঁটা খাঁটি',
        badgeColor: 'bg-emerald-600',
        descriptionBn: 'পাহাড়ি আতপ ও বিনি চাল ঢেঁকিতে ভাঙানো সম্পূর্ণ প্রিজারভেটিভমুক্ত খাঁটি চালের গুঁড়া। চিতই, ভাপা পিঠা ও পাহাড়ি ঐতিহ্যবাহী পিঠার জন্য সেরা। কোনো কৃত্রিম ফ্লেভার বা কেমিক্যাল ছাড়া সরাসরি মধুপুর বাজার থেকে প্যাকেটজাত।',
        descriptionEn: 'Stone ground mountain rice flour processed from organic hill bini rice without artificial bleach or preservatives.',
        features: ['ভেজালমুক্ত শতভাগ খাঁটি', 'ঘরোয়া ঢেঁকি ছাঁটা সুবাস', 'চিতই, ভাপা ও নকশি পিঠার জন্য আদর্শ', '৩ মাস ভালো থাকে'],
        specifications: [
          { labelBn: 'পণ্য কোড / বারকোড', valueBn: 'JM-KHG-RICE-001' },
          { labelBn: 'চালের প্রকার', valueBn: 'পাহাড়ি আতপ ও লাল বিনি চাল মিশ্রণ' },
          { labelBn: 'উৎপত্তিস্থল', valueBn: 'খাগড়াছড়ি সদর (মধুপুর এলাকা)' },
          { labelBn: 'প্রিজারভেটিভ ও কালার', valueBn: '০% কেমিক্যাল (সম্পূর্ণ প্রাকৃতিক)' },
          { labelBn: 'সংরক্ষণ মেয়াদ', valueBn: 'শুষ্ক স্থানে ৯০ দিন' },
          { labelBn: 'কোয়ালিটি গ্রেড', valueBn: 'গ্রেড-১ প্রিমিয়াম এক্সপোর্ট কোয়ালিটি' },
          { labelBn: 'এসক্রো গ্যারান্টি', valueBn: 'ঝাদিমাদি ১০০% ডেলিভারি প্রটেকশন' }
        ],
        variants: {
          sizes: [
            { nameBn: '৫০০ গ্রাম প্যাক', priceOffset: -50 },
            { nameBn: '১ কেজি প্যাক (রেগুলার)', priceOffset: 0 },
            { nameBn: '২ কেজি ফ্যামিলি প্যাক', priceOffset: 110 },
            { nameBn: '৫ কেজি বাল্ক ব্যাগ', priceOffset: 450 },
          ]
        },
        warranty: 'পণ্য পাওয়ার পর সন্তুষ্ট না হলে ৭ দিনের মধ্যে ১০০% ক্যাশব্যাক গ্যারান্টি।',
        qrCode: 'JM-V-KHG-001-PROD-01',
        barcode: '8941200192847',
        isOrganic: true,
        sellerId: 'vendor_khg_001',
        sellerUniqueId: 'V-KHG-001',
        sellerShopName: 'পাহাড়ি কৃষি ও অর্গানিক খামার',
        sellerOwnerName: 'বিপ্লব ত্রিপুরা',
        sellerAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
        sellerRating: 4.9,
        sellerPhoneMasked: '01812****-***89',
        sellerRealPhone: '01812345689'
      },
      {
        id: 'vprod_khg_2',
        nameBn: 'পাহাড়ি বোম্বাই ঝাল মরিচের গুঁড়া (২৫০ গ্রাম জার)',
        nameEn: 'Hill Naga Hot Red Chili Powder (250g)',
        category: 'SpicesGrains',
        categoryLabelBn: 'পাহাড়ি মশলা ও শস্য',
        price: 160,
        originalPrice: 195,
        unit: '২৫০ গ্রাম জার',
        stock: 50,
        origin: 'খাগড়াছড়ি সদর > মধুপুর বাজার',
        district: 'Khagrachhari',
        upazila: 'Khagrachhari Sadar',
        mahalla: 'মধুপুর বাজার',
        bazarName: 'মধুপুর কৃষি বাজার',
        image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80',
        images: [
          'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1588252303782-cb80119abd6d?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1628088062854-d1870b4553da?auto=format&fit=crop&w=800&q=80',
        ],
        rating: 4.8,
        reviewsCount: 128,
        badge: 'তীব্র ঝাল ও আসল রঙ',
        badgeColor: 'bg-red-600',
        descriptionBn: 'খাগড়াছড়ির পাহাড়ি জুমের রোদে শুকানো বোম্বাই ও নাগা মরিচের খাঁটি গুঁড়া। কোনো কৃত্রিম রঙ বা ইটগুঁড়া নেই, প্রাকৃতিক রঙ ও ঝাঁঝালো সুবাসে ভরপুর।',
        descriptionEn: 'Naturally sun-dried fire-hot authentic mountain chili powder packed in airtight food-grade jar.',
        features: ['কোনো কৃত্রিম রঙ নেই', 'পাহাড়ি জুমের তাজা মরিচ', 'তীব্র সুবাস ও খাঁটি ঝাঁঝ', 'বায়ুরোধী ফুড গ্রেড জার'],
        specifications: [
          { labelBn: 'বারকোড', valueBn: 'JM-KHG-CHILI-002' },
          { labelBn: 'মরিচের জাত', valueBn: 'পাহাড়ি বোম্বাই ও নাগা ঝাল মরিচ' },
          { labelBn: 'শুকানোর পদ্ধতি', valueBn: 'প্রাকৃতিক কড়া রোদে ড্রাইং' },
          { labelBn: 'ঝালের মাত্রা (Scoville)', valueBn: 'উচ্চ ঝাল (Extra Hot Grade)' },
          { labelBn: 'প্যাকিং', valueBn: 'বায়ুরোধী পিইটি কন্টেইনার' },
          { labelBn: 'মেয়াদ', valueBn: '১২ মাস' }
        ],
        variants: {
          sizes: [
            { nameBn: '১০০ গ্রাম ট্রায়াল জার', priceOffset: -75 },
            { nameBn: '২৫০ গ্রাম জার (স্ট্যান্ডার্ড)', priceOffset: 0 },
            { nameBn: '৫০০ গ্রাম জার', priceOffset: 140 },
          ]
        },
        warranty: 'ভেজাল প্রমাণিত হলে মূল্যের দ্বিগুণ ক্ষতিপূরণ।',
        qrCode: 'JM-V-KHG-001-PROD-02',
        barcode: '8941200192854',
        isOrganic: true,
        sellerId: 'vendor_khg_001',
        sellerUniqueId: 'V-KHG-001',
        sellerShopName: 'পাহাড়ি কৃষি ও অর্গানিক খামার',
        sellerOwnerName: 'বিপ্লব ত্রিপুরা',
        sellerAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
        sellerRating: 4.9,
        sellerPhoneMasked: '01812****-***89',
        sellerRealPhone: '01812345689'
      },
      {
        id: 'vprod_khg_3',
        nameBn: 'পাহাড়ি জুমের খাঁটি হলুদের গুঁড়া (৫০০ গ্রাম প্যাক)',
        nameEn: 'Pure Hill Jhum Turmeric Powder (500g)',
        category: 'SpicesGrains',
        categoryLabelBn: 'পাহাড়ি মশলা ও শস্য',
        price: 180,
        originalPrice: 220,
        unit: '৫০০ গ্রাম প্যাক',
        stock: 40,
        origin: 'খাগড়াছড়ি সদর > মধুপুর বাজার',
        district: 'Khagrachhari',
        upazila: 'Khagrachhari Sadar',
        mahalla: 'মধুপুর বাজার',
        bazarName: 'মধুপুর কৃষি বাজার',
        image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80',
        images: [
          'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1615485500704-8e990f9900f7?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80',
        ],
        rating: 5.0,
        reviewsCount: 165,
        badge: 'উচ্চ কারকিউমিন অর্গানিক',
        badgeColor: 'bg-amber-600',
        descriptionBn: 'উঁচু পাহাড়ের খাঁড়া ঢালে ফলানো গভীর সোনালী পাহাড়ি জুমের হলুদ। উচ্চ কারকিউমিন সমৃদ্ধ ও ঔষধি গুণসম্পন্ন। রান্নায় অপূর্ব রঙ ও স্বাস্থ্য সুরক্ষায় অসাধারণ।',
        descriptionEn: 'High-curcumin golden wild hill turmeric stone-powdered with zero chemicals.',
        features: ['উচ্চ কারকিউমিন সমৃদ্ধ', 'গাঢ় প্রাকৃতিক সোনালী রঙ', 'আসল পাহাড়ি কাঁচা হলুদের ঘ্রাণ', 'অ্যান্টিসেপটিক গুণসম্পন্ন'],
        specifications: [
          { labelBn: 'বারকোড', valueBn: 'JM-KHG-TURM-003' },
          { labelBn: 'কারকিউমিন পারসেন্টেজ', valueBn: '৫.৫%+ (সাধারণ হলুদের দ্বিগুণ)' },
          { labelBn: 'উৎপাদন স্থান', valueBn: 'খাগড়াছড়ি পাহাড়ি জুম' },
          { labelBn: 'প্যাকেজিং', valueBn: 'ফয়েল লাইন্ড ফুড গ্রেড পাউচ' },
          { labelBn: 'মেয়াদ', valueBn: '১৮ মাস' }
        ],
        variants: {
          sizes: [
            { nameBn: '২৫০ গ্রাম প্যাক', priceOffset: -85 },
            { nameBn: '৫০০ গ্রাম প্যাক (স্ট্যান্ডার্ড)', priceOffset: 0 },
            { nameBn: '১ কেজি প্যাক', priceOffset: 160 },
          ]
        },
        warranty: 'শতভাগ খাঁটি ও ক্যামিকেলমুক্ত হওয়ার নিশ্চয়তা।',
        qrCode: 'JM-V-KHG-001-PROD-03',
        barcode: '8941200192861',
        isOrganic: true,
        sellerId: 'vendor_khg_001',
        sellerUniqueId: 'V-KHG-001',
        sellerShopName: 'পাহাড়ি কৃষি ও অর্গানিক খামার',
        sellerOwnerName: 'বিপ্লব ত্রিপুরা',
        sellerAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
        sellerRating: 4.9,
        sellerPhoneMasked: '01812****-***89',
        sellerRealPhone: '01812345689'
      }
    ]
  },

  // 2. কাপ্তাই লেক পিউর শুঁটকি ও সিদল সেন্টার (V-RNG-001)
  {
    id: 'vendor_rng_001',
    uniqueId: 'V-RNG-001',
    shopName: 'কাপ্তাই লেক পিউর শুঁটকি ও সিদল সেন্টার',
    shopNameEn: 'Kaptai Lake Pure Shutki & Fish Center',
    ownerName: 'মং প্রু মারমা (Mong Pru Marma)',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    banner: 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=1200&q=80',
    phoneMasked: '01823****-***12',
    realPhone: '01823456712',
    division: 'Chittagong Division (চট্টগ্রাম)',
    district: 'Rangamati',
    upazila: 'Rangamati Sadar',
    mahalla: 'বনরুপা বাজার',
    bazarName: 'বনরুপা শুঁটকি মার্কেট, দোকান নং ০৭',
    detailedAddress: 'দোকান নং ০৭, বনরুপা বাজার ফিশ মার্কেট লেন, রাঙামাটি সদর',
    rating: 0,
    reviewsCount: 0,
    positiveRatingPercent: 100,
    shipOnTimePercent: 100,
    responseRatePercent: 100,
    followersCount: 0,
    isVerified: true,
    verifiedBadgeText: 'অফিসিয়াল ভেরিফাইড মার্চেন্ট [✓]',
    categories: ['বিষমুক্ত শুঁটকি ও সিদল', 'কাপ্তাই লেকের তাজা শুঁটকি', 'রূপালি ছুরি ও হাঙর শুঁটকি'],
    aboutBn: 'কাপ্তাই লেকের মিষ্টি পানির শতভাগ মাছি ও বিষমুক্ত সৌর ড্রায়ারে প্রস্তুত প্রিমিয়াম গ্রেড শুঁটকি ও ঐতিহ্যবাহী পাহাড়ি সিদল প্রস্তুতকারক ও পাইকারি বিক্রেতা।',
    tradeLicenseNumber: 'TRAD/RNG/SADAR/2023/1142',
    nidNumberMasked: '1979****-***29',
    establishedYear: '২০১৯',
    wallet: {
      grossSales: 0,
      totalCommissionPaid: 0,
      availableBalance: 0,
      pendingEscrowBalance: 0,
      cashouts: [],
      escrowSettlements: []
    },
    products: [
      {
        id: 'vprod_rng_1',
        nameBn: 'বিষমুক্ত অর্গানিক বোম্বাই ও কাচকি শুঁটকি (২৫০ গ্রাম)',
        nameEn: 'Chemical-Free Organic Sun-Dried Fish Mix (250g)',
        category: 'ShutkiSidol',
        categoryLabelBn: 'শুঁটকি ও সিদল',
        price: 350,
        originalPrice: 420,
        unit: '২৫০ গ্রাম প্যাক',
        stock: 55,
        origin: 'রাঙামাটি সদর > বনরুপা বাজার',
        district: 'Rangamati',
        upazila: 'Rangamati Sadar',
        mahalla: 'বনরুপা বাজার',
        bazarName: 'বনরুপা ফিশ মার্কেট',
        image: 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80',
        images: [
          'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=80',
        ],
        rating: 4.8,
        reviewsCount: 110,
        badge: 'ডিডিটি ও বিষমুক্ত',
        badgeColor: 'bg-emerald-600',
        descriptionBn: 'কাপ্তাই লেকের তাজা ছোট মাছ দিয়ে সম্পূর্ণ মাছি ও কীটনাশকমুক্ত নেট ড্রায়ারে রোদে শুকানো স্বাস্থ্যকর শুঁটকি। কোনো দুর্গন্ধ নেই, খাঁটি সুবাস ও পুষ্টিমান অক্ষুণ্ণ।',
        descriptionEn: 'Hygienically solar net-dried sweet water fresh fish from pristine Kaptai Lake with zero chemicals.',
        features: ['ডিডিটি ও পাউডার বিষমুক্ত', 'কাপ্তাই লেকের তাজা ছোট মাছ', 'বালুমুক্ত ও পরিচ্ছন্ন ড্রায়ারে প্রস্তুত', 'অতুলনীয় স্বাদ ও ঘ্রাণ'],
        specifications: [
          { labelBn: 'বারকোড', valueBn: 'JM-RNG-SHTK-001' },
          { labelBn: 'মাছের উৎস', valueBn: 'কাপ্তাই লেক মিষ্টি পানি' },
          { labelBn: 'প্রসেসিং পদ্ধতি', valueBn: 'সোলার নেট ড্রায়ার (মাছিমুক্ত)' },
          { labelBn: 'লবণের পরিমাণ', valueBn: 'প্রাকৃতিক পরিমিত লবণ (লো-সোডিয়াম)' },
          { labelBn: 'প্যাকিং', valueBn: 'ভ্যাকুয়াম সিল করা ফুড গ্রেড পাউচ' },
          { labelBn: 'মেয়াদ', valueBn: '৬ মাস' }
        ],
        variants: {
          sizes: [
            { nameBn: '২৫০ গ্রাম ট্রায়াল প্যাক', priceOffset: 0 },
            { nameBn: '৫০০ গ্রাম স্ট্যান্ডার্ড প্যাক', priceOffset: 320 },
            { nameBn: '১ কেজি ফ্যামিলি প্যাক', priceOffset: 950 },
          ]
        },
        warranty: 'শতভাগ বিষমুক্ত হওয়ার গ্যারান্টি।',
        qrCode: 'JM-V-RNG-001-PROD-01',
        barcode: '8941200192878',
        isOrganic: true,
        sellerId: 'vendor_rng_001',
        sellerUniqueId: 'V-RNG-001',
        sellerShopName: 'কাপ্তাই লেক পিউর শুঁটকি ও সিদল সেন্টার',
        sellerOwnerName: 'মং প্রু মারমা',
        sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        sellerRating: 4.9,
        sellerPhoneMasked: '01823****-***12',
        sellerRealPhone: '01823456712'
      },
      {
        id: 'vprod_rng_2',
        nameBn: 'প্রিমিয়াম গ্রেড-১ রূপালি ছুরি শুঁটকি (২০০ গ্রাম)',
        nameEn: 'Grade-A Premium Silver Ribbon Chhuri Shutki (200g)',
        category: 'ShutkiSidol',
        categoryLabelBn: 'শুঁটকি ও সিদল',
        price: 420,
        originalPrice: 490,
        unit: '২০০ গ্রাম প্যাক',
        stock: 30,
        origin: 'রাঙামাটি সদর > বনরুপা বাজার',
        district: 'Rangamati',
        upazila: 'Rangamati Sadar',
        mahalla: 'বনরুপা বাজার',
        bazarName: 'বনরুপা ফিশ মার্কেট',
        image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80',
        images: [
          'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
        ],
        rating: 4.9,
        reviewsCount: 88,
        badge: 'রূপালি চকচকে গ্রেড-১',
        badgeColor: 'bg-blue-600',
        descriptionBn: 'বাছাইকৃত রূপালি বড় ছুরি মাছের পেট পরিষ্কার করে সমুদ্রের হাওয়া ও কড়া রোদে শুকানো প্রথম শ্রেণির ছুরি শুঁটকি। ভুনা, ভর্তা ও বেগুন-আলু রান্নায় অনন্য।',
        descriptionEn: 'Export-grade cleaned whole silver ribbon fish sun-dried to perfection.',
        features: ['আঁশ ও পেট সম্পূর্ণ পরিষ্কার করা', 'লোনা কম ও সুস্বাদু নরম মাংস', 'ভর্তা ও ঝাল রান্নায় অতুলনীয়', '১০০% পরিষ্কার'],
        specifications: [
          { labelBn: 'বারকোড', valueBn: 'JM-RNG-CHURI-002' },
          { labelBn: 'গ্রেড', valueBn: 'গ্রেড-১ রফতানি মান' },
          { labelBn: 'লবণাক্ততা', valueBn: 'কম লবণ (Mild Salt)' },
          { labelBn: 'মেয়াদ', valueBn: '৬ মাস' }
        ],
        variants: {
          sizes: [
            { nameBn: '২০০ গ্রাম প্যাক', priceOffset: 0 },
            { nameBn: '৫০০ গ্রাম প্যাক', priceOffset: 550 },
            { nameBn: '১ কেজি প্যাক', priceOffset: 1550 },
          ]
        },
        warranty: 'শতভাগ ফ্রেশ ও সুস্বাদু হওয়ার নিশ্চয়তা।',
        qrCode: 'JM-V-RNG-001-PROD-02',
        barcode: '8941200192885',
        isOrganic: true,
        sellerId: 'vendor_rng_001',
        sellerUniqueId: 'V-RNG-001',
        sellerShopName: 'কাপ্তাই লেক পিউর শুঁটকি ও সিদল সেন্টার',
        sellerOwnerName: 'মং প্রু মারমা',
        sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        sellerRating: 4.9,
        sellerPhoneMasked: '01823****-***12',
        sellerRealPhone: '01823456712'
      }
    ]
  },

  // 3. বান্দরবান ওয়াইল্ড হানি ও মশলা ঘর (V-BND-001)
  {
    id: 'vendor_bnd_001',
    uniqueId: 'V-BND-001',
    shopName: 'বান্দরবান ওয়াইল্ড হানি ও ফরেস্ট স্পাইসেস',
    shopNameEn: 'Bandarban Wild Forest Honey & Spices',
    ownerName: 'সিং থোয়াই মারমা (Sing Thowai Marma)',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    banner: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=1200&q=80',
    phoneMasked: '01834****-***56',
    realPhone: '01834567856',
    division: 'Chittagong Division (চট্টগ্রাম)',
    district: 'Bandarban',
    upazila: 'Bandarban Sadar',
    mahalla: 'বালাঘাটা বাজার',
    bazarName: 'বালাঘাটা ফরেস্ট রোড মার্কেট',
    detailedAddress: 'দোকান নং ০৩, বালাঘাটা বাজার, বান্দরবান সদর, বান্দরবান',
    rating: 0,
    reviewsCount: 0,
    positiveRatingPercent: 100,
    shipOnTimePercent: 100,
    responseRatePercent: 100,
    followersCount: 0,
    isVerified: true,
    verifiedBadgeText: 'অফিসিয়াল ভেরিফাইড মার্চেন্ট [✓]',
    categories: ['চাকভাঙা বুনো মধু', 'পাহাড়ি গোলমরিচ ও দারুচিনি', 'জুমের লাল চাল'],
    aboutBn: 'বান্দরবানের রুমা ও থানচির গভীর অরণ্যের উঁচু পাহাড়ি গাছ ও পাহাড়ের চূড়া থেকে আদিবাসীদের চাকভাঙা শতভাগ অপমিশ্রিত খাঁটি বুনো কাঁচা মধু ও ফরেস্ট স্পাইস সরবরাহকারী।',
    tradeLicenseNumber: 'TRAD/BND/SADAR/2023/0441',
    nidNumberMasked: '1985****-***63',
    establishedYear: '২০২০',
    wallet: {
      grossSales: 0,
      totalCommissionPaid: 0,
      availableBalance: 0,
      pendingEscrowBalance: 0,
      cashouts: [],
      escrowSettlements: []
    },
    products: [
      {
        id: 'vprod_bnd_1',
        nameBn: 'বান্দরবানের চাকভাঙা খাঁটি পাহাড়ি বুনো মধু (৫০০ গ্রাম জার)',
        nameEn: 'Pure Wild Forest Raw Honey from Bandarban (500g)',
        category: 'SpicesGrains',
        categoryLabelBn: 'পাহাড়ি মশলা ও মধু',
        price: 550,
        originalPrice: 650,
        unit: '৫০০ গ্রাম কাচের জার',
        stock: 45,
        origin: 'বান্দরবান সদর > বালাঘাটা বাজার',
        district: 'Bandarban',
        upazila: 'Bandarban Sadar',
        mahalla: 'বালাঘাটা বাজার',
        bazarName: 'বালাঘাটা ফরেস্ট মার্কেট',
        image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80',
        images: [
          'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80',
        ],
        rating: 5.0,
        reviewsCount: 245,
        badge: 'চাকভাঙা ১০০% বুনো কাঁচা মধু',
        badgeColor: 'bg-amber-600',
        descriptionBn: 'বান্দরবানের রুমা ও থানচির গভীর পাহাড়ি জঙ্গল থেকে সরাসরি পাহাড়ি মৌয়ালদের চাকভাঙা আনপ্রসেসড কাঁচা বুনো মধু। কোনো চিনি বা কৃত্রিম সিরাপমুক্ত, প্রাকৃতিক এনজাইম ও ঔষধি গুণে ভরপুর।',
        descriptionEn: '100% unpasteurized organic raw wild forest honey harvested sustainably from deep Bandarban canopies.',
        features: ['কোনো চিনি বা সিরাপের ভেজাল নেই', 'আনপাস্তুরাইজড কাঁচা প্রাকৃতিক এনজাইম', 'ঘন তীব্র পাহাড়ি ফুলের ঘ্রাণ', 'কাচের প্রিমিয়াম ফুড গ্রেড জার'],
        specifications: [
          { labelBn: 'বারকোড', valueBn: 'JM-BND-HONY-001' },
          { labelBn: 'মধুর ধরন', valueBn: 'বুনো পাহাড়ি ফুলের কাঁচা মধু (Raw Wild Honey)' },
          { labelBn: 'সংগ্রহ এলাকা', valueBn: 'বান্দরবান (রুমা ও থানচি ফরেস্ট)' },
          { labelBn: 'প্রসেসিং', valueBn: '০% তাপযুক্ত অপরিশোধিত ফিল্টার্ড' },
          { labelBn: 'প্যাকিং', valueBn: 'হেভি-ডিউটি এয়ারটাইট গ্লাস জার' },
          { labelBn: 'মেয়াদ', valueBn: 'প্রাকৃতিক মধু আজীবন ভালো থাকে' }
        ],
        variants: {
          sizes: [
            { nameBn: '২৫০ গ্রাম জার', priceOffset: -270 },
            { nameBn: '৫০০ গ্রাম জার (স্ট্যান্ডার্ড)', priceOffset: 0 },
            { nameBn: '১ কেজি কাচের জার', priceOffset: 500 },
          ]
        },
        warranty: 'পরীক্ষাগারে ভেজাল প্রমাণিত হলে ৩ গুণ টাকা ফেরত।',
        qrCode: 'JM-V-BND-001-PROD-01',
        barcode: '8941200192892',
        isOrganic: true,
        sellerId: 'vendor_bnd_001',
        sellerUniqueId: 'V-BND-001',
        sellerShopName: 'বান্দরবান ওয়াইল্ড হানি ও ফরেস্ট স্পাইসেস',
        sellerOwnerName: 'সিং থোয়াই মারমা',
        sellerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
        sellerRating: 5.0,
        sellerPhoneMasked: '01834****-***56',
        sellerRealPhone: '01834567856'
      }
    ]
  },

  // 4. পাহারিকা আদিবাসী কোমর তাঁত ও পোশাক সম্ভার (V-KHG-002)
  {
    id: 'vendor_khg_002',
    uniqueId: 'V-KHG-002',
    shopName: 'পাহারিকা আদিবাসী কোমর তাঁত ও পোশাক',
    shopNameEn: 'Paharika Indigenous Handloom & Crafts',
    ownerName: 'মেনকা চাকমা (Menaka Chakma)',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    banner: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=1200&q=80',
    phoneMasked: '01845****-***77',
    realPhone: '01845678977',
    division: 'Chittagong Division (চট্টগ্রাম)',
    district: 'Khagrachhari',
    upazila: 'Khagrachhari Sadar',
    mahalla: 'মহাজনপাড়া',
    bazarName: 'মহাজনপাড়া তাঁত পল্লী, দোকান ০৫',
    detailedAddress: 'মহাজনপাড়া মেইন রোড, খাগড়াছড়ি সদর, খাগড়াছড়ি',
    rating: 0,
    reviewsCount: 0,
    positiveRatingPercent: 100,
    shipOnTimePercent: 100,
    responseRatePercent: 100,
    followersCount: 0,
    isVerified: true,
    verifiedBadgeText: 'অফিসিয়াল ভেরিফাইড মার্চেন্ট [✓]',
    categories: ['আদিবাসী থামি ও পিনন-হাদি', 'কোমর তাঁতের চাদর ও ব্যাগ', 'হস্তশিল্প'],
    aboutBn: 'পাহাড়ের ঐতিহ্যবাহী কোমর তাঁতে বোনা আসল আদিবাসী পিনন-হাদি, থামি, খাদি ওড়না, চাদর ও পাহাড়ি হস্তশিল্পের সরাসরি তাঁতিদের নির্ভরযোগ্য প্রতিষ্ঠান।',
    tradeLicenseNumber: 'TRAD/KHG/SADAR/2024/0523',
    nidNumberMasked: '1992****-***84',
    establishedYear: '২০২২',
    wallet: {
      grossSales: 0,
      totalCommissionPaid: 0,
      availableBalance: 0,
      pendingEscrowBalance: 0,
      cashouts: [],
      escrowSettlements: []
    },
    products: [
      {
        id: 'vprod_khg_4',
        nameBn: 'হাতে বোনা প্রিমিয়াম পাহাড়ি কোমর তাঁতের থামি ও ওড়না সেট',
        nameEn: 'Handwoven Indigenous Backstrap Loom Thami & Scarf Set',
        category: 'Clothing',
        categoryLabelBn: 'পোশাক ও কোমর তাঁত',
        price: 1850,
        originalPrice: 2200,
        unit: '১ সেট (থামি + ওড়না)',
        stock: 18,
        origin: 'খাগড়াছড়ি সদর > মহাজনপাড়া',
        district: 'Khagrachhari',
        upazila: 'Khagrachhari Sadar',
        mahalla: 'মহাজনপাড়া',
        bazarName: 'মহাজনপাড়া তাঁত বাজার',
        image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=600&q=80',
        images: [
          'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1528458909336-e7a0adfed0a5?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1445205170230-053b83016050?auto=format&fit=crop&w=800&q=80',
        ],
        rating: 4.9,
        reviewsCount: 72,
        badge: '১০০% হাতে বোনা ঐতিহ্যবাহী',
        badgeColor: 'bg-purple-600',
        descriptionBn: 'খাগড়াছড়ির অভিজ্ঞ আদিবাসী তাঁতিদের দ্বারা কোমর তাঁতে শতভাগ কটন সুতায় বোনা আকর্ষণীয় জ্যামিতিক নকশার পিনন-হাদি ও থামি সেট। রঙ পাকা ও দীর্ঘস্থায়ী।',
        descriptionEn: 'Authentic indigenous backstrap handloom thami and shawl set with vibrant geometric motifs.',
        features: ['১০০% খাঁটি সুতি সুতা', 'হাতে বোনা আকর্ষণীয় পাহাড়ি নকশা', 'রঙ পাকা ও টেকসই', 'উৎসব ও ঘরোয়া পরায় আরামদায়ক'],
        specifications: [
          { labelBn: 'বারকোড', valueBn: 'JM-KHG-CLOTH-004' },
          { labelBn: 'ফেব্রিক', valueBn: '১০০% পিওর কটন' },
          { labelBn: 'তাঁতের প্রকার', valueBn: 'কোমর তাঁত (Backstrap Loom)' },
          { labelBn: 'সাইজ', valueBn: 'ফ্রি সাইজ (থামি: ৪৪"x ৩৬", ওড়না: ৮৫"x ৩০")' },
          { labelBn: 'ওয়াশ কেয়ার', valueBn: 'ঠান্ডা পানিতে শ্যাম্পু দিয়ে ধোয়া উত্তম' }
        ],
        variants: {
          colors: [
            { nameBn: 'গাঢ় লাল ও কালো নকশা', hex: '#8B0000' },
            { nameBn: 'রয়েল ব্লু ও গোল্ডেন', hex: '#4169E1' },
            { nameBn: 'গাঢ় সবুজ ও মেজেন্টা', hex: '#006400' },
          ]
        },
        warranty: 'সুতা বা রঙে সমস্যা থাকলে ৭ দিনের মধ্যে এক্সচেঞ্জ সুবিধা।',
        qrCode: 'JM-V-KHG-002-PROD-01',
        barcode: '8941200192908',
        isOrganic: true,
        sellerId: 'vendor_khg_002',
        sellerUniqueId: 'V-KHG-002',
        sellerShopName: 'পাহারিকা আদিবাসী কোমর তাঁত ও পোশাক',
        sellerOwnerName: 'মেনকা চাকমা',
        sellerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        sellerRating: 4.9,
        sellerPhoneMasked: '01845****-***77',
        sellerRealPhone: '01845678977'
      }
    ]
  },

  // 5. চট্টগ্রাম সোলার ও এগ্রো টেক সলিউশন (V-CTG-001)
  {
    id: 'vendor_ctg_001',
    uniqueId: 'V-CTG-001',
    shopName: 'চট্টগ্রাম সোলার ও এগ্রো টেক এক্সেসরিজ',
    shopNameEn: 'Chittagong Solar & Agro Tech Accessories',
    ownerName: 'তানভীর হাসান (Tanveer Hassan)',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
    banner: 'https://images.unsplash.com/photo-1508873696983-2df5293cb32b?auto=format&fit=crop&w=1200&q=80',
    phoneMasked: '01856****-***90',
    realPhone: '01856789090',
    division: 'Chittagong Division (চট্টগ্রাম)',
    district: 'Chittagong',
    upazila: 'Kotwali',
    mahalla: 'আন্দরকিল্লা ইলেকট্রনিক্স মার্কেট',
    bazarName: 'আন্দরকিল্লা মার্কেট, ২য় তলা',
    detailedAddress: 'দোকান নং ২০৮, আন্দরকিল্লা ইলেকট্রনিক্স মার্কেট, কোতোয়ালী, চট্টগ্রাম',
    rating: 0,
    reviewsCount: 0,
    positiveRatingPercent: 100,
    shipOnTimePercent: 100,
    responseRatePercent: 100,
    followersCount: 0,
    isVerified: true,
    verifiedBadgeText: 'অফিসিয়াল ভেরিফাইড মার্চেন্ট [✓]',
    categories: ['সোলার লাইট ও প্যানেল', 'রিচার্জেবল ইমার্জেন্সি ফ্যান', 'এগ্রো ওয়াটার পাম্প'],
    aboutBn: 'পাহাড় ও প্রত্যন্ত অঞ্চলের জন্য দীর্ঘস্থায়ী সোলার হোম সিস্টেম, ডিসি ফ্যান, সোলার পাম্প ও আধুনিক রিচার্জেবল গ্যাজেটের বিশ্বস্ত সরবরাহকারী।',
    tradeLicenseNumber: 'TRAD/CTG/KOTWALI/2023/8812',
    nidNumberMasked: '1987****-***15',
    establishedYear: '২০১৮',
    wallet: {
      grossSales: 0,
      totalCommissionPaid: 0,
      availableBalance: 0,
      pendingEscrowBalance: 0,
      cashouts: [],
      escrowSettlements: []
    },
    products: [
      {
        id: 'vprod_ctg_1',
        nameBn: 'পোর্টেবল হাই-লুমেন সোলার হেডল্যাম্প ও রিচার্জেবল ক্যাম্পিং লাইট',
        nameEn: 'Portable High-Lumen Solar Headlamp & LED Torch',
        category: 'Electronics',
        categoryLabelBn: 'ইলেকট্রনিক্স ও সোলার',
        price: 950,
        originalPrice: 1200,
        unit: '১ সেট',
        stock: 35,
        origin: 'চট্টগ্রাম > কোতোয়ালী > আন্দরকিল্লা',
        district: 'Chittagong',
        upazila: 'Kotwali',
        mahalla: 'আন্দরকিল্লা',
        bazarName: 'আন্দরকিল্লা ইলেকট্রনিক্স মার্কেট',
        image: 'https://images.unsplash.com/photo-1508873696983-2df5293cb32b?auto=format&fit=crop&w=600&q=80',
        images: [
          'https://images.unsplash.com/photo-1508873696983-2df5293cb32b?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1588508065123-287b28e013da?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80',
        ],
        rating: 4.8,
        reviewsCount: 96,
        badge: 'ওয়াটারপ্রুফ ও ১ বছর ওয়ারেন্টি',
        badgeColor: 'bg-blue-700',
        descriptionBn: 'পাহাড় ও রাতের চলাচলের জন্য বিশেষ উপযোগী আল্ট্রা-ব্রাইট এলইডি সোলার রিচার্জেবল হেডল্যাম্প। শক্তিশালী ৫০০০ এমএএইচ লিথিয়াম ব্যাটারি এবং সোলার প্যানেল সহ ওয়াটারপ্রুফ বডি।',
        descriptionEn: 'Rechargeable heavy-duty solar LED headlamp with dual charging ports and rainproof casing.',
        features: ['সোলার ও ইউএসবি টাইপ-সি ডুয়াল চার্জিং', '১২ ঘণ্টা দীর্ঘ ব্যাটারি ব্যাকআপ', 'IP65 ওয়াটারপ্রুফ রেটিং', '৩টি ব্রাইটনেস মোড'],
        specifications: [
          { labelBn: 'বারকোড', valueBn: 'JM-CTG-SOLAR-001' },
          { labelBn: 'ব্যাটারি ক্যাপাসিটি', valueBn: '5000 mAh Li-ion' },
          { labelBn: 'চার্জিং সময়', valueBn: 'সোলারে ৪-৫ ঘণ্টা, টাইপ-সি তে ২ ঘণ্টা' },
          { labelBn: 'লুমেন আউটপুট', valueBn: '1200 Lumens Ultra Bright' },
          { labelBn: 'ওয়ারেন্টি', valueBn: '১ বছরের অফিসিয়াল রিপ্লেসমেন্ট ওয়ারেন্টি' }
        ],
        variants: {
          colors: [
            { nameBn: 'মিলিটারি ব্ল্যাক', hex: '#1C1C1C' },
            { nameBn: 'আর্মি গ্রিন', hex: '#4B5320' },
          ]
        },
        warranty: '১ বছরের পূর্ণ ফ্রি সার্ভিস ও রিপ্লেসমেন্ট গ্যারান্টি।',
        qrCode: 'JM-V-CTG-001-PROD-01',
        barcode: '8941200192915',
        sellerId: 'vendor_ctg_001',
        sellerUniqueId: 'V-CTG-001',
        sellerShopName: 'চট্টগ্রাম সোলার ও এগ্রো টেক এক্সেসরিজ',
        sellerOwnerName: 'তানভীর হাসান',
        sellerAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
        sellerRating: 4.8,
        sellerPhoneMasked: '01856****-***90',
        sellerRealPhone: '01856789090'
      }
    ]
  }
];
