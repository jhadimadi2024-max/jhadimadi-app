import React, { useState, useEffect, useCallback, Suspense, lazy } from 'react';
import { CustomerApp } from './components/CustomerApp';
import { JhadimadiSplashScreen } from './components/JhadimadiSplashScreen';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Loader2, Store, ArrowLeft, Home, Grid, UserPlus, Search, User, MessageSquare } from 'lucide-react';
import RoleSelectionModal from './components/RoleSelectionModal';
import ServiceProviderRegistrationForm from './components/ServiceProviderRegistrationForm';
import ServiceProviderProfile from './components/ServiceProviderProfile';
import CleanMerchantPage from './components/CleanMerchantPage';
import { SignInScreen } from './components/SignInScreen';
import { SignUpScreen } from './components/SignUpScreen';
import { RegistrationPage } from './components/RegistrationPage';
import { INITIAL_VENDOR_STORES } from './data/vendorsData';
import { adminSecurityService } from './services/adminSecurityService';

// Lazy load Admin components
const AdminScreen = lazy(() =>
  import('./components/AdminPanelModal').then((m) => ({ default: m.AdminScreen }))
);
const AdminLoginScreen = lazy(() =>
  import('./components/AdminLoginScreen').then((m) => ({ default: m.AdminLoginScreen }))
);

const AdminLoadingFallback: React.FC = () => (
  <div className="min-h-screen bg-slate-950 text-slate-200 flex flex-col items-center justify-center p-4">
    <div className="flex flex-col items-center gap-3">
      <div className="w-12 h-12 rounded-2xl bg-emerald-950/80 border border-emerald-800/40 flex items-center justify-center text-emerald-400">
        <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
      </div>
      <p className="text-xs font-semibold text-slate-400 tracking-wide">
        অ্যাডমিন প্যানেল লোড হচ্ছে...
      </p>
    </div>
  </div>
);

const AppContent: React.FC = () => {
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const handleFinishSplash = useCallback(() => {
    setIsLoading(false);
  }, []);

  const { currentUser, login, logout, selectRole } = useAuth();

  // Onboarding Step Flow State:
  // 'app' (default CustomerApp), 'auth-signin', 'auth-signup', 'role-select', 'sp-form', 'sp-profile', 'merchant-dashboard'
  const [onboardingStep, setOnboardingStep] = useState<
    'app' | 'auth-signin' | 'auth-signup' | 'role-select' | 'sp-form' | 'sp-profile' | 'merchant-dashboard'
  >(() => {
    try {
      const search = window.location.search.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (
        hash === '#sp-profile' ||
        hash === '#resume' ||
        hash === '#provider-profile' ||
        search.includes('view=provider-profile') ||
        search.includes('view=resume') ||
        search.includes('flow=sp-profile')
      ) {
        return 'sp-profile';
      }
      if (
        search.includes('flow=provider') ||
        search.includes('flow=onboarding') ||
        hash === '#role-select' ||
        hash === '#provider-onboarding'
      ) {
        return 'role-select';
      }
      if (hash === '#signin' || search.includes('flow=signin')) {
        return 'auth-signin';
      }
      if (hash === '#signup' || search.includes('flow=signup')) {
        return 'auth-signup';
      }
    } catch {
      // Default
    }
    return 'app';
  });

  const [providerProfileData, setProviderProfileData] = useState<any>(null);

  // Route state
  const [currentRoute, setCurrentRoute] = useState<'customer' | 'admin'>(() => {
    try {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      const search = window.location.search.toLowerCase();
      if (
        path.startsWith('/admin') ||
        path.startsWith('/admin-portal') ||
        hash === '#admin' ||
        hash === '#admin-portal' ||
        search.includes('view=admin')
      ) {
        return 'admin';
      }
    } catch {
      // Fallback
    }
    return 'customer';
  });

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const [isVerifyingAdmin, setIsVerifyingAdmin] = useState<boolean>(true);

  // Validate admin authentication securely on route change or refresh
  useEffect(() => {
    let isMounted = true;
    const verifyAdmin = async () => {
      try {
        const session = await adminSecurityService.getCurrentAdminSession();
        if (isMounted) {
          setIsAdminAuthenticated(Boolean(session && session.role));
          setIsVerifyingAdmin(false);
        }
      } catch {
        if (isMounted) {
          setIsAdminAuthenticated(false);
          setIsVerifyingAdmin(false);
        }
      }
    };

    verifyAdmin();
    return () => {
      isMounted = false;
    };
  }, [currentRoute]);

  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      const search = window.location.search.toLowerCase();

      if (
        path.startsWith('/admin') ||
        path.startsWith('/admin-portal') ||
        hash === '#admin' ||
        hash === '#admin-portal' ||
        search.includes('view=admin')
      ) {
        setCurrentRoute('admin');
      } else {
        setCurrentRoute('customer');
      }

      if (
        hash === '#sp-profile' ||
        hash === '#resume' ||
        hash === '#provider-profile' ||
        search.includes('view=provider-profile') ||
        search.includes('view=resume') ||
        search.includes('flow=sp-profile')
      ) {
        setOnboardingStep('sp-profile');
      } else if (
        search.includes('flow=provider') ||
        search.includes('flow=onboarding') ||
        hash === '#role-select'
      ) {
        setOnboardingStep('role-select');
      } else if (hash === '#signin' || search.includes('flow=signin')) {
        setOnboardingStep('auth-signin');
      } else if (hash === '#signup' || search.includes('flow=signup')) {
        setOnboardingStep('auth-signup');
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);

    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const navigateTo = (route: 'customer' | 'admin') => {
    setCurrentRoute(route);
    try {
      if (route === 'admin') {
        window.history.pushState({}, '', '/admin');
      } else {
        window.history.pushState({}, '', '/');
      }
    } catch {
      // Fallback
    }
  };

  const handleAdminLogout = async () => {
    try {
      await adminSecurityService.signOutAdmin();
    } catch {
      // Ignore
    }
    setIsAdminAuthenticated(false);
    navigateTo('customer');
  };

  // Step flow event handlers
  const handleRoleSelect = (type: 'merchant' | 'service') => {
    if (type === 'merchant') {
      selectRole('seller');
      setOnboardingStep('merchant-dashboard');
    } else {
      selectRole('professional');
      setOnboardingStep('sp-form');
    }
  };

  const handleFormSubmit = (data: any) => {
    setProviderProfileData(data);
    setOnboardingStep('sp-profile');
  };

  const handleResetFlow = () => {
    setProviderProfileData(null);
    setOnboardingStep('role-select');
  };

  const [customerAppTab, setCustomerAppTab] = useState<string>('home');

  const handleReturnToApp = (tab: string = 'home') => {
    setCustomerAppTab(tab);
    setOnboardingStep('app');
  };

  return (
    <>
      {isLoading && (
        <JhadimadiSplashScreen onFinish={handleFinishSplash} durationMs={2600} />
      )}
      {currentRoute === 'admin' ? (
        <Suspense fallback={<AdminLoadingFallback />}>
          {isVerifyingAdmin ? (
            <AdminLoadingFallback />
          ) : !isAdminAuthenticated ? (
            <AdminLoginScreen
              onSuccess={() => setIsAdminAuthenticated(true)}
              onNavigateToCustomerApp={() => navigateTo('customer')}
            />
          ) : (
            <div className="h-[100dvh] max-h-[100dvh] overflow-y-auto bg-slate-950">
              <AdminScreen onBack={handleAdminLogout} />
            </div>
          )}
        </Suspense>
      ) : onboardingStep === 'app' ? (
        <div className="min-h-[100dvh] h-[100dvh] max-h-[100dvh] w-full bg-[#009f4d] sm:bg-stone-200/80 flex flex-col items-center justify-start p-0 m-0 overflow-hidden font-sans select-none">
          <div className="w-full max-w-md h-full max-h-[100dvh] flex flex-col bg-[#009f4d] shadow-none sm:shadow-2xl border-0 sm:border-x sm:border-b sm:border-stone-300/80 rounded-none sm:rounded-b-2xl overflow-hidden relative pointer-events-auto z-1 p-0 m-0">
            <ErrorBoundary componentName="CustomerAppWrapper">
              <CustomerApp
                key={customerAppTab}
                initialTab={customerAppTab as any}
                onReplaySplash={() => setIsLoading(true)}
                  onNavigateToAdmin={() => navigateTo('admin')}
                  onOpenRoleSelect={() => {
                    if (!currentUser) {
                      setOnboardingStep('auth-signup');
                    } else {
                      setOnboardingStep('role-select');
                    }
                  }}
                  onOpenAuth={(mode) => {
                    setOnboardingStep(mode === 'signin' ? 'auth-signin' : 'auth-signup');
                  }}
                  onNavigateToMerchant={() => setOnboardingStep('merchant-dashboard')}
                  onNavigateToServiceProvider={() => setOnboardingStep('sp-form')}
                />
              </ErrorBoundary>
          </div>
        </div>
      ) : (
        /* Mobile Constrained Layout with SuperApp Header & 5-Tab Bottom Navigation */
        <div className="min-h-[100dvh] h-[100dvh] max-h-[100dvh] w-full bg-[#009f4d] sm:bg-stone-200/80 flex flex-col items-center justify-start p-0 m-0 overflow-hidden font-sans select-none">
          <div className="w-full max-w-md h-full max-h-[100dvh] flex flex-col bg-[#009f4d] shadow-none sm:shadow-2xl border-0 sm:border-x sm:border-b sm:border-stone-300/80 rounded-none sm:rounded-b-2xl overflow-hidden relative pointer-events-auto z-1 p-0 m-0">
            
            {/* SuperApp Top Header - Compact, sleek & balanced in Vibrant Green #009f4d */}
            <header 
              className="sticky top-0 left-0 right-0 z-50 shrink-0 w-full bg-[#009f4d] text-white shadow-xs border-b border-[#008c43] m-0"
              style={{
                backgroundColor: '#009f4d',
                paddingTop: 'env(safe-area-inset-top, 0px)',
                paddingLeft: 'env(safe-area-inset-left, 0px)',
                paddingRight: 'env(safe-area-inset-right, 0px)',
              }}
            >
              <div className="w-full px-2.5 sm:px-3 h-10 sm:h-10.5 flex items-center justify-between gap-1.5">
                <div className="flex items-center gap-1.5 min-w-0">
                  <button
                    type="button"
                    onClick={() => handleReturnToApp()}
                    className="w-6.5 h-6.5 rounded-lg bg-white/15 hover:bg-white/25 active:scale-90 text-white transition cursor-pointer shrink-0 border border-white/20 shadow-2xs flex items-center justify-center"
                    title="হোমে ফিরুন (Back)"
                    id="subpage-header-back-btn"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </button>
                  <div 
                    className="flex items-center gap-1.5 cursor-pointer select-none min-w-0"
                    onClick={() => handleReturnToApp()}
                  >
                    <div className="relative p-0.5 rounded-md bg-white shadow-xs border border-white/70 shrink-0 flex items-center justify-center w-6.5 h-6.5">
                      <img
                        src="https://i.ibb.co.com/sppWZhc9/logo33.png"
                        alt="Jhadimadi Runner"
                        className="w-4.5 h-4.5 object-contain"
                        onError={(e) => {
                          (e.currentTarget as HTMLImageElement).style.display = 'none';
                        }}
                      />
                    </div>
                    <div className="flex flex-col justify-center min-w-0">
                      <span className="text-[7.5px] font-bold text-amber-200 tracking-tight leading-none block">
                        ঝাদিমাদি ডটকম
                      </span>
                      <div className="flex items-center gap-0.5 leading-none mt-0.5">
                        <span className="text-[10px] font-black tracking-wide text-white">JHADIMADI</span>
                        <span className="text-[8px] font-black text-amber-300">.COM</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Status Badge & Home Icon */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="text-[8px] font-bold bg-white/15 text-white px-2 py-0.5 rounded-md border border-white/20 leading-none shadow-2xs">
                    {onboardingStep === 'auth-signin' && 'লগইন'}
                    {onboardingStep === 'auth-signup' && 'রেজিস্ট্রেশন'}
                    {onboardingStep === 'role-select' && 'রোল নির্বাচন'}
                    {onboardingStep === 'sp-form' && 'সার্ভিস ফর্ম'}
                    {onboardingStep === 'sp-profile' && 'প্রোফাইল'}
                    {onboardingStep === 'merchant-dashboard' && 'মার্চেন্ট'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleReturnToApp()}
                    className="w-6.5 h-6.5 rounded-lg bg-white/15 hover:bg-white/25 active:scale-90 text-white transition cursor-pointer border border-white/20 shadow-2xs flex items-center justify-center"
                    title="হোমে ফিরুন"
                    id="subpage-header-home-btn"
                  >
                    <Home className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </header>

            {/* Scrollable Body with Centered Form */}
            <main className="flex-1 overflow-y-auto scroll-smooth min-h-0 bg-[#FAF8F5] p-2 sm:p-3 overscroll-contain">
              {onboardingStep === 'auth-signin' && (
                <div className="w-full max-w-md mx-auto py-1">
                  <SignInScreen
                    lang="bn"
                    onBack={() => handleReturnToApp()}
                    onSignInSuccess={(user) => {
                      login(user, false);
                      setOnboardingStep('role-select');
                    }}
                    onNavigateToSignUp={() => setOnboardingStep('auth-signup')}
                  />
                </div>
              )}

              {onboardingStep === 'auth-signup' && (
                <div className="w-full max-w-md mx-auto py-1">
                  <RegistrationPage
                    lang="bn"
                    currentUser={currentUser}
                    onBack={() => handleReturnToApp()}
                    onSuccess={(user) => {
                      login(user, true);
                      setOnboardingStep('role-select');
                    }}
                    onNavigateToSignIn={() => setOnboardingStep('auth-signin')}
                  />
                </div>
              )}

              {onboardingStep === 'role-select' && (
                <div className="w-full max-w-md mx-auto py-2 flex flex-col items-center justify-start min-h-0">
                  <div className="w-full mb-3 flex items-center justify-between px-1">
                    <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                      অ্যাকাউন্ট নির্বাচন (Role Choice)
                    </span>
                    <button
                      type="button"
                      onClick={() => handleReturnToApp()}
                      className="text-xs text-stone-500 hover:text-stone-800 font-medium transition cursor-pointer p-1"
                    >
                      হোমে যান (Cancel)
                    </button>
                  </div>
                  <RoleSelectionModal
                    userName={currentUser?.name}
                    onSelect={handleRoleSelect}
                    onNavigateToServiceProviderForm={() => setOnboardingStep('sp-form')}
                    onNavigateToMerchantDashboard={() => setOnboardingStep('merchant-dashboard')}
                  />
                </div>
              )}

              {onboardingStep === 'sp-form' && (
                <div className="w-full max-w-md mx-auto py-1">
                  <ServiceProviderRegistrationForm
                    currentUser={providerProfileData || currentUser}
                    onSubmitSuccess={handleFormSubmit}
                    onSuccess={handleFormSubmit}
                    onBack={() => setOnboardingStep('role-select')}
                    lang="bn"
                  />
                </div>
              )}

              {onboardingStep === 'sp-profile' && (
                <div className="w-full max-w-md mx-auto py-1">
                  <ServiceProviderProfile
                    profileData={providerProfileData || currentUser}
                    currentUser={currentUser}
                    isOwner={true}
                    onEditProfile={() => setOnboardingStep('sp-form')}
                    onNavigateDashboard={() => setOnboardingStep('merchant-dashboard')}
                    onSignOut={() => {
                      logout();
                      handleReturnToApp();
                    }}
                    onDeleteAccount={handleResetFlow}
                    onBack={() => setOnboardingStep('sp-form')}
                    lang="bn"
                  />
                </div>
              )}

              {onboardingStep === 'merchant-dashboard' && (
                <div className="w-full max-w-md mx-auto py-1">
                  <div className="mb-3 flex items-center justify-between border-b border-stone-200 pb-2">
                    <span className="text-xs font-bold text-[#009661] uppercase tracking-wider flex items-center gap-1.5">
                      <Store className="w-4 h-4" />
                      <span>মার্চেন্ট প্রোফাইল</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setOnboardingStep('role-select')}
                      className="text-xs text-blue-600 font-medium hover:underline cursor-pointer"
                    >
                      ← রোল পরিবর্তন
                    </button>
                  </div>
                  <CleanMerchantPage
                    lang="bn"
                    store={INITIAL_VENDOR_STORES[0]}
                    currentUserRole="merchant"
                    isOwner={true}
                    isAdmin={false}
                    onBack={() => setOnboardingStep('role-select')}
                  />
                </div>
              )}
            </main>

            {/* SuperApp 5-Tab Bottom Navigation Bar (Full-Width Edge-to-Edge, Slim, Harmonious #009f4d Green Bar) */}
            <nav 
              className="sticky bottom-0 left-0 right-0 z-50 shrink-0 w-full bg-[#009f4d] text-white border-t border-[#008c43] shadow-[0_-2px_10px_rgba(0,0,0,0.06)] m-0 pointer-events-auto"
              style={{
                backgroundColor: '#009f4d',
                paddingBottom: 'env(safe-area-inset-bottom, 0px)',
                paddingLeft: 'env(safe-area-inset-left, 0px)',
                paddingRight: 'env(safe-area-inset-right, 0px)',
              }}
              id="subpage-bottom-nav"
            >
              <div className="w-full h-11 sm:h-12 grid grid-cols-5 items-center justify-items-center px-1">
                {/* Slot 1: Home */}
                <button 
                  type="button"
                  onClick={() => handleReturnToApp('home')} 
                  className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
                  id="subpage-nav-home"
                  title="হোম"
                >
                  <div className="transition-colors flex items-center justify-center text-white/85 group-hover:text-white">
                    <Home className="w-4 h-4 stroke-[2.2]" />
                  </div>
                  <span className="text-[9px] sm:text-[9.5px] font-medium tracking-tight text-center leading-none mt-0.5 text-white/90 whitespace-nowrap truncate max-w-full px-0.5">
                    হোম
                  </span>
                </button>

                {/* Slot 2: Jhadimadi (Chat icon, label "ঝাদিমাধি" / "Jhadimadi", opens AI chat) */}
                <button 
                  type="button"
                  onClick={() => handleReturnToApp('ai_chat')} 
                  className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none relative"
                  title="ঝাদিমাধি এআই মেসেজ ও ভয়েস সাপোর্ট"
                  id="subpage-nav-jhadimadi"
                >
                  <div className="transition-colors flex items-center justify-center text-white/85 group-hover:text-white relative">
                    <MessageSquare className="w-4 h-4 stroke-[2.2]" />
                    <span className="absolute -top-1 -right-2 bg-amber-400 text-slate-950 text-[6.5px] font-black px-1 rounded-full leading-none shadow-2xs">
                      AI
                    </span>
                  </div>
                  <span className="text-[9px] sm:text-[9.5px] font-medium tracking-tight text-center leading-none mt-0.5 text-white/90 whitespace-nowrap truncate max-w-full px-0.5">
                    ঝাদিমাধি
                  </span>
                </button>

                {/* Slot 3 (Center): Registration */}
                <button 
                  type="button"
                  onClick={() => {
                    if (!currentUser) {
                      setOnboardingStep('auth-signup');
                    } else {
                      setOnboardingStep('role-select');
                    }
                  }} 
                  className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
                  title="রেজিস্ট্রেশন বা একাউন্ট রোল নির্বাচন করুন"
                  id="subpage-nav-register"
                >
                  <div className={`transition-colors flex items-center justify-center ${
                    onboardingStep === 'auth-signup' || onboardingStep === 'role-select' || onboardingStep === 'sp-form'
                      ? 'text-amber-300'
                      : 'text-white/85 group-hover:text-white'
                  }`}>
                    <UserPlus className="w-4 h-4 stroke-[2.2]" />
                  </div>
                  <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${
                    onboardingStep === 'auth-signup' || onboardingStep === 'role-select' || onboardingStep === 'sp-form'
                      ? 'font-bold text-amber-300'
                      : 'font-medium text-white/90'
                  }`}>
                    রেজিস্ট্রেশন
                  </span>
                </button>

                {/* Slot 4: Search */}
                <button 
                  type="button"
                  onClick={() => handleReturnToApp('search')} 
                  className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
                  id="subpage-nav-search"
                  title="সার্চ"
                >
                  <div className="transition-colors flex items-center justify-center text-white/85 group-hover:text-white">
                    <Search className="w-4 h-4 stroke-[2.2]" />
                  </div>
                  <span className="text-[9px] sm:text-[9.5px] font-medium tracking-tight text-center leading-none mt-0.5 text-white/90 whitespace-nowrap truncate max-w-full px-0.5">
                    সার্চ
                  </span>
                </button>

                {/* Slot 5 (Far Right): Profile (Strictly retained) */}
                <button 
                  type="button"
                  onClick={() => handleReturnToApp('profile')} 
                  className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
                  title="আমার প্রোফাইল"
                  id="subpage-nav-profile"
                >
                  <div className={`transition-colors flex items-center justify-center ${
                    onboardingStep === 'sp-profile' ? 'text-amber-300' : 'text-white/85 group-hover:text-white'
                  }`}>
                    {currentUser?.avatar ? (
                      <img 
                        src={currentUser.avatar} 
                        alt="Profile" 
                        className="w-4 h-4 rounded-full object-cover ring-1 ring-white" 
                      />
                    ) : (
                      <User className="w-4 h-4 stroke-[2.2]" />
                    )}
                  </div>
                  <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${
                    onboardingStep === 'sp-profile' ? 'font-bold text-amber-300' : 'font-medium text-white/90'
                  }`}>
                    প্রোফাইল
                  </span>
                </button>
              </div>
            </nav>
          </div>
        </div>
      )}
    </>
  );
};

export const App: React.FC = () => {
  return (
    <ErrorBoundary componentName="RootApplication">
      <AuthProvider>
        <DataProvider>
          <AppContent />
        </DataProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
};

export default App;