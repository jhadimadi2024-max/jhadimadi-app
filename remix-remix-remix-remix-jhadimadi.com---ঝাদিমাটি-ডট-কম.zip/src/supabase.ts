import { createClient } from '@supabase/supabase-js';

// Load Supabase URL and Publishable/Anon Key from client environment variables
const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim() || 'https://placeholder.supabase.co';
const rawKey = (
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || 
  import.meta.env.VITE_SUPABASE_ANON_KEY || 
  ''
).trim();

// Security guard: Ensure privileged / service_role keys are NEVER used in frontend client code
const isPrivilegedKey = (key: string): boolean => {
  if (!key) return false;
  const lower = key.toLowerCase();
  if (
    lower.includes('service_role') || 
    lower.startsWith('sbp_secret') || 
    lower.startsWith('sb_secret') || 
    lower.startsWith('secret_')
  ) {
    return true;
  }
  try {
    const parts = key.split('.');
    if (parts.length === 3) {
      const payload = JSON.parse(atob(parts[1]));
      if (payload.role === 'service_role' || payload.role === 'supabase_admin') {
        return true;
      }
    }
  } catch {
    // Non-JWT string or decoding error
  }
  return false;
};

if (isPrivilegedKey(rawKey)) {
  console.error('[SECURITY WARNING] Privileged Supabase secret/service-role key detected in client environment! This key has been blocked from frontend initialization to prevent exposure.');
}

const supabaseKey = (!isPrivilegedKey(rawKey) && rawKey) ? rawKey : 'placeholder-anon-key';

// Helper to determine if Supabase is properly configured with valid public credentials
export const isSupabaseConfigured = Boolean(
  import.meta.env.VITE_SUPABASE_URL && 
  (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || import.meta.env.VITE_SUPABASE_ANON_KEY) &&
  !isPrivilegedKey(rawKey) &&
  supabaseUrl !== 'https://placeholder.supabase.co' &&
  supabaseKey !== 'placeholder-anon-key'
);

// Supabase client instance (safe for browser client-side usage)
export const supabase = createClient(supabaseUrl, supabaseKey);

/**
 * Validates connectivity to the configured Supabase project.
 * Safe to execute on both client and server; never exposes private credentials.
 */
export async function testSupabaseConnection(): Promise<{
  connected: boolean;
  configured: boolean;
  url: string;
  hasPublishableKey: boolean;
  error?: string;
}> {
  if (!isSupabaseConfigured) {
    return {
      connected: false,
      configured: false,
      url: supabaseUrl,
      hasPublishableKey: Boolean(rawKey && !isPrivilegedKey(rawKey)),
      error: 'Supabase environment variables (VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY) are missing or incomplete.',
    };
  }

  try {
    const { error } = await supabase.auth.getSession();
    if (error) {
      return {
        connected: false,
        configured: true,
        url: supabaseUrl,
        hasPublishableKey: true,
        error: error.message,
      };
    }
    return {
      connected: true,
      configured: true,
      url: supabaseUrl,
      hasPublishableKey: true,
    };
  } catch (err: any) {
    return {
      connected: false,
      configured: true,
      url: supabaseUrl,
      hasPublishableKey: true,
      error: err?.message || 'Network error connecting to Supabase',
    };
  }
}

if (typeof window !== 'undefined' && isSupabaseConfigured) {
  console.info('[Supabase] Initialized successfully with client credentials');
}

export default supabase;
