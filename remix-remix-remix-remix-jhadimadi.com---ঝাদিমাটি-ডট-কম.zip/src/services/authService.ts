/**
 * JHADIMADI.COM — ENTERPRISE SUPABASE AUTHENTICATION SERVICE
 * Complete Supabase Auth & PostgreSQL Integration
 * Architecture: ONE USER ACCOUNT -> ONE PROFILE -> MULTIPLE ROLES
 * Fully replaces all legacy Firebase Auth and Firestore operations.
 */

import { supabase, isSupabaseConfigured } from '../supabase';
import { UserProfile } from '../types';
import { databaseService } from './databaseService';
import { generateMemberUID, getLocationCodes } from '../data/locationMaster';

export interface AuthResult {
  success: boolean;
  user?: UserProfile;
  error?: string;
  errorCode?: string;
  isNewUser?: boolean;
}

export interface SocialAuthResult extends AuthResult {}

/**
 * Universal timeout wrapper to guarantee async operations never hang indefinitely
 */
export async function withTimeout<T>(
  promise: Promise<T>,
  ms: number = 8000,
  fallbackOrErrorMsg?: string | T
): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((resolve, reject) => {
      setTimeout(() => {
        if (typeof fallbackOrErrorMsg !== 'undefined' && typeof fallbackOrErrorMsg !== 'string') {
          resolve(fallbackOrErrorMsg as T);
        } else {
          reject(new Error(typeof fallbackOrErrorMsg === 'string' ? fallbackOrErrorMsg : 'REQUEST_TIMEOUT'));
        }
      }, ms);
    })
  ]);
}

/**
 * Helper to normalize Bengali digits to standard English ASCII digits
 */
export function normalizeDigits(val: string): string {
  if (!val) return '';
  const bnToEn: Record<string, string> = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
  };
  return val.replace(/[০-৯]/g, (d) => bnToEn[d] || d);
}

/**
 * Validates whether string is a well-formed email address
 */
export function isValidEmailFormat(val: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
}

/**
 * Validates phone number (Bangladeshi 11-digit standard: 01XXXXXXXXX)
 */
export function isValidPhone(phone: string): boolean {
  const clean = normalizeDigits(phone).replace(/[^0-9]/g, '');
  return /^01[3-9]\d{8}$/.test(clean);
}

/**
 * Maps Supabase / Auth error codes to user-friendly messages in Bangla & English.
 */
export function getFriendlyAuthErrorMessage(errorCodeOrMsg: string, lang: 'bn' | 'en' = 'bn'): string {
  const lower = (errorCodeOrMsg || '').toLowerCase();

  if (lower.includes('user already registered') || lower.includes('email-already-in-use') || lower.includes('already exists')) {
    return lang === 'bn'
      ? 'এই ইমেইল / অ্যাকাউন্ট ইতিমধ্যে নিবন্ধিত রয়েছে। অনুগ্রহ করে লগইন করুন।'
      : 'This email is already in use. Please sign in instead.';
  }
  if (lower.includes('invalid login credentials') || lower.includes('wrong-password') || lower.includes('invalid credentials')) {
    return lang === 'bn'
      ? 'ভুল মোবাইল/ইমেইল বা পাসওয়ার্ড দেওয়া হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।'
      : 'Invalid email/phone or password. Please try again.';
  }
  if (lower.includes('user not found') || lower.includes('user-not-found')) {
    return lang === 'bn'
      ? 'এই তথ্যের কোনো রেজিস্টার্ড অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে প্রথমে সাইন আপ করুন।'
      : 'No registered account found with these credentials. Please sign up first.';
  }
  if (lower.includes('password') && (lower.includes('short') || lower.includes('weak') || lower.includes('least 6 characters'))) {
    return lang === 'bn'
      ? 'পাসওয়ার্ড অত্যন্ত দুর্বল। কমপক্ষে ৬টি অক্ষর ব্যবহার করুন।'
      : 'Password must be at least 6 characters long.';
  }
  if (lower.includes('invalid email') || lower.includes('email format')) {
    return lang === 'bn'
      ? 'সঠিক ফরম্যাটের ইমেইল ঠিকানা দিন।'
      : 'Please enter a valid email address.';
  }
  if (lower.includes('rate limit') || lower.includes('too many requests')) {
    return lang === 'bn'
      ? 'অতিরিক্ত ভুল চেষ্টার কারণে সাময়িক লক হয়েছে। কিছুক্ষণ পর চেষ্টা করুন।'
      : 'Too many requests. Please wait a few moments and try again.';
  }
  if (lower.includes('timeout') || lower.includes('request_timeout')) {
    return lang === 'bn'
      ? 'অনুরোধের সময়সীমা শেষ হয়েছে। আপনার ইন্টারনেট সংযোগ পরীক্ষা করুন।'
      : 'Request timed out. Please check your internet connection.';
  }
  if (lower.includes('network') || lower.includes('fetch')) {
    return lang === 'bn'
      ? 'ইন্টারনেট সংযোগে সমস্যা হয়েছে। অনুগ্রহ করে সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।'
      : 'Network connection error. Please try again.';
  }

  return lang === 'bn'
    ? 'অথেন্টিকেশন সম্পন্ন করা যায়নি। অনুগ্রহ করে পুনরায় চেষ্টা করুন।'
    : 'Authentication failed. Please try again.';
}

/**
 * Check if a username is already taken in the Supabase 'profiles' table
 */
export async function checkUsernameAvailability(username: string): Promise<boolean> {
  const cleanUsername = username.trim().toLowerCase();
  if (!cleanUsername || cleanUsername.length < 3) return false;

  if (!isSupabaseConfigured) return true;

  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('username')
      .eq('username', cleanUsername)
      .maybeSingle();

    if (error) return true;
    return !data; // Available if no existing record
  } catch {
    return true;
  }
}

/**
 * Sign up a new user using Supabase Auth.
 * Automatically provisions:
 * 1. Supabase auth.users record
 * 2. profiles table entry
 * 3. user_roles default 'customer' role (and any secondary role requested)
 * 4. security_logs registration entry
 */
export async function signUpWithEmailPassword(params: {
  email: string;
  password: string;
  fullName: string;
  phone?: string;
  username?: string;
  role?: 'customer' | 'seller' | 'freelancer' | 'service_provider' | 'member';
  location?: {
    division?: string;
    district?: string;
    upazila?: string;
    mahalla?: string;
  };
  additionalProfile?: Partial<UserProfile>;
  lang?: 'bn' | 'en';
}): Promise<AuthResult> {
  const lang = params.lang || 'bn';
  const cleanEmail = normalizeDigits(params.email.trim().toLowerCase());
  const cleanPassword = params.password.trim();
  const division = params.location?.division || 'চট্টগ্রাম';
  const district = params.location?.district || 'খাগড়াছড়ি';
  const upazila = params.location?.upazila || 'খাগড়াছড়ি সদর';
  const mahalla = params.location?.mahalla || 'পৌর এলাকা';
  const locationCodes = getLocationCodes(division, district, upazila);
  const generatedUID = generateMemberUID(division, district, upazila);
  const cleanPhone = params.phone ? normalizeDigits(params.phone.trim()) : '';
  const username = params.username?.trim().toLowerCase() || `user_${Date.now().toString().slice(-6)}`;
  const role = params.role || 'customer';

  // Strict Validation
  if (!cleanPassword || cleanPassword.length < 6) {
    return {
      success: false,
      error: lang === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.',
      errorCode: 'weak-password'
    };
  }

  let resolvedUid = `usr_${Date.now()}`;

  // 1. Supabase Auth Sign Up
  if (isSupabaseConfigured && isValidEmailFormat(cleanEmail)) {
    try {
      const { data: authData, error: authError } = await withTimeout(
        supabase.auth.signUp({
          email: cleanEmail,
          password: cleanPassword,
          options: {
            data: {
              full_name: params.fullName.trim(),
              name: params.fullName.trim(),
              username,
              phone: cleanPhone,
              division,
              district,
              upazila,
              initial_role: role,
            }
          }
        }),
        8000,
        'AUTH_TIMEOUT'
      );

      if (authError) {
        return {
          success: false,
          error: getFriendlyAuthErrorMessage(authError.message, lang),
          errorCode: authError.code || 'sign-up-error'
        };
      }

      if (authData.user?.id) {
        resolvedUid = authData.user.id;
      }
    } catch (err: any) {
      console.warn('[Supabase Auth] Sign up notice:', err?.message || err);
      // Fallback for offline or local preview environments
    }
  }

  // 2. Build UserProfile Object
  const newUserProfile: UserProfile = {
    id: resolvedUid,
    uid: resolvedUid,
    memberUID: generatedUID,
    memberId: generatedUID,
    name: params.fullName.trim(),
    fullName: params.fullName.trim(),
    username,
    email: cleanEmail,
    phone: cleanPhone,
    role,
    division,
    district,
    upazila,
    thana: upazila,
    mahalla,
    para: mahalla,
    paraMahalla: `${mahalla}, ${upazila}`,
    divisionCode: locationCodes.divCode,
    districtCode: locationCodes.distCode,
    upazilaCode: locationCodes.upazilaCode,
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    isNidVerified: false,
    isPaidMember: false,
    createdAt: new Date().toISOString().split('T')[0],
    ...(params.additionalProfile || {}),
  };

  // 3. Upsert to Supabase profiles & user_roles tables
  if (isSupabaseConfigured) {
    try {
      // Upsert profile
      await supabase.from('profiles').upsert([
        {
          id: resolvedUid,
          full_name: newUserProfile.fullName,
          username,
          email: cleanEmail,
          phone: cleanPhone,
          avatar_url: newUserProfile.avatar,
          division,
          district,
          upazila,
          address: `${mahalla}, ${upazila}`,
          account_status: 'active',
          updated_at: new Date().toISOString()
        }
      ]);

      // Assign roles: customer + requested role
      await supabase.from('user_roles').upsert([
        { user_id: resolvedUid, role: 'customer' }
      ], { onConflict: 'user_id,role' });

      if (role && role !== 'customer') {
        await supabase.from('user_roles').upsert([
          { user_id: resolvedUid, role }
        ], { onConflict: 'user_id,role' });
      }

      // Security audit log
      await supabase.from('security_logs').insert([
        {
          user_id: resolvedUid,
          action: 'REGISTER',
          description: `User registration completed with role: ${role}`,
          device_info: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown'
        }
      ]);
    } catch (dbErr) {
      console.warn('[Supabase Database] Profile sync notice:', dbErr);
    }
  }

  // 4. Update in-memory databaseService cache
  try {
    await databaseService.saveUserProfile(newUserProfile, { skipUniqueCheck: true });
  } catch (cacheErr) {
    console.warn('[DatabaseService] Local sync note:', cacheErr);
  }

  return {
    success: true,
    user: newUserProfile,
    isNewUser: true,
  };
}

/**
 * Sign in an existing user using Supabase Auth.
 * Accepts either Email, Username, or Phone Number as the identifier.
 */
export async function signInWithEmailPassword(
  identifier: string,
  password: string,
  lang: 'bn' | 'en' = 'bn'
): Promise<AuthResult> {
  const cleanInput = normalizeDigits(identifier.trim());
  const cleanPassword = password.trim();

  if (!cleanInput) {
    return {
      success: false,
      error: lang === 'bn' ? 'অনুগ্রহ করে মোবাইল নম্বর বা ইমেইল লিখুন।' : 'Please enter email or phone number.',
      errorCode: 'invalid-input',
    };
  }

  let emailToAuth = cleanInput;

  // If input is not an email, resolve from username or phone in profiles table / cache
  if (!cleanInput.includes('@')) {
    if (isSupabaseConfigured) {
      try {
        const { data: profile } = await supabase
          .from('profiles')
          .select('email, id')
          .or(`username.eq.${cleanInput.toLowerCase()},phone.eq.${cleanInput}`)
          .maybeSingle();

        if (profile?.email) {
          emailToAuth = profile.email;
        }
      } catch (err) {
        console.warn('[Supabase] Identifier lookup notice:', err);
      }
    }

    // Fallback to in-memory cache
    if (emailToAuth === cleanInput) {
      const cached = await databaseService.getUserByIdOrPhone(cleanInput);
      if (cached?.email && cached.email.includes('@')) {
        emailToAuth = cached.email;
      }
    }
  }

  // 1. Authenticate via Supabase Auth
  if (isSupabaseConfigured && isValidEmailFormat(emailToAuth)) {
    try {
      const { data, error } = await withTimeout(
        supabase.auth.signInWithPassword({
          email: emailToAuth,
          password: cleanPassword,
        }),
        7000,
        'AUTH_TIMEOUT'
      );

      if (error) {
        return {
          success: false,
          error: getFriendlyAuthErrorMessage(error.message, lang),
          errorCode: error.code || 'invalid-credentials'
        };
      }

      if (data?.user) {
        const uid = data.user.id;

        // Fetch user profile and roles from Supabase
        let profileData: any = null;
        try {
          const { data: p } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', uid)
            .maybeSingle();
          profileData = p;
        } catch {
          // ignore
        }

        // Fetch roles
        let userRoles: string[] = ['customer'];
        try {
          const { data: r } = await supabase
            .from('user_roles')
            .select('role')
            .eq('user_id', uid);
          if (r && r.length > 0) {
            userRoles = r.map((item: any) => item.role);
          }
        } catch {
          // ignore
        }

        const primaryRole = userRoles.find(r => r !== 'customer') || 'customer';

        const userProfile: UserProfile = {
          id: uid,
          uid: uid,
          name: profileData?.full_name || data.user.user_metadata?.full_name || 'ব্যবহারকারী',
          fullName: profileData?.full_name || data.user.user_metadata?.full_name || 'ব্যবহারকারী',
          username: profileData?.username || data.user.user_metadata?.username || '',
          email: data.user.email || emailToAuth,
          phone: profileData?.phone || data.user.user_metadata?.phone || cleanInput,
          role: primaryRole,
          division: profileData?.division || 'চট্টগ্রাম',
          district: profileData?.district || 'খাগড়াছড়ি',
          upazila: profileData?.upazila || 'খাগড়াছড়ি সদর',
          mahalla: profileData?.address || 'শান্তিনগর',
          avatar: profileData?.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
          isNidVerified: false,
          isPaidMember: false,
          createdAt: profileData?.created_at || new Date().toISOString().split('T')[0],
        };

        // Audit Log
        try {
          await supabase.from('security_logs').insert([
            {
              user_id: uid,
              action: 'LOGIN',
              description: 'User signed in successfully via Supabase Auth',
              device_info: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown'
            }
          ]);
        } catch {
          // safe ignore
        }

        // Cache locally
        databaseService.saveUserProfile(userProfile, { skipUniqueCheck: true }).catch(() => {});

        return {
          success: true,
          user: userProfile,
          isNewUser: false,
        };
      }
    } catch (err: any) {
      console.warn('[Supabase Auth] Sign in error:', err);
    }
  }

  // 2. Query in-memory cache for registered profile
  try {
    const foundUser = await databaseService.getUserByIdOrPhone(cleanInput);
    if (foundUser) {
      if (foundUser.password && foundUser.password.trim() !== cleanPassword) {
        return {
          success: false,
          error: getFriendlyAuthErrorMessage('wrong-password', lang),
          errorCode: 'wrong-password',
        };
      }

      return {
        success: true,
        user: foundUser,
        isNewUser: false,
      };
    }
  } catch (dbErr) {
    console.warn('[DatabaseService] User lookup error:', dbErr);
  }

  return {
    success: false,
    error: getFriendlyAuthErrorMessage('user-not-found', lang),
    errorCode: 'user-not-found',
  };
}

/**
 * Social Authentication via Supabase OAuth (Google / Facebook)
 */
export async function performSocialAuth(
  providerType: 'Google' | 'Facebook',
  defaultLocation?: { division?: string; district?: string; upazila?: string; mahalla?: string },
  lang: 'bn' | 'en' = 'bn'
): Promise<SocialAuthResult> {
  if (!isSupabaseConfigured) {
    // Graceful offline mock user for preview mode
    const fakeUid = `social_${Date.now()}`;
    const profile: UserProfile = {
      id: fakeUid,
      uid: fakeUid,
      name: providerType === 'Google' ? 'Google ব্যবহারকারী' : 'Facebook ব্যবহারকারী',
      fullName: providerType === 'Google' ? 'Google ব্যবহারকারী' : 'Facebook ব্যবহারকারী',
      email: `${providerType.toLowerCase()}_user@jhadimadi.com`,
      phone: '01800000000',
      role: 'customer',
      division: defaultLocation?.division || 'চট্টগ্রাম',
      district: defaultLocation?.district || 'খাগড়াছড়ি',
      upazila: defaultLocation?.upazila || 'খাগড়াছড়ি সদর',
      mahalla: defaultLocation?.mahalla || 'পৌর এলাকা',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
      isNidVerified: false,
      isPaidMember: false,
      createdAt: new Date().toISOString().split('T')[0]
    };
    return { success: true, user: profile, isNewUser: false };
  }

  try {
    const provider = providerType.toLowerCase() as 'google' | 'facebook';
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: typeof window !== 'undefined' ? window.location.origin : undefined
      }
    });

    if (error) {
      return {
        success: false,
        error: getFriendlyAuthErrorMessage(error.message, lang),
        errorCode: error.message
      };
    }

    return {
      success: true,
      isNewUser: false
    };
  } catch (err: any) {
    return {
      success: false,
      error: getFriendlyAuthErrorMessage(err?.message || 'Social auth failed', lang),
      errorCode: 'social-auth-error'
    };
  }
}

/**
 * Send password reset email using Supabase Auth
 */
export async function sendUserPasswordResetEmail(
  email: string,
  lang: 'bn' | 'en' = 'bn'
): Promise<{ success: boolean; error?: string }> {
  const cleanEmail = email.trim().toLowerCase();
  if (!isValidEmailFormat(cleanEmail)) {
    return {
      success: false,
      error: lang === 'bn' ? 'সঠিক ইমেইল ঠিকানা দিন।' : 'Please enter a valid email address.'
    };
  }

  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
        redirectTo: typeof window !== 'undefined' ? `${window.location.origin}?reset=true` : undefined
      });
      if (error) {
        return { success: false, error: getFriendlyAuthErrorMessage(error.message, lang) };
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'পাসওয়ার্ড রিসেট ইমেইল পাঠানো যায়নি' };
    }
  }

  return { success: true };
}

/**
 * Update authenticated user's password in Supabase Auth
 */
export async function updateUserPassword(
  newPassword: string,
  lang: 'bn' | 'en' = 'bn'
): Promise<{ success: boolean; error?: string }> {
  if (!newPassword || newPassword.length < 6) {
    return {
      success: false,
      error: lang === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.'
    };
  }

  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) {
        return { success: false, error: getFriendlyAuthErrorMessage(error.message, lang) };
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'পাসওয়ার্ড পরিবর্তন করা যায়নি' };
    }
  }

  return { success: true };
}

/**
 * Sign out the current user from Supabase Auth
 */
export async function performSignOut(): Promise<void> {
  if (isSupabaseConfigured) {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.warn('[Supabase Auth] Sign out error:', err);
    }
  }
}

/**
 * Fetch all roles assigned to a user from user_roles table
 */
export async function getUserRoles(userId: string): Promise<string[]> {
  if (!isSupabaseConfigured || !userId) return ['customer'];

  try {
    const { data, error } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userId);

    if (error || !data || data.length === 0) {
      return ['customer'];
    }
    return data.map((d: any) => d.role);
  } catch {
    return ['customer'];
  }
}

/**
 * Add a role to a user (e.g. seller, freelancer, service_provider)
 */
export async function addRoleToUser(
  userId: string,
  role: 'seller' | 'freelancer' | 'service_provider' | 'member'
): Promise<{ success: boolean; error?: string }> {
  if (!userId) return { success: false, error: 'User ID is required' };

  if (isSupabaseConfigured) {
    try {
      const { error } = await supabase
        .from('user_roles')
        .upsert([{ user_id: userId, role }], { onConflict: 'user_id,role' });

      if (error) {
        return { success: false, error: error.message };
      }

      await supabase.from('security_logs').insert([
        {
          user_id: userId,
          action: 'ROLE_ACTIVATED',
          description: `User activated role: ${role}`,
          device_info: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown'
        }
      ]);

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }

  return { success: true };
}

/**
 * Delete a user account from Supabase
 */
export async function deleteUserAccount(userId?: string): Promise<{ success: boolean; error?: string }> {
  try {
    if (userId) {
      await databaseService.deleteUserProfile(userId);
      if (isSupabaseConfigured) {
        await supabase.from('profiles').delete().eq('id', userId);
      }
    }
    await performSignOut();
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'অ্যাকাউন্ট ডিলিট করতে সমস্যা হয়েছে' };
  }
}

/**
 * Checks if error is an authentication domain error
 */
export function isDomainError(err: any): boolean {
  if (!err) return false;
  const msg = typeof err === 'string' ? err : (err?.message || '');
  return msg.includes('auth') || msg.includes('unauthorized') || msg.includes('domain');
}

