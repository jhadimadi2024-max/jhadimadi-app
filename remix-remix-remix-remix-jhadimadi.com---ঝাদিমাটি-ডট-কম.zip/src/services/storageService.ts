/**
 * Enterprise Safe Storage Service
 * Provides fault-tolerant localStorage / sessionStorage access with
 * automatic JSON parsing, fallback memory cache, and quota handling.
 */

class SafeStorageService {
  private memoryCache: Map<string, string> = new Map();

  private isStorageAvailable(type: 'localStorage' | 'sessionStorage'): boolean {
    try {
      const storage = window[type];
      const testKey = '__storage_test__';
      storage.setItem(testKey, testKey);
      storage.removeItem(testKey);
      return true;
    } catch {
      return false;
    }
  }

  public getItem<T>(key: string, defaultValue: T, type: 'localStorage' | 'sessionStorage' = 'localStorage'): T {
    try {
      if (this.isStorageAvailable(type)) {
        const item = window[type].getItem(key);
        if (item === null) return defaultValue;
        return JSON.parse(item) as T;
      } else {
        const cached = this.memoryCache.get(`${type}:${key}`);
        if (!cached) return defaultValue;
        return JSON.parse(cached) as T;
      }
    } catch (err) {
      console.warn(`[StorageService] Failed to read key "${key}":`, err);
      return defaultValue;
    }
  }

  public setItem<T>(key: string, value: T, type: 'localStorage' | 'sessionStorage' = 'localStorage'): boolean {
    try {
      const serialized = JSON.stringify(value);
      if (this.isStorageAvailable(type)) {
        window[type].setItem(key, serialized);
      }
      this.memoryCache.set(`${type}:${key}`, serialized);
      return true;
    } catch (err) {
      console.warn(`[StorageService] Failed to write key "${key}":`, err);
      this.memoryCache.set(`${type}:${key}`, JSON.stringify(value));
      return false;
    }
  }

  public removeItem(key: string, type: 'localStorage' | 'sessionStorage' = 'localStorage'): void {
    try {
      if (this.isStorageAvailable(type)) {
        window[type].removeItem(key);
      }
      this.memoryCache.delete(`${type}:${key}`);
    } catch (err) {
      console.warn(`[StorageService] Failed to remove key "${key}":`, err);
    }
  }

  public clear(type: 'localStorage' | 'sessionStorage' = 'localStorage'): void {
    try {
      if (this.isStorageAvailable(type)) {
        window[type].clear();
      }
      this.memoryCache.clear();
    } catch (err) {
      console.warn(`[StorageService] Failed to clear storage:`, err);
    }
  }
}

export const safeStorage = new SafeStorageService();
export default safeStorage;
