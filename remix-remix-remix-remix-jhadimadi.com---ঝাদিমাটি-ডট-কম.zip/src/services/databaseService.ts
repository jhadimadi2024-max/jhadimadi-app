/**
 * JHADIMADI.COM — ENTERPRISE DATABASE SERVICE
 * Direct Supabase PostgreSQL & In-Memory Real-time Engine
 * Architecture: ONE USER -> ONE PROFILE -> MULTIPLE ROLES
 * Completely replaces all legacy Cloud Firestore methods with zero Firebase dependencies.
 */

import { supabase, isSupabaseConfigured } from '../supabase';
import {
  UserProfile,
  UserSearchFilterParams,
  OrganicProduct,
  ServiceProvider,
  ProductOrder,
  BloodDonor,
  PujaGiftApplication
} from '../types';
import { sanitizeDatabasePayload } from '../utils/imageUtils';

export type Unsubscribe = () => void;

/**
 * Universal timeout wrapper for database calls
 */
async function withDbTimeout<T>(promise: Promise<T>, timeoutMs = 4000, fallbackVal?: T): Promise<T> {
  let timer: any;
  const timeoutPromise = new Promise<T>((resolve) => {
    timer = setTimeout(() => resolve(fallbackVal as T), timeoutMs);
  });
  return Promise.race([
    promise.then((res) => {
      clearTimeout(timer);
      return res;
    }),
    timeoutPromise
  ]);
}

class DatabaseService {
  private userCache: UserProfile[] = [];
  private productCache: OrganicProduct[] = [];
  private listeners: Array<() => void> = [];
  private isInitialized = false;
  private realtimeChannel: any = null;

  constructor() {
    this.initSupabaseListener();
  }

  /**
   * Initializes real-time Postgres changes channel on 'profiles' table
   */
  private initSupabaseListener(): void {
    if (!isSupabaseConfigured) {
      this.isInitialized = true;
      return;
    }

    try {
      this.realtimeChannel = supabase
        .channel('db-service-profiles')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'profiles' },
          () => {
            this.fetchUsersFromSupabase().catch(() => {});
          }
        )
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            this.fetchUsersFromSupabase().catch(() => {});
          }
        });
    } catch (err) {
      console.warn('[Supabase Realtime] Setup note:', err);
    }
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  private notify(): void {
    this.listeners.forEach((cb) => {
      try {
        cb();
      } catch (err) {
        console.error('[DatabaseService] Listener error:', err);
      }
    });
  }

  // ==========================================
  // UNIQUE CONSTRAINTS & DATA VALIDATION
  // ==========================================

  /**
   * Validates unique constraints: 1 Account per Phone Number, 1 per Email, and 1 per Username/NID.
   */
  public async checkUniqueConstraints(params: {
    phone?: string;
    email?: string;
    username?: string;
    nidNumber?: string;
    excludeUserId?: string;
  }): Promise<{ isDuplicate: boolean; conflictField?: 'phone' | 'email' | 'nid' | 'username'; message?: string }> {
    const cleanPhone = params.phone ? params.phone.replace(/[^0-9]/g, '') : '';
    const cleanEmail = params.email ? params.email.trim().toLowerCase() : '';
    const cleanUsername = params.username ? params.username.trim().toLowerCase() : '';
    const cleanNid = params.nidNumber ? params.nidNumber.replace(/[^0-9a-zA-Z]/g, '') : '';

    const isSyntheticEmail = cleanEmail.endsWith('@jhadimadi.com') || cleanEmail.includes('placeholder');

    // 1. Check in-memory cache
    for (const cached of this.userCache) {
      if (params.excludeUserId && cached.id === params.excludeUserId) continue;

      if (cleanPhone.length >= 10 && cached.phone) {
        const cachedDigits = cached.phone.replace(/[^0-9]/g, '');
        if (cachedDigits === cleanPhone || (cleanPhone.endsWith(cachedDigits) && cachedDigits.length >= 10)) {
          return {
            isDuplicate: true,
            conflictField: 'phone',
            message: 'এই ফোন নম্বর দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা হয়েছে।'
          };
        }
      }

      if (cleanEmail && !isSyntheticEmail && cached.email) {
        if (cached.email.trim().toLowerCase() === cleanEmail) {
          return {
            isDuplicate: true,
            conflictField: 'email',
            message: 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা হয়েছে।'
          };
        }
      }

      if (cleanUsername && (cached as any).username) {
        if ((cached as any).username.trim().toLowerCase() === cleanUsername) {
          return {
            isDuplicate: true,
            conflictField: 'username',
            message: 'এই ইউজারনেম ইতিমধ্যে ব্যবহৃত হয়েছে। অন্য একটি ইউজারনেম পছন্দ করুন।'
          };
        }
      }

      if (cleanNid.length >= 8 && cached.nidNumber) {
        const cachedNid = cached.nidNumber.replace(/[^0-9a-zA-Z]/g, '');
        if (cachedNid === cleanNid) {
          return {
            isDuplicate: true,
            conflictField: 'nid',
            message: 'এই এনআইডি নম্বর দিয়ে ইতিমধ্যে অ্যাকাউন্ট তৈরি করা হয়েছে।'
          };
        }
      }
    }

    // 2. Query Supabase directly if configured
    if (isSupabaseConfigured) {
      try {
        if (cleanPhone.length >= 10) {
          const { data } = await supabase
            .from('profiles')
            .select('id')
            .eq('phone', params.phone)
            .neq('id', params.excludeUserId || '')
            .maybeSingle();

          if (data) {
            return {
              isDuplicate: true,
              conflictField: 'phone',
              message: 'এই ফোন নম্বর দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা হয়েছে।'
            };
          }
        }

        if (cleanEmail && !isSyntheticEmail) {
          const { data } = await supabase
            .from('profiles')
            .select('id')
            .eq('email', cleanEmail)
            .neq('id', params.excludeUserId || '')
            .maybeSingle();

          if (data) {
            return {
              isDuplicate: true,
              conflictField: 'email',
              message: 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা হয়েছে।'
            };
          }
        }

        if (cleanUsername) {
          const { data } = await supabase
            .from('profiles')
            .select('id')
            .eq('username', cleanUsername)
            .neq('id', params.excludeUserId || '')
            .maybeSingle();

          if (data) {
            return {
              isDuplicate: true,
              conflictField: 'username',
              message: 'এই ইউজারনেম ইতিমধ্যে ব্যবহৃত হয়েছে। অন্য একটি ইউজারনেম পছন্দ করুন।'
            };
          }
        }
      } catch (err) {
        console.warn('[Supabase] Unique constraint check note:', err);
      }
    }

    return { isDuplicate: false };
  }

  // ==========================================
  // USER PROFILES & ACCOUNTS
  // ==========================================

  /**
   * Save user profile to Supabase 'profiles' table and in-memory cache
   */
  public async saveUserProfile(
    profile: UserProfile,
    options?: { skipUniqueCheck?: boolean }
  ): Promise<{ success: boolean; data?: UserProfile; error?: string }> {
    const docId = profile.id || `usr_${profile.phone?.replace(/[^0-9]/g, '') || Date.now()}`;

    if (!options?.skipUniqueCheck) {
      const constraintCheck = await this.checkUniqueConstraints({
        phone: profile.phone,
        email: profile.email,
        username: (profile as any).username,
        nidNumber: profile.nidNumber,
        excludeUserId: docId
      });

      if (constraintCheck.isDuplicate) {
        return {
          success: false,
          error: constraintCheck.message || 'এই এনআইডি/ফোন নম্বর/ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা হয়েছে।'
        };
      }
    }

    const payload: UserProfile = {
      ...profile,
      id: docId,
      uniqueId: profile.uniqueId || `JM-${Date.now().toString().slice(-4)}`,
      memberUID: profile.memberUID || `CG-${Date.now()}`,
      memberId: profile.memberId || profile.memberUID || `JM-${Date.now().toString().slice(-4)}`,
      name: profile.name || profile.fullName || 'Anonymous User',
      fullName: profile.fullName || profile.name || 'Anonymous User',
      phone: profile.phone || '',
      email: profile.email || `${profile.phone?.replace(/[^0-9]/g, '') || Date.now()}@jhadimadi.com`,
      role: profile.role || 'customer',
      division: profile.division || 'চট্টগ্রাম',
      district: profile.district || 'খাগড়াছড়ি',
      upazila: profile.upazila || profile.thana || 'খাগড়াছড়ি সদর',
      thana: profile.thana || profile.upazila || 'খাগড়াছড়ি সদর',
      mahalla: profile.mahalla || profile.para || '',
      para: profile.para || profile.mahalla || '',
      paraMahalla: profile.paraMahalla || `${profile.mahalla || ''}, ${profile.upazila || ''}`,
      bloodGroup: profile.bloodGroup || '',
      profession: profile.profession || profile.professionBn || 'সাধারন নাগরিক',
      professionBn: profile.professionBn || profile.profession || 'সাধারন নাগরিক',
      serviceCategory: profile.serviceCategory || profile.categorySkill || '',
      categorySkill: profile.categorySkill || profile.serviceCategory || '',
      nidNumber: profile.nidNumber || '',
      isNidVerified: Boolean(profile.isNidVerified),
      isPaidMember: Boolean(profile.isPaidMember),
      isBloodDonor: Boolean(profile.isBloodDonor ?? (!!profile.bloodGroup)),
      isBloodDonorAvailable: Boolean(profile.isBloodDonorAvailable ?? true),
      isAvailable: Boolean(profile.isAvailable ?? true),
      experienceYears: Number(profile.experienceYears) || 0,
      dailyRate: profile.dailyRate ? String(profile.dailyRate) : '',
      rateType: profile.rateType || 'দৈনিক',
      rating: Number(profile.rating) || 5.0,
      completedJobs: Number(profile.completedJobs) || 0,
      avatar: profile.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      shopName: profile.shopName || '',
      ownerName: profile.ownerName || '',
      businessCategory: profile.businessCategory || '',
      tradeLicenseOrNid: profile.tradeLicenseOrNid || '',
      detailedAddress: profile.detailedAddress || '',
      dateOfBirth: profile.dateOfBirth || '',
      bio: profile.bio || '',
      createdAt: profile.createdAt || new Date().toISOString(),
    };

    // Update in-memory live cache immediately
    const existingIdx = this.userCache.findIndex((u) => u.id === docId);
    if (existingIdx >= 0) {
      this.userCache[existingIdx] = payload;
    } else {
      this.userCache.unshift(payload);
    }
    this.notify();

    // Persist to Supabase
    if (isSupabaseConfigured) {
      try {
        const sanitized = await sanitizeDatabasePayload({
          id: docId,
          full_name: payload.fullName,
          username: (payload as any).username || `user_${docId.slice(-6)}`,
          email: payload.email,
          phone: payload.phone,
          avatar_url: payload.avatar,
          division: payload.division,
          district: payload.district,
          upazila: payload.upazila,
          address: payload.paraMahalla || payload.detailedAddress || '',
          account_status: 'active',
          updated_at: new Date().toISOString()
        });

        await supabase.from('profiles').upsert([sanitized]);

        // Ensure role exists in user_roles table
        if (payload.role) {
          await supabase.from('user_roles').upsert([
            { user_id: docId, role: payload.role }
          ], { onConflict: 'user_id,role' });
        }
      } catch (err) {
        console.warn('[Supabase] Profile save note:', err);
      }
    }

    return { success: true, data: payload };
  }

  /**
   * Delete user profile from Supabase and cache
   */
  public async deleteUserProfile(userId: string): Promise<{ success: boolean; error?: string }> {
    if (!userId) return { success: false, error: 'User ID is required' };

    this.userCache = this.userCache.filter((u) => u.id !== userId);
    this.notify();

    if (isSupabaseConfigured) {
      try {
        await supabase.from('profiles').delete().eq('id', userId);
        await supabase.from('user_roles').delete().eq('user_id', userId);
      } catch (err: any) {
        console.warn('[Supabase] Profile deletion error:', err);
        return { success: false, error: err?.message };
      }
    }

    return { success: true };
  }

  /**
   * Backward compatible alias
   */
  public async saveUserToFirestore(profile: UserProfile): Promise<{ success: boolean; data?: UserProfile; error?: string }> {
    return this.saveUserProfile(profile);
  }

  /**
   * Register or update a professional / service provider
   */
  public async registerProvider(
    providerData: Partial<UserProfile> | ServiceProvider,
    options?: { skipUniqueCheck?: boolean }
  ): Promise<{ success: boolean; data?: UserProfile; error?: string }> {
    const docId = (providerData as any).id || `pro_${(providerData as any).phone?.replace(/[^0-9]/g, '') || Date.now()}`;

    const providerProfile: UserProfile = {
      id: docId,
      uniqueId: (providerData as any).uniqueId || `PRO-${Date.now().toString().slice(-4)}`,
      memberUID: (providerData as any).memberUID || `CG-PRO-${Date.now()}`,
      memberId: (providerData as any).memberId || docId,
      name: providerData.name || (providerData as any).fullName || 'পেশাজীবী সেবাদাতা',
      fullName: (providerData as any).fullName || providerData.name || 'পেশাজীবী সেবাদাতা',
      phone: (providerData as any).phone || (providerData as any).realPhone || '',
      email: (providerData as any).email || `${(providerData as any).phone || Date.now()}@jhadimadi.com`,
      role: 'service_provider',
      division: (providerData as any).division || 'চট্টগ্রাম',
      district: (providerData as any).district || 'খাগড়াছড়ি',
      upazila: (providerData as any).upazila || (providerData as any).thana || 'খাগড়াছড়ি সদর',
      thana: (providerData as any).thana || (providerData as any).upazila || 'খাগড়াছড়ি সদর',
      mahalla: (providerData as any).mahalla || (providerData as any).para || '',
      para: (providerData as any).para || (providerData as any).mahalla || '',
      paraMahalla: (providerData as any).paraMahalla || `${(providerData as any).mahalla || ''}, ${(providerData as any).upazila || ''}`,
      bloodGroup: (providerData as any).bloodGroup || '',
      profession: (providerData as any).profession || (providerData as any).category || 'দক্ষ টেকনিশিয়ান',
      professionBn: (providerData as any).professionBn || (providerData as any).profession || 'দক্ষ কারিগর ও টেকনিশিয়ান',
      serviceCategory: (providerData as any).serviceCategory || (providerData as any).category || '',
      categorySkill: (providerData as any).categorySkill || (providerData as any).skills?.join?.(', ') || '',
      experienceYears: Number((providerData as any).experienceYears || (providerData as any).experience) || 3,
      dailyRate: String((providerData as any).dailyRate || (providerData as any).rate || '৬০০'),
      rateType: (providerData as any).rateType || 'দৈনিক',
      rating: Number((providerData as any).rating) || 5.0,
      completedJobs: Number((providerData as any).completedJobs) || 12,
      isNidVerified: true,
      isPaidMember: true,
      isAvailable: Boolean((providerData as any).isAvailable ?? true),
      isBloodDonor: Boolean((providerData as any).isBloodDonor ?? (!!(providerData as any).bloodGroup)),
      isBloodDonorAvailable: true,
      avatar: (providerData as any).avatar || (providerData as any).image || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200',
      nidNumber: (providerData as any).nidNumber || '',
      createdAt: (providerData as any).createdAt || new Date().toISOString(),
    };

    const saveRes = await this.saveUserProfile(providerProfile, options);

    // Also persist specific service provider profile table in Supabase
    if (isSupabaseConfigured && saveRes.success) {
      try {
        await supabase.from('service_provider_profiles').upsert([
          {
            user_id: docId,
            service_category: providerProfile.serviceCategory || providerProfile.profession,
            hourly_rate: Number(providerProfile.dailyRate) || 0,
            experience_years: providerProfile.experienceYears || 1,
            bio: providerProfile.bio || ''
          }
        ], { onConflict: 'user_id' });

        await supabase.from('user_roles').upsert([
          { user_id: docId, role: 'service_provider' }
        ], { onConflict: 'user_id,role' });
      } catch (spErr) {
        console.warn('[Supabase] Service provider specific table sync:', spErr);
      }
    }

    return saveRes;
  }

  /**
   * Fetch all users from Supabase 'profiles' table
   */
  public async fetchUsersFromSupabase(): Promise<UserProfile[]> {
    if (!isSupabaseConfigured) return this.userCache;

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error || !data) return this.userCache;

      const loaded: UserProfile[] = data.map((d: any) => ({
        id: d.id,
        uid: d.id,
        name: d.full_name || 'Anonymous',
        fullName: d.full_name || 'Anonymous',
        username: d.username || '',
        email: d.email || '',
        phone: d.phone || '',
        avatar: d.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
        role: 'customer',
        division: d.division || 'চট্টগ্রাম',
        district: d.district || 'খাগড়াছড়ি',
        upazila: d.upazila || 'খাগড়াছড়ি সদর',
        mahalla: d.address || d.mahalla || 'পৌর এলাকা',
        isNidVerified: !!d.is_nid_verified,
        isPaidMember: !!d.is_paid_member,
        createdAt: d.created_at || new Date().toISOString()
      }));

      this.userCache = loaded;
      this.isInitialized = true;
      this.notify();
      return loaded;
    } catch (err) {
      console.warn('[Supabase] fetch users note:', err);
      return this.userCache;
    }
  }

  /**
   * Backward compatible alias for fetchUsersFromFirestore
   */
  public async fetchUsersFromFirestore(): Promise<UserProfile[]> {
    return this.fetchUsersFromSupabase();
  }

  /**
   * Multi-Indexed Search Engine
   */
  public async searchUsers(params: UserSearchFilterParams): Promise<UserProfile[]> {
    const live = await this.fetchUsersFromSupabase();
    return this.searchUserProfiles(params, live);
  }

  /**
   * Realtime Snapshot Listener for 'users' / 'profiles'
   */
  public subscribeToUsersFirestore(onUpdate: (users: UserProfile[]) => void, _onError?: (err: Error) => void): Unsubscribe {
    onUpdate(this.userCache);
    return this.subscribe(() => {
      onUpdate(this.userCache);
    });
  }

  public getAllUserProfiles(): UserProfile[] {
    return this.userCache;
  }

  public saveUserProfiles(users: UserProfile[]): void {
    this.userCache = users;
    this.notify();
  }

  public addUserProfile(profile: UserProfile): UserProfile {
    this.saveUserProfile(profile).catch((err) => console.error('[DatabaseService] save error:', err));
    return profile;
  }

  public async updateUserProfile(id: string, updates: Partial<UserProfile>): Promise<UserProfile | null> {
    const idx = this.userCache.findIndex((u) => u.id === id);
    if (idx >= 0) {
      const merged = { ...this.userCache[idx], ...updates };
      this.userCache[idx] = merged;
      this.notify();

      if (isSupabaseConfigured) {
        try {
          await supabase.from('profiles').update({
            full_name: updates.fullName || updates.name,
            phone: updates.phone,
            avatar_url: updates.avatar,
            division: updates.division,
            district: updates.district,
            upazila: updates.upazila,
            address: updates.paraMahalla || updates.detailedAddress,
            updated_at: new Date().toISOString()
          }).eq('id', id);
        } catch (e) {
          console.warn('[Supabase] Update user note:', e);
        }
      }
      return merged;
    }
    return null;
  }

  public async getUserByIdOrPhone(identifier: string): Promise<UserProfile | null> {
    if (!identifier || !identifier.trim()) return null;
    const clean = identifier.trim();
    const cleanLower = clean.toLowerCase();
    const cleanDigits = clean.replace(/[^0-9]/g, '');

    // 1. In-memory cache first
    const cached = this.userCache.find((u) => {
      if (u.id === clean || u.uid === clean) return true;
      if (u.email && u.email.trim().toLowerCase() === cleanLower) return true;
      if ((u as any).username && (u as any).username.trim().toLowerCase() === cleanLower) return true;
      if (u.memberUID && u.memberUID.trim().toLowerCase() === cleanLower) return true;
      if (u.memberId && u.memberId.trim().toLowerCase() === cleanLower) return true;
      if (cleanDigits.length >= 10 && u.phone) {
        const uDigits = u.phone.replace(/[^0-9]/g, '');
        if (uDigits === cleanDigits || (cleanDigits.endsWith(uDigits) && uDigits.length >= 10)) return true;
      }
      return false;
    });

    if (cached) return cached;

    // 2. Supabase lookup
    if (isSupabaseConfigured) {
      try {
        const { data } = await supabase
          .from('profiles')
          .select('*')
          .or(`id.eq.${clean},username.eq.${cleanLower},email.eq.${cleanLower},phone.eq.${clean}`)
          .maybeSingle();

        if (data) {
          const user: UserProfile = {
            id: data.id,
            uid: data.id,
            name: data.full_name || 'ব্যবহারকারী',
            fullName: data.full_name || 'ব্যবহারকারী',
            username: data.username || '',
            email: data.email || '',
            phone: data.phone || '',
            avatar: data.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
            role: 'customer',
            division: data.division || 'চট্টগ্রাম',
            district: data.district || 'খাগড়াছড়ি',
            upazila: data.upazila || 'খাগড়াছড়ি সদর',
            mahalla: data.address || data.mahalla || 'পৌর এলাকা',
            isNidVerified: !!data.is_nid_verified,
            isPaidMember: !!data.is_paid_member,
            createdAt: data.created_at || new Date().toISOString()
          };
          this.userCache.push(user);
          return user;
        }
      } catch (err) {
        console.warn('[Supabase] getUserByIdOrPhone note:', err);
      }
    }

    return null;
  }

  public searchUserProfiles(params: UserSearchFilterParams, sourceUsers?: UserProfile[]): UserProfile[] {
    const users = sourceUsers && sourceUsers.length > 0 ? sourceUsers : this.userCache;
    const { district, thana, bloodGroup, profession, keyword, para } = params;

    return users.filter((user) => {
      if (district && district !== 'বাংলাদেশ' && district !== 'সকল জেলা' && district !== 'All' && district !== '') {
        const dNorm = district.toLowerCase().replace('জেলা', '').trim();
        const userD = (user.district || '').toLowerCase().replace('জেলা', '').trim();
        if (dNorm && userD && !userD.includes(dNorm) && !dNorm.includes(userD)) return false;
      }

      if (thana && thana !== 'সকল থানা/উপজেলা' && thana !== 'সকল উপজেলা' && thana !== 'সকল থানা' && thana !== 'All' && thana !== '') {
        const tNorm = thana.toLowerCase().replace('উপজেলা', '').replace('থানা', '').replace('সদর', '').trim();
        const userU = (user.upazila || user.thana || '').toLowerCase().replace('উপজেলা', '').replace('থানা', '').replace('সদর', '').trim();
        if (tNorm && userU && !userU.includes(tNorm) && !tNorm.includes(userU)) return false;
      }

      if (bloodGroup && bloodGroup !== 'সকল ব্লাড গ্রুপ' && bloodGroup !== 'সকল গ্রুপ' && bloodGroup !== 'All' && bloodGroup !== '') {
        const cleanBg = bloodGroup.replace('পজিটিভ', '+').replace('নেগেটিভ', '-').trim().toUpperCase();
        const userBg = (user.bloodGroup || '').replace('পজিটিভ', '+').replace('নেগেটিভ', '-').trim().toUpperCase();
        if (cleanBg && !userBg.includes(cleanBg)) return false;
      }

      if (profession && profession !== 'সকল পেশা' && profession !== 'সকল ক্যাটাগরি' && profession !== 'All' && profession !== '') {
        const pNorm = profession.toLowerCase().trim();
        const userP = `${user.profession || ''} ${user.professionBn || ''} ${user.serviceCategory || ''} ${user.categorySkill || ''}`.toLowerCase();
        if (!userP.includes(pNorm) && !pNorm.includes(userP)) return false;
      }

      if (para && para.trim().length > 0) {
        const paraNorm = para.toLowerCase().trim();
        const userPara = `${user.mahalla || ''} ${user.para || ''} ${user.paraMahalla || ''}`.toLowerCase();
        if (!userPara.includes(paraNorm)) return false;
      }

      if (keyword && keyword.trim().length > 0) {
        const kNorm = keyword.toLowerCase().trim();
        const searchableText = `${user.fullName || user.name || ''} ${user.phone || ''} ${user.profession || ''} ${user.professionBn || ''} ${user.serviceCategory || ''} ${user.district || ''} ${user.upazila || ''} ${user.mahalla || ''} ${user.para || ''} ${user.bloodGroup || ''} ${user.categorySkill || ''}`.toLowerCase();
        if (!searchableText.includes(kNorm)) return false;
      }

      return true;
    });
  }

  // ==========================================
  // PRODUCTS & ORDERS
  // ==========================================

  public saveProducts(products: OrganicProduct[]): void {
    this.productCache = products;
    this.notify();
  }

  public getProducts(defaultProducts: OrganicProduct[]): OrganicProduct[] {
    return this.productCache.length > 0 ? this.productCache : defaultProducts;
  }

  public saveProviders(providers: ServiceProvider[]): void {
    this.notify();
  }

  public getProviders(defaultProviders: ServiceProvider[]): ServiceProvider[] {
    return defaultProviders;
  }

  public saveOrders(orders: ProductOrder[]): void {
    this.notify();
  }

  public getOrders(defaultOrders: ProductOrder[]): ProductOrder[] {
    return defaultOrders;
  }

  public saveBloodDonors(donors: BloodDonor[]): void {
    this.notify();
  }

  public getBloodDonors(defaultDonors: BloodDonor[]): BloodDonor[] {
    return defaultDonors;
  }

  // ============================================================
  // PUJA GIFT & FESTIVAL WELFARE APPLICATIONS
  // ============================================================

  public async submitPujaGiftApplication(
    application: PujaGiftApplication
  ): Promise<{ success: boolean; id: string; error?: string }> {
    try {
      const docId = application.id || `PUJA-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const payload: PujaGiftApplication = {
        ...application,
        id: docId,
        appliedAt: application.appliedAt || new Date().toISOString(),
        status: application.status || 'Pending'
      };

      try {
        const stored = localStorage.getItem('jhadimadi_puja_applications');
        const existing: PujaGiftApplication[] = stored ? JSON.parse(stored) : [];
        const filtered = existing.filter((a) => a.id !== docId);
        filtered.unshift(payload);
        localStorage.setItem('jhadimadi_puja_applications', JSON.stringify(filtered));
      } catch {
        // safe ignore
      }

      this.notify();
      return { success: true, id: docId };
    } catch (err: any) {
      return { success: false, id: application.id, error: err?.message || 'Submission failed' };
    }
  }

  public async fetchPujaGiftApplications(): Promise<PujaGiftApplication[]> {
    try {
      const stored = localStorage.getItem('jhadimadi_puja_applications');
      if (stored) return JSON.parse(stored);
    } catch {
      // safe ignore
    }
    return [];
  }

  public async getPujaGiftApplicationById(appId: string): Promise<PujaGiftApplication | null> {
    const list = await this.fetchPujaGiftApplications();
    return list.find((a) => a.id === appId) || null;
  }
}

export const databaseService = new DatabaseService();
export default databaseService;
