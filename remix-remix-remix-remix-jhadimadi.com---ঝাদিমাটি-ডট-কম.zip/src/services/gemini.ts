/**
 * Gemini AI Client Service
 * Hyperlocal AI Assistance, Smart Intent Parsing & Content Assistant
 * Connects to server-side Gemini 3.7 Flash API with graceful fallback.
 */

export interface GeminiAssistantResponse {
  responseBn: string;
  recommendedCategory?: string;
  estimatedPriceRange?: string;
  suggestedActions?: string[];
  source?: 'gemini-live' | 'domain-fallback';
}

export interface GeminiSmartSearchResponse {
  category: string;
  cleanKeywords: string;
  explanation: string;
  estimatedRate: string;
  tags: string[];
  source?: 'gemini-live' | 'domain-fallback';
}

/**
 * Ask Gemini Assistant for hyperlocal rates, job market data & agricultural advice
 */
export async function askGeminiAssistant(
  userQuery: string,
  context?: { location?: string; timestamp?: string }
): Promise<GeminiAssistantResponse> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000);

    const response = await fetch('/api/gemini/assistant', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userQuery: userQuery.trim(),
        context: context || {
          location: 'রাঙ্গামাটি / খাগড়াছড়ি / বান্দরবান',
          timestamp: new Date().toISOString(),
        },
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`API responded with status ${response.status}`);
    }

    const result = await response.json();
    if (result.success && result.data) {
      return result.data;
    }

    throw new Error(result.message || 'Invalid response structure');
  } catch (error) {
    console.warn('[Gemini Service] Fallback triggered:', (error as Error).message);
    return {
      responseBn: `✨ **ঝাদিমাটি এআই সহায়তা:**\n\n"${userQuery}" সংক্রান্ত তথ্যের জন্য আমাদের ভেরিফাইড ডিরেক্টরি ব্রাউজ করুন অথবা সরাসরি সার্চ ফিল্টার ব্যবহার করুন।`,
      recommendedCategory: 'all',
      estimatedPriceRange: 'লোকাল মার্কেট রেট অনুযায়ী',
      suggestedActions: ['সার্চে দেখুন', 'হোমপেজে ফিরে যান'],
      source: 'domain-fallback',
    };
  }
}

/**
 * Smart Search with natural language query parsing via Gemini
 */
export async function smartSearchGemini(
  query: string,
  location?: string
): Promise<GeminiSmartSearchResponse> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    const response = await fetch('/api/gemini/smart-search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query: query.trim(),
        location: location || 'পার্বত্য চট্টগ্রাম',
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`API error ${response.status}`);
    }

    const result = await response.json();
    if (result.success) {
      return {
        category: result.category || 'all',
        cleanKeywords: result.cleanKeywords || query,
        explanation: result.explanation || 'ফিল্টার সম্পন্ন হয়েছে।',
        estimatedRate: result.estimatedRate || '',
        tags: result.tags || [],
        source: result.source || 'gemini-live',
      };
    }

    throw new Error('Search parsing failed');
  } catch (err) {
    console.warn('[Gemini Smart Search] Error fallback:', (err as Error).message);
    return {
      category: 'all',
      cleanKeywords: query,
      explanation: 'সার্চ রেজাল্ট লোড হয়েছে।',
      estimatedRate: 'আলোচনা সাপেক্ষ',
      tags: ['সার্চ দেখুন'],
      source: 'domain-fallback',
    };
  }
}

export interface GeminiProductRecommendation {
  id?: string;
  name: string;
  price: string;
  category?: string;
  image?: string;
}

export interface GeminiSupportChatResponse {
  replyBn: string;
  replyEn?: string;
  recommendedProducts?: GeminiProductRecommendation[];
  quickReplyChips?: string[];
  source?: string;
}

export interface GeminiNidVerificationResult {
  success: boolean;
  isDuplicate?: boolean;
  isFakeDetected?: boolean;
  authenticityScore?: number;
  duplicateWarning?: string;
  tamperWarnings?: string[];
  message?: string;
  extractedData?: {
    nidNumber: string;
    nameBangla: string;
    nameEnglish: string;
    fatherName?: string;
    motherName?: string;
    dateOfBirth: string;
    bloodGroup?: string;
    address?: string;
    nidType: string;
    authenticityScore: number;
    isFakeDetected: boolean;
    tamperWarnings: string[];
    verificationSummaryBn: string;
  };
  verifiedBadge?: string;
}

/**
 * Ask Gemini Customer Support Chatbot
 */
export async function askGeminiSupportChat(
  message: string,
  conversationHistory: { role: 'user' | 'assistant'; content: string }[] = [],
  userContext?: { userName?: string; phone?: string; location?: string }
): Promise<GeminiSupportChatResponse> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000);

    const response = await fetch('/api/gemini/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message: message.trim(),
        conversationHistory,
        userContext,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Chat API responded with status ${response.status}`);
    }

    const result = await response.json();
    if (result.success) {
      return {
        replyBn: result.replyBn,
        replyEn: result.replyEn,
        recommendedProducts: result.recommendedProducts || [],
        quickReplyChips: result.quickReplyChips || [],
        source: result.source || 'gemini-3.7-flash',
      };
    }

    throw new Error(result.message || 'Support chat response failed');
  } catch (error) {
    console.warn('[Gemini Support Service] Fallback triggered:', (error as Error).message);
    const qLower = message.toLowerCase();
    
    // Greeting
    if (/^(হ্যালো|হাই|সালাম|আসসালামু|নমস্কার|কেমন আছেন|hello|hi|hey)/i.test(qLower) || qLower === 'হ্যালো' || qLower === 'হাই' || qLower === 'কেমন আছেন') {
      return {
        replyBn: `👋 **হ্যালো! আমি ঝাদিমাধি এআই।**\n\nআমি ভালো আছি, ধন্যবাদ! আপনি কেমন আছেন? ঝাদিমাধির পাহাড়ি অর্গানিক পণ্য (হলুদ, মরিচ, মধু, শুটকি), পণ্যের দাম, বা যেকোনো সেবা সম্পর্কে কী জানতে চান বলুন?`,
        recommendedProducts: [],
        quickReplyChips: ['হলুদের দাম', 'মরিচের দাম', 'খাঁটি মধু', 'ডেলিভারি চার্জ', 'মিস্ত্রি সেবা'],
        source: 'client-contextual',
      };
    }

    // Turmeric
    if (qLower.includes('হলুদ') || qLower.includes('turmeric') || qLower.includes('holud')) {
      return {
        replyBn: `🌿 **পাহাড়ি জুমের খাঁটি হলুদের গুঁড়া (৫০০ গ্রাম):**\n\n• **দাম:** মাত্র **৳১৮০** (পূর্বমূল্য ৳২২০)\n• **উৎস:** রাঙামাটি বরকলের পাহাড়ি জুম\n• **বৈশিষ্ট্য:** উচ্চ কারকিউমিন সমৃদ্ধ, গাঢ় প্রাকৃতিক সোনালী রঙ ও কাঁচা হলুদের খাঁটি সুবাস। সম্পূর্ণ রাসায়নিকমুক্ত।`,
        recommendedProducts: [
          {
            id: 'prod_turmeric_powder',
            name: 'পাহাড়ি জুমের খাঁটি হলুদের গুঁড়া (৫০০ গ্রাম)',
            price: '৳ ১৮০',
            category: 'SpicesGrains',
            image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80',
          },
        ],
        quickReplyChips: ['মরিচের দাম', 'পাহাড়ি মধু', 'ডেলিভারি নিয়ম'],
        source: 'client-contextual',
      };
    }

    // Chili
    if (qLower.includes('মরিচ') || qLower.includes('chili') || qLower.includes('morich')) {
      return {
        replyBn: `🌶️ **পাহাড়ি বোম্বাই ঝাল মরিচের গুঁড়া (২৫০ গ্রাম):**\n\n• **দাম:** মাত্র **৳১৬০** (পূর্বমূল্য ৳১৯৫)\n• **উৎস:** বান্দরবান রোয়াংছড়ি\n• **বৈশিষ্ট্য:** রোদে শুকানো পাহাড়ি জুমের তাজা মরিচ, তীব্র সুবাস ও প্রাকৃতিক গাঢ় লাল রঙ।`,
        recommendedProducts: [
          {
            id: 'prod_chili_powder',
            name: 'পাহাড়ি বোম্বাই ঝাল মরিচের গুঁড়া (২৫০ গ্রাম)',
            price: '৳ ১৬০',
            category: 'SpicesGrains',
            image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80',
          },
        ],
        quickReplyChips: ['হলুদের দাম', 'পাহাড়ি মধু', 'ডেলিভারি নিয়ম'],
        source: 'client-contextual',
      };
    }

    // Honey
    if (qLower.includes('মধু') || qLower.includes('honey')) {
      return {
        replyBn: `🍯 **বান্দরবানের পাহাড়ি চাকের খাঁটি কাঁচা মধু (১ কেজি):**\n\n• **দাম:** **৳৯৫০**\n• **উৎস:** বান্দরবান রুমা ও থানচির অরণ্য\n• **বৈশিষ্ট্য:** সরাসরি পাহাড়ি চাক থেকে সংগৃহীত ১০০% কাঁচা অপ্রক্রিয়াজাত মধু।`,
        recommendedProducts: [
          {
            id: 'prod_wild_honey',
            name: 'বান্দরবানের পাহাড়ি চাকের খাঁটি কাঁচা মধু (১ কেজি)',
            price: '৳ ৯৫০',
            category: 'CraftsHoney',
            image: 'https://images.unsplash.com/photo-1587049352847-4a222e784d38?auto=format&fit=crop&w=600&q=80',
          },
        ],
        quickReplyChips: ['হলুদের দাম', 'মরিচের দাম', 'ডেলিভারি নিয়ম'],
        source: 'client-contextual',
      };
    }

    return {
      replyBn: `✨ **ঝাদিমাধি এআই সহায়তা:**\n\n"${message}" সংক্রান্ত যেকোনো তথ্য ও সহায়তায় আমরা প্রস্তুত।\n\n• **ডেলিভারি:** পাহাড়ি এলাকায় ২-৪ ঘণ্টা (চার্জ ৳৪০), সারাদেশে ২৪-৪৮ ঘণ্টায় ক্যাশ অন ডেলিভারি।\n• **পেমেন্ট:** বিকাশ, নগদ, রকেট ও ক্যাশ অন ডেলিভারি (COD)।\n• নির্দিষ্ট পণ্যের দাম জানতে পণ্যের নাম লিখে মেসেজ দিন (যেমন: "হলুদের দাম কত?")।`,
      recommendedProducts: [],
      quickReplyChips: ['হলুদের দাম', 'মরিচের দাম', 'খাঁটি মধু', 'ডেলিভারি চার্জ', 'মিস্ত্রি সেবা'],
      source: 'client-fallback',
    };
  }
}

/**
 * Verify Bangladesh NID Card using Gemini Vision API
 */
export async function verifyNidWithGeminiVision(
  imageBase64: string,
  backImageBase64?: string,
  userInfo?: { phone?: string; userName?: string }
): Promise<GeminiNidVerificationResult> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 20000);

    const response = await fetch('/api/nid-verify-gemini', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        imageBase64,
        backImageBase64,
        phone: userInfo?.phone || '',
        userName: userInfo?.userName || '',
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('[Gemini NID Verification Service Error]:', error);
    return {
      success: false,
      isFakeDetected: false,
      message: 'সার্ভার সংযোগে ত্রুটি হয়েছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।',
    };
  }
}

