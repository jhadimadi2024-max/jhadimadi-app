import { safeStorage } from './storageService';

export interface TrafficMetric {
  date: string;
  visitors: number;
  orders: number;
  searches: number;
  newRegistrations: number;
}

export interface DistrictDistribution {
  district: string;
  visitors: number;
  providers: number;
  percentage: number;
}

export interface SearchQueryItem {
  query: string;
  count: number;
  category: string;
  trend: 'up' | 'down' | 'steady';
}

export interface KycModerationMetric {
  totalPending: number;
  totalApproved: number;
  totalRejected: number;
  verifiedPercentage: number;
}

const STORAGE_KEYS = {
  SEARCH_QUERIES: 'jhadimadi_analytics_searches',
  VISITOR_LOGS: 'jhadimadi_analytics_visitors',
  DISTRICT_DATA: 'jhadimadi_analytics_districts',
};

class AnalyticsService {
  /**
   * Log search query analytics with trend tracking
   */
  public logSearchQuery(query: string, category: string = 'General'): void {
    if (!query || query.trim().length === 0) return;
    const cleanQuery = query.trim().toLowerCase();
    const existing = safeStorage.getItem<SearchQueryItem[]>(STORAGE_KEYS.SEARCH_QUERIES, []);

    const itemIndex = existing.findIndex((item) => item.query.toLowerCase() === cleanQuery);
    if (itemIndex >= 0) {
      existing[itemIndex].count += 1;
      existing[itemIndex].trend = 'up';
    } else {
      existing.unshift({
        query: query.trim(),
        count: 1,
        category,
        trend: 'up',
      });
    }

    safeStorage.setItem(STORAGE_KEYS.SEARCH_QUERIES, existing.slice(0, 30));
  }

  /**
   * Get top search queries for admin dashboard
   */
  public getTopSearchQueries(): SearchQueryItem[] {
    return safeStorage.getItem<SearchQueryItem[]>(STORAGE_KEYS.SEARCH_QUERIES, []);
  }

  /**
   * Get district-wise traffic breakdown based on real data
   */
  public getDistrictTraffic(districtsSummary?: { district: string; count: number }[]): DistrictDistribution[] {
    const defaultDistricts = [
      { district: 'খাগড়াছড়ি (Khagrachhari)', key: 'খাগড়াছড়ি' },
      { district: 'রাঙ্গামাটি (Rangamati)', key: 'রাঙ্গামাটি' },
      { district: 'বান্দরবান (Bandarban)', key: 'বান্দরবান' },
      { district: 'চট্টগ্রাম (Chittagong)', key: 'চট্টগ্রাম' },
      { district: 'ঢাকা (Dhaka)', key: 'ঢাকা' },
    ];

    if (!districtsSummary || districtsSummary.length === 0) {
      return defaultDistricts.map(d => ({
        district: d.district,
        visitors: 0,
        providers: 0,
        percentage: 0
      }));
    }

    const total = districtsSummary.reduce((sum, d) => sum + d.count, 0);

    return defaultDistricts.map(d => {
      const found = districtsSummary.find(item => item.district.includes(d.key));
      const count = found ? found.count : 0;
      return {
        district: d.district,
        visitors: count,
        providers: count,
        percentage: total > 0 ? Math.round((count / total) * 100) : 0
      };
    });
  }

  /**
   * Get KYC moderation metrics based on live provider data
   */
  public getKycMetrics(providersCount: number = 0, verifiedCount: number = 0, rejectedCount: number = 0): KycModerationMetric {
    const totalPending = Math.max(0, providersCount - verifiedCount - rejectedCount);
    const percentage = providersCount > 0 ? Math.round((verifiedCount / providersCount) * 100) : 0;
    return {
      totalPending,
      totalApproved: verifiedCount,
      totalRejected: rejectedCount,
      verifiedPercentage: percentage,
    };
  }
}

export const analyticsService = new AnalyticsService();
export default analyticsService;
