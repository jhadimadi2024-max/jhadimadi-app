import React from 'react';
import { Home, Search, MessageSquare, UserPlus, User } from 'lucide-react';
import { Language, UserProfile } from '../types';
import { useAuth } from '../context/AuthContext';

export interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: any) => void;
  lang?: Language;
  isLoggedIn?: boolean;
  currentUser?: UserProfile | null;
  onPostClick?: () => void;
  onProfileClick?: () => void;
  onAuthClick?: () => void;
  onRegistrationClick?: () => void;
  onOpenAiChat?: () => void;
}

export const BottomNavigation: React.FC<BottomNavProps> = ({ 
  activeTab, 
  setActiveTab,
  lang = 'bn',
  isLoggedIn,
  currentUser: propUser,
  onProfileClick,
  onAuthClick,
  onRegistrationClick,
  onOpenAiChat
}) => {
  // Access global AuthContext safely if provided
  let authContextUser: UserProfile | null = null;
  try {
    const auth = useAuth();
    authContextUser = auth.currentUser;
  } catch (e) {
    // fallback to propUser if rendered outside AuthProvider
  }

  const activeUser = propUser !== undefined ? propUser : authContextUser;

  const handleRegistrationTabClick = () => {
    if (onRegistrationClick) {
      onRegistrationClick();
    } else if (onAuthClick) {
      onAuthClick();
    } else {
      setActiveTab('registration');
    }
  };

  const handleJhadimadiChatClick = () => {
    if (onOpenAiChat) {
      onOpenAiChat();
    } else {
      setActiveTab('ai_chat');
    }
  };

  const handleProfileClick = () => {
    if (onProfileClick) {
      onProfileClick();
    } else {
      setActiveTab('profile');
    }
  };

  const isRegistrationActive = 
    activeTab === 'registration' || 
    activeTab === 'track_selection' || 
    activeTab === 'registration_flow' || 
    activeTab === 'auth' || 
    activeTab === 'signin' || 
    activeTab === 'signup' || 
    activeTab === 'sp_form' || 
    activeTab === 'role_select';

  const isJhadimadiActive = activeTab === 'ai_chat' || activeTab === 'message' || activeTab === 'support';
  const isProfileActive = activeTab === 'profile' || activeTab === 'my-account';

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 z-50 w-full bg-[#009f4d] text-white border-t border-[#008c43] shadow-[0_-2px_10px_rgba(0,0,0,0.06)] m-0 pointer-events-auto"
      style={{
        backgroundColor: '#009f4d',
        paddingBottom: 'env(safe-area-inset-bottom, 0px)',
        paddingLeft: 'env(safe-area-inset-left, 0px)',
        paddingRight: 'env(safe-area-inset-right, 0px)',
      }}
      id="bottom-navigation-bar"
    >
      <div className="w-full h-11 sm:h-12 grid grid-cols-5 items-center justify-items-center px-1">
        {/* Slot 1 (Far Left): Home */}
        <button 
          id="btn-nav-home"
          type="button"
          onClick={() => setActiveTab('home')} 
          className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
          title={lang === 'en' ? 'Home' : 'হোম'}
        >
          <div className={`transition-colors flex items-center justify-center ${activeTab === 'home' ? 'text-amber-300' : 'text-white/85 group-hover:text-white'}`}>
            <Home className="w-4 h-4 stroke-[2.2]" />
          </div>
          <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${activeTab === 'home' ? 'font-bold text-amber-300' : 'font-medium text-white/90'}`}>
            {lang === 'en' ? 'Home' : 'হোম'}
          </span>
        </button>

        {/* Slot 2: Jhadimadi (Messaging/Chat Icon - Opens AI Messaging Overlay) */}
        <button 
          id="btn-nav-jhadimadi"
          type="button"
          onClick={handleJhadimadiChatClick} 
          className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none relative"
          title="ঝাদিমাধি এআই মেসেজিং ও সাপোর্ট"
        >
          <div className={`transition-colors flex items-center justify-center relative ${isJhadimadiActive ? 'text-amber-300' : 'text-white/85 group-hover:text-white'}`}>
            <MessageSquare className="w-4 h-4 stroke-[2.2]" />
            <span className="absolute -top-1 -right-2 bg-amber-400 text-slate-950 text-[6.5px] font-black px-1 rounded-full leading-none shadow-2xs">
              AI
            </span>
          </div>
          <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${isJhadimadiActive ? 'font-bold text-amber-300' : 'font-medium text-white/90'}`}>
            {lang === 'en' ? 'Jhadimadi' : 'ঝাদিমাধি'}
          </span>
        </button>

        {/* Slot 3 (Center): Registration */}
        <button 
          id="btn-nav-registration"
          type="button"
          onClick={handleRegistrationTabClick} 
          className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
          title={lang === 'bn' ? 'রেজিস্ট্রেশন বা একাউন্ট রোল নির্বাচন করুন' : 'Registration or Account Role Selection'}
        >
          <div className={`transition-colors flex items-center justify-center ${isRegistrationActive ? 'text-amber-300' : 'text-white/85 group-hover:text-white'}`}>
            <UserPlus className="w-4 h-4 stroke-[2.2]" />
          </div>
          <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${isRegistrationActive ? 'font-bold text-amber-300' : 'font-medium text-white/90'}`}>
            {lang === 'en' ? 'Registration' : 'রেজিস্ট্রেশন'}
          </span>
        </button>

        {/* Slot 4: Search */}
        <button 
          id="btn-nav-search"
          type="button"
          onClick={() => setActiveTab('search')} 
          className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
          title={lang === 'en' ? 'Search' : 'সার্চ'}
        >
          <div className={`transition-colors flex items-center justify-center ${activeTab === 'search' ? 'text-amber-300' : 'text-white/85 group-hover:text-white'}`}>
            <Search className="w-4 h-4 stroke-[2.2]" />
          </div>
          <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${activeTab === 'search' ? 'font-bold text-amber-300' : 'font-medium text-white/90'}`}>
            {lang === 'en' ? 'Search' : 'সার্চ'}
          </span>
        </button>

        {/* Slot 5 (Far Right): Profile (Strictly retained) */}
        <button 
          id="btn-nav-profile"
          type="button"
          onClick={handleProfileClick} 
          className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
          title={lang === 'bn' ? 'আমার প্রোফাইল' : 'Profile'}
        >
          <div className={`transition-colors flex items-center justify-center ${isProfileActive ? 'text-amber-300' : 'text-white/85 group-hover:text-white'}`}>
            {activeUser?.avatar ? (
              <img 
                src={activeUser.avatar} 
                alt="Profile" 
                className="w-4 h-4 rounded-full object-cover ring-1 ring-white" 
              />
            ) : (
              <User className="w-4 h-4 stroke-[2.2]" />
            )}
          </div>
          <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${isProfileActive ? 'font-bold text-amber-300' : 'font-medium text-white/90'}`}>
            {lang === 'en' ? 'Profile' : 'প্রোফাইল'}
          </span>
        </button>
      </div>
    </nav>
  );
};

// Also export as BottomNav for backward compatibility
export const BottomNav = BottomNavigation;
export default BottomNavigation;
