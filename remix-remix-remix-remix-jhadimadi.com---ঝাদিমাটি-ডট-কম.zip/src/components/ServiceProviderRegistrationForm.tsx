import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Camera,
  Upload,
  ArrowLeft,
  ShieldCheck,
  Search,
  Plus,
  X,
  FileText,
  Image as ImageIcon,
  Check,
  Eye,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Loader2,
  Lock,
  EyeOff,
  ShieldAlert,
  Globe,
} from 'lucide-react';
import { Language } from '../types';
import { ALL_PROFESSIONS_FLAT_LIST, BANGLADESH_GEO_DIRECTORY } from '../data/professionsMasterData';
import { databaseService } from '../services/databaseService';

export interface ServiceProviderRegistrationFormProps {
  currentUser?: any;
  initialData?: any;
  isEditMode?: boolean;
  lang?: Language | 'bn' | 'en' | string;
  onBack?: () => void;
  onSuccess?: (data: any) => void;
  onSubmitSuccess?: (data: any) => void;
}

export const ServiceProviderRegistrationForm: React.FC<ServiceProviderRegistrationFormProps> = ({
  currentUser,
  initialData,
  isEditMode = false,
  lang = 'bn',
  onBack,
  onSuccess,
  onSubmitSuccess,
}) => {
  const effectiveUser = initialData || currentUser;
  const [currentLang, setCurrentLang] = useState<'bn' | 'en'>(lang === 'en' ? 'en' : 'bn');
  const isBn = currentLang === 'bn';

  // Lightbox preview modal state
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [lightboxCaption, setLightboxCaption] = useState<string>('');

  // Initial selected professions from effectiveUser
  const initialProfessions = useMemo(() => {
    if (Array.isArray(effectiveUser?.selectedProfessions) && effectiveUser.selectedProfessions.length > 0) {
      return effectiveUser.selectedProfessions;
    }
    if (Array.isArray(effectiveUser?.skills) && effectiveUser.skills.length > 0) {
      return effectiveUser.skills;
    }
    if (effectiveUser?.profession) {
      return [effectiveUser.profession];
    }
    return [];
  }, [effectiveUser]);

  // Initial DOB parsing
  const initialDob = effectiveUser?.dob || effectiveUser?.dateOfBirth || '';
  let initDay = '15';
  let initMonth = '06';
  let initYear = '1992';
  if (initialDob && initialDob.includes('-')) {
    const parts = initialDob.split('-');
    if (parts.length === 3) {
      initYear = parts[0];
      initMonth = parts[1];
      initDay = parts[2];
    }
  }

  // Multi-Profession search & state
  const [selectedProfessions, setSelectedProfessions] = useState<string[]>(initialProfessions);
  const [professionSearch, setProfessionSearch] = useState('');
  const [isProfessionDropdownOpen, setIsProfessionDropdownOpen] = useState(false);
  const [customProfessionInput, setCustomProfessionInput] = useState('');
  const [showCustomInput, setShowCustomInput] = useState(false);
  const professionDropdownRef = useRef<HTMLDivElement>(null);

  // File input refs
  const profilePicInputRef = useRef<HTMLInputElement>(null);
  const nidFrontInputRef = useRef<HTMLInputElement>(null);
  const nidBackInputRef = useRef<HTMLInputElement>(null);
  const certsInputRef = useRef<HTMLInputElement>(null);
  const cvInputRef = useRef<HTMLInputElement>(null);
  const portfolioInputRef = useRef<HTMLInputElement>(null);

  // Form Data State
  const [formData, setFormData] = useState({
    profilePic: effectiveUser?.avatar || effectiveUser?.profilePic || effectiveUser?.photoUrl || '',
    fullName: effectiveUser?.name || effectiveUser?.fullName || '',
    fatherName: effectiveUser?.fatherName || '',
    motherName: effectiveUser?.motherName || '',
    birthDay: initDay,
    birthMonth: initMonth,
    birthYear: initYear,
    bloodGroup: effectiveUser?.bloodGroup || 'A+',
    nidNumber: effectiveUser?.nidNumber || '',
    mobileNumber: effectiveUser?.phone || effectiveUser?.mobileNumber || '',
    password: effectiveUser?.password || '',
    email: effectiveUser?.email || '',
    fullAddress: effectiveUser?.fullAddress || effectiveUser?.address || '',
    district: effectiveUser?.district || 'খাগড়াছড়ি (KSA - Khagrachhari)',
    upazila: effectiveUser?.upazila || effectiveUser?.thana || 'খাগড়াছড়ি সদর',
    paraMahalla: effectiveUser?.paraMahalla || effectiveUser?.area || effectiveUser?.mahalla || effectiveUser?.para || '',
    workNature: Array.isArray(effectiveUser?.workNature) && effectiveUser.workNature.length > 0
      ? effectiveUser.workNature
      : ['ঘণ্টাভিত্তিক', 'দৈনিক'],
    education: effectiveUser?.education || 'এসএসসি / দাখিল (SSC / Dakhil)',
    nidFrontImage: effectiveUser?.nidFrontImage || '',
    nidBackImage: effectiveUser?.nidBackImage || '',
    certificates: Array.isArray(effectiveUser?.certificates)
      ? effectiveUser.certificates
      : (effectiveUser?.certFile ? [effectiveUser.certFile] : []),
    cvFileName: effectiveUser?.cvFileName || '',
    cvFileData: effectiveUser?.cvFileData || '',
    portfolioPhotos: Array.isArray(effectiveUser?.portfolioPhotos) ? effectiveUser.portfolioPhotos : [],
    bio: effectiveUser?.bio || effectiveUser?.bioText || '',
  });

  // Re-sync form state if initialData/effectiveUser updates
  useEffect(() => {
    if (effectiveUser) {
      setFormData((prev) => ({
        ...prev,
        profilePic: effectiveUser.avatar || effectiveUser.profilePic || effectiveUser.photoUrl || prev.profilePic,
        fullName: effectiveUser.name || effectiveUser.fullName || prev.fullName,
        fatherName: effectiveUser.fatherName || prev.fatherName,
        motherName: effectiveUser.motherName || prev.motherName,
        bloodGroup: effectiveUser.bloodGroup || prev.bloodGroup,
        nidNumber: effectiveUser.nidNumber || prev.nidNumber,
        mobileNumber: effectiveUser.phone || effectiveUser.mobileNumber || prev.mobileNumber,
        email: effectiveUser.email || prev.email,
        fullAddress: effectiveUser.fullAddress || effectiveUser.address || prev.fullAddress,
        district: effectiveUser.district || prev.district,
        upazila: effectiveUser.upazila || effectiveUser.thana || prev.upazila,
        paraMahalla: effectiveUser.paraMahalla || effectiveUser.area || effectiveUser.mahalla || prev.paraMahalla,
        workNature: Array.isArray(effectiveUser.workNature) && effectiveUser.workNature.length > 0 ? effectiveUser.workNature : prev.workNature,
        education: effectiveUser.education || prev.education,
        nidFrontImage: effectiveUser.nidFrontImage || prev.nidFrontImage,
        nidBackImage: effectiveUser.nidBackImage || prev.nidBackImage,
        certificates: Array.isArray(effectiveUser.certificates) ? effectiveUser.certificates : prev.certificates,
        cvFileName: effectiveUser.cvFileName || prev.cvFileName,
        cvFileData: effectiveUser.cvFileData || prev.cvFileData,
        portfolioPhotos: Array.isArray(effectiveUser.portfolioPhotos) ? effectiveUser.portfolioPhotos : prev.portfolioPhotos,
        bio: effectiveUser.bio || effectiveUser.bioText || prev.bio,
      }));
      if (Array.isArray(effectiveUser.selectedProfessions) && effectiveUser.selectedProfessions.length > 0) {
        setSelectedProfessions(effectiveUser.selectedProfessions);
      } else if (Array.isArray(effectiveUser.skills) && effectiveUser.skills.length > 0) {
        setSelectedProfessions(effectiveUser.skills);
      } else if (effectiveUser.profession) {
        setSelectedProfessions([effectiveUser.profession]);
      }
    }
  }, [effectiveUser]);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasConsentedToPrivacy, setHasConsentedToPrivacy] = useState(false);
  const [consentError, setConsentError] = useState(false);

  // Close profession dropdown when clicking outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (professionDropdownRef.current && !professionDropdownRef.current.contains(e.target as Node)) {
        setIsProfessionDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // District List with KSA Khagrachhari at the top
  const districtList = useMemo(() => {
    const rawKeys = Object.keys(BANGLADESH_GEO_DIRECTORY);
    const khagrachhariKey = rawKeys.find((k) => k.includes('খাগড়াছড়ি') || k.includes('খাগড়াছড়ি'));
    const others = rawKeys.filter((k) => k !== khagrachhariKey);
    return [
      { key: khagrachhariKey || 'খাগড়াছড়ি', label: 'খাগড়াছড়ি (KSA - Khagrachhari)', isKSA: true },
      ...others.map((k) => ({ key: k, label: k, isKSA: false })),
    ];
  }, []);

  // Selected district key for upazilas
  const selectedDistrictKey = useMemo(() => {
    if (!formData.district) return 'খাগড়াছড়ি';
    if (formData.district.includes('খাগড়াছড়ি') || formData.district.includes('খাগড়াছড়ি') || formData.district.includes('KSA')) {
      return 'খাগড়াছড়ি';
    }
    const clean = formData.district.split(' ')[0];
    return clean;
  }, [formData.district]);

  // Dynamic Upazila List
  const upazilaList = useMemo(() => {
    const entry = BANGLADESH_GEO_DIRECTORY[selectedDistrictKey];
    if (entry && entry.thanas && entry.thanas.length > 0) {
      return entry.thanas;
    }
    return ['সদর', 'অন্যান্য'];
  }, [selectedDistrictKey]);

  // Filtered Professions from 1,000+ database
  const filteredProfessions = useMemo(() => {
    if (!professionSearch.trim()) {
      return ALL_PROFESSIONS_FLAT_LIST.slice(0, 15);
    }
    const query = professionSearch.toLowerCase();
    const matches = ALL_PROFESSIONS_FLAT_LIST.filter(
      (p) => p.name.toLowerCase().includes(query) || p.category.toLowerCase().includes(query)
    );
    return matches.slice(0, 25);
  }, [professionSearch]);

  // Add profession to selected list
  const handleAddProfession = (profName: string) => {
    const trimmed = profName.trim();
    if (!trimmed) return;
    if (!selectedProfessions.includes(trimmed)) {
      setSelectedProfessions((prev) => [...prev, trimmed]);
    }
    setProfessionSearch('');
    setCustomProfessionInput('');
    setShowCustomInput(false);
    setIsProfessionDropdownOpen(false);
  };

  // Remove profession from selected list
  const handleRemoveProfession = (profName: string) => {
    setSelectedProfessions((prev) => prev.filter((p) => p !== profName));
  };

  // Handle single file upload with security validation & preview
  const handleSingleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    field: 'profilePic' | 'nidFrontImage' | 'nidBackImage'
  ) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const ext = file.name.split('.').pop()?.toLowerCase() || '';
      const isDoc = field === 'nidFrontImage' || field === 'nidBackImage';
      const allowedExts = isDoc ? ['jpg', 'jpeg', 'png', 'webp', 'pdf'] : ['jpg', 'jpeg', 'png', 'webp', 'gif'];

      if (!allowedExts.includes(ext) || file.type.includes('svg') || file.type.includes('html')) {
        alert(isBn ? 'নিরাপত্তা স্বার্থে শুধুমাত্র ছবি ও ডকুমেন্ট ফাইল (JPG, PNG, WebP) গ্রহণযোগ্য।' : 'Security restriction: Only JPG, PNG, and WebP files are allowed.');
        return;
      }

      const maxSize = isDoc ? 15 * 1024 * 1024 : 5 * 1024 * 1024;
      if (file.size > maxSize) {
        alert(isBn ? `ফাইলের আকার সর্বোচ্চ ${isDoc ? 15 : 5} মেগাবাইট হতে পারবে।` : `File size cannot exceed ${isDoc ? 15 : 5}MB.`);
        return;
      }

      const url = URL.createObjectURL(file);
      setFormData((prev) => ({ ...prev, [field]: url }));
    }
  };

  // Handle multi certificate upload with security validation
  const handleCertificatesUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newUrls: string[] = [];
      const safeExtensions = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];

      Array.from(e.target.files).forEach((file) => {
        const ext = file.name.split('.').pop()?.toLowerCase() || '';
        if (safeExtensions.includes(ext) && !file.type.includes('svg') && !file.type.includes('html') && file.size <= 10 * 1024 * 1024) {
          newUrls.push(URL.createObjectURL(file));
        }
      });
      setFormData((prev) => ({
        ...prev,
        certificates: [...prev.certificates, ...newUrls],
      }));
    }
  };

  const removeCertificate = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      certificates: prev.certificates.filter((_, i) => i !== index),
    }));
  };

  // Handle CV/Biodata file upload with security validation
  const handleCvUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const ext = file.name.split('.').pop()?.toLowerCase() || '';
      const safeDocExts = ['pdf', 'doc', 'docx'];

      if (!safeDocExts.includes(ext) || file.size > 10 * 1024 * 1024) {
        alert(isBn ? 'শুধুমাত্র PDF বা DOC ফাইল (সর্বোচ্চ ১০ মেগাবাইট) গ্রহণযোগ্য।' : 'Only PDF or DOC files up to 10MB are allowed.');
        return;
      }

      const url = URL.createObjectURL(file);
      setFormData((prev) => ({
        ...prev,
        cvFileName: file.name,
        cvFileData: url,
      }));
    }
  };

  // Handle Portfolio multi-image upload with security validation
  const handlePortfolioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newUrls: string[] = [];
      const safeExtensions = ['jpg', 'jpeg', 'png', 'webp'];

      Array.from(e.target.files).forEach((file) => {
        const ext = file.name.split('.').pop()?.toLowerCase() || '';
        if (safeExtensions.includes(ext) && !file.type.includes('svg') && file.size <= 10 * 1024 * 1024) {
          newUrls.push(URL.createObjectURL(file));
        }
      });
      setFormData((prev) => ({
        ...prev,
        portfolioPhotos: [...prev.portfolioPhotos, ...newUrls],
      }));
    }
  };

  const removePortfolioPhoto = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      portfolioPhotos: prev.portfolioPhotos.filter((_, i) => i !== index),
    }));
  };

  // Toggle Work Nature
  const handleWorkNatureToggle = (item: string) => {
    setFormData((prev) => {
      const exists = prev.workNature.includes(item);
      const updated = exists
        ? prev.workNature.filter((w) => w !== item)
        : [...prev.workNature, item];
      return {
        ...prev,
        workNature: updated.length > 0 ? updated : [item],
      };
    });
  };

  // Dynamic verification calculation:
  // Evaluates whether all required fields and valid NID information are fully provided
  const hasValidNidNumber = Boolean(formData.nidNumber && formData.nidNumber.trim().length >= 10);
  const hasNidFrontDoc = Boolean(formData.nidFrontImage);
  const hasFullName = Boolean(formData.fullName && formData.fullName.trim().length >= 2);
  const hasPhone = Boolean(formData.mobileNumber && formData.mobileNumber.trim().length >= 10);
  const hasProfession = selectedProfessions.length > 0;

  // Unverified Status Safeguard:
  // If critical documents or mandatory fields (like NID number, full verification data)
  // are missing during partial submission, the profile status remains "Unverified" (অযাচাইকৃত / পেন্ডিং).
  // Only when ALL required fields and valid NID information are fully provided, it changes to "Verified".
  const isCompleteForVerification = Boolean(
    hasValidNidNumber &&
    hasNidFrontDoc &&
    hasFullName &&
    hasPhone &&
    hasProfession
  );

  // Submit Handler: Non-Blocking Flexible Partial / Incremental Registration with Database Persistence
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Google Play Store Compliance: Mandatory Privacy Consent Check
    if (!hasConsentedToPrivacy) {
      setConsentError(true);
      alert(
        isBn
          ? "ফর্ম জমা দিতে অনুগ্রহ করে ঝাদিমাদি ডট কম-এর শর্তাবলী এবং গোপনীয়তা নীতি (Privacy Policy) সম্মতি চেকবক্সে টিক দিন।"
          : "Please check and accept the Privacy Policy and Data Consent checkbox before submitting."
      );
      const consentBox = document.getElementById('sp-privacy-consent-box');
      if (consentBox) {
        consentBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }
    setConsentError(false);

    const trimmedName = formData.fullName.trim();
    const trimmedPhone = formData.mobileNumber.trim();

    // Flexible initial validation: only require at least one basic initial identifier (name or phone)
    if (!trimmedName && !trimmedPhone) {
      alert(
        isBn
          ? 'আংশিক নিবন্ধনের জন্য অনুগ্রহ করে অন্তত আপনার নাম অথবা মোবাইল নম্বর দিন।'
          : 'Please enter at least your name or mobile number for initial registration.'
      );
      return;
    }

    setIsSubmitting(true);

    const finalFullName = trimmedName || (isBn ? `প্রোভাইডার ${trimmedPhone.slice(-4) || 'সদস্য'}` : `Provider ${trimmedPhone.slice(-4) || 'Member'}`);
    const finalMobile = trimmedPhone || currentUser?.phone || '০১XXXXXXXXX';
    const finalProfessions = selectedProfessions.length > 0
      ? selectedProfessions
      : [isBn ? 'সাধারণ কারিগরি ও হোম সার্ভিস' : 'General Technical & Home Services'];

    const formattedDob = `${formData.birthYear}-${formData.birthMonth.padStart(2, '0')}-${formData.birthDay.padStart(2, '0')}`;
    const proId = currentUser?.id || `pro_${finalMobile.replace(/[^0-9]/g, '') || Date.now()}`;

    const preparedData = {
      ...formData,
      id: proId,
      name: finalFullName,
      fullName: finalFullName,
      phone: finalMobile,
      mobileNumber: finalMobile,
      password: formData.password || '',
      avatar: formData.profilePic || '',
      profilePic: formData.profilePic || '',
      fatherName: formData.fatherName || '',
      motherName: formData.motherName || '',
      email: formData.email || '',
      bloodGroup: formData.bloodGroup || '',
      education: formData.education || '',
      workNature: Array.isArray(formData.workNature) ? formData.workNature : [],
      certificates: Array.isArray(formData.certificates) ? formData.certificates : [],
      portfolioPhotos: Array.isArray(formData.portfolioPhotos) ? formData.portfolioPhotos : [],
      selectedProfessions: finalProfessions,
      profession: finalProfessions[0] || (isBn ? 'সার্ভিস প্রোভাইডার' : 'Service Provider'),
      skills: finalProfessions,
      skillsList: finalProfessions,
      dob: formattedDob,
      dateOfBirth: formattedDob,
      birthDay: formData.birthDay,
      birthMonth: formData.birthMonth,
      birthYear: formData.birthYear,
      district: formData.district,
      thana: formData.upazila,
      upazila: formData.upazila,
      area: formData.paraMahalla,
      mahalla: formData.paraMahalla,
      para: formData.paraMahalla,
      bioText: formData.bio || '',
      bio: formData.bio || '',
      // Google Play Store User Data and Privacy Compliance Attributes
      isPhoneHiddenByDefault: true,
      isNidHiddenByDefault: true,
      isAddressHiddenByDefault: true,
      phoneVisibilityPolicy: 'unlocked_on_confirmed_booking',
      privacyPolicyConsentAccepted: true,
      privacyConsentTimestamp: new Date().toISOString(),
      privacyConsentText: "আমি 'ঝাদিমাড়ি ডট কম'-এর শর্তাবলী এবং গোপনীয়তা নীতি (Privacy Policy)-তে সম্মত আছি এবং নিরাপত্তার স্বার্থে আমার এনআইডি, ফোন নম্বর ও লোকেশন ডেটা সংরক্ষণে সম্মতি প্রদান করছি।",
      // Verification flags - Unverified Status Safeguard
      isNidVerified: isCompleteForVerification,
      isVerified: isCompleteForVerification,
      verificationStatus: isCompleteForVerification ? 'verified' : 'unverified',
      verificationBadgeText: isCompleteForVerification
        ? (isBn ? 'যাচাইকৃত' : 'Verified')
        : (isBn ? 'অযাচাইকৃত / পেন্ডিং' : 'Unverified / Pending'),
      isPartialRegistration: !isCompleteForVerification,
      // Real clean metrics: 0 reviews and 0 completed jobs for newly registered profile
      rating: currentUser?.rating !== undefined ? currentUser.rating : 0,
      reviewCount: currentUser?.reviewCount !== undefined ? currentUser.reviewCount : 0,
      completedJobs: currentUser?.completedJobs !== undefined ? currentUser.completedJobs : 0,
      reviews: Array.isArray(currentUser?.reviews) ? currentUser.reviews : [],
      dailyRate: (currentUser as any)?.dailyRate || 0,
      joinedDate: (currentUser as any)?.joinedDate || new Date().toISOString().split('T')[0],
      role: 'provider',
      division: (currentUser as any)?.division || 'Chittagong Division (চট্টগ্রাম)',
      isPaidMember: true,
    };

    // Save to Database / Supabase
    try {
      await databaseService.saveUserProfile(preparedData as any, { skipUniqueCheck: true });
      await databaseService.registerProvider(preparedData as any);
    } catch (err) {
      console.warn('Database service save note:', err);
    }

    // Keep active localStorage session synchronized
    try {
      const activeCurrent = localStorage.getItem('jhadimadi_current_user');
      if (activeCurrent) {
        const parsed = JSON.parse(activeCurrent);
        if (parsed.id === proId || parsed.phone === finalMobile || !parsed.id) {
          localStorage.setItem('jhadimadi_current_user', JSON.stringify({
            ...parsed,
            ...preparedData,
          }));
        }
      }
    } catch (e) {
      console.warn('Local storage sync note:', e);
    }

    setIsSubmitting(false);

    if (onSubmitSuccess) {
      onSubmitSuccess(preparedData);
    }
    if (onSuccess) {
      onSuccess(preparedData);
    }
  };

  // Education list options
  const educationOptions = [
    'অষ্টম শ্রেণী পাস (Class 8 Pass)',
    'এসএসসি / দাখিল (SSC / Dakhil)',
    'এইচএসসি / আলিম (HSC / Alim)',
    'ডিপ্লোমা / কারিগরি শিক্ষা (Diploma / Vocational)',
    'ডিগ্রি / ফাজিল (Degree / Fazil)',
    'স্নাতক / অনার্স (Bachelor / Honors)',
    'স্নাতকোত্তর / মাস্টার্স / কামিল (Master / Kamil)',
    'অন্যান্য / ধর্মীয় ও ঐতিহ্যবাহী শিক্ষা (Other / Traditional)',
  ];

  const bloodGroupOptions = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const workNatureOptions = ['ঘণ্টাভিত্তিক', 'দৈনিক', 'চুক্তিভিত্তিক'];

  // Days (1 to 31)
  const daysArray = Array.from({ length: 31 }, (_, i) => String(i + 1));
  
  // Months (1 to 12)
  const monthsArray = [
    { value: '01', labelBn: 'জানুয়ারি (০১)', labelEn: 'January (01)' },
    { value: '02', labelBn: 'ফেব্রুয়ারি (০২)', labelEn: 'February (02)' },
    { value: '03', labelBn: 'মার্চ (০৩)', labelEn: 'March (03)' },
    { value: '04', labelBn: 'এপ্রিল (০৪)', labelEn: 'April (04)' },
    { value: '05', labelBn: 'মে (০৫)', labelEn: 'May (05)' },
    { value: '06', labelBn: 'জুন (০৬)', labelEn: 'June (06)' },
    { value: '07', labelBn: 'জুলাই (০৭)', labelEn: 'July (07)' },
    { value: '08', labelBn: 'আগস্ট (০৮)', labelEn: 'August (08)' },
    { value: '09', labelBn: 'সেপ্টেম্বর (০৯)', labelEn: 'September (09)' },
    { value: '10', labelBn: 'অক্টোবর (১০)', labelEn: 'October (10)' },
    { value: '11', labelBn: 'নভেম্বর (১১)', labelEn: 'November (11)' },
    { value: '12', labelBn: 'ডিসেম্বর (১২)', labelEn: 'December (12)' },
  ];

  // Years (2010 down to 1950)
  const yearsArray = Array.from({ length: 61 }, (_, i) => String(2010 - i));

  return (
    <div className="w-full max-w-md mx-auto bg-white p-3.5 sm:p-5 rounded-2xl shadow-xs border border-stone-200/90 my-1">
      
      {/* 1. Top Navigation & Layout Rules:
          - Clean Top Bar: Strictly NO progress score bars, percentage badges, or unnecessary headers.
          - Language Switcher: Toggle button (BN / EN) at the top-right corner.
      */}
      <div className="flex items-center justify-between border-b border-stone-200 pb-3 mb-4">
        {onBack ? (
          <button
            id="sp-form-back-btn"
            type="button"
            onClick={onBack}
            className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition cursor-pointer flex items-center gap-1 text-xs font-semibold"
            title={isBn ? 'ফিরে যান' : 'Back'}
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{isBn ? 'ফিরে যান' : 'Back'}</span>
          </button>
        ) : <div />}

        {/* Language Switcher: Toggle button (BN / EN) at the top-right corner */}
        <button
          id="sp-form-lang-toggle-btn"
          type="button"
          onClick={() => setCurrentLang(currentLang === 'bn' ? 'en' : 'bn')}
          className="px-2.5 py-1 border border-stone-300 rounded text-xs font-bold text-stone-700 hover:bg-stone-100 transition cursor-pointer shadow-2xs"
        >
          {currentLang === 'bn' ? 'English' : 'বাংলা'}
        </button>
      </div>

      {/* Header & Tagline: Large, bold, unboxed headline style */}
      <div id="sp-registration-form-header" className="mb-4 space-y-1.5 text-center px-1">
        <h1 className="text-base sm:text-lg md:text-xl font-bold text-stone-900 leading-snug">
          {isBn
            ? 'ঝাদিমাদি ডটকম এর একজন গর্বিত সেবা দাতা হতে নিচের রেজিস্ট্রেশন ফর্মটি পূরণ করুন।'
            : 'Fill out the registration form below to become a proud service provider of Jhadimadi.com.'}
        </h1>
        <p className="text-xs sm:text-sm font-medium text-stone-600 leading-relaxed">
          {isBn
            ? 'পৃথিবীর সকল পেশাই সম্মানের, কোনো পেশা ছোট নয়।'
            : 'All professions in the world are honorable, no profession is small.'}
        </p>
      </div>

      {/* Google Play Store Privacy Compliant Banner */}
      <div className="mb-5 bg-emerald-50 border border-emerald-300 rounded-xl p-3.5 flex items-start gap-2.5 shadow-2xs">
        <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
        <div className="text-xs text-emerald-900 leading-relaxed">
          <p className="font-bold text-emerald-950 mb-0.5">
            {isBn ? 'Google Play Store ডেটা প্রাইভেসী ও ইউজার সুরক্ষা নীতিমালা' : 'Google Play Store User Data & Privacy Policy'}
          </p>
          <p>
            {isBn
              ? 'আপনার নিরাপত্তা ও গোপনীয়তা রক্ষার্থে NID কার্ড, মোবাইল নম্বর ও বিস্তারিত বাসা-বাড়ির ঠিকানা সম্পূর্ণ প্রাইভেট/গোপন থাকবে। গ্রাহকরা শুধুমাত্র আপনার নাম, পেশা ও সাধারণ এলাকা দেখতে পারবেন। সেবা বুকিং উভয়পক্ষ থেকে নিশ্চিত হলেই কেবল পারস্পরিক যোগাযোগ তথ্য প্রকাশ পাবে।'
              : 'To safeguard your privacy, NID documents, phone numbers, and detailed physical addresses remain strictly hidden and private by default. Customers will only see your name, profession, and general area.'}
          </p>
        </div>
      </div>

      {/* Sequential Form Fields: Inputs stretch 100% full-width stacked vertically */}
      <form onSubmit={handleSubmit} className="flex flex-col space-y-6">
        
        {/* ========================================================================= */}
        {/* SECTION 1: BASIC INFO (১. প্রাথমিক তথ্য) */}
        {/* Full Name (Public), Father's & Mother's Name (Private), DOB & Blood Group */}
        {/* ========================================================================= */}
        <div className="p-4 sm:p-5 bg-white border border-stone-200 rounded-2xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">১</span>
              <h2 className="text-sm sm:text-base font-bold text-stone-900">
                {isBn ? 'প্রাথমিক তথ্য (Basic Info)' : 'Basic Information'}
              </h2>
            </div>
            <span className="text-[11px] text-stone-500 font-medium flex items-center gap-1">
              <Globe className="w-3 h-3 text-blue-600" />
              <span>{isBn ? 'নাম প্রকাশ্য' : 'Name Public'}</span>
            </span>
          </div>

          {/* Profile Picture Box: Square/Rectangular avatar upload container with live preview */}
          <div className="w-full flex flex-col items-center">
            <div
              id="profile-picture-upload-box"
              onClick={() => profilePicInputRef.current?.click()}
              className="w-32 h-32 sm:w-36 sm:h-36 rounded-xl border-2 border-dashed border-stone-300 hover:border-blue-500 bg-stone-50 hover:bg-blue-50/30 cursor-pointer flex flex-col items-center justify-center p-2 relative overflow-hidden transition group shadow-2xs"
            >
              {formData.profilePic ? (
                <>
                  <img
                    src={formData.profilePic}
                    alt="Profile Preview"
                    className="w-full h-full object-cover rounded-lg"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white text-xs font-bold gap-1 rounded-lg">
                    <Camera className="w-4 h-4" />
                    <span>{isBn ? 'পরিবর্তন' : 'Change'}</span>
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center text-center p-2">
                  <div className="w-9 h-9 rounded-lg bg-blue-100/80 text-blue-600 flex items-center justify-center mb-1.5">
                    <Camera className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-semibold text-stone-700 leading-tight">
                    {isBn ? 'ছবি তুলুন / নির্বাচন' : 'Upload Photo'}
                  </span>
                  <span className="text-[10px] text-stone-400 mt-0.5">
                    {isBn ? 'চারকোনা পাসপোর্ট সাইজ' : 'Square Photo'}
                  </span>
                </div>
              )}
            </div>
            <input
              ref={profilePicInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handleSingleImageUpload(e, 'profilePic')}
            />
          </div>

          {/* Full Name (পূর্ণ নাম): Public */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                পূর্ণ নাম (Full Name) <span className="text-emerald-700 text-xs font-normal bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200/60">(প্রাথমিক আবশ্যক)</span>
              </label>
              <span className="text-[10px] text-blue-700 bg-blue-50 px-2 py-0.5 rounded font-bold border border-blue-200">
                পাবলিক ভিউ
              </span>
            </div>
            <input
              id="sp-full-name-input"
              type="text"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              placeholder={isBn ? 'যেমন: মোহাম্মদ আব্দুল করিম' : 'e.g. Mohammad Abdul Karim'}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-medium"
            />
          </div>

          {/* Father's Name (পিতার নাম): Private */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                পিতার নাম (Father's Name) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                <span>ব্যক্তিগত / গোপন</span>
              </span>
            </div>
            <input
              id="sp-father-name-input"
              type="text"
              value={formData.fatherName}
              onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
              placeholder={isBn ? 'পিতার পূর্ণ নাম লিখুন' : "Enter Father's Name"}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs"
            />
          </div>

          {/* Mother's Name (মাতার নাম): Private */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                মাতার নাম (Mother's Name) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                <span>ব্যক্তিগত / গোপন</span>
              </span>
            </div>
            <input
              id="sp-mother-name-input"
              type="text"
              value={formData.motherName}
              onChange={(e) => setFormData({ ...formData, motherName: e.target.value })}
              placeholder={isBn ? 'মাতার পূর্ণ নাম লিখুন' : "Enter Mother's Name"}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs"
            />
          </div>

          {/* Date of Birth (জন্ম তারিখ): Private */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                জন্ম তারিখ (Date of Birth) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                <span>গোপন থাকবে</span>
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {/* Day Dropdown */}
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-0.5">
                  {isBn ? 'দিন (Day)' : 'Day'}
                </label>
                <select
                  id="sp-dob-day-select"
                  value={formData.birthDay}
                  onChange={(e) => setFormData({ ...formData, birthDay: e.target.value })}
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs sm:text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-medium"
                >
                  {daysArray.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              {/* Month Dropdown */}
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-0.5">
                  {isBn ? 'মাস (Month)' : 'Month'}
                </label>
                <select
                  id="sp-dob-month-select"
                  value={formData.birthMonth}
                  onChange={(e) => setFormData({ ...formData, birthMonth: e.target.value })}
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs sm:text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-medium"
                >
                  {monthsArray.map((m) => (
                    <option key={m.value} value={m.value}>
                      {isBn ? m.labelBn : m.labelEn}
                    </option>
                  ))}
                </select>
              </div>

              {/* Year Dropdown */}
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-0.5">
                  {isBn ? 'বছর (Year)' : 'Year'}
                </label>
                <select
                  id="sp-dob-year-select"
                  value={formData.birthYear}
                  onChange={(e) => setFormData({ ...formData, birthYear: e.target.value })}
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs sm:text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-medium"
                >
                  {yearsArray.map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Blood Group (রক্তের গ্রুপ): Dropdown select */}
          <div className="w-full">
            <label className="block text-xs sm:text-sm font-bold text-stone-800 mb-1">
              রক্তের গ্রুপ (Blood Group) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
            </label>
            <select
              id="sp-blood-group-select"
              value={formData.bloodGroup}
              onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-semibold"
            >
              {bloodGroupOptions.map((bg) => (
                <option key={bg} value={bg}>
                  {bg}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* SECTION 2: SERVICE DETAILS (২. সেবা ও পেশাগত বিবরণ) */}
        {/* Profession/Service Selection (Public), Work Nature & Qualification (Public) */}
        {/* ========================================================================= */}
        <div className="p-4 sm:p-5 bg-white border border-stone-200 rounded-2xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">২</span>
              <h2 className="text-sm sm:text-base font-bold text-stone-900">
                {isBn ? 'সেবা ও পেশাগত বিবরণ (Service Details)' : 'Service Details'}
              </h2>
            </div>
            <span className="text-[11px] text-blue-700 bg-blue-50 px-2 py-0.5 rounded font-bold border border-blue-200">
              গ্রাহকদের জন্য সম্পূর্ণ প্রকাশ্য
            </span>
          </div>

          {/* Multi-Profession & Service Selection Engine (বহুসংখ্যক পেশা নির্বাচন):
            Smart Searchable Multi-Select Auto-complete + Custom Add + Removable Tags
        */}
        <div className="w-full relative" ref={professionDropdownRef}>
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs sm:text-sm font-bold text-stone-800">
              বহুসংখ্যক পেশা ও সেবা নির্বাচন (Multi-Service Selection) <span className="text-red-500">*</span>
            </label>
            <span className="text-[11px] text-blue-700 font-semibold bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              ১,০০০+ পেশা ডাটাবেস
            </span>
          </div>

          <div className="relative">
            <input
              id="sp-profession-autocomplete-input"
              type="text"
              value={professionSearch}
              onChange={(e) => {
                setProfessionSearch(e.target.value);
                setIsProfessionDropdownOpen(true);
              }}
              onFocus={() => setIsProfessionDropdownOpen(true)}
              placeholder={
                isBn
                  ? 'পেশা সার্চ করুন ও যুক্ত করুন (যেমন: ইলেকট্রিশিয়ান, প্লাম্বার, ইমাম, এসি টেকনিশিয়ান...)'
                  : 'Search & add professions (e.g. Electrician, Plumber, AC Repair...)'
              }
              className="w-full p-3 pl-9 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-medium"
            />
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Autocomplete Suggestions Dropdown */}
          {isProfessionDropdownOpen && (
            <div className="absolute z-40 left-0 right-0 mt-1 bg-white border border-stone-200 rounded-xl shadow-xl max-h-60 overflow-y-auto divide-y divide-stone-100">
              <div className="p-2 bg-stone-50 text-[11px] font-bold text-stone-500 flex justify-between items-center">
                <span>{isBn ? 'পেশা নির্বাচন করুন (ক্লিক করলেই যুক্ত হবে)' : 'Click to select profession'}</span>
                <button
                  type="button"
                  onClick={() => setIsProfessionDropdownOpen(false)}
                  className="text-stone-400 hover:text-stone-700"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {filteredProfessions.map((prof, idx) => {
                const isAlreadySelected = selectedProfessions.includes(prof.name);
                return (
                  <button
                    key={`${prof.name}-${idx}`}
                    type="button"
                    onClick={() => {
                      if (!isAlreadySelected) {
                        handleAddProfession(prof.name);
                      }
                    }}
                    className={`w-full text-left p-2.5 flex items-center justify-between text-xs sm:text-sm transition cursor-pointer ${
                      isAlreadySelected
                        ? 'bg-blue-50/50 text-blue-900 font-semibold'
                        : 'text-stone-800 hover:bg-blue-50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      {isAlreadySelected && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                      <span>{prof.name}</span>
                    </div>
                    <span className="text-[10px] text-stone-400 font-medium px-2 py-0.5 bg-stone-100 rounded">
                      {prof.category}
                    </span>
                  </button>
                );
              })}

              {/* Custom Profession Add Field Button */}
              <div className="p-2.5 bg-blue-50/80 border-t border-blue-100">
                <button
                  type="button"
                  onClick={() => {
                    setShowCustomInput(true);
                    setIsProfessionDropdownOpen(false);
                  }}
                  className="w-full flex items-center gap-1.5 text-xs font-bold text-blue-700 hover:text-blue-800"
                >
                  <Plus className="w-4 h-4" />
                  <span>{isBn ? 'তালিকায় নেই? নিজের পছন্দের নতুন পেশা লিখুন' : 'Not in list? Add custom profession'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Custom Profession Input Box */}
          {showCustomInput && (
            <div className="mt-2 p-3 bg-amber-50 rounded-lg border border-amber-200">
              <label className="block text-xs font-bold text-amber-900 mb-1">
                {isBn ? 'কাস্টম পেশা / কাজের নাম লিখুন:' : 'Enter custom profession name:'}
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder={isBn ? 'যেমন: সৌর বিদ্যুৎ টেকনিশিয়ান' : 'e.g. Solar Tech'}
                  value={customProfessionInput}
                  onChange={(e) => setCustomProfessionInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddProfession(customProfessionInput);
                    }
                  }}
                  className="flex-1 p-2 bg-white border border-amber-300 rounded-md text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
                <button
                  type="button"
                  onClick={() => handleAddProfession(customProfessionInput)}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-md text-xs font-bold cursor-pointer"
                >
                  {isBn ? 'যোগ করুন' : 'Add'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowCustomInput(false)}
                  className="px-2 py-1.5 bg-stone-200 text-stone-700 rounded-md text-xs font-medium cursor-pointer"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
              </div>
            </div>
          )}

          {/* Selected Services Tags: Removable chips [ Electrician ✖ ] [ Plumber ✖ ] */}
          <div className="mt-2.5">
            <div className="flex items-center justify-between text-[11px] text-stone-500 mb-1.5">
              <span>
                {isBn
                  ? `নির্বাচিত সেবা: ${selectedProfessions.length}টি (গ্রাহকরা এই সেবাগুলো সার্চ করে আপনাকে খুঁজে পাবে)`
                  : `Selected services: ${selectedProfessions.length} (customers will find you by these tags)`}
              </span>
            </div>

            {selectedProfessions.length > 0 ? (
              <div className="flex flex-wrap gap-1.5 p-2.5 bg-stone-50 border border-stone-200 rounded-lg">
                {selectedProfessions.map((prof, idx) => (
                  <span
                    key={`${prof}-${idx}`}
                    className="inline-flex items-center gap-1.5 bg-white border border-blue-300 text-blue-900 text-xs font-semibold px-2.5 py-1 rounded-md shadow-2xs"
                  >
                    <span>{prof}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveProfession(prof)}
                      className="text-stone-400 hover:text-red-600 transition cursor-pointer p-0.5"
                      title="Remove service"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-xs text-amber-700 italic bg-amber-50 p-2 rounded border border-amber-200">
                {isBn ? 'কোনো সেবা নির্বাচিত হয়নি। উপরে সার্চ করে সেবা যুক্ত করুন।' : 'No services selected yet. Search above to add.'}
              </p>
            )}
          </div>
        </div>


          {/* Work Nature (কাজের ধরণ - Multi-select Checkboxes) */}
          <div className="w-full">
            <label className="block text-xs sm:text-sm font-bold text-stone-800 mb-1.5">
              কাজের ধরণ (Work Nature)
            </label>
            <div className="grid grid-cols-3 gap-2">
              {workNatureOptions.map((nature) => {
                const isChecked = formData.workNature.includes(nature);
                return (
                  <button
                    key={nature}
                    type="button"
                    onClick={() => handleWorkNatureToggle(nature)}
                    className={`p-2.5 rounded-lg border text-xs sm:text-sm font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      isChecked
                        ? 'border-blue-600 bg-blue-50 text-blue-800 ring-1 ring-blue-300'
                        : 'border-stone-300 bg-white text-stone-700 hover:border-stone-400'
                    }`}
                  >
                    {isChecked && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                    <span>{nature}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Educational Qualification */}
          <div className="w-full">
            <label className="block text-xs sm:text-sm font-bold text-stone-800 mb-1">
              শিক্ষাগত যোগ্যতা (Educational Qualification) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
            </label>
            <select
              id="sp-education-select"
              value={formData.education}
              onChange={(e) => setFormData({ ...formData, education: e.target.value })}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-medium"
            >
              {educationOptions.map((edu) => (
                <option key={edu} value={edu}>
                  {edu}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* SECTION 3: LOCATION (৩. এলাকা ও অবস্থান) */}
        {/* District, Upazila, Area/Mahalla (Public for local search), Detailed Physical Address (Private) */}
        {/* ========================================================================= */}
        <div className="p-4 sm:p-5 bg-white border border-stone-200 rounded-2xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">৩</span>
              <h2 className="text-sm sm:text-base font-bold text-stone-900">
                {isBn ? 'এলাকা ও অবস্থান (Location)' : 'Location & Address'}
              </h2>
            </div>
            <span className="text-[11px] text-stone-500 font-medium flex items-center gap-1">
              <Globe className="w-3 h-3 text-blue-600" />
              <span>{isBn ? 'সার্চ এলাকা প্রকাশ্য' : 'Area Public'}</span>
            </span>
          </div>

          {/* District (জেলা): 64 districts */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                জেলা নির্বাচন (District) <span className="text-red-500">*</span>
              </label>
              <span className="text-[10px] text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded font-bold">সার্চ ফিল্টার</span>
            </div>
            <select
              id="sp-district-select"
              value={formData.district}
              onChange={(e) => {
                const newDistrict = e.target.value;
                setFormData((prev) => ({
                  ...prev,
                  district: newDistrict,
                  upazila: 'সদর',
                }));
              }}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-semibold"
            >
              {districtList.map((d) => (
                <option key={d.key} value={d.label}>
                  {d.label} {d.isKSA ? '★ (প্রধান কার্যএলাকা)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Upazila / Thana (উপজেলা/থানা) */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                উপজেলা / থানা (Upazila / Thana) <span className="text-red-500">*</span>
              </label>
              <span className="text-[10px] text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded font-bold">সার্চ ফিল্টার</span>
            </div>
            <select
              id="sp-upazila-select"
              value={formData.upazila}
              onChange={(e) => setFormData({ ...formData, upazila: e.target.value })}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-semibold"
            >
              {upazilaList.map((thana) => (
                <option key={thana} value={thana}>
                  {thana}
                </option>
              ))}
            </select>
          </div>

          {/* Para / Mahalla / Village (পাড়া/মহল্লা/গ্রাম): Public general area */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                পাড়া / মহল্লা / গ্রাম (Para / Mahalla / Village) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
              </label>
              <span className="text-[10px] text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded font-bold">সাধারণ এলাকা</span>
            </div>
            <input
              id="sp-para-mahalla-input"
              type="text"
              value={formData.paraMahalla}
              onChange={(e) => setFormData({ ...formData, paraMahalla: e.target.value })}
              placeholder={isBn ? 'যেমন: আদালত পাড়া, কলেজ রোড, মধ্যম পাড়া' : 'e.g. Adalat Para, College Road'}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-medium"
            />
          </div>

          {/* Full Physical Address: Strictly Private / Hidden by default */}
          <div className="w-full pt-1">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                বিস্তারিত বাসা/প্রতিষ্ঠানের পূর্ণ ঠিকানা (Detailed Physical Address) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                <span>সম্পূর্ণ গোপন থাকবে</span>
              </span>
            </div>
            <textarea
              id="sp-full-address-textarea"
              rows={2}
              value={formData.fullAddress}
              onChange={(e) => setFormData({ ...formData, fullAddress: e.target.value })}
              placeholder={isBn ? 'বাড়ি/হোল্ডিং নম্বর, সড়ক নম্বর, বিস্তারিত অবস্থান (গ্রাহকদের নিকট এটি দেখানো হবে না)' : 'House/Holding number, street, detailed address (Will remain hidden from customers)'}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs resize-none"
            />
            <p className="mt-1 text-[11px] text-stone-500 font-medium">
              * নিরাপত্তা নিশ্চিত করতে এই পূর্ণ ঠিকানা জনসাধারণের কাছে প্রকাশ করা হয় না। শুধুমাত্র পারস্পরিক সেবা বুকিং নিশ্চিত হলে উভয়পক্ষের সম্মতিতে তথ্য দৃশ্যমান হবে।
            </p>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* SECTION 4: CONTACT & SENSITIVE DATA (৪. যোগাযোগ ও নিরাপত্তা তথ্য) */}
        {/* Mobile Number (Hidden, unlocks on booking with required helper disclaimer), Email Address */}
        {/* ========================================================================= */}
        <div className="p-4 sm:p-5 bg-white border border-stone-200 rounded-2xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">৪</span>
              <h2 className="text-sm sm:text-base font-bold text-stone-900">
                {isBn ? 'যোগাযোগ ও নিরাপত্তা তথ্য (Contact & Security)' : 'Contact & Security Data'}
              </h2>
            </div>
            <span className="text-[11px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
              <Lock className="w-2.5 h-2.5" />
              <span>ডিফল্ট হাইড / সুরক্ষিত</span>
            </span>
          </div>

          {/* Mobile Number: Phone input for verification, strictly private */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                মোবাইল নম্বর (Mobile Number) <span className="text-emerald-700 text-xs font-normal bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200/60">(প্রাথমিক আবশ্যক)</span>
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                <span>বুকিং ব্যতীত গোপন থাকবে</span>
              </span>
            </div>
            <input
              id="sp-mobile-number-input"
              type="tel"
              value={formData.mobileNumber}
              onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })}
              placeholder={isBn ? '০১XXXXXXXXX' : '01XXXXXXXXX'}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-mono"
            />
            {/* Required Google Play Store Helper Disclaimer */}
            <p className="mt-1.5 text-xs text-stone-600 font-medium bg-stone-50 border border-stone-200 rounded-lg p-2.5 flex items-start gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>নিরাপত্তা ও ভেরিফিকেশনের জন্য এই তথ্য নেওয়া হচ্ছে, যা সম্পূর্ণ সুরক্ষিত থাকবে এবং কারো সাথে প্রকাশ্যে শেয়ার করা হবে না।</span>
            </p>
          </div>

          {/* Email Address (optional) */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                ইমেইল ঠিকানা (Email Address) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                <span>গোপন থাকবে</span>
              </span>
            </div>
            <input
              id="sp-email-input"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder={isBn ? 'example@gmail.com' : 'example@gmail.com'}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs"
            />
          </div>

          {/* Account Password Field */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                অ্যাকাউন্ট পাসওয়ার্ড (Account Password) <span className="text-stone-400 font-normal">(লগইনের জন্য)</span>
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                <span>গোপন থাকবে</span>
              </span>
            </div>
            <input
              id="sp-password-input"
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              placeholder="••••••••"
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-mono"
            />
          </div>
        </div>

        {/* ========================================================================= */}
        {/* SECTION 5: DOCUMENTS & VERIFICATION (৫. কাগজপত্র, ভেরিফিকেশন ও পোর্টফোলিও) */}
        {/* NID Card & Number (Strictly Hidden), Certificates, Portfolio & Bio (Public) */}
        {/* ========================================================================= */}
        <div className="p-4 sm:p-5 bg-white border border-stone-200 rounded-2xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">৫</span>
              <h2 className="text-sm sm:text-base font-bold text-stone-900">
                {isBn ? 'কাগজপত্র ও ভেরিফিকেশন (Documents & Verification)' : 'Documents & Verification'}
              </h2>
            </div>
            <span className="text-[11px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
              <Lock className="w-2.5 h-2.5" />
              <span>এনআইডি সম্পূর্ণ গোপন</span>
            </span>
          </div>

          {/* National ID (NID) Number: Strictly Private */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                জাতীয় পরিচয়পত্র (NID) নম্বর <span className="text-stone-400 font-normal">(ভেরিফিকেশনের জন্য, প্রাথমিক সেটআপে ঐচ্ছিক)</span>
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                <span>সম্পূর্ণ গোপন থাকবে</span>
              </span>
            </div>
            <input
              id="sp-nid-number-input"
              type="text"
              value={formData.nidNumber}
              onChange={(e) => setFormData({ ...formData, nidNumber: e.target.value })}
              placeholder={isBn ? '১০ বা ১৭ ডিজিটের এনআইডি নম্বর লিখুন (ঐচ্ছিক)' : 'Enter 10 or 17 digit NID number (Optional)'}
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs font-mono"
            />
            {/* Required Google Play Store Helper Disclaimer under NID */}
            <p className="mt-1.5 text-xs text-stone-600 font-medium bg-stone-50 border border-stone-200 rounded-lg p-2.5 flex items-start gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>নিরাপত্তা ও ভেরিফিকেশনের জন্য এই তথ্য নেওয়া হচ্ছে, যা সম্পূর্ণ সুরক্ষিত থাকবে এবং কারো সাথে প্রকাশ্যে শেয়ার করা হবে না।</span>
            </p>
          </div>

          {/* NID Front & Back Image Upload (Hidden from public view) */}
          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-800">
                জাতীয় পরিচয়পত্র (NID) ছবি (সামনে ও পেছনে)
              </label>
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <EyeOff className="w-2.5 h-2.5" />
                <span>পাবলিক ভিউতে সম্পূর্ণ গোপন</span>
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div
                onClick={() => nidFrontInputRef.current?.click()}
                className="p-3 border-2 border-dashed border-stone-300 hover:border-blue-400 bg-white rounded-lg flex flex-col items-center justify-center cursor-pointer transition text-center min-h-[75px]"
              >
                {formData.nidFrontImage ? (
                  <span className="text-xs text-emerald-700 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>সামনের ছবি যুক্ত</span>
                  </span>
                ) : (
                  <>
                    <Upload className="w-4 h-4 text-stone-400 mb-0.5" />
                    <span className="text-xs font-medium text-stone-600">সামনে (Front)</span>
                  </>
                )}
              </div>
              <input
                ref={nidFrontInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleSingleImageUpload(e, 'nidFrontImage')}
              />

              <div
                onClick={() => nidBackInputRef.current?.click()}
                className="p-3 border-2 border-dashed border-stone-300 hover:border-blue-400 bg-white rounded-lg flex flex-col items-center justify-center cursor-pointer transition text-center min-h-[75px]"
              >
                {formData.nidBackImage ? (
                  <span className="text-xs text-emerald-700 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>পেছনের ছবি যুক্ত</span>
                  </span>
                ) : (
                  <>
                    <Upload className="w-4 h-4 text-stone-400 mb-0.5" />
                    <span className="text-xs font-medium text-stone-600">পেছনে (Back)</span>
                  </>
                )}
              </div>
              <input
                ref={nidBackInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleSingleImageUpload(e, 'nidBackImage')}
              />
            </div>
          </div>

          {/* Skill Certificates Upload (PNG/JPG with click-to-preview lightbox) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-stone-800">
                দক্ষতা ও সার্টিফিকেট আপলোড (Skill Certificates)
              </label>
              <span className="text-[10px] text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded font-bold">পাবলিক ক্রেডেনশিয়াল</span>
            </div>
            <div
              onClick={() => certsInputRef.current?.click()}
              className="p-3 border-2 border-dashed border-stone-300 hover:border-blue-400 bg-stone-50 rounded-lg flex items-center justify-center gap-2 cursor-pointer transition text-center"
            >
              <Upload className="w-4 h-4 text-stone-500" />
              <span className="text-xs font-bold text-stone-700">
                {isBn ? 'সার্টিফিকেট ছবি নির্বাচন করুন (PNG/JPG)' : 'Choose Certificate Images'}
              </span>
            </div>
            <input
              ref={certsInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleCertificatesUpload}
            />

            {formData.certificates.length > 0 && (
              <div className="grid grid-cols-4 gap-2 mt-2">
                {formData.certificates.map((certUrl, idx) => (
                  <div key={idx} className="relative group rounded-md overflow-hidden border border-stone-200 aspect-4/3 bg-stone-100">
                    <img src={certUrl} alt={`Cert ${idx + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => {
                        setLightboxImage(certUrl);
                        setLightboxCaption(`সার্টিফিকেট #${idx + 1}`);
                      }}
                      className="absolute inset-0 bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => removeCertificate(idx)}
                      className="absolute top-1 right-1 bg-red-600 text-white p-0.5 rounded shadow-xs hover:bg-red-700 transition cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Biodata / CV Document Upload (PDF/DOCX) */}
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">
              বায়োডাটা / সিভি ডকুমেন্ট আপলোড (PDF/DOCX) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
            </label>
            <div
              onClick={() => cvInputRef.current?.click()}
              className="p-3 border border-stone-300 hover:border-blue-400 bg-stone-50 rounded-lg flex items-center justify-between cursor-pointer transition"
            >
              <div className="flex items-center gap-2 truncate">
                <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                <span className="text-xs font-medium text-stone-700 truncate">
                  {formData.cvFileName || (isBn ? 'সিভি ফাইল নির্বাচন করুন (PDF বা DOCX)' : 'Choose CV / Biodata (PDF/DOCX)')}
                </span>
              </div>
              <span className="text-xs text-blue-600 font-bold shrink-0 ml-2">
                {formData.cvFileName ? (isBn ? 'পরিবর্তন' : 'Change') : (isBn ? 'ব্রাউজ' : 'Browse')}
              </span>
            </div>
            <input
              ref={cvInputRef}
              type="file"
              accept=".pdf,.doc,.docx"
              className="hidden"
              onChange={handleCvUpload}
            />
          </div>

          {/* Work Portfolio Photos Upload */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-stone-800">
                কাজের স্যাম্পল ও পোর্টফোলিও ছবি (Portfolio Gallery)
              </label>
              <span className="text-[10px] text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded font-bold">পাবলিক গ্যালারি</span>
            </div>
            <div
              onClick={() => portfolioInputRef.current?.click()}
              className="p-3 border-2 border-dashed border-stone-300 hover:border-blue-400 bg-stone-50 rounded-lg flex items-center justify-center gap-2 cursor-pointer transition text-center"
            >
              <ImageIcon className="w-4 h-4 text-stone-500" />
              <span className="text-xs font-bold text-stone-700">
                {isBn ? 'কাজের ছবি যুক্ত করুন (একাধিক ফটো)' : 'Add Portfolio Work Photos'}
              </span>
            </div>
            <input
              ref={portfolioInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handlePortfolioUpload}
            />

            {formData.portfolioPhotos.length > 0 && (
              <div className="grid grid-cols-4 gap-2 mt-2">
                {formData.portfolioPhotos.map((photoUrl, idx) => (
                  <div key={idx} className="relative group rounded-md overflow-hidden border border-stone-200 aspect-4/3 bg-stone-100">
                    <img src={photoUrl} alt={`Portfolio ${idx + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => {
                        setLightboxImage(photoUrl);
                        setLightboxCaption(`পোর্টফোলিও কাজের ছবি #${idx + 1}`);
                      }}
                      className="absolute inset-0 bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => removePortfolioPhoto(idx)}
                      className="absolute top-1 right-1 bg-red-600 text-white p-0.5 rounded shadow-xs hover:bg-red-700 transition cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Bio & Description: Rich text area (Public) */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs sm:text-sm font-bold text-stone-800">
                বায়ো / কাজের অভিজ্ঞতা ও বিবরণ (Bio & Professional Description) <span className="text-stone-400 font-normal">(ঐচ্ছিক)</span>
              </label>
              <span className="text-[10px] text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded font-bold">পাবলিক প্রোফাইল</span>
            </div>
            <textarea
              id="sp-bio-textarea"
              rows={3}
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              placeholder={
                isBn
                  ? 'আপনার কাজের দীর্ঘ অভিজ্ঞতা, বিশেষত্ব, টুলস ব্যবহারের পারদর্শিতা এবং গ্রাহকদের কী ধরণের সেরা সেবা প্রদান করেন তা বিস্তারিত লিখুন...'
                  : 'Write details of your work experience, specialty, and services provided to clients...'
              }
              className="w-full p-3 border border-stone-300 rounded-lg text-sm bg-white text-stone-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition shadow-2xs leading-relaxed resize-none"
            />
          </div>
        </div>

        {/* Submission Action */}
        {/* ========================================================================= */}
        {/* SECTION 6: MANDATORY PRIVACY CONSENT & SUBMISSION */}
        {/* Mandatory Privacy Policy Consent Checkbox + "সেভ ও প্রোফাইল তৈরি করুন" Submit Button */}
        {/* ========================================================================= */}
        <div id="sp-privacy-consent-box" className="space-y-4 pt-2">
          {/* Mandatory Privacy Consent Checkbox Box */}
          <div className={`p-4 rounded-xl border-2 transition-all ${
            consentError
              ? 'bg-red-50/90 border-red-500 ring-2 ring-red-200'
              : hasConsentedToPrivacy
              ? 'bg-emerald-50/90 border-emerald-500 ring-1 ring-emerald-200'
              : 'bg-amber-50/70 border-amber-300'
          }`}>
            <label className="flex items-start gap-3 cursor-pointer select-none">
              <input
                id="sp-privacy-consent-checkbox"
                type="checkbox"
                checked={hasConsentedToPrivacy}
                onChange={(e) => {
                  setHasConsentedToPrivacy(e.target.checked);
                  if (e.target.checked) setConsentError(false);
                }}
                className="mt-1 w-5 h-5 rounded border-stone-300 text-blue-600 focus:ring-blue-500 cursor-pointer shrink-0"
              />
              <div className="flex-1">
                <span className="text-xs sm:text-sm font-semibold text-stone-900 leading-snug block">
                  {isBn 
                    ? 'আমি সজ্ঞানে ও স্বেচ্ছায় এই তথ্যসমূহ প্রদান করতে সম্মতি জানাচ্ছি।' 
                    : 'I knowingly and willingly consent to provide these data.'}
                </span>
                <div className="flex items-center gap-1 mt-1 text-[11px] text-stone-500 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>
                    {isBn 
                      ? "নিরাপত্তার স্বার্থে ঝাদিমাদি ডট কম-এর শর্তাবলী ও ডেটা সুরক্ষায় সম্মতি প্রযোজ্য।" 
                      : "Governed by Jhadimadi data protection & safety policies."}
                  </span>
                </div>
              </div>
            </label>
            {consentError && (
              <p className="mt-2 text-xs font-bold text-red-600 flex items-center gap-1">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span>প্রোফাইল তৈরি করতে অনুগ্রহ করে শর্তাবলী ও গোপনীয়তা নীতিতে সম্মতি প্রদান করুন।</span>
              </p>
            )}
          </div>

          {/* Submission Button: "সেভ ও প্রোফাইল তৈরি করুন" */}
          <div>
            <button
              id="sp-submit-profile-btn"
              type="submit"
              disabled={isSubmitting || !hasConsentedToPrivacy}
              className={`w-full font-bold py-3.5 px-5 rounded-xl transition shadow-md text-sm sm:text-base flex items-center justify-center gap-2 ${
                !hasConsentedToPrivacy
                  ? 'bg-stone-300 text-stone-500 cursor-not-allowed shadow-none'
                  : isSubmitting
                  ? 'bg-blue-400 text-white cursor-wait'
                  : 'bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white hover:shadow-lg cursor-pointer'
              }`}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>{isBn ? 'সংরক্ষণ হচ্ছে...' : 'Saving profile...'}</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  <span>
                    {isEditMode
                      ? (isBn ? 'তথ্য আপডেট করুন' : 'Update Profile Information')
                      : (isBn ? 'সেভ ও প্রোফাইল তৈরি করুন' : 'Save & Create Profile')}
                  </span>
                </>
              )}
            </button>
            {!hasConsentedToPrivacy && (
              <p className="text-center text-[11px] text-stone-500 mt-1.5 font-medium">
                (বাটন সক্রিয় করতে উপরের শর্তাবলী ও গোপনীয়তা নীতি সম্মতি চেকবক্সে টিক দিন)
              </p>
            )}
          </div>
        </div>
      </form>

      {/* Lightbox Modal for Certificate / Portfolio preview */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          onClick={() => setLightboxImage(null)}
        >
          <div
            className="bg-white rounded-xl overflow-hidden max-w-lg w-full max-h-[85vh] flex flex-col relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-3 flex items-center justify-between border-b">
              <span className="text-xs font-bold text-stone-800">{lightboxCaption || 'ফাইল প্রিভিউ'}</span>
              <button
                type="button"
                onClick={() => setLightboxImage(null)}
                className="p-1 rounded text-stone-400 hover:text-stone-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-2 overflow-auto flex items-center justify-center bg-stone-950">
              <img src={lightboxImage} alt="Preview" className="max-h-[70vh] object-contain rounded" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceProviderRegistrationForm;


