import React from 'react';
import { AppMode, Language } from '../types';
import { RedCarrierLogo } from './RedCarrierLogo';
import { 
  Smartphone, 
  ShoppingBag, 
  ArrowLeft,
  UserPlus,
  UserCheck,
  Briefcase
} from 'lucide-react';

interface NavbarProps {
  mode: AppMode;
  setMode: (mode: AppMode) => void;
  lang: Language;
  setLang: (lang: Language) => void;
  cartCount: number;
  onOpenCart: () => void;
  onTriggerSOS?: (tab?: 'police' | 'ambulance' | 'blood') => void;
  showBack?: boolean;
  onBack?: () => void;
  onOpenProfile?: () => void;
  onOpenAuth?: () => void;
  onOpenSellerRegistration?: () => void;
  onOpenServiceRegistration?: () => void;
  isLoggedIn?: boolean;
  userName?: string;
  logoUrl?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  mode,
  setMode,
  lang,
  setLang,
  cartCount,
  onOpenCart,
  showBack,
  onBack,
  onOpenProfile,
  onOpenAuth,
  onOpenServiceRegistration,
  isLoggedIn,
  userName,
  logoUrl,
}) => {
  const safeLogoSrc = logoUrl || "https://i.ibb.co/3sWJ2R8/jhadimadi-red-logo.png";

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/90 shadow-xs shrink-0 transition-all">
      
      {/* 1. TOP NAVBAR: LOGO + CART + MEMBERSHIP */}
      <div className="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 bg-white flex items-center justify-between border-b border-slate-100 transition-all gap-2">
        
        {/* Left: Optional Back Button + Crisp Brand Logo */}
        <div className="flex items-center gap-2 min-w-0 flex-1">
          {showBack && onBack && (
            <button
              onClick={onBack}
              aria-label="Back"
              title="Back (পিছনে যান)"
              className="p-1.5 bg-slate-100 hover:bg-slate-200 text-[#1A1D20] rounded-xl flex items-center justify-center font-bold cursor-pointer transition-all active:scale-95 border border-slate-200 shrink-0"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}

          <div
            onClick={() => setMode('customer')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && setMode('customer')}
            aria-label="Jhadimadi.com Home"
            className="flex items-center cursor-pointer select-none group min-w-0"
            id="header-brand-logo"
            title="Jhadimadi.com Home"
          >
            <img
              src="https://i.ibb.co.com/sppWZhc9/logo33.png"
              alt="JHADIMADI Logo"
              className="h-10 w-auto object-contain mr-2 flex-shrink-0 group-hover:scale-105 transition-transform"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = "https://placehold.co/512x512/006A4E/FFF?text=JM";
              }}
            />

            <div className="flex flex-col justify-center">
              <span className="text-[17px] sm:text-[19px] font-black tracking-tight text-[#B80000] uppercase font-sans leading-none truncate">
                JHADIMADI.COM
              </span>
              <span className="text-[9px] font-bold text-slate-500 tracking-wider mt-0.5">
                ঝাদিমাটি ডট কম • CHT SUPER-APP
              </span>
            </div>
          </div>
        </div>

        {/* Right Side: Cart & Profile / Registration Actions */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Shopping Cart */}
          <button
            onClick={onOpenCart}
            aria-label="Shopping Cart"
            title="শপিং কার্ট"
            className="relative p-2 bg-white hover:bg-slate-100 text-[#1A1D20] rounded-xl border border-slate-200 cursor-pointer transition-all active:scale-95 shadow-2xs"
          >
            <ShoppingBag className="w-4 h-4 text-[#0A7B44]" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#FF9F1C] text-slate-950 font-black text-[8.5px] w-4 h-4 rounded-full flex items-center justify-center shadow-xs border-2 border-white">
                {cartCount}
              </span>
            )}
          </button>

          {/* Member Profile / Auth Button */}
          <button
            onClick={isLoggedIn ? onOpenProfile : (onOpenServiceRegistration || onOpenAuth)}
            aria-label={isLoggedIn ? 'User Profile' : 'Become a Member'}
            title={isLoggedIn ? 'সদস্য ড্যাশবোর্ড' : 'সদস্য হোন (Become a Member)'}
            className={`px-3 py-2 rounded-xl border text-[11px] font-black cursor-pointer transition-all flex items-center gap-1.5 shadow-2xs active:scale-95 whitespace-nowrap ${
              isLoggedIn 
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800 hover:bg-emerald-100 shadow-xs' 
                : 'bg-[#B80000] hover:bg-[#990000] border-[#B80000] text-white shadow-xs'
            }`}
          >
            {isLoggedIn ? (
              <>
                <UserCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="max-w-[75px] sm:max-w-[90px] truncate font-extrabold">{userName || 'ড্যাশবোর্ড'}</span>
              </>
            ) : (
              <>
                <UserPlus className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                <span className="font-extrabold tracking-tight">সদস্য হোন</span>
              </>
            )}
          </button>
        </div>

      </div>

      {/* 2. SUB-NAV: MODE SELECTOR & LANGUAGE SWITCHER */}
      <div className="px-3.5 py-1.5 bg-[#F8F9FA] flex items-center justify-between gap-2 text-[10.5px]">
        
        {/* App Mode Switcher */}
        <div className="flex items-center bg-slate-200/80 p-0.5 rounded-xl border border-slate-300/80">
          <button
            onClick={() => setMode('customer')}
            className={`px-2.5 py-0.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 text-[10.5px] ${
              mode === 'customer'
                ? 'bg-white text-[#0A7B44] shadow-2xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3 h-3" />
            <span>গ্রাহক (Customer)</span>
          </button>
          
          <button
            onClick={() => setMode('partner')}
            className={`px-2.5 py-0.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 text-[10.5px] ${
              mode === 'partner'
                ? 'bg-[#0A7B44] text-white shadow-2xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Briefcase className="w-3 h-3" />
            <span>পার্টনার (Partner)</span>
          </button>
        </div>

        {/* Language Selector */}
        <button 
          onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}
          aria-label="Switch Language"
          className="px-2 py-0.5 bg-white hover:bg-slate-100 text-[#1A1D20] border border-slate-200 rounded-lg font-extrabold text-[10px] cursor-pointer transition shadow-2xs"
        >
          {lang === 'bn' ? 'English' : 'বাংলা'}
        </button>
      </div>

    </header>
  );
};