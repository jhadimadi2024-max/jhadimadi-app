import React, { useState } from 'react';
import { StoreProduct } from '../data/productsData';
import { 
  X, Star, MapPin, ShieldCheck, ShoppingCart, Truck, 
  RotateCcw, CheckCircle2, Plus, Minus, Sparkles, Heart,
  Store, QrCode, Zap, Check
} from 'lucide-react';
import { Language, getTranslation } from '../utils/translations';
import { ProductDetailsModal } from './ProductDetailsModal';

interface ProductDetailModalProps {
  product: StoreProduct | null;
  onClose: () => void;
  onAddToCart: (product: StoreProduct, qty: number) => void;
  onDirectCheckout?: (product: StoreProduct, qty: number) => void;
  onVisitStore?: (sellerIdOrUniqueId: string) => void;
  lang?: Language;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = (props) => {
  return (
    <ProductDetailsModal
      isOpen={!!props.product}
      product={props.product as any}
      onClose={props.onClose}
      onAddToCart={(prod, qty) => props.onAddToCart(prod as StoreProduct, qty || 1)}
      onBuyNow={(prod, qty) => {
        if (props.onDirectCheckout) {
          props.onDirectCheckout(prod as StoreProduct, qty || 1);
        } else {
          props.onAddToCart(prod as StoreProduct, qty || 1);
        }
      }}
      onVisitStore={props.onVisitStore}
      lang={props.lang || 'bn'}
    />
  );
};
