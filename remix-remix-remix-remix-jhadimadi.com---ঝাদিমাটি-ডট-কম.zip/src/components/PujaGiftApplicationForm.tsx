import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Camera,
  Upload,
  X,
  Check,
  ShieldCheck,
  Lock,
  MapPin,
  Calendar,
  AlertCircle,
  FileText,
  User,
  Phone,
  CheckCircle2,
  Trash2,
  Printer,
  Sparkles,
  ArrowLeft,
  Heart,
  Droplet,
  Globe,
  Share2,
  Gift
} from 'lucide-react';
import { UserProfile, Language, PujaGiftApplication } from '../types';
import { LOCATION_MASTER, getAllDivisions } from '../data/locationMaster';
import { databaseService } from '../services/databaseService';
import { compressImage } from '../utils/imageUtils';

export interface PujaGiftApplicationFormProps {
  currentUser?: UserProfile | null;
  onSuccess?: (app: PujaGiftApplication) => void;
  onBack?: () => void;
  lang?: Language;
}

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export const PujaGiftApplicationForm: React.FC<PujaGiftApplicationFormProps> = ({
  currentUser,
  onSuccess,
  onBack,
  lang: initialLang = 'bn',
}) => {
  // 1. Language State
  const [lang, setLang] = useState<Language>(initialLang);

  // 2. Form Fields State
  const [passportPhoto, setPassportPhoto] = useState<string>(currentUser?.avatar || '');
  const [photoFileName, setPhotoFileName] = useState<string>('');
  const [isPhotoLoading, setIsPhotoLoading] = useState<boolean>(false);

  const [fullName, setFullName] = useState<string>(currentUser?.fullName || currentUser?.name || '');
  const [fatherOrHusbandName, setFatherOrHusbandName] = useState<string>('');
  const [motherName, setMotherName] = useState<string>('');
  const [dateOfBirth, setDateOfBirth] = useState<string>('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other' | ''>('');
  const [bloodGroup, setBloodGroup] = useState<string>(currentUser?.bloodGroup || '');
  const [nidOrBirthCertificate, setNidOrBirthCertificate] = useState<string>(currentUser?.nidNumber || '');
  const [contactNumber, setContactNumber] = useState<string>(currentUser?.phone || '');

  // Present Address
  const [presentVillage, setPresentVillage] = useState<string>(currentUser?.para || currentUser?.mahalla || '');
  const [presentThana, setPresentThana] = useState<string>(currentUser?.upazila || currentUser?.thana || '');
  const [presentDistrict, setPresentDistrict] = useState<string>(currentUser?.district || '');

  // Permanent Address
  const [sameAsPresent, setSameAsPresent] = useState<boolean>(false);
  const [permanentVillage, setPermanentVillage] = useState<string>('');
  const [permanentThana, setPermanentThana] = useState<string>('');
  const [permanentDistrict, setPermanentDistrict] = useState<string>('');

  // Declaration & Additional Notes
  const [declarationNotes, setDeclarationNotes] = useState<string>('');
  const [declarationAgreed, setDeclarationAgreed] = useState<boolean>(true);

  // 3. UI and Submission States
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submittedApp, setSubmittedApp] = useState<PujaGiftApplication | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync same as present address
  useEffect(() => {
    if (sameAsPresent) {
      setPermanentVillage(presentVillage);
      setPermanentThana(presentThana);
      setPermanentDistrict(presentDistrict);
    }
  }, [sameAsPresent, presentVillage, presentThana, presentDistrict]);

  // Extract all 64 districts from LOCATION_MASTER
  const allDistricts = useMemo(() => {
    const list: { nameBn: string; nameEn: string; upazilas: { nameBn: string; nameEn: string }[] }[] = [];
    LOCATION_MASTER.forEach(div => {
      div.districts.forEach(dist => {
        list.push({
          nameBn: dist.nameBn,
          nameEn: dist.nameEn,
          upazilas: dist.upazilas.map(u => ({ nameBn: u.nameBn, nameEn: u.nameEn }))
        });
      });
    });
    return list.sort((a, b) => a.nameBn.localeCompare(b.nameBn));
  }, []);

  // Upazila suggestions for present district
  const presentUpazilaOptions = useMemo(() => {
    if (!presentDistrict) return [];
    const found = allDistricts.find(d => d.nameBn === presentDistrict || d.nameEn.toLowerCase() === presentDistrict.toLowerCase());
    return found ? found.upazilas : [];
  }, [presentDistrict, allDistricts]);

  // Upazila suggestions for permanent district
  const permanentUpazilaOptions = useMemo(() => {
    if (!permanentDistrict) return [];
    const found = allDistricts.find(d => d.nameBn === permanentDistrict || d.nameEn.toLowerCase() === permanentDistrict.toLowerCase());
    return found ? found.upazilas : [];
  }, [permanentDistrict, allDistricts]);

  // Handle Photo File Selection
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrors(prev => ({
        ...prev,
        passportPhoto: lang === 'bn' ? 'দয়া করে একটি সঠিক ছবির ফাইল (JPG, PNG) নির্বাচন করুন।' : 'Please choose a valid image file (JPG, PNG).'
      }));
      return;
    }

    setPhotoFileName(file.name);
    setIsPhotoLoading(true);
    setErrors(prev => {
      const next = { ...prev };
      delete next.passportPhoto;
      return next;
    });

    try {
      // Compress to passport size (approx 350x420)
      const compressed = await compressImage(file, 350, 420, 0.78);
      setPassportPhoto(compressed);
    } catch (err) {
      console.error('Error compressing passport photo:', err);
      // Fallback to direct FileReader
      const reader = new FileReader();
      reader.onload = () => {
        setPassportPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    } finally {
      setIsPhotoLoading(false);
    }
  };

  const handleRemovePhoto = () => {
    setPassportPhoto('');
    setPhotoFileName('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Form Validation
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!passportPhoto) {
      newErrors.passportPhoto = lang === 'bn' ? 'পাসপোর্ট সাইজের ছবি আপলোড করা আবশ্যক।' : 'Passport size photo is required.';
    }

    if (!fullName.trim()) {
      newErrors.fullName = lang === 'bn' ? 'আবেদনকারীর পূর্ণ নাম লিখুন।' : "Applicant's full name is required.";
    }

    if (!fatherOrHusbandName.trim()) {
      newErrors.fatherOrHusbandName = lang === 'bn' ? 'পিতা অথবা স্বামীর নাম লিখুন।' : "Father's or Husband's name is required.";
    }

    if (!motherName.trim()) {
      newErrors.motherName = lang === 'bn' ? 'মাতার নাম লিখুন।' : "Mother's name is required.";
    }

    if (!dateOfBirth.trim()) {
      newErrors.dateOfBirth = lang === 'bn' ? 'জন্ম তারিখ নির্বাচন বা লিখুন।' : 'Date of birth is required.';
    }

    if (!gender) {
      newErrors.gender = lang === 'bn' ? 'লিঙ্গ নির্বাচন করুন।' : 'Please select gender.';
    }

    if (!bloodGroup) {
      newErrors.bloodGroup = lang === 'bn' ? 'রক্তের গ্রুপ নির্বাচন করুন।' : 'Please select blood group.';
    }

    if (!nidOrBirthCertificate.trim()) {
      newErrors.nidOrBirthCertificate = lang === 'bn' ? 'জাতীয় পরিচয়পত্র (NID) বা জন্ম নিবন্ধন নম্বর লিখুন।' : 'National ID or Birth Certificate number is required.';
    } else if (nidOrBirthCertificate.trim().length < 10) {
      newErrors.nidOrBirthCertificate = lang === 'bn' ? 'সঠিক NID বা জন্ম নিবন্ধন নম্বর দিন (কমপক্ষে ১০ ডিজিট)।' : 'Please provide a valid NID or Birth Certificate number (min 10 digits).';
    }

    if (!contactNumber.trim()) {
      newErrors.contactNumber = lang === 'bn' ? 'যোগাযোগের মোবাইল নম্বর লিখুন।' : 'Mobile number is required.';
    } else if (!/^01[3-9]\d{8}$/.test(contactNumber.replace(/[\s-]/g, '')) && contactNumber.length < 11) {
      newErrors.contactNumber = lang === 'bn' ? '১১ ডিজিটের সঠিক মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)।' : 'Please enter a valid 11-digit mobile number.';
    }

    // Present Address
    if (!presentVillage.trim()) {
      newErrors.presentVillage = lang === 'bn' ? 'বর্তমান গ্রাম/এলাকার নাম দিন।' : 'Present village/area is required.';
    }
    if (!presentThana.trim()) {
      newErrors.presentThana = lang === 'bn' ? 'বর্তমান থানা/উপজেলা দিন।' : 'Present thana/upazila is required.';
    }
    if (!presentDistrict.trim()) {
      newErrors.presentDistrict = lang === 'bn' ? 'বর্তমান জেলা নির্বাচন করুন।' : 'Please select present district.';
    }

    // Permanent Address
    if (!sameAsPresent) {
      if (!permanentVillage.trim()) {
        newErrors.permanentVillage = lang === 'bn' ? 'স্থায়ী গ্রাম/এলাকার নাম দিন।' : 'Permanent village/area is required.';
      }
      if (!permanentThana.trim()) {
        newErrors.permanentThana = lang === 'bn' ? 'স্থায়ী থানা/উপজেলা দিন।' : 'Permanent thana/upazila is required.';
      }
      if (!permanentDistrict.trim()) {
        newErrors.permanentDistrict = lang === 'bn' ? 'স্থায়ী জেলা নির্বাচন করুন।' : 'Please select permanent district.';
      }
    }

    if (!declarationAgreed) {
      newErrors.declarationAgreed = lang === 'bn' ? 'অঙ্গীকারনামায় সম্মতি প্রদান করুন।' : 'Please agree to the declaration statement.';
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      // Scroll to the first error
      const firstKey = Object.keys(newErrors)[0];
      const el = document.getElementById(`field-${firstKey}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return false;
    }

    return true;
  };

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const year = new Date().getFullYear();
      const randomSuffix = Math.floor(10000 + Math.random() * 90000);
      const uniqueAppId = `JMD-PUJA-${year}-${randomSuffix}`;

      const applicationData: PujaGiftApplication = {
        id: uniqueAppId,
        applicantUid: currentUser?.memberUID || currentUser?.uniqueId || `PRO-${randomSuffix}`,
        userId: currentUser?.id,
        passportPhoto,
        fullName: fullName.trim(),
        fatherOrHusbandName: fatherOrHusbandName.trim(),
        motherName: motherName.trim(),
        dateOfBirth: dateOfBirth.trim(),
        gender: gender as 'Male' | 'Female' | 'Other',
        bloodGroup,
        nidOrBirthCertificate: nidOrBirthCertificate.trim(),
        contactNumber: contactNumber.trim(),
        presentAddress: {
          villageArea: presentVillage.trim(),
          thanaUpazila: presentThana.trim(),
          district: presentDistrict.trim()
        },
        permanentAddress: {
          villageArea: (sameAsPresent ? presentVillage : permanentVillage).trim(),
          thanaUpazila: (sameAsPresent ? presentThana : permanentThana).trim(),
          district: (sameAsPresent ? presentDistrict : permanentDistrict).trim()
        },
        declarationNotes: declarationNotes.trim(),
        status: 'Pending',
        appliedAt: new Date().toISOString()
      };

      const res = await databaseService.submitPujaGiftApplication(applicationData);

      if (res.success) {
        setSubmittedApp(applicationData);
        if (onSuccess) {
          onSuccess(applicationData);
        }
      } else {
        alert(lang === 'bn' ? 'আবেদন জমা দিতে সমস্যা হয়েছে। পুনরায় চেষ্টা করুন।' : 'Failed to submit application. Please try again.');
      }
    } catch (err) {
      console.error('Submission error:', err);
      alert(lang === 'bn' ? 'আবেদন প্রক্রিয়াকরণে সমস্যা হয়েছে।' : 'Error processing application.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // =========================================================================
  // SUCCESS RECEIPT VIEW (আবেদন সফল হলে অফিসিয়াল মানসম্পন্ন রিসিট)
  // =========================================================================
  if (submittedApp) {
    return (
      <div className="w-full bg-[#FAF8F5] min-h-screen py-6 px-3 sm:px-6 animate-in fade-in duration-300">
        <div className="max-w-xl mx-auto bg-white rounded-3xl shadow-xl border border-emerald-100 overflow-hidden print:shadow-none print:border-none print:m-0">
          
          {/* Header Banner */}
          <div className="bg-[#0A6A32] text-white p-5 sm:p-6 relative text-center">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="absolute left-4 top-4 bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition cursor-pointer print:hidden"
                title={lang === 'bn' ? 'ফিরে যান' : 'Go back'}
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}

            <div className="w-14 h-14 bg-white text-[#0A6A32] rounded-2xl flex items-center justify-center mx-auto shadow-md mb-2.5">
              <Gift className="w-7 h-7 stroke-[2.5]" />
            </div>

            <span className="inline-flex items-center gap-1 bg-amber-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider mb-1">
              <Sparkles className="w-3 h-3 fill-slate-950" />
              {lang === 'bn' ? 'আবেদন সফলভাবে গৃহীত হয়েছে' : 'Application Received'}
            </span>

            <h2 className="text-lg sm:text-xl font-black text-white">
              {lang === 'bn' ? 'পূজা উপহার আবেদন রশিদ' : 'Puja Gift Application Slip'}
            </h2>
            <p className="text-xs text-emerald-100 font-medium mt-0.5">
              {lang === 'bn' ? 'ঝাদিমাটি.কম সেবাদাতা কল্যাণ কর্মসূচি' : 'Jhadimadi.com Service Provider Welfare Program'}
            </p>
          </div>

          {/* Body Content */}
          <div className="p-5 sm:p-6 space-y-5 text-left">
            
            {/* Tracking ID Box */}
            <div className="bg-emerald-50 border-2 border-emerald-200 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
              <div>
                <p className="text-[10px] font-bold text-emerald-800 uppercase tracking-wide">
                  {lang === 'bn' ? 'আবেদন ট্র্যাকিং নম্বর (Application ID)' : 'Application Tracking ID'}
                </p>
                <p className="text-base sm:text-lg font-mono font-black text-[#0A6A32]">
                  {submittedApp.id}
                </p>
                <p className="text-[11px] text-gray-500 font-medium">
                  {lang === 'bn' ? 'তারিখ: ' : 'Date: '}
                  {new Date(submittedApp.appliedAt).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}
                </p>
              </div>

              <div className="shrink-0">
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#0A6A32] text-white text-xs font-bold rounded-xl shadow-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>{lang === 'bn' ? 'যাচাইকরণ প্রক্রিয়াধীন' : 'Under Review'}</span>
                </span>
              </div>
            </div>

            {/* Applicant Summary with Passport Photo */}
            <div className="border border-gray-200 rounded-2xl p-4 bg-gray-50/60 flex items-start gap-4">
              <div className="relative shrink-0">
                <img
                  src={submittedApp.passportPhoto}
                  alt={submittedApp.fullName}
                  className="w-20 h-24 sm:w-24 sm:h-28 object-cover rounded-xl border-2 border-[#0A6A32] shadow-sm bg-white"
                />
                <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 bg-[#0A6A32] text-white text-[8px] font-black px-1.5 py-0.2 rounded-full whitespace-nowrap">
                  {submittedApp.bloodGroup}
                </span>
              </div>

              <div className="min-w-0 flex-1 space-y-1">
                <h3 className="text-base font-black text-gray-900 leading-tight">
                  {submittedApp.fullName}
                </h3>
                <p className="text-xs text-gray-600 font-medium">
                  <span className="font-bold text-gray-700">{lang === 'bn' ? 'পিতা/স্বামী: ' : 'Father/Husband: '}</span>
                  {submittedApp.fatherOrHusbandName}
                </p>
                <p className="text-xs text-gray-600 font-medium">
                  <span className="font-bold text-gray-700">{lang === 'bn' ? 'মাতা: ' : 'Mother: '}</span>
                  {submittedApp.motherName}
                </p>
                <p className="text-xs text-gray-600 font-medium">
                  <span className="font-bold text-gray-700">{lang === 'bn' ? 'জন্ম তারিখ: ' : 'DOB: '}</span>
                  {submittedApp.dateOfBirth} ({submittedApp.gender === 'Male' ? (lang === 'bn' ? 'পুরুষ' : 'Male') : submittedApp.gender === 'Female' ? (lang === 'bn' ? 'মহিলা' : 'Female') : (lang === 'bn' ? 'অন্যান্য' : 'Other')})
                </p>
                <p className="text-xs text-gray-600 font-medium flex items-center gap-1 truncate">
                  <MapPin className="w-3.5 h-3.5 text-[#0A6A32] shrink-0" />
                  <span>{submittedApp.presentAddress.thanaUpazila}, {submittedApp.presentAddress.district}</span>
                </p>
              </div>
            </div>

            {/* Privacy & Confidentiality Reminder */}
            <div className="bg-amber-50/80 border border-amber-200/80 rounded-2xl p-3 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-900 font-medium leading-relaxed">
                {lang === 'bn' 
                  ? 'আপনার জাতীয় পরিচয়পত্র (NID) এবং মোবাইল নম্বর গোপন রাখা হয়েছে। উৎসব উপহার বিতরণের পূর্বে যাচাইকারী দল আপনার সাথে যোগাযোগ করবে।' 
                  : 'Your National ID and mobile number are securely protected. Our verification team will reach out to you before gift dispatch.'}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3 print:hidden">
              <button
                type="button"
                onClick={handlePrint}
                className="w-full sm:flex-1 py-3 bg-white hover:bg-gray-50 border-2 border-[#0A6A32] text-[#0A6A32] font-black text-xs sm:text-sm rounded-2xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <Printer className="w-4 h-4" />
                <span>{lang === 'bn' ? 'রশিদ প্রিন্ট বা সংরক্ষণ করুন' : 'Print / Save Receipt'}</span>
              </button>

              {onBack && (
                <button
                  type="button"
                  onClick={onBack}
                  className="w-full sm:flex-1 py-3 bg-[#0A6A32] hover:bg-emerald-800 text-white font-black text-xs sm:text-sm rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'bn' ? 'ড্যাশবোর্ডে ফিরে যান' : 'Return to Dashboard'}</span>
                </button>
              )}
            </div>

            <div className="text-center pt-2 print:hidden">
              <button
                type="button"
                onClick={() => {
                  setSubmittedApp(null);
                  setPassportPhoto('');
                  setFatherOrHusbandName('');
                  setMotherName('');
                  setDeclarationNotes('');
                }}
                className="text-xs text-gray-500 hover:text-[#0A6A32] underline font-bold cursor-pointer"
              >
                {lang === 'bn' ? 'আরেকটি নতুন আবেদন জমা দিন' : 'Submit another application'}
              </button>
            </div>

          </div>

          {/* Footer note */}
          <div className="bg-gray-50 p-4 border-t border-gray-100 text-center text-[11px] text-gray-500">
            Jhadimadi.com Hyperlocal Welfare Initiative • Empowering Local Service Heroes
          </div>

        </div>
      </div>
    );
  }

  // =========================================================================
  // MAIN APPLICATION FORM (ইনটেক ফর্ম)
  // =========================================================================
  return (
    <div className="w-full bg-[#FAF8F5] min-h-screen py-4 sm:py-6 px-3 sm:px-4 flex justify-center text-left">
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-sm sm:shadow-lg border border-gray-200/80 overflow-hidden">
        
        {/* ================= HEADER SECTION ================= */}
        <header className="bg-[#0A6A32] text-white p-4 sm:p-5 relative">
          <div className="flex items-center justify-between gap-2">
            
            {/* Left: Back button & Title */}
            <div className="flex items-center gap-2.5 min-w-0">
              {onBack && (
                <button
                  type="button"
                  onClick={onBack}
                  className="bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition cursor-pointer shrink-0"
                  title={lang === 'bn' ? 'ফিরে যান' : 'Go back'}
                  id="btn-header-back"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
              )}
              
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                    {lang === 'bn' ? 'উৎসব কল্যাণ প্যাকেজ' : 'Festival Welfare'}
                  </span>
                  <span className="text-[10px] text-emerald-200 font-medium">
                    {lang === 'bn' ? 'সেবা প্রদানকারীদের জন্য' : 'For Service Providers'}
                  </span>
                </div>
                <h1 className="text-base sm:text-xl font-black text-white leading-tight mt-0.5 truncate" id="puja-form-title">
                  {lang === 'bn' ? 'পূজা উপহার আবেদন ফর্ম' : 'Puja Gift Application Form'}
                </h1>
              </div>
            </div>

            {/* Right: Language Switcher Toggle [ Bangla / English ] */}
            <div className="shrink-0 flex items-center bg-black/20 p-0.5 rounded-xl border border-white/20">
              <button
                type="button"
                onClick={() => setLang('bn')}
                className={`px-2.5 py-1 text-xs font-black rounded-lg transition cursor-pointer ${
                  lang === 'bn'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-white/80 hover:text-white'
                }`}
                id="btn-lang-bn"
              >
                বাংলা
              </button>
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-2.5 py-1 text-xs font-black rounded-lg transition cursor-pointer ${
                  lang === 'en'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-white/80 hover:text-white'
                }`}
                id="btn-lang-en"
              >
                English
              </button>
            </div>

          </div>

          <p className="text-[11px] sm:text-xs text-emerald-100 font-medium mt-2 leading-relaxed">
            {lang === 'bn'
              ? 'ঝাদিমাটি.কম-এর নিবন্ধিত সেবা প্রদানকারী ও দক্ষ কারিগরদের জন্য উৎসব উপহার ও বিশেষ কল্যাণ অনুদান গ্রহণের আবেদন পত্র।'
              : 'Official intake form for registered service providers to receive special festival gifts and welfare packages from Jhadimadi.com.'}
          </p>
        </header>

        {/* ================= FORM BODY ================= */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5" noValidate>
          
          {/* ================= 1. PASSPORT SIZE PHOTO UPLOAD (VERY FIRST FIELD) ================= */}
          <div 
            id="field-passportPhoto" 
            className={`p-4 rounded-2xl border-2 transition-all ${
              errors.passportPhoto ? 'border-red-400 bg-red-50/40' : 'border-emerald-100 bg-emerald-50/30'
            }`}
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-2.5">
              <div>
                <label className="block text-xs sm:text-sm font-black text-gray-900 flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-[#0A6A32]" />
                  <span>
                    {lang === 'bn' ? 'পাসপোর্ট সাইজের ছবি আপলোড' : 'Passport Size Photo Upload'}
                  </span>
                  <span className="text-red-500 font-bold">*</span>
                </label>
                <p className="text-[11px] text-gray-500 font-medium">
                  {lang === 'bn' 
                    ? 'ছবিটি আপলোড করার সাথে সাথেই এখানে প্রিভিউ দেখা যাবে' 
                    : 'Preview will appear here immediately after uploading file'}
                </p>
              </div>

              <span className="text-[10px] font-bold text-[#0A6A32] bg-white border border-emerald-200 px-2 py-0.5 rounded-full">
                {lang === 'bn' ? 'অনুপাত ১:১ বা পাসপোর্ট সাইজ' : 'Passport Size (1:1 / 4:5)'}
              </span>
            </div>

            {/* Live Preview and Upload Control Box */}
            <div className="flex flex-col sm:flex-row items-center gap-4 pt-1">
              
              {/* Photo Preview Frame */}
              <div className="relative group shrink-0">
                <div className="w-28 h-32 sm:w-32 sm:h-36 rounded-2xl border-2 border-dashed border-[#0A6A32] bg-white overflow-hidden flex flex-col items-center justify-center relative shadow-sm">
                  {isPhotoLoading ? (
                    <div className="flex flex-col items-center gap-1 text-[#0A6A32] p-2 text-center">
                      <div className="w-6 h-6 border-2 border-[#0A6A32] border-t-transparent rounded-full animate-spin"></div>
                      <span className="text-[10px] font-bold">
                        {lang === 'bn' ? 'প্রসেসিং হচ্ছে...' : 'Processing...'}
                      </span>
                    </div>
                  ) : passportPhoto ? (
                    <>
                      <img
                        src={passportPhoto}
                        alt="Passport Preview"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="p-1.5 bg-white text-[#0A6A32] rounded-xl shadow-xs hover:bg-emerald-50 cursor-pointer"
                          title={lang === 'bn' ? 'ছবি পরিবর্তন করুন' : 'Change photo'}
                        >
                          <Camera className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={handleRemovePhoto}
                          className="p-1.5 bg-red-600 text-white rounded-xl shadow-xs hover:bg-red-700 cursor-pointer"
                          title={lang === 'bn' ? 'ছবি মুছে ফেলুন' : 'Remove photo'}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center gap-1 text-gray-400 p-2 text-center">
                      <User className="w-10 h-10 text-gray-300 stroke-[1.5]" />
                      <span className="text-[9.5px] font-bold text-gray-400 leading-tight">
                        {lang === 'bn' ? 'ছবি প্রিভিউ ফ্রেম' : 'Photo Preview'}
                      </span>
                    </div>
                  )}
                </div>

                {passportPhoto && (
                  <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-[#0A6A32] text-white text-[8.5px] font-black px-2 py-0.5 rounded-full shadow-xs flex items-center gap-1 whitespace-nowrap">
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                    <span>{lang === 'bn' ? 'ছবি প্রস্তুত' : 'Ready'}</span>
                  </span>
                )}
              </div>

              {/* File Input and Drag-and-Drop Area */}
              <div className="flex-1 w-full space-y-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp,image/jpg"
                  onChange={handlePhotoUpload}
                  className="hidden"
                  id="passport-photo-file-input"
                />

                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-gray-300 hover:border-[#0A6A32] bg-white hover:bg-emerald-50/20 rounded-2xl p-4 text-center cursor-pointer transition-all group"
                >
                  <Upload className="w-6 h-6 text-[#0A6A32] mx-auto group-hover:scale-110 transition-transform mb-1" />
                  <p className="text-xs font-black text-gray-800">
                    {lang === 'bn' ? 'ফাইল নির্বাচন করুন (Choose File)' : 'Choose File or Click to Upload'}
                  </p>
                  <p className="text-[10px] text-gray-500 mt-0.5">
                    {photoFileName 
                      ? photoFileName 
                      : (lang === 'bn' ? 'কোন ফাইল নির্বাচন করা হয়নি (No file chosen)' : 'No file chosen')}
                  </p>
                  <span className="inline-block mt-2 text-[9px] font-bold text-[#0A6A32] bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                    {lang === 'bn' ? 'ক্যামেরা বা গ্যালারি থেকে ছবি নিন' : 'Select from Camera or Gallery'}
                  </span>
                </div>

                {errors.passportPhoto && (
                  <p className="text-xs font-bold text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.passportPhoto}</span>
                  </p>
                )}
              </div>

            </div>
          </div>

          {/* ================= 2. APPLICANT'S FULL NAME ================= */}
          <div id="field-fullName" className="space-y-1">
            <label className="block text-xs sm:text-sm font-bold text-gray-800">
              {lang === 'bn' ? 'আবেদনকারীর পূর্ণ নাম (Applicant\'s Full Name)' : "Applicant's Full Name"}
              <span className="text-red-500 font-bold ml-1">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={fullName}
                onChange={(e) => {
                  setFullName(e.target.value);
                  if (errors.fullName) {
                    setErrors(prev => {
                      const next = { ...prev };
                      delete next.fullName;
                      return next;
                    });
                  }
                }}
                placeholder={lang === 'bn' ? 'এনআইডি অনুযায়ী পূর্ণ নাম লিখুন' : 'Enter full name as per NID'}
                className={`w-full px-3.5 py-2.5 sm:py-3 bg-white border rounded-xl text-xs sm:text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A6A32]/20 focus:border-[#0A6A32] transition ${
                  errors.fullName ? 'border-red-500 ring-1 ring-red-200' : 'border-gray-300'
                }`}
                id="input-fullName"
              />
            </div>
            {errors.fullName && (
              <p className="text-xs font-bold text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errors.fullName}</span>
              </p>
            )}
          </div>

          {/* ================= 3. FATHER'S / HUSBAND'S NAME ================= */}
          <div id="field-fatherOrHusbandName" className="space-y-1">
            <label className="block text-xs sm:text-sm font-bold text-gray-800">
              {lang === 'bn' ? 'পিতা / স্বামীর নাম (Father\'s / Husband\'s Name)' : "Father's / Husband's Name"}
              <span className="text-red-500 font-bold ml-1">*</span>
            </label>
            <input
              type="text"
              value={fatherOrHusbandName}
              onChange={(e) => {
                setFatherOrHusbandName(e.target.value);
                if (errors.fatherOrHusbandName) {
                  setErrors(prev => {
                    const next = { ...prev };
                    delete next.fatherOrHusbandName;
                    return next;
                  });
                }
              }}
              placeholder={lang === 'bn' ? 'পিতা অথবা স্বামীর নাম লিখুন' : "Enter father's or husband's name"}
              className={`w-full px-3.5 py-2.5 sm:py-3 bg-white border rounded-xl text-xs sm:text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A6A32]/20 focus:border-[#0A6A32] transition ${
                errors.fatherOrHusbandName ? 'border-red-500 ring-1 ring-red-200' : 'border-gray-300'
              }`}
              id="input-fatherOrHusbandName"
            />
            {errors.fatherOrHusbandName && (
              <p className="text-xs font-bold text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errors.fatherOrHusbandName}</span>
              </p>
            )}
          </div>

          {/* ================= 4. MOTHER'S NAME ================= */}
          <div id="field-motherName" className="space-y-1">
            <label className="block text-xs sm:text-sm font-bold text-gray-800">
              {lang === 'bn' ? 'মাতার নাম (Mother\'s Name)' : "Mother's Name"}
              <span className="text-red-500 font-bold ml-1">*</span>
            </label>
            <input
              type="text"
              value={motherName}
              onChange={(e) => {
                setMotherName(e.target.value);
                if (errors.motherName) {
                  setErrors(prev => {
                    const next = { ...prev };
                    delete next.motherName;
                    return next;
                  });
                }
              }}
              placeholder={lang === 'bn' ? 'মাতার নাম লিখুন' : "Enter mother's name"}
              className={`w-full px-3.5 py-2.5 sm:py-3 bg-white border rounded-xl text-xs sm:text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A6A32]/20 focus:border-[#0A6A32] transition ${
                errors.motherName ? 'border-red-500 ring-1 ring-red-200' : 'border-gray-300'
              }`}
              id="input-motherName"
            />
            {errors.motherName && (
              <p className="text-xs font-bold text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errors.motherName}</span>
              </p>
            )}
          </div>

          {/* ================= 5. DATE OF BIRTH & 6. GENDER SELECTION ================= */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* 5. Date of Birth (DD / MM / YYYY) */}
            <div id="field-dateOfBirth" className="space-y-1">
              <label className="block text-xs sm:text-sm font-bold text-gray-800">
                {lang === 'bn' ? 'জন্ম তারিখ (Date of Birth)' : 'Date of Birth'}
                <span className="text-red-500 font-bold ml-1">*</span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={dateOfBirth}
                  onChange={(e) => {
                    setDateOfBirth(e.target.value);
                    if (errors.dateOfBirth) {
                      setErrors(prev => {
                        const next = { ...prev };
                        delete next.dateOfBirth;
                        return next;
                      });
                    }
                  }}
                  className={`w-full px-3.5 py-2.5 sm:py-3 bg-white border rounded-xl text-xs sm:text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A6A32]/20 focus:border-[#0A6A32] transition ${
                    errors.dateOfBirth ? 'border-red-500 ring-1 ring-red-200' : 'border-gray-300'
                  }`}
                  id="input-dateOfBirth"
                />
              </div>
              <span className="text-[10px] text-gray-500 font-medium">
                {lang === 'bn' ? '[ দিন / মাস / বছর ]' : '[ DD / MM / YYYY ]'}
              </span>
              {errors.dateOfBirth && (
                <p className="text-xs font-bold text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errors.dateOfBirth}</span>
                </p>
              )}
            </div>

            {/* 6. Gender Selection */}
            <div id="field-gender" className="space-y-1">
              <label className="block text-xs sm:text-sm font-bold text-gray-800">
                {lang === 'bn' ? 'লিঙ্গ (Gender)' : 'Gender'}
                <span className="text-red-500 font-bold ml-1">*</span>
              </label>
              
              <div className="grid grid-cols-3 gap-2 pt-0.5">
                {[
                  { key: 'Male', bn: 'পুরুষ (Male)', en: 'Male' },
                  { key: 'Female', bn: 'মহিলা (Female)', en: 'Female' },
                  { key: 'Other', bn: 'অন্যান্য (Other)', en: 'Other' }
                ].map(opt => (
                  <button
                    key={opt.key}
                    type="button"
                    onClick={() => {
                      setGender(opt.key as any);
                      if (errors.gender) {
                        setErrors(prev => {
                          const next = { ...prev };
                          delete next.gender;
                          return next;
                        });
                      }
                    }}
                    className={`py-2.5 px-2 rounded-xl text-xs font-black border transition cursor-pointer flex items-center justify-center gap-1.5 ${
                      gender === opt.key
                        ? 'bg-[#0A6A32] text-white border-[#0A6A32] shadow-xs'
                        : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <span className={`w-3 h-3 rounded-full border-2 flex items-center justify-center ${gender === opt.key ? 'border-white bg-white' : 'border-gray-400'}`}>
                      {gender === opt.key && <span className="w-1.5 h-1.5 rounded-full bg-[#0A6A32]" />}
                    </span>
                    <span>{lang === 'bn' ? opt.bn.split(' ')[0] : opt.en}</span>
                  </button>
                ))}
              </div>

              {errors.gender && (
                <p className="text-xs font-bold text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errors.gender}</span>
                </p>
              )}
            </div>

          </div>

          {/* ================= 7. BLOOD GROUP (DROPDOWN) ================= */}
          <div id="field-bloodGroup" className="space-y-1">
            <label className="block text-xs sm:text-sm font-bold text-gray-800 flex items-center gap-1">
              <Droplet className="w-4 h-4 text-red-600 fill-red-600" />
              <span>{lang === 'bn' ? 'রক্তের গ্রুপ (Blood Group)' : 'Blood Group'}</span>
              <span className="text-red-500 font-bold ml-1">*</span>
            </label>
            <select
              value={bloodGroup}
              onChange={(e) => {
                setBloodGroup(e.target.value);
                if (errors.bloodGroup) {
                  setErrors(prev => {
                    const next = { ...prev };
                    delete next.bloodGroup;
                    return next;
                  });
                }
              }}
              className={`w-full px-3.5 py-2.5 sm:py-3 bg-white border rounded-xl text-xs sm:text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A6A32]/20 focus:border-[#0A6A32] transition cursor-pointer ${
                errors.bloodGroup ? 'border-red-500 ring-1 ring-red-200' : 'border-gray-300'
              }`}
              id="select-bloodGroup"
            >
              <option value="">{lang === 'bn' ? '[ রক্তের গ্রুপ নির্বাচন করুন ▼ ]' : '[ Select Blood Group ▼ ]'}</option>
              {BLOOD_GROUPS.map((bg) => (
                <option key={bg} value={bg}>
                  {bg} {lang === 'bn' ? 'পজিটিভ/নেগেটিভ' : ''}
                </option>
              ))}
            </select>
            {errors.bloodGroup && (
              <p className="text-xs font-bold text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errors.bloodGroup}</span>
              </p>
            )}
          </div>

          {/* ================= 8. NATIONAL ID (NID) / BIRTH CERTIFICATE WITH PRIVACY NOTE ================= */}
          <div id="field-nidOrBirthCertificate" className="space-y-1.5 p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
            <div className="flex items-center justify-between">
              <label className="block text-xs sm:text-sm font-bold text-gray-900 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#0A6A32]" />
                <span>{lang === 'bn' ? 'জাতীয় পরিচয়পত্র (NID) / জন্ম নিবন্ধন নম্বর' : 'National ID (NID) / Birth Certificate Number'}</span>
                <span className="text-red-500 font-bold ml-1">*</span>
              </label>
              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/70 px-2 py-0.5 rounded-md flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                {lang === 'bn' ? 'গোপন ও সুরক্ষিত' : 'Securely Hidden'}
              </span>
            </div>

            <input
              type="text"
              value={nidOrBirthCertificate}
              onChange={(e) => {
                setNidOrBirthCertificate(e.target.value);
                if (errors.nidOrBirthCertificate) {
                  setErrors(prev => {
                    const next = { ...prev };
                    delete next.nidOrBirthCertificate;
                    return next;
                  });
                }
              }}
              placeholder={lang === 'bn' ? '১০, ১৩ অথবা ১৭ ডিজিটের এনআইডি/জন্ম নিবন্ধন নম্বর' : 'Enter 10, 13, or 17 digit NID / Birth Cert number'}
              className={`w-full px-3.5 py-2.5 sm:py-3 bg-white border rounded-xl text-xs sm:text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A6A32]/20 focus:border-[#0A6A32] transition font-mono ${
                errors.nidOrBirthCertificate ? 'border-red-500 ring-1 ring-red-200' : 'border-gray-300'
              }`}
              id="input-nidOrBirthCertificate"
            />

            {/* MANDATORY PRIVACY NOTE */}
            <div className="flex items-start gap-1.5 pt-0.5 text-slate-600">
              <Lock className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
              <p className="text-[11px] font-medium leading-tight">
                {lang === 'bn' 
                  ? '(বিশেষ দ্রষ্টব্য: আপনার এই তথ্যটি জনসমক্ষে সম্পূর্ণ গোপন ও সুরক্ষিত রাখা হবে)।' 
                  : '(Note: This information will remain securely hidden from the public view).'}
              </p>
            </div>

            {errors.nidOrBirthCertificate && (
              <p className="text-xs font-bold text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errors.nidOrBirthCertificate}</span>
              </p>
            )}
          </div>

          {/* ================= 9. CONTACT NUMBER (MOBILE) WITH PRIVACY NOTE ================= */}
          <div id="field-contactNumber" className="space-y-1.5 p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
            <div className="flex items-center justify-between">
              <label className="block text-xs sm:text-sm font-bold text-gray-900 flex items-center gap-1.5">
                <Phone className="w-4 h-4 text-[#0A6A32]" />
                <span>{lang === 'bn' ? 'যোগাযোগ নম্বর (মোবাইল)' : 'Contact Number (Mobile)'}</span>
                <span className="text-red-500 font-bold ml-1">*</span>
              </label>
              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/70 px-2 py-0.5 rounded-md flex items-center gap-1">
                <ShieldCheck className="w-2.5 h-2.5" />
                {lang === 'bn' ? 'ব্যক্তিগত' : 'Private'}
              </span>
            </div>

            <input
              type="tel"
              value={contactNumber}
              onChange={(e) => {
                setContactNumber(e.target.value);
                if (errors.contactNumber) {
                  setErrors(prev => {
                    const next = { ...prev };
                    delete next.contactNumber;
                    return next;
                  });
                }
              }}
              placeholder="01XXXXXXXXX"
              className={`w-full px-3.5 py-2.5 sm:py-3 bg-white border rounded-xl text-xs sm:text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A6A32]/20 focus:border-[#0A6A32] transition font-mono ${
                errors.contactNumber ? 'border-red-500 ring-1 ring-red-200' : 'border-gray-300'
              }`}
              id="input-contactNumber"
            />

            {/* MANDATORY PRIVACY NOTE */}
            <div className="flex items-start gap-1.5 pt-0.5 text-slate-600">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
              <p className="text-[11px] font-medium leading-tight">
                {lang === 'bn' 
                  ? '(বিশেষ দ্রষ্টব্য: এটি সম্পূর্ণ ব্যক্তিগত ও নিরাপদ থাকবে)।' 
                  : '(Note: This will remain private).'}
              </p>
            </div>

            {errors.contactNumber && (
              <p className="text-xs font-bold text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errors.contactNumber}</span>
              </p>
            )}
          </div>

          {/* ================= 10. PRESENT ADDRESS ================= */}
          <div className="border border-emerald-200/80 rounded-2xl p-4 bg-emerald-50/20 space-y-3">
            <div className="flex items-center gap-2 border-b border-emerald-100 pb-2">
              <MapPin className="w-4 h-4 text-[#0A6A32]" />
              <h3 className="text-xs sm:text-sm font-black text-gray-900 uppercase tracking-wide">
                {lang === 'bn' ? 'বর্তমান ঠিকানা (Present Address)' : 'Present Address'}
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              
              {/* Village / Area */}
              <div id="field-presentVillage" className="space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  {lang === 'bn' ? 'গ্রাম / এলাকা / পাড়া' : 'Village / Area'}
                  <span className="text-red-500 font-bold ml-0.5">*</span>
                </label>
                <input
                  type="text"
                  value={presentVillage}
                  onChange={(e) => {
                    setPresentVillage(e.target.value);
                    if (errors.presentVillage) {
                      setErrors(prev => {
                        const next = { ...prev };
                        delete next.presentVillage;
                        return next;
                      });
                    }
                  }}
                  placeholder={lang === 'bn' ? 'গ্রাম বা এলাকা' : 'Village or Area'}
                  className={`w-full px-3 py-2 bg-white border rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#0A6A32] ${
                    errors.presentVillage ? 'border-red-500' : 'border-gray-300'
                  }`}
                  id="input-presentVillage"
                />
                {errors.presentVillage && <p className="text-[10px] text-red-600 font-bold">{errors.presentVillage}</p>}
              </div>

              {/* Thana / Upazila */}
              <div id="field-presentThana" className="space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  {lang === 'bn' ? 'থানা / উপজেলা' : 'Thana / Upazila'}
                  <span className="text-red-500 font-bold ml-0.5">*</span>
                </label>
                {presentUpazilaOptions.length > 0 ? (
                  <select
                    value={presentThana}
                    onChange={(e) => {
                      setPresentThana(e.target.value);
                      if (errors.presentThana) {
                        setErrors(prev => {
                          const next = { ...prev };
                          delete next.presentThana;
                          return next;
                        });
                      }
                    }}
                    className={`w-full px-3 py-2 bg-white border rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#0A6A32] cursor-pointer ${
                      errors.presentThana ? 'border-red-500' : 'border-gray-300'
                    }`}
                    id="select-presentThana"
                  >
                    <option value="">{lang === 'bn' ? '[ থানা নির্বাচন করুন ]' : '[ Select Thana ]'}</option>
                    {presentUpazilaOptions.map(u => (
                      <option key={u.nameEn} value={u.nameBn}>
                        {lang === 'bn' ? u.nameBn : u.nameEn}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    value={presentThana}
                    onChange={(e) => {
                      setPresentThana(e.target.value);
                      if (errors.presentThana) {
                        setErrors(prev => {
                          const next = { ...prev };
                          delete next.presentThana;
                          return next;
                        });
                      }
                    }}
                    placeholder={lang === 'bn' ? 'থানা বা উপজেলা' : 'Thana / Upazila'}
                    className={`w-full px-3 py-2 bg-white border rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#0A6A32] ${
                      errors.presentThana ? 'border-red-500' : 'border-gray-300'
                    }`}
                    id="input-presentThana"
                  />
                )}
                {errors.presentThana && <p className="text-[10px] text-red-600 font-bold">{errors.presentThana}</p>}
              </div>

              {/* District Dropdown */}
              <div id="field-presentDistrict" className="space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  {lang === 'bn' ? 'জেলা (District)' : 'District'}
                  <span className="text-red-500 font-bold ml-0.5">*</span>
                </label>
                <select
                  value={presentDistrict}
                  onChange={(e) => {
                    setPresentDistrict(e.target.value);
                    if (errors.presentDistrict) {
                      setErrors(prev => {
                        const next = { ...prev };
                        delete next.presentDistrict;
                        return next;
                      });
                    }
                  }}
                  className={`w-full px-3 py-2 bg-white border rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#0A6A32] cursor-pointer ${
                    errors.presentDistrict ? 'border-red-500' : 'border-gray-300'
                  }`}
                  id="select-presentDistrict"
                >
                  <option value="">{lang === 'bn' ? '[ জেলা নির্বাচন করুন ▼ ]' : '[ Select District ▼ ]'}</option>
                  {allDistricts.map(d => (
                    <option key={d.nameEn} value={d.nameBn}>
                      {lang === 'bn' ? d.nameBn : d.nameEn}
                    </option>
                  ))}
                </select>
                {errors.presentDistrict && <p className="text-[10px] text-red-600 font-bold">{errors.presentDistrict}</p>}
              </div>

            </div>
          </div>

          {/* ================= 11. PERMANENT ADDRESS ================= */}
          <div className="border border-gray-200 rounded-2xl p-4 bg-gray-50/50 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-200 pb-2">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#0A6A32]" />
                <h3 className="text-xs sm:text-sm font-black text-gray-900 uppercase tracking-wide">
                  {lang === 'bn' ? 'স্থায়ী ঠিকানা (Permanent Address)' : 'Permanent Address'}
                </h3>
              </div>

              {/* Same as present address checkbox */}
              <label className="inline-flex items-center gap-1.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={sameAsPresent}
                  onChange={(e) => setSameAsPresent(e.target.checked)}
                  className="w-4 h-4 rounded text-[#0A6A32] focus:ring-[#0A6A32] accent-[#0A6A32] cursor-pointer"
                  id="checkbox-sameAsPresent"
                />
                <span className="text-xs font-bold text-[#0A6A32]">
                  {lang === 'bn' ? 'বর্তমান ঠিকানার অনুরূপ (Same as Present)' : 'Same as Present Address'}
                </span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              
              {/* Village / Area */}
              <div id="field-permanentVillage" className="space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  {lang === 'bn' ? 'গ্রাম / এলাকা / পাড়া' : 'Village / Area'}
                  {!sameAsPresent && <span className="text-red-500 font-bold ml-0.5">*</span>}
                </label>
                <input
                  type="text"
                  disabled={sameAsPresent}
                  value={permanentVillage}
                  onChange={(e) => {
                    setPermanentVillage(e.target.value);
                    if (errors.permanentVillage) {
                      setErrors(prev => {
                        const next = { ...prev };
                        delete next.permanentVillage;
                        return next;
                      });
                    }
                  }}
                  placeholder={lang === 'bn' ? 'স্থায়ী গ্রাম বা এলাকা' : 'Permanent village'}
                  className={`w-full px-3 py-2 bg-white border rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#0A6A32] ${
                    sameAsPresent ? 'bg-gray-100 text-gray-500 cursor-not-allowed' : ''
                  } ${errors.permanentVillage ? 'border-red-500' : 'border-gray-300'}`}
                  id="input-permanentVillage"
                />
                {errors.permanentVillage && <p className="text-[10px] text-red-600 font-bold">{errors.permanentVillage}</p>}
              </div>

              {/* Thana / Upazila */}
              <div id="field-permanentThana" className="space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  {lang === 'bn' ? 'থানা / উপজেলা' : 'Thana / Upazila'}
                  {!sameAsPresent && <span className="text-red-500 font-bold ml-0.5">*</span>}
                </label>
                {permanentUpazilaOptions.length > 0 && !sameAsPresent ? (
                  <select
                    value={permanentThana}
                    onChange={(e) => {
                      setPermanentThana(e.target.value);
                      if (errors.permanentThana) {
                        setErrors(prev => {
                          const next = { ...prev };
                          delete next.permanentThana;
                          return next;
                        });
                      }
                    }}
                    className={`w-full px-3 py-2 bg-white border rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#0A6A32] cursor-pointer ${
                      errors.permanentThana ? 'border-red-500' : 'border-gray-300'
                    }`}
                    id="select-permanentThana"
                  >
                    <option value="">{lang === 'bn' ? '[ থানা নির্বাচন করুন ]' : '[ Select Thana ]'}</option>
                    {permanentUpazilaOptions.map(u => (
                      <option key={u.nameEn} value={u.nameBn}>
                        {lang === 'bn' ? u.nameBn : u.nameEn}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    disabled={sameAsPresent}
                    value={permanentThana}
                    onChange={(e) => {
                      setPermanentThana(e.target.value);
                      if (errors.permanentThana) {
                        setErrors(prev => {
                          const next = { ...prev };
                          delete next.permanentThana;
                          return next;
                        });
                      }
                    }}
                    placeholder={lang === 'bn' ? 'স্থায়ী থানা বা উপজেলা' : 'Permanent Thana'}
                    className={`w-full px-3 py-2 bg-white border rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#0A6A32] ${
                      sameAsPresent ? 'bg-gray-100 text-gray-500 cursor-not-allowed' : ''
                    } ${errors.permanentThana ? 'border-red-500' : 'border-gray-300'}`}
                    id="input-permanentThana"
                  />
                )}
                {errors.permanentThana && <p className="text-[10px] text-red-600 font-bold">{errors.permanentThana}</p>}
              </div>

              {/* District Dropdown */}
              <div id="field-permanentDistrict" className="space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  {lang === 'bn' ? 'জেলা (District)' : 'District'}
                  {!sameAsPresent && <span className="text-red-500 font-bold ml-0.5">*</span>}
                </label>
                <select
                  disabled={sameAsPresent}
                  value={permanentDistrict}
                  onChange={(e) => {
                    setPermanentDistrict(e.target.value);
                    if (errors.permanentDistrict) {
                      setErrors(prev => {
                        const next = { ...prev };
                        delete next.permanentDistrict;
                        return next;
                      });
                    }
                  }}
                  className={`w-full px-3 py-2 bg-white border rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#0A6A32] cursor-pointer ${
                    sameAsPresent ? 'bg-gray-100 text-gray-500 cursor-not-allowed' : ''
                  } ${errors.permanentDistrict ? 'border-red-500' : 'border-gray-300'}`}
                  id="select-permanentDistrict"
                >
                  <option value="">{lang === 'bn' ? '[ জেলা নির্বাচন করুন ▼ ]' : '[ Select District ▼ ]'}</option>
                  {allDistricts.map(d => (
                    <option key={d.nameEn} value={d.nameBn}>
                      {lang === 'bn' ? d.nameBn : d.nameEn}
                    </option>
                  ))}
                </select>
                {errors.permanentDistrict && <p className="text-[10px] text-red-600 font-bold">{errors.permanentDistrict}</p>}
              </div>

            </div>
          </div>

          {/* ================= 12. DECLARATION / ADDITIONAL NOTES ================= */}
          <div className="space-y-2">
            <label className="block text-xs sm:text-sm font-bold text-gray-800">
              {lang === 'bn' ? 'অঙ্গীকারনামা / অতিরিক্ত বিবরণ (Declaration / Additional Notes)' : 'Declaration / Additional Notes'}
            </label>
            <textarea
              rows={3}
              value={declarationNotes}
              onChange={(e) => setDeclarationNotes(e.target.value)}
              placeholder={
                lang === 'bn'
                  ? 'আপনার সেবা প্রদানের ধরণ, অভিজ্ঞতা বা বিশেষ কোনো নোট থাকলে এখানে লিখুন (ঐচ্ছিক)...'
                  : 'Write additional notes, profession category, or service details (optional)...'
              }
              className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs sm:text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A6A32]/20 focus:border-[#0A6A32] transition"
              id="textarea-declarationNotes"
            />

            {/* Declaration Checkbox */}
            <div id="field-declarationAgreed" className="pt-1">
              <label className="flex items-start gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={declarationAgreed}
                  onChange={(e) => {
                    setDeclarationAgreed(e.target.checked);
                    if (errors.declarationAgreed) {
                      setErrors(prev => {
                        const next = { ...prev };
                        delete next.declarationAgreed;
                        return next;
                      });
                    }
                  }}
                  className="w-4 h-4 mt-0.5 rounded text-[#0A6A32] focus:ring-[#0A6A32] accent-[#0A6A32] cursor-pointer"
                  id="checkbox-declarationAgreed"
                />
                <span className="text-[11px] sm:text-xs text-gray-700 leading-relaxed">
                  {lang === 'bn' 
                    ? 'আমি প্রত্যয়ন করছি যে উপরে প্রদত্ত সকল তথ্য সত্য ও নির্ভুল। উৎসব উপহারের জন্য আমি একজন প্রকৃত নিবন্ধিত সেবা প্রদানকারী।' 
                    : 'I declare that all the information provided above is true and accurate, and I am a genuine registered service provider for festival welfare gifts.'}
                </span>
              </label>
              {errors.declarationAgreed && (
                <p className="text-xs font-bold text-red-600 flex items-center gap-1 mt-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errors.declarationAgreed}</span>
                </p>
              )}
            </div>
          </div>

          {/* ================= 13. SUBMIT APPLICATION BUTTON ================= */}
          <div className="pt-3">
            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-full py-3.5 sm:py-4 px-6 rounded-2xl text-white font-black text-sm sm:text-base shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
                isSubmitting 
                  ? 'bg-gray-400 cursor-not-allowed opacity-80' 
                  : 'bg-[#0A6A32] hover:bg-emerald-800 active:scale-[0.99] shadow-emerald-900/20'
              }`}
              id="btn-submit-puja-application"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>{lang === 'bn' ? 'আবেদন জমা হচ্ছে...' : 'Submitting Application...'}</span>
                </>
              ) : (
                <>
                  <Gift className="w-5 h-5" />
                  <span>{lang === 'bn' ? 'আবেদন জমা দিন (Submit Application)' : 'Submit Application'}</span>
                </>
              )}
            </button>
            <p className="text-[10px] text-gray-400 text-center mt-2">
              {lang === 'bn' 
                ? 'আবেদন সম্পন্ন হওয়ার সাথে সাথেই আপনি একটি ডিজিটাল রসিদ ও ট্র্যাকিং আইডি পাবেন।' 
                : 'You will receive a digital application receipt and tracking ID immediately upon submission.'}
            </p>
          </div>

        </form>

      </div>
    </div>
  );
};
