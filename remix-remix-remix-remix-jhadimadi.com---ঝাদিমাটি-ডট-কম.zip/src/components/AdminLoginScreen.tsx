import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Lock, KeyRound, Eye, EyeOff, 
  ArrowLeft, AlertCircle, Mail, RefreshCw, CheckCircle2
} from 'lucide-react';
import { adminSecurityService } from '../services/adminSecurityService';
import { AdminFirstTimeSetup } from './AdminFirstTimeSetup';

interface AdminLoginScreenProps {
  onSuccess: () => void;
  onNavigateToCustomerApp: () => void;
}

export const AdminLoginScreen: React.FC<AdminLoginScreenProps> = ({
  onSuccess,
  onNavigateToCustomerApp,
}) => {
  // Always start with empty credentials - zero public or pre-filled credentials
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // First-time setup tracking
  const [checkingSetup, setCheckingSetup] = useState(true);
  const [isSetupComplete, setIsSetupComplete] = useState<boolean | null>(null);
  const [setupSuccessNotice, setSetupSuccessNotice] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    const verifySetupStatus = async () => {
      try {
        const res = await adminSecurityService.getSetupStatus();
        if (isMounted) {
          setIsSetupComplete(res.isSetupComplete);
        }
      } catch {
        if (isMounted) {
          setIsSetupComplete(true);
        }
      } finally {
        if (isMounted) {
          setCheckingSetup(false);
        }
      }
    };

    verifySetupStatus();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim();
    if (!cleanEmail || !password) {
      setError('ইউজারনেম/ইমেইল এবং পাসওয়ার্ড লিখুন।');
      return;
    }

    setError('');
    setIsLoading(true);

    try {
      const result = await adminSecurityService.signInAdmin(cleanEmail, password);
      setIsLoading(false);

      if (result.success) {
        onSuccess();
      } else if (result.requiresSetup) {
        setIsSetupComplete(false);
      } else {
        setError(result.message || 'ভুল অ্যাডমিন ইউজারনেম/ইমেইল বা পাসওয়ার্ড!');
      }
    } catch {
      setIsLoading(false);
      setError('অ্যাডমিন যাচাইকরণে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
    }
  };

  // 1. Loading check
  if (checkingSetup) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center p-6 select-none">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-emerald-500/30 border-t-emerald-400 rounded-full animate-spin" />
          <p className="text-xs font-medium text-slate-400">সিকিউরিটি ও অ্যাকাউন্ট স্ট্যাটাস যাচাই করা হচ্ছে...</p>
        </div>
      </div>
    );
  }

  // 2. First-time setup required: Render AdminFirstTimeSetup
  if (isSetupComplete === false) {
    return (
      <AdminFirstTimeSetup
        onSetupSuccess={(chosenUsername) => {
          setIsSetupComplete(true);
          setSetupSuccessNotice('সুপার অ্যাডমিন অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে! অনুগ্রহ করে আপনার তৈরি করা ইউজারনেম এবং পাসওয়ার্ড দিয়ে লগইন করুন।');
          if (chosenUsername) {
            setEmail(chosenUsername);
          }
        }}
        onNavigateToCustomerApp={onNavigateToCustomerApp}
      />
    );
  }

  // 3. Regular secure login screen
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between items-center p-4 sm:p-6 font-sans relative overflow-hidden select-none">
      
      {/* Background Subtle Gradient Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950 pointer-events-none" />

      {/* Top Header Navigation */}
      <div className="w-full max-w-md flex items-center justify-between z-10 pt-2">
        <button
          id="btn-back-to-customer-app"
          type="button"
          onClick={onNavigateToCustomerApp}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 transition cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>কাস্টমার অ্যাপে ফিরুন</span>
        </button>

        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-xl">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Super Admin Access</span>
        </div>
      </div>

      {/* Main Professional Login Card */}
      <div className="w-full max-w-sm my-auto z-10 py-6">
        <div className="bg-slate-900/90 border border-slate-800/90 rounded-3xl p-7 shadow-2xl backdrop-blur-xl space-y-6">
          
          {/* Brand & Security Header */}
          <div className="text-center space-y-2">
            <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center mx-auto shadow-lg shadow-emerald-950 text-white">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg font-black text-white tracking-tight">
                অ্যাডমিন লগইন পোর্টাল
              </h1>
              <p className="text-xs text-slate-400 font-medium">
                ঝাড়িমাদি সুপার অ্যাডমিন ও ম্যানেজমেন্ট ড্যাশবোর্ড
              </p>
            </div>
          </div>

          {/* Setup Completion Success Notice */}
          {setupSuccessNotice && (
            <div className="bg-emerald-950/80 border border-emerald-500/50 rounded-2xl p-3 flex items-start gap-2 text-emerald-200 text-xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span className="text-[11px] leading-relaxed font-medium">{setupSuccessNotice}</span>
            </div>
          )}

          {/* Clean Secure Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Username / Email Field */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">
                ইউজারনেম বা ইমেইল
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  id="input-admin-email"
                  type="text"
                  required
                  autoFocus
                  autoComplete="username"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError('');
                  }}
                  placeholder="ইউজারনেম অথবা ইমেইল লিখুন"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-2xl text-white text-xs font-medium placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
                />
              </div>
            </div>

            {/* Masked Password Field */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">
                অ্যাডমিন পাসওয়ার্ড
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <KeyRound className="w-4 h-4" />
                </div>
                <input
                  id="input-admin-password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError('');
                  }}
                  placeholder="পাসওয়ার্ড লিখুন"
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-800 rounded-2xl text-white text-xs font-medium placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition p-1"
                  title={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-rose-950/50 border border-rose-800/80 rounded-2xl p-3 flex items-start gap-2.5 text-rose-200 text-xs animate-shake">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span className="text-[11px] font-medium leading-relaxed">{error}</span>
              </div>
            )}

            {/* Submit Action */}
            <button
              id="btn-admin-submit"
              type="submit"
              disabled={isLoading || !email.trim() || !password}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.99] disabled:opacity-50 text-white font-bold text-xs rounded-2xl shadow-lg shadow-emerald-950 transition cursor-pointer flex items-center justify-center gap-2 mt-2"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  যাচাই করা হচ্ছে...
                </span>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>নিরাপদে লগইন করুন</span>
                </>
              )}
            </button>
          </form>

        </div>
      </div>

      {/* Footer Info */}
      <div className="z-10 text-center pb-3 text-[11px] text-slate-500 font-mono">
        Jhadimadi Administration System • Secure Portal
      </div>

    </div>
  );
};

export default AdminLoginScreen;
