import React, { useState, useRef, useEffect } from 'react';
import { 
  X, Send, Mic, MicOff, Volume2, VolumeX, Bot, User, 
  Phone, ShoppingCart, CheckCheck, Clock, Sparkles, 
  ArrowLeft, ShieldCheck, ChevronRight, Play, Pause, 
  MessageSquare, Headphones, RefreshCw, ExternalLink,
  Package, MapPin, Truck, AlertTriangle
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { askGeminiSupportChat, GeminiProductRecommendation } from '../services/gemini';
import { STORE_PRODUCTS, StoreProduct } from '../data/productsData';

export interface JhadimadiChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'admin' | 'system';
  text: string;
  isVoice?: boolean;
  voiceDuration?: string;
  recommendedProducts?: GeminiProductRecommendation[];
  serviceInfo?: {
    title: string;
    rate: string;
    deliveryTime: string;
    category: string;
  };
  timestamp: string;
}

export interface JhadimadiChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang?: Language;
  currentUser?: UserProfile | null;
  onAddToCart?: (product: StoreProduct, qty?: number) => void;
  onDirectOrder?: (product: StoreProduct) => void;
  onOpenProductDetails?: (product: StoreProduct) => void;
  onOpenNidVerification?: () => void;
}

export const JhadimadiChatModal: React.FC<JhadimadiChatModalProps> = ({
  isOpen,
  onClose,
  lang = 'bn',
  currentUser,
  onAddToCart,
  onDirectOrder,
  onOpenProductDetails,
  onOpenNidVerification,
}) => {
  const createWelcomeMessage = (): JhadimadiChatMessage => ({
    id: 'welcome_1',
    sender: 'assistant',
    text: lang === 'bn'
      ? 'হ্যালো! আমি ঝাদিমাধি এআই। ঝাদিমাধির পণ্য, দাম, বা সেবা সম্পর্কে কী জানতে চান বলুন?'
      : 'Hello! I am Jhadimadi AI. What would you like to know about Jhadimadi products, prices, or services?',
    timestamp: new Date().toLocaleTimeString(lang === 'bn' ? 'bn-BD' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
  });

  const [messages, setMessages] = useState<JhadimadiChatMessage[]>([createWelcomeMessage()]);

  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [activeVoicePlayingId, setActiveVoicePlayingId] = useState<string | null>(null);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [adminName, setAdminName] = useState<string>('সজিব চাকমা (সিনিয়র সাপোর্ট অফিসার)');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recordingTimerRef = useRef<any>(null);
  const speechRecognitionRef = useRef<any>(null);

  // Reset chat to clean welcome message
  const handleResetChat = () => {
    setMessages([createWelcomeMessage()]);
    setIsAdminMode(false);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  };

  // Auto-scroll to bottom of chat
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading, isOpen]);

  // Voice recording timer
  useEffect(() => {
    if (isRecordingVoice) {
      setRecordingSeconds(0);
      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
      setRecordingSeconds(0);
    }
    return () => {
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
    };
  }, [isRecordingVoice]);

  if (!isOpen) return null;

  // Speak text using Web Speech API
  const speakText = (text: string) => {
    if (isAudioMuted) return;
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        // Strip markdown stars or bullet points for speech
        const cleanText = text.replace(/[*_#•]/g, '').slice(0, 180);
        const utterance = new SpeechSynthesisUtterance(cleanText);
        utterance.lang = lang === 'bn' ? 'bn-BD' : 'en-US';
        utterance.rate = 1.0;
        window.speechSynthesis.speak(utterance);
      }
    } catch (e) {
      console.warn('Speech synthesis error:', e);
    }
  };

  // Toggle voice playback simulation for a voice bubble
  const handleToggleVoicePlayback = (msgId: string, text: string) => {
    if (activeVoicePlayingId === msgId) {
      setActiveVoicePlayingId(null);
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } else {
      setActiveVoicePlayingId(msgId);
      speakText(text);
      setTimeout(() => {
        setActiveVoicePlayingId(null);
      }, 4000);
    }
  };

  // Voice Recognition handler (Web Speech API)
  const handleStartVoiceRecording = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert(lang === 'bn' ? 'আপনার ব্রাউজারে ভয়েস ইনপুট সমর্থিত নয়। অনুগ্রহ করে ক্রোম ব্রাউজার ব্যবহার করুন।' : 'Voice input not supported in your browser.');
      return;
    }

    try {
      if (isRecordingVoice) {
        if (speechRecognitionRef.current) {
          speechRecognitionRef.current.stop();
        }
        setIsRecordingVoice(false);
        return;
      }

      const recognition = new SpeechRecognition();
      recognition.lang = lang === 'bn' ? 'bn-BD' : 'en-US';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsRecordingVoice(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results?.[0]?.[0]?.transcript;
        if (transcript) {
          handleSendVoiceMessage(transcript, recordingSeconds || 4);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event);
        setIsRecordingVoice(false);
      };

      recognition.onend = () => {
        setIsRecordingVoice(false);
      };

      speechRecognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error('Failed to start voice recognition:', err);
      setIsRecordingVoice(false);
    }
  };

  // Send a voice message
  const handleSendVoiceMessage = (spokenText: string, durationSec: number = 3) => {
    const durationFormatted = `0:${durationSec < 10 ? '0' + durationSec : durationSec}`;
    const userVoiceMsg: JhadimadiChatMessage = {
      id: `voice_${Date.now()}`,
      sender: 'user',
      text: spokenText,
      isVoice: true,
      voiceDuration: durationFormatted,
      timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userVoiceMsg]);
    setIsRecordingVoice(false);
    processAiOrAdminResponse(spokenText);
  };

  // Send typed text message
  const handleSendMessage = (textToSend?: string) => {
    const query = (textToSend || inputMessage).trim();
    if (!query || isLoading) return;

    const userMsg: JhadimadiChatMessage = {
      id: `msg_${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    processAiOrAdminResponse(query);
  };

  // Process response from Gemini AI or Human Admin takeover
  const processAiOrAdminResponse = async (query: string) => {
    setIsLoading(true);

    // If query is requesting human admin
    if (query.includes('অ্যাডমিন') || query.includes('admin') || query.includes('মানুষ') || query.includes('প্রতিনিধি')) {
      setTimeout(() => {
        setIsAdminMode(true);
        const adminWelcomeMsg: JhadimadiChatMessage = {
          id: `admin_${Date.now()}`,
          sender: 'admin',
          text: `👤 **ঝাদিমাদি অফিসিয়াল সাপোর্ট অফিসার (${adminName}) চ্যাটে যুক্ত হয়েছেন।**\n\nসম্মানিত গ্রাহক, আমি আপনার ইনকোয়ারি দেখতে পাচ্ছি। আপনার অর্ডার, পণ্য সংক্রান্ত যেকোনো প্রশ্ন, অথবা স্পেশাল ডেলিভারি সংক্রান্ত সহায়তা প্রয়োজন হলে অনুগ্রহ করে বিস্তারিত জানান।`,
          timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, adminWelcomeMsg]);
        setIsLoading(false);
        speakText('ঝাদিমাদি অফিসিয়াল সাপোর্ট অফিসার চ্যাটে যুক্ত হয়েছেন।');
      }, 1000);
      return;
    }

    try {
      const history = messages.slice(-5).map((m) => ({
        role: (m.sender === 'user' ? 'user' : 'assistant') as 'user' | 'assistant',
        content: m.text,
      }));

      const response = await askGeminiSupportChat(query, history, {
        userName: currentUser?.name,
        phone: currentUser?.phone,
        location: currentUser?.upazila || currentUser?.district || 'Khagrachari',
      });

      // Match products from store database if relevant
      let productsToAdd = response.recommendedProducts || [];
      const qLower = query.toLowerCase();

      // STRICT: For general greetings or casual conversation, never attach product cards
      const isGreeting = /^(হ্যালো|হাই|সালাম|আসসালামু|নমস্কার|কেমন আছেন|hello|hi|hey|kemon achen)/i.test(qLower) || 
                         qLower === 'হ্যালো' || qLower === 'হাই' || qLower === 'কেমন আছেন';

      if (isGreeting) {
        productsToAdd = [];
      } else if (!productsToAdd || productsToAdd.length === 0) {
        if (qLower.includes('হলুদ') || qLower.includes('turmeric') || qLower.includes('holud')) {
          productsToAdd = [
            {
              id: 'prod_turmeric_powder',
              name: 'পাহাড়ি জুমের খাঁটি হলুদের গুঁড়া (৫০০ গ্রাম)',
              price: '৳ ১৮০',
              category: 'SpicesGrains',
              image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80',
            },
          ];
        } else if (qLower.includes('মরিচ') || qLower.includes('chili') || qLower.includes('morich')) {
          productsToAdd = [
            {
              id: 'prod_chili_powder',
              name: 'পাহাড়ি বোম্বাই ঝাল মরিচের গুঁড়া (২৫০ গ্রাম)',
              price: '৳ ১৬০',
              category: 'SpicesGrains',
              image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80',
            },
          ];
        } else if (qLower.includes('আদা') || qLower.includes('ginger')) {
          productsToAdd = [
            {
              id: 'prod_hill_ginger',
              name: 'সুগন্ধি পাহাড়ি ফ্রেশ কাঁচা আদা (১ কেজি)',
              price: '৳ ১৪০',
              category: 'SpicesGrains',
              image: 'https://images.unsplash.com/photo-1615485500704-8e990f9900f7?auto=format&fit=crop&w=600&q=80',
            },
          ];
        } else if (qLower.includes('মধু') || qLower.includes('honey')) {
          productsToAdd = [
            {
              id: 'prod_wild_honey',
              name: 'বান্দরবানের পাহাড়ি চাকের খাঁটি কাঁচা মধু (১ কেজি)',
              price: '৳ ৯৫০',
              category: 'CraftsHoney',
              image: 'https://images.unsplash.com/photo-1587049352847-4a222e784d38?auto=format&fit=crop&w=600&q=80',
            },
          ];
        } else if (qLower.includes('চাল') || qLower.includes('rice') || qLower.includes('গুঁড়া')) {
          productsToAdd = [
            {
              id: 'prod_rice_flour',
              name: 'খাঁটি পাহাড়ি চালের গুঁড়া (১ কেজি)',
              price: '৳ ১২০',
              category: 'SpicesGrains',
              image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
            },
          ];
        } else if (qLower.includes('বাঁশ') || qLower.includes('কোড়ল') || qLower.includes('bamboo')) {
          productsToAdd = [
            {
              id: 'prod_bamboo_shoot',
              name: 'সিজনাল পাহাড়ি ফ্রেশ মিষ্টি বাঁশ কোড়ল (১ কেজি)',
              price: '৳ ১৮০',
              category: 'SpicesGrains',
              image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
            },
          ];
        } else if (qLower.includes('শুটকি') || qLower.includes('শুঁটকি') || qLower.includes('সিদল')) {
          productsToAdd = [
            {
              id: 'prod_shutki_sp',
              name: 'রাঙ্গামাটি স্পেশাল বোম্বাই শুটকি (২৫০ গ্রাম)',
              price: '৳ ৩৫০',
              category: 'ShutkiSidol',
              image: 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=300',
            },
          ];
        } else if (qLower.includes('পোশাক') || qLower.includes('তাঁত') || qLower.includes('পিনন')) {
          productsToAdd = [
            {
              id: 'prod_pinon_hadi',
              name: 'পাহাড়ি খাঁটি হস্তচালিত তাঁতের পিনন-হাদি ও থামি সেট',
              price: '৳ ১৮৫০',
              category: 'Clothing',
              image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=300',
            },
          ];
        }
      }

      // Check if service info is needed
      let serviceInfo: JhadimadiChatMessage['serviceInfo'] | undefined;
      if (query.includes('মিস্ত্রি') || query.includes('ইলেকট্রিশিয়ান') || query.includes('প্লাম্বার') || query.includes('worker') || query.includes('সার্ভিস')) {
        serviceInfo = {
          title: 'ভেরিফায়েড লোকাল সার্ভিস পার্টনার',
          rate: '৳ ৪০০ - ৳ ৮০০ / কাজ অনুযায়ী',
          deliveryTime: '১ - ২ ঘণ্টার মধ্যে সার্ভিস উপস্থিত',
          category: 'গৃহস্থালি ও কারিগরি সেবা',
        };
      }

      const botReplyMsg: JhadimadiChatMessage = {
        id: `bot_${Date.now()}`,
        sender: isAdminMode ? 'admin' : 'assistant',
        text: (lang === 'bn' ? response.replyBn : response.replyEn) || response.replyBn,
        recommendedProducts: productsToAdd,
        serviceInfo,
        timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botReplyMsg]);
      speakText(botReplyMsg.text);
    } catch (err) {
      console.warn('AI Chat Error:', err);
      const fallbackMsg: JhadimadiChatMessage = {
        id: `fb_${Date.now()}`,
        sender: 'assistant',
        text: lang === 'bn'
          ? `✨ **ঝাদিমাধি সাপোর্ট আপডেট:**\n\nআপনার প্রশ্নের উত্তরে জানাতে পেরে আনন্দিত:\n• **ডেলিভারি:** পাহাড়ি অঞ্চলে ২-৪ ঘণ্টা, সারাদেশে ২৪-৪৮ ঘণ্টায় ক্যাশ অন ডেলিভারি।\n• **পেমেন্ট:** বিকাশ, নগদ ও ক্যাশ অন ডেলিভারি (COD)।\n• **সরাসরি অর্ডার:** যেকোনো পণ্যের কার্ড থেকে "অর্ডার করুন" বাটনে ক্লিক করে সরাসরি অর্ডার প্লেস করতে পারেন।`
          : `✨ **Jhadimadi Support Update:**\n\n• Delivery: Local hills 2-4 hours, Nationwide 24-48 hours.\n• Payment: bKash, Nagad, Cash on Delivery.\n• Direct Order: Tap "Order Now" on any product card.`,
        timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Quick inquiry chips
  const quickInquiries = [
    { label: '🌿 হলুদের দাম কত?', text: 'পাহাড়ি জুমের হলুদের গুঁড়ার দাম কত এবং ওজন কত?' },
    { label: '🌶️ মরিচের দাম কত?', text: 'পাহাড়ি বোম্বাই ঝাল মরিচের গুঁড়ার দাম কত?' },
    { label: '🍯 পাহাড়ি মধুর দাম', text: 'বান্দরবানের পাহাড়ি চাকের খাঁটি কাঁচা মধুর দাম কত?' },
    { label: '🚚 ডেলিভারি নিয়ম ও চার্জ', text: 'পাহাড় ও সারাদেশের ডেলিভারি সময় এবং চার্জ কত?' },
    { label: '🛠️ লোকাল মিস্ত্রি রেট', text: 'ইলেকট্রিশিয়ান ও প্লাম্বার মিস্ত্রির কাজের রেট কত?' },
    { label: '👤 হিউম্যান অ্যাডমিন', text: 'আমি একজন হিউম্যান অ্যাডমিন প্রতিনিধির সাথে কথা বলতে চাই।' },
  ];

  // Helper to find store product for cart/checkout
  const getMatchedProduct = (rec: GeminiProductRecommendation): StoreProduct => {
    const found = STORE_PRODUCTS.find(
      (p) => p.id === rec.id || p.nameBn.includes(rec.name) || rec.name.includes(p.nameBn)
    );
    if (found) return found;

    return {
      id: rec.id || `chat_prod_${Date.now()}`,
      nameBn: rec.name,
      nameEn: rec.name,
      category: (rec.category as any) || 'CraftsHoney',
      categoryLabelBn: 'পাহাড়ি খাঁটি পণ্য',
      price: parseInt(rec.price?.replace(/[^0-9]/g, '') || '1200', 10),
      originalPrice: parseInt(rec.price?.replace(/[^0-9]/g, '') || '1200', 10) + 150,
      unit: '১ প্যাকেট',
      origin: 'খাগড়াছড়ি',
      image: rec.image || 'https://images.unsplash.com/photo-1587049352847-4a222e784d38?w=300',
      rating: 4.9,
      reviewsCount: 120,
      stock: 25,
      descriptionBn: 'ঝাদিমাদি অনুমোদিত ১০০% খাঁটি পাহাড়ি প্রাকৃতিক পণ্য।',
      descriptionEn: 'Authentic organic hill product certified by Jhadimadi.',
      features: ['শতভাগ বিশুদ্ধ', 'সরাসরি পাহাড়ের খামার থেকে সংগৃহীত', 'ক্যাশ অন ডেলিভারি'],
    };
  };

  return (
    <div 
      className="fixed inset-0 z-[60] flex items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      id="jhadimadi-ai-chat-overlay"
    >
      {/* Messaging Modal Container (Full-height mobile, compact rounded card on desktop) */}
      <div className="w-full max-w-md h-full sm:h-[92vh] sm:max-h-[720px] bg-[#EFEAE2] flex flex-col overflow-hidden shadow-2xl sm:rounded-3xl border-0 sm:border sm:border-emerald-700/30 relative">
        
        {/* ================= 1. WHATSAPP-STYLE HEADER IN EXACT #009f4d ================= */}
        <header 
          className="w-full bg-[#009f4d] text-white shadow-md z-20 shrink-0 border-b border-[#008c43]"
          style={{
            paddingTop: 'env(safe-area-inset-top, 0px)',
          }}
        >
          <div className="px-3 py-2.5 flex items-center justify-between gap-2">
            
            {/* Left: Back Button + Jhadimadi Avatar + Title */}
            <div className="flex items-center gap-2 min-w-0">
              <button
                type="button"
                onClick={onClose}
                className="p-1 rounded-full hover:bg-white/20 active:scale-95 text-white transition cursor-pointer shrink-0"
                title={lang === 'bn' ? 'ফিরে যান' : 'Back'}
                id="btn-chat-back"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>

              {/* Jhadimadi Brand Avatar with Online Pulse */}
              <div className="relative shrink-0">
                <div className="w-9.5 h-9.5 rounded-full bg-white p-0.5 shadow-sm border border-white/80 flex items-center justify-center overflow-hidden">
                  <img
                    src="https://i.ibb.co.com/sppWZhc9/logo33.png"
                    alt="Jhadimadi AI"
                    className="w-7 h-7 object-contain"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/logo11.png';
                    }}
                  />
                </div>
                {/* Active Online Green Dot */}
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-300 rounded-full border-2 border-[#009f4d] ring-1 ring-white animate-pulse" />
              </div>

              {/* Identity & Online Subtitle */}
              <div className="flex flex-col justify-center min-w-0">
                <div className="flex items-center gap-1.5 leading-tight">
                  <span className="font-extrabold text-sm text-white tracking-tight truncate">
                    {isAdminMode ? 'ঝাদিমাধি অ্যাডমিন সাপোর্ট' : 'ঝাদিমাধি এআই (Jhadimadi AI)'}
                  </span>
                  <span className="bg-amber-300 text-slate-950 text-[8px] font-black px-1.5 py-0.2 rounded-full uppercase shrink-0">
                    {isAdminMode ? 'Admin' : 'AI Bot'}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-[10.5px] text-emerald-100/95 font-medium leading-none mt-0.5 truncate">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-300 inline-block"></span>
                  <span>{isAdminMode ? `${adminName} • সক্রিয়` : 'অনলাইন • সাথে সাথে উত্তর দেয়'}</span>
                </div>
              </div>
            </div>

            {/* Right Header Actions: Reset Chat, Audio Mute, Call, Close */}
            <div className="flex items-center gap-1 shrink-0">
              {/* Reset / New Chat Button */}
              <button
                type="button"
                onClick={handleResetChat}
                className="p-1.5 rounded-lg bg-black/15 hover:bg-black/25 active:scale-95 text-white transition cursor-pointer"
                title="নতুন চ্যাট শুরু করুন (Clear Chat)"
                id="btn-chat-reset"
              >
                <RefreshCw className="w-4 h-4 text-white" />
              </button>

              {/* Speaker Mute/Unmute Toggle */}
              <button
                type="button"
                onClick={() => {
                  const nextState = !isAudioMuted;
                  setIsAudioMuted(nextState);
                  if (nextState && 'speechSynthesis' in window) {
                    window.speechSynthesis.cancel();
                  }
                }}
                className="p-1.5 rounded-lg bg-black/15 hover:bg-black/25 active:scale-95 text-white transition cursor-pointer"
                title={isAudioMuted ? 'ভয়েস অন করুন' : 'ভয়েস মিউট করুন'}
                id="btn-chat-toggle-audio"
              >
                {isAudioMuted ? (
                  <VolumeX className="w-4 h-4 text-amber-300" />
                ) : (
                  <Volume2 className="w-4 h-4 text-white" />
                )}
              </button>

              {/* Direct Call / Helpline button */}
              <a
                href="tel:01800000000"
                className="p-1.5 rounded-lg bg-black/15 hover:bg-black/25 active:scale-95 text-white transition cursor-pointer flex items-center justify-center"
                title="সরাসরি ফোন কল করুন"
                id="btn-chat-call-support"
              >
                <Phone className="w-4 h-4 text-amber-300" />
              </a>

              {/* Close Button */}
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg bg-black/15 hover:bg-black/25 active:scale-95 text-white transition cursor-pointer"
                title="চ্যাট উইন্ডো বন্ধ করুন"
                id="btn-chat-close-modal"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

          </div>

          {/* Mode banner indicator */}
          <div className="bg-black/15 px-3 py-1 flex items-center justify-between text-[10px] text-white/95 border-t border-white/15">
            <div className="flex items-center gap-1.5 truncate">
              {isAdminMode ? (
                <>
                  <Headphones className="w-3 h-3 text-amber-300 shrink-0" />
                  <span>লাইভ হিউম্যান অ্যাডমিন সেশন সংযুক্ত</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3 h-3 text-amber-300 shrink-0" />
                  <span>Google Gemini 3.8 Flash দ্বারা চালিত এআই চ্যাট</span>
                </>
              )}
            </div>

            {!isAdminMode ? (
              <button
                type="button"
                onClick={() => {
                  handleSendMessage('আমি একজন হিউম্যান অ্যাডমিন প্রতিনিধির সাথে কথা বলতে চাই।');
                }}
                className="px-2 py-0.5 rounded-md bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-[9px] transition cursor-pointer shrink-0 shadow-2xs"
              >
                👤 অ্যাডমিন সহায়তা
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setIsAdminMode(false)}
                className="px-2 py-0.5 rounded-md bg-white/20 hover:bg-white/30 text-white font-bold text-[9px] transition cursor-pointer shrink-0"
              >
                🤖 এআই মোডে ফিরুন
              </button>
            )}
          </div>
        </header>

        {/* ================= 2. CHAT CANVAS (WHATSAPP BACKGROUND) ================= */}
        <div 
          className="flex-1 overflow-y-auto p-3 space-y-3 relative"
          style={{
            backgroundImage: 'radial-gradient(#d1d5db 0.75px, transparent 0.75px)',
            backgroundSize: '16px 16px',
          }}
        >
          {/* Security & Official Trust Banner */}
          <div className="flex justify-center">
            <div className="bg-amber-50/90 text-amber-900 border border-amber-200/80 px-3 py-1 rounded-xl text-[10px] font-medium shadow-2xs flex items-center gap-1.5 max-w-[90%] text-center">
              <ShieldCheck className="w-3.5 h-3.5 text-[#009f4d] shrink-0" />
              <span>ঝাদিমাদি সুরক্ষিত মেসেজিং: আপনার চ্যাট ও অর্ডার সম্পূর্ণ নিরাপদ ও এনক্রিপ্টেড।</span>
            </div>
          </div>

          {/* Date separator pill */}
          <div className="flex justify-center my-1">
            <span className="bg-white/85 text-stone-600 px-3 py-0.5 rounded-full text-[9px] font-bold shadow-2xs border border-stone-200">
              আজ (Today)
            </span>
          </div>

          {/* Message Stream */}
          {messages.map((msg) => {
            const isMe = msg.sender === 'user';

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} animate-in fade-in slide-in-from-bottom-2 duration-150`}
              >
                {/* Message Bubble Container */}
                <div className={`flex items-end gap-1.5 max-w-[88%] sm:max-w-[82%]`}>
                  
                  {/* Left Avatar for Assistant or Admin */}
                  {!isMe && (
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mb-1 shadow-xs border ${msg.sender === 'admin' ? 'bg-amber-400 text-slate-950 border-amber-500' : 'bg-[#009f4d] text-white border-white'}`}>
                      {msg.sender === 'admin' ? (
                        <Headphones className="w-3.5 h-3.5" />
                      ) : (
                        <Bot className="w-4 h-4" />
                      )}
                    </div>
                  )}

                  {/* Bubble Content */}
                  <div
                    className={`p-3 rounded-2xl text-xs leading-relaxed shadow-xs relative ${
                      isMe
                        ? 'bg-[#009f4d] text-white rounded-br-xs font-medium'
                        : msg.sender === 'admin'
                        ? 'bg-white text-stone-900 border-2 border-amber-300/80 rounded-bl-xs'
                        : 'bg-white text-stone-900 border border-stone-200/90 rounded-bl-xs'
                    }`}
                  >
                    {/* Admin or AI Sender Badge */}
                    {!isMe && (
                      <div className="flex items-center justify-between gap-2 border-b border-stone-100 pb-1 mb-1.5">
                        <span className={`text-[10px] font-bold ${msg.sender === 'admin' ? 'text-amber-700' : 'text-[#009f4d]'}`}>
                          {msg.sender === 'admin' ? `👤 ${adminName}` : '🤖 ঝাদিমাদি এআই (Jhadimadi AI)'}
                        </span>
                        
                        {/* Speaker audio replay button */}
                        <button
                          type="button"
                          onClick={() => speakText(msg.text)}
                          className="text-stone-400 hover:text-emerald-700 p-0.5 rounded transition cursor-pointer"
                          title="মেসেজটি শুনুন (Listen)"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {/* Voice Note Bubble representation */}
                    {msg.isVoice ? (
                      <div className="flex flex-col gap-1.5 py-0.5">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleToggleVoicePlayback(msg.id, msg.text)}
                            className="w-8 h-8 rounded-full bg-white/25 hover:bg-white/35 text-white flex items-center justify-center transition active:scale-90 cursor-pointer shadow-xs shrink-0"
                          >
                            {activeVoicePlayingId === msg.id ? (
                              <Pause className="w-4 h-4 fill-white" />
                            ) : (
                              <Play className="w-4 h-4 fill-white ml-0.5" />
                            )}
                          </button>

                          {/* Sound wave graphic */}
                          <div className="flex-1 flex items-center gap-0.5 h-6 px-1">
                            {[40, 75, 55, 90, 30, 85, 60, 95, 45, 70, 35, 80, 50].map((h, i) => (
                              <span
                                key={i}
                                className={`w-1 rounded-full transition-all ${
                                  activeVoicePlayingId === msg.id ? 'bg-amber-300 animate-pulse' : 'bg-white/80'
                                }`}
                                style={{ height: `${h}%` }}
                              />
                            ))}
                          </div>

                          <span className="text-[10px] font-mono text-white/90 shrink-0">
                            {msg.voiceDuration || '0:04'}
                          </span>
                        </div>

                        {/* Transcribed text */}
                        <div className="text-[11px] text-white/95 italic bg-black/10 p-1.5 rounded-lg mt-0.5">
                          "{msg.text}"
                        </div>
                      </div>
                    ) : (
                      /* Regular Text Message */
                      <div className="whitespace-pre-line break-words text-[12.5px] leading-relaxed">
                        {msg.text}
                      </div>
                    )}

                    {/* Service Info Card (if inquiry about local worker / service) */}
                    {msg.serviceInfo && (
                      <div className="mt-2.5 pt-2 border-t border-stone-200 bg-emerald-50/70 p-2.5 rounded-xl text-stone-900 border border-emerald-200">
                        <div className="flex items-center gap-1.5 text-[11px] font-extrabold text-[#009f4d] mb-1">
                          <Truck className="w-3.5 h-3.5" />
                          <span>{msg.serviceInfo.title}</span>
                        </div>
                        <div className="text-[11px] space-y-0.5 text-stone-700">
                          <p>• <strong>আনুমানিক রেট:</strong> {msg.serviceInfo.rate}</p>
                          <p>• <strong>ডেলিভারি / পৌঁছানোর সময়:</strong> {msg.serviceInfo.deliveryTime}</p>
                        </div>
                        <div className="mt-2 flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              handleSendMessage('আমি একজন মিস্ত্রি বা সার্ভিস বুক করতে চাই। বুকিং কীভাবে হবে?');
                            }}
                            className="px-2.5 py-1 bg-[#009f4d] hover:bg-emerald-700 text-white rounded-lg text-[10px] font-bold shadow-xs active:scale-95 cursor-pointer"
                          >
                            সার্ভিস বুক করুন
                          </button>
                          <a
                            href="tel:01800000000"
                            className="px-2.5 py-1 bg-white hover:bg-stone-100 text-stone-800 border border-stone-300 rounded-lg text-[10px] font-bold shadow-2xs"
                          >
                            সরাসরি কল
                          </a>
                        </div>
                      </div>
                    )}

                    {/* Product Recommendation Cards (with Direct Order & Cart buttons) */}
                    {msg.recommendedProducts && msg.recommendedProducts.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-stone-200 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10.5px] font-extrabold text-[#009f4d] uppercase tracking-wider flex items-center gap-1">
                            <Package className="w-3.5 h-3.5" />
                            <span>প্রস্তাবিত পণ্য ও সরাসরি অর্ডার:</span>
                          </span>
                        </div>

                        <div className="grid grid-cols-1 gap-2">
                          {msg.recommendedProducts.map((prod, pIdx) => {
                            const storeProduct = getMatchedProduct(prod);

                            return (
                              <div
                                key={pIdx}
                                className="bg-stone-50 hover:bg-emerald-50/60 p-2 rounded-xl border border-stone-200/90 flex gap-2.5 items-center transition shadow-2xs group"
                              >
                                <img
                                  src={prod.image || storeProduct.image}
                                  alt={prod.name}
                                  className="w-13 h-13 rounded-lg object-cover shrink-0 border border-stone-200 shadow-2xs"
                                  onError={(e) => {
                                    (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1587049352847-4a222e784d38?w=300';
                                  }}
                                />

                                <div className="flex-1 min-w-0">
                                  <h4 className="font-extrabold text-[11.5px] text-stone-900 truncate">
                                    {prod.name}
                                  </h4>
                                  <div className="flex items-center gap-2 mt-0.5">
                                    <span className="text-[12px] font-black text-[#009f4d]">
                                      {prod.price || `৳ ${storeProduct.price}`}
                                    </span>
                                    <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded">
                                      স্টকে আছে
                                    </span>
                                  </div>

                                  {/* Direct Order & Cart Action Buttons */}
                                  <div className="flex items-center gap-1.5 mt-1.5">
                                    {/* Direct Order Button */}
                                    <button
                                      type="button"
                                      onClick={() => {
                                        if (onDirectOrder) {
                                          onDirectOrder(storeProduct);
                                        } else if (onAddToCart) {
                                          onAddToCart(storeProduct, 1);
                                        }
                                        onClose();
                                      }}
                                      className="px-2.5 py-1 bg-[#009f4d] hover:bg-emerald-700 active:scale-95 text-white rounded-lg text-[9.5px] font-black shadow-xs cursor-pointer flex items-center gap-1"
                                      title="সরাসরি চেকআউট করুন"
                                    >
                                      <ShoppingCart className="w-3 h-3" />
                                      <span>অর্ডার করুন</span>
                                    </button>

                                    {/* Add to Cart Button */}
                                    {onAddToCart && (
                                      <button
                                        type="button"
                                        onClick={() => onAddToCart(storeProduct, 1)}
                                        className="px-2 py-1 bg-white hover:bg-stone-100 active:scale-95 text-stone-800 border border-stone-300 rounded-lg text-[9.5px] font-bold cursor-pointer"
                                        title="কার্টে যোগ করুন"
                                      >
                                        কার্টে নিন
                                      </button>
                                    )}

                                    {/* Product Details */}
                                    {onOpenProductDetails && (
                                      <button
                                        type="button"
                                        onClick={() => {
                                          onOpenProductDetails(storeProduct);
                                          onClose();
                                        }}
                                        className="px-1.5 py-1 text-stone-500 hover:text-stone-800 text-[9px] font-medium cursor-pointer"
                                      >
                                        বিস্তারিত
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Timestamp & double tick (WhatsApp style) */}
                    <div className={`flex items-center justify-end gap-1 mt-1 text-[9px] ${isMe ? 'text-emerald-100' : 'text-stone-400'}`}>
                      <span>{msg.timestamp}</span>
                      {isMe && <CheckCheck className="w-3 h-3 text-amber-200" />}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Typing / Loading Indicator */}
          {isLoading && (
            <div className="flex items-center gap-2 text-stone-600 text-xs p-2 animate-in fade-in">
              <div className="w-7 h-7 rounded-full bg-[#009f4d] text-white flex items-center justify-center shadow-xs">
                <Bot className="w-4 h-4 animate-bounce" />
              </div>
              <div className="bg-white px-3 py-2 rounded-2xl rounded-bl-xs shadow-2xs border border-stone-200 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#009f4d] animate-ping" />
                <span className="font-semibold text-stone-700 text-xs">
                  {isAdminMode ? 'অ্যাডমিন রিপ্লাই লিখছেন...' : 'ঝাদিমাদি এআই উত্তর তৈরি করছে...'}
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* ================= 3. QUICK SUGGESTION CHIPS ================= */}
        <div className="bg-[#EFEAE2] px-2.5 pt-1.5 pb-1 shrink-0 border-t border-stone-200/80">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {quickInquiries.map((chip, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  if (chip.label.includes('NID') && onOpenNidVerification) {
                    onClose();
                    onOpenNidVerification();
                  } else {
                    handleSendMessage(chip.text);
                  }
                }}
                className="px-2.5 py-1 rounded-full bg-white hover:bg-emerald-50 active:scale-95 text-stone-700 hover:text-[#009f4d] text-[10px] font-bold whitespace-nowrap border border-stone-300/90 shadow-2xs transition cursor-pointer shrink-0"
              >
                {chip.label}
              </button>
            ))}
          </div>
        </div>

        {/* ================= 4. WHATSAPP-STYLE INPUT BAR ================= */}
        <footer 
          className="p-2.5 bg-[#F0F2F5] border-t border-stone-200/90 shrink-0"
          style={{
            paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 6px)',
          }}
        >
          {/* Active Voice Recording Bar */}
          {isRecordingVoice ? (
            <div className="flex items-center justify-between gap-2 bg-red-50 border border-red-200 p-2 rounded-2xl shadow-xs animate-pulse">
              <div className="flex items-center gap-2 text-red-600 font-bold text-xs">
                <span className="w-3 h-3 rounded-full bg-red-600 animate-ping" />
                <span>ভয়েস রেকর্ড হচ্ছে... ({recordingSeconds}s)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setIsRecordingVoice(false)}
                  className="px-2.5 py-1 bg-stone-200 hover:bg-stone-300 text-stone-700 text-xs font-bold rounded-xl cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleStartVoiceRecording}
                  className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl cursor-pointer shadow-xs"
                >
                  সমাপ্ত ও পাঠান
                </button>
              </div>
            </div>
          ) : (
            /* Normal Input Form */
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-1.5"
            >
              {/* Voice Message Microphone Button */}
              <button
                type="button"
                onClick={handleStartVoiceRecording}
                className="p-2 rounded-full bg-white hover:bg-emerald-50 active:scale-90 text-[#009f4d] border border-stone-300/80 shadow-2xs transition cursor-pointer shrink-0 flex items-center justify-center"
                title="ভয়েস মেসেজ রেকর্ড করুন (Voice Note)"
                id="btn-chat-mic-record"
              >
                <Mic className="w-5 h-5" />
              </button>

              {/* Text Input Field */}
              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder="মেসেজ লিখুন বা বাংলায় কথা বলুন..."
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  disabled={isLoading}
                  className="w-full bg-white border border-stone-300/90 rounded-2xl px-3.5 py-2.5 text-xs font-medium text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-[#009f4d] focus:ring-1 focus:ring-[#009f4d] transition shadow-2xs"
                  id="input-chat-message"
                />
              </div>

              {/* Send Button */}
              <button
                type="submit"
                disabled={isLoading || !inputMessage.trim()}
                className="w-10 h-10 rounded-full bg-[#009f4d] hover:bg-emerald-600 disabled:opacity-40 text-white flex items-center justify-center shrink-0 transition active:scale-95 shadow-sm cursor-pointer"
                title="মেসেজ পাঠান"
                id="btn-chat-send"
              >
                <Send className="w-4.5 h-4.5 -ml-0.5" />
              </button>
            </form>
          )}
        </footer>

      </div>
    </div>
  );
};

export default JhadimadiChatModal;
