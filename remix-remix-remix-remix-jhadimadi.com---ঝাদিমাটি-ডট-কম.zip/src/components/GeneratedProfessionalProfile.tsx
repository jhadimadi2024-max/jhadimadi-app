import React from 'react';
import { ServiceProviderPublicProfile, ProfileData } from './ServiceProviderPublicProfile';
import { ProductSellerProfile } from './ProductSellerProfile';
import { PermanentMemberProfile } from './PermanentMemberProfile';

export interface GeneratedProfessionalProfileProps {
  profile?: any;
  currentUser?: any;
  lang?: 'bn' | 'en';
  onEdit?: (profileData?: any) => void;
  onSignOut?: () => void;
  onDeleteSuccess?: () => void;
  onUpdateProfile?: (updated: any) => void;
  onBackToHome?: () => void;
  allDistricts?: any[];
  readOnly?: boolean;
}

/**
 * GeneratedProfessionalProfile
 * Dynamic role-based profile router for registered users:
 * - Product Seller -> ProductSellerProfile
 * - Permanent Member -> PermanentMemberProfile
 * - Service Provider -> ServiceProviderPublicProfile
 */
export const GeneratedProfessionalProfile: React.FC<GeneratedProfessionalProfileProps> = ({
  profile,
  currentUser,
  lang = 'bn',
  onEdit,
  onSignOut,
  onDeleteSuccess,
  onBackToHome,
}) => {
  const mergedData: ProfileData = {
    ...(currentUser || {}),
    ...(profile || {}),
  };

  const memberUID = mergedData.memberUID || mergedData.uniqueId || '';
  const isSeller = mergedData.role === 'seller' || (typeof memberUID === 'string' && memberUID.startsWith('JH-S-'));
  const isPermanent = mergedData.role === 'permanent' || (typeof memberUID === 'string' && memberUID.startsWith('JH-M-'));

  return (
    <div className="w-full max-w-md mx-auto min-h-screen bg-white overflow-x-hidden overflow-y-auto box-border">
      {isSeller ? (
        <ProductSellerProfile
          profileData={mergedData}
          currentUser={currentUser}
          lang={lang}
          isOwner={true}
          onBack={onBackToHome}
          onEditProfile={() => onEdit && onEdit(mergedData)}
          onSignOut={onSignOut}
        />
      ) : isPermanent ? (
        <PermanentMemberProfile
          profileData={mergedData}
          currentUser={currentUser}
          lang={lang}
          isOwner={true}
          onBack={onBackToHome}
          onEditProfile={() => onEdit && onEdit(mergedData)}
          onSignOut={onSignOut}
        />
      ) : (
        <ServiceProviderPublicProfile
          profileData={mergedData}
          currentUser={currentUser}
          lang={lang}
          onEditProfile={onEdit}
          onSignOut={onSignOut}
          onDeleteAccount={onDeleteSuccess}
          onBack={onBackToHome}
        />
      )}
    </div>
  );
};

export default GeneratedProfessionalProfile;
