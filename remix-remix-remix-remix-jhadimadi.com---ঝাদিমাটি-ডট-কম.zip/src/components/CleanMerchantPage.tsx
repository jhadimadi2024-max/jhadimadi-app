import React from 'react';
import { MerchantStorefront, MerchantStorefrontProps } from './MerchantStorefront';

export type CleanMerchantPageProps = MerchantStorefrontProps;

export const CleanMerchantPage: React.FC<CleanMerchantPageProps> = (props) => {
  return <MerchantStorefront {...props} />;
};

export default CleanMerchantPage;
