import React, { useState, useRef, useEffect } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  ArrowLeft, 
  MoreVertical, 
  LayoutDashboard, 
  UserCheck, 
  LogOut, 
  Trash2, 
  Check, 
  Copy, 
  Droplet, 
  AlertTriangle, 
  Languages,
  Calendar,
  Award,
  BadgeCheck,
  Building,
  MapPin,
  Phone,
  Mail,
  FileText,
  User,
  HeartHandshake
} from 'lucide-react';
import { Language } from '../utils/translations';
import { useAuth } from '../context/AuthContext';

export interface PermanentMemberProfileProps {
  profileData: any;
  currentUser?: any;
  lang?: Language;
  isOwner?: boolean;
  onEditProfile?: (data?: any) => void;
  onNavigateDashboard?: () => void;
  onSignOut?: () => void;
  onDeleteAccount?: () => void;
  onBack?: () => void;
}

export const PermanentMemberProfile: React.FC<PermanentMemberProfileProps> = ({
  profileData,
  currentUser,
  lang: initialLang = 'bn',
  isOwner = true,
  onEditProfile,
  onNavigateDashboard,
  onSignOut,
  onDeleteAccount,
  onBack,
}) => {
  const [lang, setLang] = useState<Language>(initialLang);
  const [showMenu, setShowMenu] = useState(false);
  const [copiedUID, setCopiedUID] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const menuRef = useRef<HTMLDivElement>(null);
  const { logout } = useAuth();

  const isBn = lang === 'bn';

  // Merge profile data
  const data = {
    ...(currentUser || {}),
    ...(profileData || {}),
  };

  const memberUID = data.memberUID || data.uniqueId || data.id || 'JH-M-KHG-003';
  const name = data.fullName || data.name || 'স্থায়ী সদস্য';
  const phone = data.phone || data.realPhone || '018XXXXXXXX';
  const email = data.email || 'member@jhadimadi.com';
  const bloodGroup = data.bloodGroup || 'O+';
  const district = data.district || 'খাগড়াছড়ি';
  const upazila = data.upazila || 'খাগড়াছড়ি সদর';
  const area = data.mahalla || data.detailedAddress || 'পানখাইয়াপাড়া';
  const specialization = data.profession || data.professionBn || (isBn ? 'স্থায়ী প্রতিনিধি ও আঞ্চলিক কো-অর্ডিনেটর' : 'Regional Coordinator & Permanent Representative');
  const nidNumber = data.nidNumber || '1992XXXXXXXXXX';
  const emergencyContact = data.emergencyContact || 'জরুরি যোগাযোগ সংরক্ষিত';
  const bio = data.bio || (isBn ? 'ঝাদিমাদি ডট কম-এর স্থায়ী নিবন্ধিত সদস্য ও সম্মানিত প্রতিনিধি। পার্বত্য চট্টগ্রামে ডিজিটাল সেবা ও স্থানীয় মানুষের উন্নয়নে নিবেদিত।' : 'Permanent registered member and official regional representative of Jhadimadi.com platform.');
  const avatar = data.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80';
  const createdAt = data.createdAt || new Date().toISOString().split('T')[0];

  // Close menu on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setShowMenu(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const handleCopyUID = () => {
    navigator.clipboard.writeText(memberUID);
    setCopiedUID(true);
    setTimeout(() => setCopiedUID(false), 2000);
  };

  return (
    <div className="bg-white min-h-screen text-gray-900 pb-20 font-sans" id="permanent-member-profile-root">
      
      {/* ================= TOP NAVIGATION BAR ================= */}
      <div className="sticky top-0 z-30 bg-[#0E8246] text-white px-4 py-2 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="w-8 h-8 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition active:scale-95 cursor-pointer"
              title={isBn ? 'ফিরে যান' : 'Back'}
              id="perm-btn-back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <h1 className="text-xs sm:text-sm font-bold tracking-tight leading-tight">
              {isBn ? 'স্থায়ী সদস্য বিস্তারিত প্রোফাইল' : 'Permanent Member Detailed Profile'}
            </h1>
            <span className="text-[10px] text-emerald-100 font-medium block leading-none">
              {isBn ? 'ঝাদিমাদি ডট কম আজীবন সম্মানিত সদস্য' : 'Jhadimadi.com Lifetime Representative'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Language Toggle */}
          <button
            type="button"
            onClick={() => setLang(prev => (prev === 'bn' ? 'en' : 'bn'))}
            className="px-2 py-1 bg-white/15 hover:bg-white/25 rounded-md text-[11px] font-bold text-white transition flex items-center gap-1 cursor-pointer"
            id="perm-btn-lang"
          >
            <Languages className="w-3 h-3" />
            <span>{isBn ? 'EN' : 'বাং'}</span>
          </button>

          {/* Three-Dot (⋮) Management Menu */}
          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setShowMenu(!showMenu)}
              className="w-8 h-8 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition active:scale-95 cursor-pointer"
              title={isBn ? 'মেনু' : 'Menu'}
              id="perm-profile-three-dot-btn"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {showMenu && (
              <div 
                className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-xl border border-gray-200 py-1 z-50 text-xs text-gray-800 animate-in fade-in zoom-in-95 duration-150"
                id="perm-profile-dropdown-menu"
              >
                {/* 1. Dashboard */}
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    if (onNavigateDashboard) {
                      onNavigateDashboard();
                    } else if (onBack) {
                      onBack();
                    }
                  }}
                  className="w-full text-left px-3.5 py-2.5 hover:bg-emerald-50 text-gray-800 font-semibold flex items-center gap-2.5 transition cursor-pointer"
                  id="perm-menu-dashboard-btn"
                >
                  <LayoutDashboard className="w-4 h-4 text-[#0E8246]" />
                  <span>{isBn ? 'ড্যাশবোর্ড' : 'Dashboard'}</span>
                </button>

                {/* 2. Edit Profile -> Opens Permanent Member Comprehensive Form */}
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    if (onEditProfile) {
                      onEditProfile(data);
                    }
                  }}
                  className="w-full text-left px-3.5 py-2.5 hover:bg-blue-50 text-gray-800 font-semibold flex items-center gap-2.5 transition cursor-pointer"
                  id="perm-menu-edit-profile-btn"
                >
                  <UserCheck className="w-4 h-4 text-blue-600" />
                  <span>{isBn ? 'প্রোফাইল এডিট' : 'Edit Profile'}</span>
                </button>

                <div className="h-px bg-gray-100 my-1"></div>

                {/* 3. Sign Out */}
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    if (onSignOut) {
                      onSignOut();
                    } else {
                      logout();
                    }
                  }}
                  className="w-full text-left px-3.5 py-2 hover:bg-gray-100 text-gray-700 font-medium flex items-center gap-2.5 transition cursor-pointer"
                  id="perm-menu-signout-btn"
                >
                  <LogOut className="w-4 h-4 text-gray-500" />
                  <span>{isBn ? 'সাইন আউট' : 'Sign Out'}</span>
                </button>

                {/* 4. Delete Profile */}
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    setShowDeleteModal(true);
                  }}
                  className="w-full text-left px-3.5 py-2 hover:bg-red-50 text-red-600 font-semibold flex items-center gap-2.5 transition cursor-pointer"
                  id="perm-menu-delete-btn"
                >
                  <Trash2 className="w-4 h-4 text-red-600" />
                  <span>{isBn ? 'প্রোফাইল মুছে ফেলুন' : 'Delete Profile'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-4 space-y-4">

        {/* ================= OFFICIAL PERMANENT MEMBER BADGE & CERTIFICATE CARD ================= */}
        <div className="bg-gradient-to-br from-emerald-900 via-[#0E8246] to-emerald-950 rounded-2xl p-4 text-white shadow-md relative overflow-hidden">
          {/* Subtle Watermark Graphic */}
          <div className="absolute -right-6 -bottom-6 opacity-10 pointer-events-none">
            <ShieldCheck className="w-44 h-44 text-white" />
          </div>

          <div className="flex items-center justify-between border-b border-emerald-500/40 pb-2.5 mb-3">
            <div className="flex items-center gap-1.5">
              <Award className="w-4 h-4 text-amber-300 shrink-0" />
              <span className="text-[11px] font-black uppercase tracking-wider text-amber-200">
                {isBn ? 'আজীবন স্থায়ী সদস্য সনদ' : 'Permanent Member Certificate'}
              </span>
            </div>
            <span className="text-[9px] font-bold bg-amber-400/20 text-amber-200 border border-amber-300/30 px-2 py-0.5 rounded-full">
              {isBn ? 'সক্রিয় ও অনুমোদিত' : 'Active & Verified'}
            </span>
          </div>

          <div className="flex items-start gap-3.5">
            {/* Member Photo */}
            <div className="relative shrink-0">
              <img
                src={avatar}
                alt={name}
                className="w-16 h-18 rounded-xl object-cover border-2 border-amber-300 shadow-md bg-emerald-800"
              />
              <span className="absolute -bottom-1 -right-1 bg-amber-400 text-emerald-950 p-0.5 rounded-full shadow-xs" title="Official Representative">
                <BadgeCheck className="w-3.5 h-3.5" />
              </span>
            </div>

            {/* Member Identity */}
            <div className="flex-1 min-w-0 space-y-1">
              <h2 className="text-base font-black tracking-tight leading-tight truncate text-white">
                {name}
              </h2>
              <p className="text-xs font-semibold text-emerald-100 flex items-center gap-1">
                <Building className="w-3 h-3 text-amber-300 shrink-0" />
                <span className="truncate">{specialization}</span>
              </p>

              {/* Badges: NID Verified & Blood Group */}
              <div className="flex items-center gap-1.5 pt-1 flex-wrap">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-800/80 text-emerald-100 border border-emerald-400/40">
                  <ShieldCheck className="w-3 h-3 text-emerald-300" />
                  <span>NID ভেরিফাইড</span>
                </span>
                
                <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/30 text-red-100 border border-red-300/40">
                  <Droplet className="w-2.5 h-2.5 text-red-300 fill-red-300" />
                  <span>{bloodGroup}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Member UID Ribbon */}
          <div className="mt-3.5 p-2 bg-emerald-950/70 rounded-xl border border-emerald-500/30 flex items-center justify-between text-xs">
            <div>
              <span className="text-[9px] text-emerald-200 font-bold block">
                {isBn ? 'স্থায়ী সদস্য পরিচিতি কোড (UID):' : 'Permanent Member UID:'}
              </span>
              <span className="font-mono font-black text-amber-300 text-xs tracking-wider">
                {memberUID}
              </span>
            </div>
            <button
              type="button"
              onClick={handleCopyUID}
              className="px-2.5 py-1 bg-white/20 hover:bg-white/30 rounded-lg font-semibold text-white text-[11px] flex items-center gap-1 transition cursor-pointer active:scale-95"
              id="btn-copy-perm-uid"
            >
              {copiedUID ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3 text-white/80" />}
              <span>{copiedUID ? (isBn ? 'কপি হয়েছে' : 'Copied') : (isBn ? 'কপি' : 'Copy')}</span>
            </button>
          </div>
        </div>

        {/* ================= COMPREHENSIVE PERSONAL & VERIFICATION DETAILS ================= */}
        <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-gray-900 flex items-center gap-1.5 border-b border-gray-100 pb-2">
            <User className="w-3.5 h-3.5 text-[#0E8246]" />
            <span>{isBn ? 'ব্যক্তিগত পরিচিতি ও ঠিকানা' : 'Personal & Contact Details'}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            {/* Phone */}
            <div className="p-2.5 bg-gray-50 rounded-xl border border-gray-200">
              <span className="text-[10px] text-gray-500 font-bold block">{isBn ? 'মোবাইল নম্বর:' : 'Mobile Number:'}</span>
              <span className="font-semibold text-gray-900 flex items-center gap-1 mt-0.5">
                <Phone className="w-3 h-3 text-[#0E8246]" />
                <span>{phone}</span>
              </span>
            </div>

            {/* Email */}
            <div className="p-2.5 bg-gray-50 rounded-xl border border-gray-200">
              <span className="text-[10px] text-gray-500 font-bold block">{isBn ? 'ইমেইল এড্রেস:' : 'Email Address:'}</span>
              <span className="font-semibold text-gray-900 flex items-center gap-1 mt-0.5 truncate">
                <Mail className="w-3 h-3 text-[#0E8246]" />
                <span className="truncate">{email}</span>
              </span>
            </div>

            {/* NID */}
            <div className="p-2.5 bg-gray-50 rounded-xl border border-gray-200">
              <span className="text-[10px] text-gray-500 font-bold block">{isBn ? 'জাতীয় পরিচয়পত্র (NID):' : 'National ID (NID):'}</span>
              <span className="font-mono font-bold text-gray-900 flex items-center gap-1 mt-0.5">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                <span>{nidNumber}</span>
              </span>
            </div>

            {/* Blood Group */}
            <div className="p-2.5 bg-gray-50 rounded-xl border border-gray-200">
              <span className="text-[10px] text-gray-500 font-bold block">{isBn ? 'রক্তের গ্রুপ (জরুরি সহায়তা):' : 'Blood Group (Emergency):'}</span>
              <span className="font-black text-red-600 flex items-center gap-1 mt-0.5">
                <Droplet className="w-3 h-3 text-red-600 fill-red-600" />
                <span>{bloodGroup}</span>
              </span>
            </div>
          </div>

          {/* Full Detailed Address */}
          <div className="p-2.5 bg-gray-50 rounded-xl border border-gray-200 text-xs">
            <span className="text-[10px] text-gray-500 font-bold block mb-0.5">
              {isBn ? 'স্থায়ী আবাসিক ও সাংগঠনিক ঠিকানা:' : 'Permanent Residential Address:'}
            </span>
            <span className="font-semibold text-gray-900 flex items-start gap-1">
              <MapPin className="w-3.5 h-3.5 text-[#0E8246] shrink-0 mt-0.5" />
              <span>{area}, {upazila}, {district}, চট্টগ্রাম বিভাগ</span>
            </span>
          </div>

          {/* Emergency Contact */}
          {emergencyContact && (
            <div className="p-2.5 bg-red-50/50 rounded-xl border border-red-100 text-xs">
              <span className="text-[10px] text-red-700 font-bold block mb-0.5">
                {isBn ? 'জরুরি পারিবারিক যোগাযোগ:' : 'Emergency Contact:'}
              </span>
              <span className="font-semibold text-gray-900">
                {emergencyContact}
              </span>
            </div>
          )}
        </div>

        {/* ================= STATEMENT & BIO ================= */}
        <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm space-y-2">
          <h3 className="text-xs font-bold text-gray-900 flex items-center gap-1.5 border-b border-gray-100 pb-1.5">
            <FileText className="w-3.5 h-3.5 text-[#0E8246]" />
            <span>{isBn ? 'সদস্য পরিচিতি ও অঙ্গীকার' : 'Member Bio & Mission'}</span>
          </h3>
          <p className="text-xs text-gray-700 leading-relaxed font-medium">
            {bio}
          </p>
        </div>

        {/* ================= PERMANENT MEMBER PRIVILEGES ================= */}
        <div className="bg-emerald-50/70 rounded-2xl border border-emerald-200 p-4 space-y-2.5">
          <h3 className="text-xs font-black text-[#0E8246] flex items-center gap-1.5 border-b border-emerald-200 pb-1.5">
            <HeartHandshake className="w-4 h-4 text-[#0E8246]" />
            <span>{isBn ? 'স্থায়ী সদস্য হিসেবে বিশেষ অধিকার ও সুবিধা' : 'Permanent Member Entitlements'}</span>
          </h3>
          <ul className="text-xs text-gray-700 space-y-1.5 font-medium">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#0E8246] shrink-0" />
              <span>{isBn ? 'ঝাদিমাদি ডট কম প্ল্যাটফর্মে আজীবন সম্মানিত প্রতিনিধি মর্যাদা।' : 'Lifetime representative standing on Jhadimadi.com.'}</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#0E8246] shrink-0" />
              <span>{isBn ? 'আঞ্চলিক কো-অর্ডিনেশন ও স্থানীয় কর্মসূচি পরিচালনায় অগ্রাধিকার।' : 'Priority regional coordination and program management.'}</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#0E8246] shrink-0" />
              <span>{isBn ? 'জরুরি রক্তদান ও সামাজিক সেবামূলক নেটওয়ার্কে সরাসরি অন্তর্ভুক্তি।' : 'Direct inclusion in emergency blood donation & welfare networks.'}</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#0E8246] shrink-0" />
              <span>{isBn ? '২৪/৭ ডেডিকেটেড সাপোর্ট ও প্রাতিষ্ঠানিক সনদ ভেরিফিকেশন।' : '24/7 dedicated platform support and ID verification.'}</span>
            </li>
          </ul>
        </div>

        {/* ================= EDIT PROFILE DIRECT TRIGGER BUTTON ================= */}
        <div className="pt-2">
          <button
            type="button"
            onClick={() => {
              if (onEditProfile) {
                onEditProfile(data);
              }
            }}
            className="w-full py-3 bg-white hover:bg-emerald-50 text-[#0E8246] border border-[#0E8246] rounded-xl text-xs font-black flex items-center justify-center gap-2 transition cursor-pointer shadow-xs active:scale-98"
            id="btn-perm-edit-profile-cta"
          >
            <UserCheck className="w-4 h-4" />
            <span>{isBn ? 'স্থায়ী সদস্য বিস্তারিত ফর্ম এডিট করুন' : 'Edit Permanent Member Detailed Form'}</span>
          </button>
        </div>

      </div>

      {/* ================= DELETE PROFILE CONFIRMATION MODAL ================= */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-4 space-y-3 shadow-2xl border border-red-200">
            <div className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-black text-gray-950">
                {isBn ? 'প্রোফাইল মুছে ফেলার নিশ্চয়তা' : 'Confirm Delete Profile'}
              </h3>
            </div>
            <p className="text-xs text-gray-600 leading-relaxed">
              {isBn 
                ? 'আপনি কি নিশ্চিতভাবে এই স্থায়ী সদস্য প্রোফাইলটি চিরতরে মুছে ফেলতে চান? আপনার আজীবন সদস্যপদ আইডি ও সমস্ত তথ্য মুছে যাবে।'
                : 'Are you sure you want to delete your Permanent Member profile? Your lifetime membership credentials and records will be permanently removed.'}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="px-3 py-1.5 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-100 text-xs font-semibold cursor-pointer"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowDeleteModal(false);
                  if (onDeleteAccount) {
                    onDeleteAccount();
                  } else {
                    logout();
                  }
                }}
                className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer"
                id="btn-confirm-perm-delete"
              >
                {isBn ? 'হ্যাঁ, মুছে ফেলুন' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default PermanentMemberProfile;
