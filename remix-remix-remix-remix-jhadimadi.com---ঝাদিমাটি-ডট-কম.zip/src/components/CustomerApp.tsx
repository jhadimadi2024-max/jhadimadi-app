import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  ShoppingBag, 
  Bell, 
  User, 
  Search, 
  Sparkles, 
  Home, 
  Briefcase, 
  Grid, 
  MapPin, 
  Mic,
  ShoppingCart,
  Camera,
  Home as RealEstateIcon,
  Utensils,
  Shirt,
  Car,
  Gem,
  Apple,
  Tv,
  HeartPulse,
  BookOpen,
  Briefcase as JobIcon,
  Building,
  Building2,
  Wrench as ToolIcon,
  Wrench,
  Coffee,
  Package,
  Phone,
  UserPlus,
  LogIn,
  CheckCircle,
  Globe,
  Languages,
  Star,
  Award,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Flame,
  Fish,
  Headphones,
  SlidersHorizontal,
  ArrowUpDown,
  Tag,
  Zap,
  Sparkle,
  WifiOff,
  Wifi,
  CloudOff,
  Key,
  GraduationCap,
  Sprout,
  Palette,
  Compass,
  PawPrint,
  Smartphone,
  Droplet,
  Heart,
  Gift,
  MessageCircle,
  MessageSquare,
  Cpu,
  X,
  Siren,
  ShieldAlert,
  PhoneCall,
  Lock,
  Activity,
  LifeBuoy,
  Radio,
  Truck
} from 'lucide-react';
import { 
  NATIONAL_HELPLINES, 
  POLICE_STATIONS_DIRECTORY, 
  AMBULANCE_SERVICES_DIRECTORY, 
  NationalHelpline, 
  PoliceStationContact, 
  AmbulanceServiceContact 
} from '../data/emergencyContactsData';
import { ProfessionalRegistrationWizard, RegisteredProfessional } from './ProfessionalRegistrationWizard';
import { WorkerProfileModal } from './WorkerProfileModal';
import { STORE_PRODUCTS, StoreProduct } from '../data/productsData';
import { 
  ALL_PROFESSIONS_FLAT_LIST, 
  CORE_6_SERVICE_CATEGORIES, 
  ALL_1000_PROFESSIONS_FLAT_LIST,
  MASTER_1000_PROFESSIONS
} from '../data/professionsMasterData';
import { ProductDetailModal } from './ProductDetailModal';
import { VendorStorefrontModal } from './VendorStorefrontModal';
import { INITIAL_VENDOR_STORES, VendorStore, VendorStoreProduct } from '../data/vendorsData';
import { CartDrawerModal, CartItemType } from './CartDrawerModal';
import { QuickAuthModal } from './QuickAuthModal';
import { RoleSelectionModal } from './RoleSelectionModal';
import { ServiceProviderRegistrationForm } from './ServiceProviderRegistrationForm';
import { ServiceProviderProfile } from './ServiceProviderProfile';
import { UserProfileDashboard } from './UserProfileDashboard';
import { EmbeddedSignUpPage } from './EmbeddedSignUpPage';
import { SignUpForm } from './SignUpForm';
import { SignInScreen } from './SignInScreen';
import { RegistrationPage } from './RegistrationPage';
import { EmbeddedTrackSelectionPage } from './EmbeddedTrackSelectionPage';
import { RegistrationFlow } from './RegistrationFlow';
import { EmbeddedVendorStorefrontPage } from './EmbeddedVendorStorefrontPage';
import { MerchantStorefront } from './MerchantStorefront';
import { CleanMerchantPage } from './CleanMerchantPage';
import { EmbeddedServiceProfileBuilder } from './EmbeddedServiceProfileBuilder';
import { EmbeddedFreelancerDashboard } from './EmbeddedFreelancerDashboard';
import { EmbeddedSearchMatrixPage } from './EmbeddedSearchMatrixPage';
import { ProductDetailsScreen, ProductDetailItem } from './ProductDetailsScreen';
import { DynamicAutoRoutingSystem } from './DynamicAutoRoutingSystem';
import { SuperAdminDashboard } from './SuperAdminDashboard';
import { PujaGiftApplicationForm } from './PujaGiftApplicationForm';
import { GeminiAssistantModal } from './GeminiAssistantModal';
import { JhadimadiChatModal } from './JhadimadiChatModal';
import { BrandLogo } from './BrandLogo';
import { Footer } from './Footer';
import { UserProfile, ServiceProvider } from '../types';
import { useNetworkStatus } from '../hooks/useNetworkStatus';
import { OfflineBanner, OfflineFallbackCard } from './OfflineBanner';
import { offlineStorage, OFFLINE_KEYS } from '../utils/offlineStorage';
import { supabase, isSupabaseConfigured } from '../supabase';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { Language, getTranslation } from '../utils/translations';
import { parseBanglaSearchQuery, startBanglaVoiceRecognition, ParsedSearchResult } from '../utils/aiSearchParser';

export type CustomerAppTab =
  | 'home'
  | 'services'
  | 'search'
  | 'profile'
  | 'signup'
  | 'signin'
  | 'registration'
  | 'registration_flow'
  | 'role_select'
  | 'sp_form'
  | 'sp_profile'
  | 'track_selection'
  | 'track_a_vendor'
  | 'track_b_freelancer'
  | 'freelancer_dashboard'
  | 'product_details'
  | 'auto_directory'
  | 'super_admin'
  | 'puja_gift'
  | 'ai_chat'
  | 'message';

export interface CustomerAppProps {
  onReplaySplash?: () => void;
  onNavigateToAdmin?: () => void;
  onOpenRoleSelect?: () => void;
  onOpenAuth?: (mode?: 'signin' | 'signup') => void;
  onNavigateToMerchant?: () => void;
  onNavigateToServiceProvider?: () => void;
  initialTab?: CustomerAppTab;
}

// ১৫টি অপরিহার্য টপ ক্যাটাগরি ইন্টারফেস
export interface EssentialCategoryItem {
  id: string;
  nameBn: string;
  nameEn: string;
  icon: React.ReactNode;
  badgeBg: string;
  badgeBorder: string;
  iconColor: string;
  activeBg: string;
  activeRing: string;
  categoryFilterKey: string;
  keywords: string[];
}

// ১৫টি অপরিহার্য টপ ক্যাটাগরির তালিকা (Exact 15 Essential Categories)
export const ESSENTIAL_15_CATEGORIES: EssentialCategoryItem[] = [
  {
    id: 'cat_real_estate',
    nameBn: 'রিয়েল এস্টেট',
    nameEn: 'Real Estate',
    icon: <Building2 className="w-5 h-5" />,
    badgeBg: 'bg-emerald-50 hover:bg-emerald-100',
    badgeBorder: 'border-emerald-200',
    iconColor: 'text-emerald-600',
    activeBg: 'bg-emerald-600 text-white shadow-emerald-200',
    activeRing: 'ring-2 ring-emerald-500',
    categoryFilterKey: 'RealEstate',
    keywords: ['জমি', 'টিলা', 'বাগান', 'প্লট', 'রিয়েল এস্টেট', 'land', 'real estate', 'ফ্ল্যাট', 'বাড়ি']
  },
  {
    id: 'cat_apparel_fashion',
    nameBn: 'ড্রেস / পোশাক',
    nameEn: 'Apparel & Fashion',
    icon: <Shirt className="w-5 h-5" />,
    badgeBg: 'bg-pink-50 hover:bg-pink-100',
    badgeBorder: 'border-pink-200',
    iconColor: 'text-pink-600',
    activeBg: 'bg-pink-600 text-white shadow-pink-200',
    activeRing: 'ring-2 ring-pink-500',
    categoryFilterKey: 'Clothing',
    keywords: ['পোশাক', 'পাঞ্জাবি', 'পিনন', 'হাদি', 'শাল', 'কুর্তি', 'শার্ট', 'টি-শার্ট', 'dress', 'clothing', 'তাঁত']
  },
  {
    id: 'cat_food_grocery',
    nameBn: 'ফুড & খাবার',
    nameEn: 'Food & Grocery',
    icon: <Utensils className="w-5 h-5" />,
    badgeBg: 'bg-orange-50 hover:bg-orange-100',
    badgeBorder: 'border-orange-200',
    iconColor: 'text-orange-600',
    activeBg: 'bg-orange-600 text-white shadow-orange-200',
    activeRing: 'ring-2 ring-orange-500',
    categoryFilterKey: 'SpicesGrains',
    keywords: ['খাবার', 'চাল', 'হলুদ', 'মরিচ', 'শুঁটকি', 'সিদল', 'আদা', 'food', 'grocery', 'মশলা']
  },
  {
    id: 'cat_car_vehicles',
    nameBn: 'গাড়ি & যানবাহন',
    nameEn: 'Car & Vehicles',
    icon: <Car className="w-5 h-5" />,
    badgeBg: 'bg-red-50 hover:bg-red-100',
    badgeBorder: 'border-red-200',
    iconColor: 'text-red-600',
    activeBg: 'bg-red-600 text-white shadow-red-200',
    activeRing: 'ring-2 ring-red-500',
    categoryFilterKey: 'Vehicles',
    keywords: ['গাড়ি', 'যানবাহন', 'চান্দের গাড়ি', 'জীপ', 'বাইক', 'রাইড', 'ড্রাইভার', 'car', 'vehicle']
  },
  {
    id: 'cat_services_hiring',
    nameBn: 'পেশাদার সেবা',
    nameEn: 'Services & Hiring',
    icon: <Briefcase className="w-5 h-5" />,
    badgeBg: 'bg-indigo-50 hover:bg-indigo-100',
    badgeBorder: 'border-indigo-200',
    iconColor: 'text-indigo-600',
    activeBg: 'bg-indigo-600 text-white shadow-indigo-200',
    activeRing: 'ring-2 ring-indigo-500',
    categoryFilterKey: 'Services',
    keywords: ['সেবা', 'মিস্ত্রি', 'পেশাজীবী', 'ইলেকট্রিশিয়ান', 'প্লাম্বার', 'কারিগর', 'মেকানিক', 'service', 'professional']
  },
  {
    id: 'cat_electronics_gadgets',
    nameBn: 'ইলেকট্রনিক্স',
    nameEn: 'Electronics & Gadgets',
    icon: <Smartphone className="w-5 h-5" />,
    badgeBg: 'bg-blue-50 hover:bg-blue-100',
    badgeBorder: 'border-blue-200',
    iconColor: 'text-blue-600',
    activeBg: 'bg-blue-600 text-white shadow-blue-200',
    activeRing: 'ring-2 ring-blue-500',
    categoryFilterKey: 'Electronics',
    keywords: ['ইলেকট্রনিক্স', 'স্মার্টওয়াচ', 'ইয়ারবাডস', 'পাওয়ার ব্যাংক', 'ফ্যান', 'হেডল্যাম্প', 'electronics', 'gadget']
  },
  {
    id: 'cat_ornaments_jewelry',
    nameBn: 'গহনা & অলংকার',
    nameEn: 'Ornaments & Jewelry',
    icon: <Gem className="w-5 h-5" />,
    badgeBg: 'bg-purple-50 hover:bg-purple-100',
    badgeBorder: 'border-purple-200',
    iconColor: 'text-purple-600',
    activeBg: 'bg-purple-600 text-white shadow-purple-200',
    activeRing: 'ring-2 ring-purple-500',
    categoryFilterKey: 'Jewelry',
    keywords: ['গহনা', 'অলংকার', 'রূপা', 'হাঁসুলি', 'চন্দ্রহার', 'জুয়েলারি', 'necklace', 'jewelry', 'ornament']
  },
  {
    id: 'cat_house_rent',
    nameBn: 'বাসা ভাড়া',
    nameEn: 'House Rent',
    icon: <Key className="w-5 h-5" />,
    badgeBg: 'bg-amber-50 hover:bg-amber-100',
    badgeBorder: 'border-amber-200',
    iconColor: 'text-amber-600',
    activeBg: 'bg-amber-600 text-white shadow-amber-200',
    activeRing: 'ring-2 ring-amber-500',
    categoryFilterKey: 'HouseRent',
    keywords: ['বাসা ভাড়া', 'ফ্ল্যাট', 'রুম', 'মেস', 'সাবলেট', 'house rent', 'flat', 'apartment']
  },
  {
    id: 'cat_tuition_education',
    nameBn: 'টিউশনি & শিক্ষা',
    nameEn: 'Tuition & Education',
    icon: <GraduationCap className="w-5 h-5" />,
    badgeBg: 'bg-cyan-50 hover:bg-cyan-100',
    badgeBorder: 'border-cyan-200',
    iconColor: 'text-cyan-600',
    activeBg: 'bg-cyan-600 text-white shadow-cyan-200',
    activeRing: 'ring-2 ring-cyan-500',
    categoryFilterKey: 'Education',
    keywords: ['টিউশনি', 'শিক্ষা', 'টিউটর', 'শিক্ষক', 'বই', 'কোর্স', 'education', 'tuition', 'study']
  },
  {
    id: 'cat_jhadimadi_specials',
    nameBn: 'জাদি মাডি পণ্য',
    nameEn: 'Jhadimadi Specials',
    icon: <ShoppingBag className="w-5 h-5" />,
    badgeBg: 'bg-emerald-50 hover:bg-emerald-100',
    badgeBorder: 'border-emerald-300',
    iconColor: 'text-[#2EAA26]',
    activeBg: 'bg-[#2EAA26] text-white shadow-emerald-200',
    activeRing: 'ring-2 ring-emerald-500',
    categoryFilterKey: 'JhadimadiSpecials',
    keywords: ['জাদি মাডি', 'ঝাদিমাদি', 'স্পেশাল', 'খাঁটি', 'পাহাড়ি পণ্য', 'special', 'authentic']
  },
  {
    id: 'cat_agri_hill_products',
    nameBn: 'কৃষি & পাহাড়ি ফসল',
    nameEn: 'Agri & Hill Products',
    icon: <Sprout className="w-5 h-5" />,
    badgeBg: 'bg-lime-50 hover:bg-lime-100',
    badgeBorder: 'border-lime-200',
    iconColor: 'text-lime-700',
    activeBg: 'bg-lime-600 text-white shadow-lime-200',
    activeRing: 'ring-2 ring-lime-500',
    categoryFilterKey: 'Agri',
    keywords: ['কৃষি', 'ফসল', 'আম্রপালি', 'আম', 'আনারস', 'কাজুবাদাম', 'ফলমূল', 'বাঁশ কোড়ল', 'agriculture', 'harvest']
  },
  {
    id: 'cat_handicrafts_native',
    nameBn: 'হস্তশিল্প',
    nameEn: 'Handicrafts & Native',
    icon: <Palette className="w-5 h-5" />,
    badgeBg: 'bg-rose-50 hover:bg-rose-100',
    badgeBorder: 'border-rose-200',
    iconColor: 'text-rose-600',
    activeBg: 'bg-rose-600 text-white shadow-rose-200',
    activeRing: 'ring-2 ring-rose-500',
    categoryFilterKey: 'CraftsHoney',
    keywords: ['হস্তশিল্প', 'বাঁশ', 'বেত', 'কুটির শিল্প', 'মধু', 'হ্যান্ডিক্রাফট', 'ঝুড়ি', 'handicrafts', 'craft']
  },
  {
    id: 'cat_tour_travel',
    nameBn: 'ট্যুর & ট্রাভেল',
    nameEn: 'Tour & Travel',
    icon: <Compass className="w-5 h-5" />,
    badgeBg: 'bg-sky-50 hover:bg-sky-100',
    badgeBorder: 'border-sky-200',
    iconColor: 'text-sky-600',
    activeBg: 'bg-sky-600 text-white shadow-sky-200',
    activeRing: 'ring-2 ring-sky-500',
    categoryFilterKey: 'Tour',
    keywords: ['ট্যুর', 'ট্রাভেল', 'সাজেক', 'রিসোর্ট', 'কটেজ', 'গাইড', 'ভ্রমণ', 'কাপ্তাই', 'tour', 'travel']
  },
  {
    id: 'cat_pets_livestock',
    nameBn: 'পশু-পাখি & খামার',
    nameEn: 'Pets & Livestock',
    icon: <PawPrint className="w-5 h-5" />,
    badgeBg: 'bg-amber-50 hover:bg-amber-100',
    badgeBorder: 'border-amber-200',
    iconColor: 'text-amber-800',
    activeBg: 'bg-amber-800 text-white shadow-amber-200',
    activeRing: 'ring-2 ring-amber-600',
    categoryFilterKey: 'Livestock',
    keywords: ['পশু', 'পাখি', 'খামার', 'খাসি', 'মুরগি', 'হাঁস', 'ডেইরি', 'গরু', 'livestock', 'pets']
  },
  {
    id: 'cat_health_beauty',
    nameBn: 'স্বাস্থ্য & রূপচর্চা',
    nameEn: 'Health & Beauty',
    icon: <HeartPulse className="w-5 h-5" />,
    badgeBg: 'bg-teal-50 hover:bg-teal-100',
    badgeBorder: 'border-teal-200',
    iconColor: 'text-teal-600',
    activeBg: 'bg-teal-600 text-white shadow-teal-200',
    activeRing: 'ring-2 ring-teal-500',
    categoryFilterKey: 'Health',
    keywords: ['স্বাস্থ্য', 'রূপচর্চা', 'ভেষজ', 'তেল', 'আয়ুর্বেদিক', 'ঔষধ', 'হেয়ার অয়েল', 'health', 'beauty']
  }
];

// ১১টি সুনির্দিষ্ট অনুভূমিক ক্যাটাগরি ফিল্টার মেনু (Exact 11 Horizontal Category Filter Tabs)
export interface ProductFilterTabItem {
  key: string;
  nameBn: string;
  nameEn: string;
  categoryFilterKey: string;
  keywords: string[];
}

export const PRODUCT_FILTER_TABS: ProductFilterTabItem[] = [
  {
    key: 'all',
    nameBn: 'সকল পণ্য',
    nameEn: 'All Products',
    categoryFilterKey: 'all',
    keywords: []
  },
  {
    key: 'jhadimadi',
    nameBn: 'ঝাদিমাটি',
    nameEn: 'Jhadimadi',
    categoryFilterKey: 'Jhadimadi',
    keywords: ['ঝাদিমাটি', 'জাদি মাডি', 'ঝাড়িম্যাটি', 'সিগনেচার', 'পাহাড়ি', 'অর্গানিক', 'মধু', 'হলুদ', 'jhadimadi']
  },
  {
    key: 'cosmetics',
    nameBn: 'কসমেটিক',
    nameEn: 'Cosmetics',
    categoryFilterKey: 'Cosmetics',
    keywords: ['কসমেটিক', 'রূপচর্চা', 'তেল', 'হেয়ার অয়েল', 'ফেসপ্যাক', 'অ্যালোভেরা', 'চন্দন', 'স্কিন', 'cosmetic', 'beauty', 'glow']
  },
  {
    key: 'clothing',
    nameBn: 'পোশাক-আশাক',
    nameEn: 'Apparel & Clothing',
    categoryFilterKey: 'Clothing',
    keywords: ['পোশাক', 'পাঞ্জাবি', 'পিনন', 'হাদি', 'শাল', 'কুর্তি', 'শার্ট', 'টি-শার্ট', 'থামি', 'তাঁত', 'clothing', 'apparel', 'dress']
  },
  {
    key: 'electronics',
    nameBn: 'ইলেকট্রনিক্স',
    nameEn: 'Electronics',
    categoryFilterKey: 'Electronics',
    keywords: ['ইলেকট্রনিক্স', 'স্মার্টওয়াচ', 'ইয়ারবাডস', 'পাওয়ার ব্যাংক', 'ফ্যান', 'স্পিকার', 'হেডল্যাম্প', 'টর্চ', 'electronics', 'gadget']
  },
  {
    key: 'medicines',
    nameBn: 'ঔষধ',
    nameEn: 'Medicines',
    categoryFilterKey: 'Medicines',
    keywords: ['ঔষধ', 'ওষুধ', 'মলম', 'পেইন রিলিফ', 'ফার্স্ট এইড', 'ব্যান্ডেজ', 'মেডিকেল', 'medicine', 'health', 'relief']
  },
  {
    key: 'furniture',
    nameBn: 'আসবাবপত্র',
    nameEn: 'Furniture',
    categoryFilterKey: 'Furniture',
    keywords: ['আসবাবপত্র', 'চেয়ার', 'টেবিল', 'সেগুন', 'খাট', 'ডেস্ক', 'ফার্নিচার', 'furniture', 'wood']
  },
  {
    key: 'construction',
    nameBn: 'নির্মাণাধীন সামগ্রী',
    nameEn: 'Construction Materials',
    categoryFilterKey: 'Construction',
    keywords: ['নির্মাণ', 'রড', 'সিমেন্ট', 'স্টিল', 'BSRM', 'হোলসিম', 'বিল্ডিং', 'ইট', 'বালু', 'কনস্ট্রাকশন', 'construction', 'cement', 'steel']
  },
  {
    key: 'toys',
    nameBn: 'খেলনা',
    nameEn: 'Toys',
    categoryFilterKey: 'Toys',
    keywords: ['খেলনা', 'টয়', 'ট্রেন', 'গাড়ি', 'পাজল', 'মনস্টার', 'বাচ্চাদের', 'toys', 'kids']
  },
  {
    key: 'books',
    nameBn: 'বইপত্র',
    nameEn: 'Books',
    categoryFilterKey: 'Books',
    keywords: ['বই', 'বইপত্র', 'ইতিহাস', 'সংস্কৃতি', 'গ্রামার', 'গাইড', 'সাহিত্য', 'উপন্যাস', 'books', 'guide']
  },
  {
    key: 'realestate',
    nameBn: 'রিয়েল এস্টেট',
    nameEn: 'Real Estate',
    categoryFilterKey: 'RealEstate',
    keywords: ['রিয়েল এস্টেট', 'রিয়েল এস্টেট', 'জমি', 'বাগান', 'টিলা', 'প্লট', 'ফ্ল্যাট', 'আমবাগান', 'লেক ভিউ', 'real estate', 'land']
  }
];

// ১৫টি ক্যাটালগ (বিস্তারিত ড্রিলডাউন পেজের জন্য)
const CATEGORIES_CATALOG = [
  { id: 1, name: "রিয়েল এস্টেট", icon: <RealEstateIcon className="w-4 h-4 text-emerald-600" /> },
  { id: 2, name: "ফুড ও রেস্টুরেন্ট", icon: <Utensils className="w-4 h-4 text-orange-500" /> },
  { id: 3, name: "পোশাক-আশাক", icon: <Shirt className="w-4 h-4 text-blue-500" /> },
  { id: 4, name: "গাড়ি ও বাইক", icon: <Car className="w-4 h-4 text-red-500" /> },
  { id: 5, name: "গহনা ও অর্নামেন্টস", icon: <Gem className="w-4 h-4 text-purple-500" /> },
  { id: 6, name: "পাহাড়ি ফলমূল", icon: <Apple className="w-4 h-4 text-amber-500" /> },
  { id: 7, name: "ইলেকট্রনিক্স", icon: <Tv className="w-4 h-4 text-indigo-500" /> },
  { id: 8, name: "স্বাস্থ্য ও চিকিৎসা", icon: <HeartPulse className="w-4 h-4 text-rose-500" /> },
  { id: 9, name: "শিক্ষা ও বই", icon: <BookOpen className="w-4 h-4 text-cyan-600" /> },
  { id: 10, name: "পেশাজীবী সেবা", icon: <JobIcon className="w-4 h-4 text-teal-600" /> },
  { id: 11, name: "নির্মাণ ও মিস্ত্রি", icon: <Building className="w-4 h-4 text-amber-700" /> },
  { id: 12, name: "যন্ত্রপাতি রিপেয়ার", icon: <ToolIcon className="w-4 h-4 text-slate-600" /> },
  { id: 13, name: "চা ও কফি", icon: <Coffee className="w-4 h-4 text-amber-800" /> },
  { id: 14, name: "কুটির শিল্প", icon: <Package className="w-4 h-4 text-pink-500" /> },
  { id: 15, name: "দৈনন্দিন বাজার", icon: <ShoppingCart className="w-4 h-4 text-green-600" /> }
];

// ১১টি গ্রুপের ১০০০+ সকল পেশাজীবীর তালিকা
const ALL_PROFESSION_CATEGORIES = [
  {
    category: "১. কারিগরি, নির্মাণ ও ভারী শিল্প",
    jobs: [
      "রাজমিস্ত্রি (প্রধান হেড মিস্ত্রি)", "রাজমিস্ত্রি (সহকারী / হেলপার)", "কাঠমিস্ত্রি (আসবাবপত্র ও ডেকোরেশন)", 
      "কাঠমিস্ত্রি (দরজা-জানালা ও ফ্রেম)", "ইলেকট্রিশিয়ান (বাসাবাড়ি ওয়্যারিং)", "ইলেকট্রিশিয়ান (শিল্পকারখানা ও থ্রি-ফেজ)", 
      "প্লাম্বার (স্যানিটারি ও ওয়াটার লাইন)", "পাইপ ফিটার (গ্যাস লাইন)", "থাই ও গ্লাস ফিটিং মিস্ত্রি", 
      "অ্যালুমিনিয়াম ফ্যাব্রিকেটর", "টাইলস ও মার্বেল মিস্ত্রি", "মোজাইক পলিশ মিস্ত্রি", "রডবাইন্ডার / রড মিস্ত্রি", 
      "ওয়েল্ডিং মিস্ত্রি (লোহা ও স্টিল)", "গ্রিল ও এসএস মিস্ত্রি", "রং মিস্ত্রি (ইন্টেরিয়র পেইন্টার)", 
      "রং মিস্ত্রি (এক্সটেরিয়র ও বিল্ডিং পেইন্টার)", "উড পলিশ মিস্ত্রি (আসবাবপত্র বার্নিশ)", "সাটারিং মিস্ত্রি (ঢালাই কাজ)", 
      "স্ক্যাফোল্ডিং / বাঁশ-মাচা মিস্ত্রি", "জেনারেটর মেকানিক ও টেকনিশিয়ান", "লিফট টেকনিশিয়ান ও মেইনটেন্যান্স মিস্ত্রি", 
      "সোলার প্যানেল ইনস্টলার ও টেকনিশিয়ান", "সিসিটিভি ও সিকিউরিটি ক্যামেরা ইনস্টলার", "ওয়াটারপ্রুফিং ও ড্যাম্প মিস্ত্রি", 
      "ফলস সিলিং ও জিপসাম মিস্ত্রি", "বোরিং মিস্ত্রি (টিউবওয়েল ও গভীর নলকূপ)", "ড্রেন ও পয়ঃনিষ্কাশন মিস্ত্রি", 
      "মাটি পরীক্ষা কারিগর (সয়েল টেস্ট টেকনিশিয়ান)", "আর্কিটেকচারাল ড্রাফটসম্যান"
    ]
  },
  {
    category: "২. ইলেকট্রনিক্স, মেকানিক ও হোম অ্যাপ্লায়েন্স",
    jobs: [
      "এসি সার্ভিসিং ও রিপেয়ার টেকনিশিয়ান", "ফ্রিজ / রেফ্রিজারেটর মেকানিক", "ওয়াশিং মেশিন রিপেয়ার টেকনিশিয়ান", 
      "মাইক্রোওয়েভ ওভেন মেকানিক", "টিভি ও এলইডি মনিটর মেকানিক", "আইপিএস ও ইউপিএস মেকানিক", 
      "পানির পাম্প ও মোটর মিস্ত্রি", "গ্যাস স্টোভ ও চুলা মেরামতকারী", "রাইস কুকার ও ইন্ডাকশন চুলা মেকানিক", 
      "ওয়াটার ফিল্টার ও আর-ও (RO) সার্ভিসিং মেকানিক", "গিজার ও ওয়াটার হিটার ফিটিং মিস্ত্রি", 
      "কম্পিউটার ও ল্যাপটপ হার্ডওয়্যার মেকানিক", "প্রিন্টার ও স্ক্যানার মেরামতের টেকনিশিয়ান", "স্মার্টফোন ও মোবাইল ফোন মেকানিক", 
      "সাউন্ড সিস্টেম ও অডিও মেকানিক", "ডিজিটাল ক্যামেরা repair মিস্ত্রি", "সেলাই মেশিন ও টেক্সটাইল মেকানিক"
    ]
  },
  {
    category: "৩. পরিবহন, ড্রাইভ ও যানবাহন মেকানিক",
    jobs: [
      "ব্যক্তিগত প্রাইভেট কার ড্রাইভার", "হেভি ভেহিকল (বাস ও ট্রাক) ড্রাইভার", "মাইক্রোবাস ও হাইয়েস ড্রাইভার", 
      "সিএনজি ও অটো-রিকশা চালক", "রাইড শেয়ারিং বাইকার (পাঠাও/উবার)", "পিকআপ ও কাভার্ড ভ্যান চালক", 
      "ট্রাক্টর ও পাওয়ার ট্রিলার চালক", "স্কেভেটর / ক্রেন অপারেটর", "অ্যাম্বুলেন্স ড্রাইভার", 
      "রাইডার / পার্সেল ডেলিভারিম্যান", "মোটরবাইক মেকানিক", "কার ইঞ্জিন ও ডেন্টিং-পেইন্টিং মিস্ত্রি", 
      "অটো-ইলেকট্রিশিয়ান (গাড়ির ওয়্যারিং)", "গাড়ির এসি মেকানিক", "টায়ার ও ভলকানাইজিং মিস্ত্রি", 
      "সাইকেল ও রিকশা মেরামতকারী", "বোট ও ট্রলার মেকানিক"
    ]
  },
  {
    category: "৪. গৃহস্থালি, পরিচ্ছন্নতা ও দৈনন্দিন সেবা",
    jobs: [
      "পার্ট-টাইম গৃহকর্মী (রান্না ও ধোয়ামোছা)", "ফুল-টাইম গৃহকর্মী (বাসায় থেকে কাজ)", "হোম ক্লিনার (ডিপ ক্লিনিং টিম)", 
      "সোফা ও কার্পেট ক্লিনিং কারিগর", "ওয়াটার ট্যাংক ও সেপটিক ট্যাংক পরিষ্কারক", "ডিশওয়াশার / বাসন মাজার কাজ", 
      "লন্ড্রি বয় (কাপড় ধোয়া ও ইস্ত্রি)", "লন্ড্রি ড্রায়ার ও কেমিক্যাল ড্রাই ক্লিনার", "পেস্ট কন্ট্রোল ও ছারপোকা দমন কারিগর", 
      "কেয়ারগিভার (প্রবীণ ও অসুস্থ মানুষের সেবা)", "বেবি সিটার / আয়া (শিশু লালন-পালন)", "মালী / বাগান পরিচর্যাকারী", 
      "ড্রেন ও ময়লা পরিষ্কারক", "সিকিউরিটি গার্ড / পাহারাদার", "দারোয়ান / গেট কিপার", "বাসাবাড়ির কেয়ারটেকার"
    ]
  },
  {
    category: "৫. কৃষি, খামার, পশুপালন ও পাহাড় কেন্দ্রিক",
    jobs: [
      "কৃষি শ্রমিক (জমি চাষ ও ফসল রোপণ)", "ধান কাটা ও মাড়াই শ্রমিক", "জুম চাষী ও পাহাড়ি কৃষি শ্রমিক", 
      "ফল চাষী ও বাগান রক্ষক (আম, লিচু, ড্রাগন)", "চা বাগান শ্রমিক", "রাবার বাগান কষ সংগ্রহকারী", 
      "বাঁশ ও বেত সামগ্রী কারিগর", "মাশরুম চাষী", "গবাদিপশু (গরু-ছাগল) খামারি", 
      "ডেইরি ফার্ম ফার্মাকোলজি ও দুধ সংগ্রহকারী", "হাঁস-মুরগির (পোল্ট্রি) খামার শ্রমিক", "মৎস্য চাষী ও পুকুর পরিচর্যাকারী", 
      "জেলে / মাছ ধরার ট্রলার শ্রমিক", "মৌমাছি চাষী ও মধু সংগ্রহকারী (বাওয়ালি)", "কসাই (গরু, ছাগল ও খাসি কাটার মিস্ত্রি)", 
      "কোরবানি পশুর মাংস কাটার কারিগর", "পশুর চামড়া ছাড়ানোর কারিগর", "পশুপালন টেকনিশিয়ান / ভ্যাক্সিনেটর", 
      "গাছ কাটার কারিগর / কাঠুরে", "ডালপালা ও বাগান ছাঁটাই মিস্ত্রি"
    ]
  },
  {
    category: "৬. স্বাস্থ্য, চিকিৎসা ও ব্যক্তিগত পরিচর্যা",
    jobs: [
      "জেনারেল ফিজিশিয়ান (MBBS)", "শিশু রোগ বিশেষজ্ঞ", "গাইনোকোলজিস্ট ও প্রসূতি বিশেষজ্ঞ", 
      "দন্ত চিকিৎসক (ডেন্টিস্ট)", "ফিজিও থেরাপিস্ট (হোম সার্ভিস)", "হোম নার্স (পুরুষ/নারী)", 
      "প্যাথলজি ব্লাড কালেকশন বয় (হোম স্যাম্পলিং)", "ফার্মাসিস্ট ও ওষুধ বিক্রেতা", "অলটারনেটিভ মেডিসিন / হোমিও চিকিৎসক", 
      "থেরাপিস্ট ও মাসাজ সার্ভিস (হোম/স্পা)", "বিউটিশিয়ান (হোম পার্লার সার্ভিস)", "মেকআপ আর্টিস্ট (ব্রাইডাল ও পার্টি)", 
      "মেহেদি আর্টিস্ট", "নরসুন্দর / সেলুন কারিগর", "ফিটনেস ট্রেইনার / জিম ইনস্ট্রাক্টর", "যোগব্যায়াম (Yoga) শিক্ষক"
    ]
  },
  {
    category: "৭. শিক্ষা, পরামর্শ ও ফ্রিল্যান্সার",
    jobs: [
      "হাউস টিউটর (গণিত ও বিজ্ঞান)", "হাউস টিউটর (ইংরেজি ও মানবিক)", "প্রাইমারি ও অল-সাবজেক্ট টিউটর", 
      "কুরআন ও ধর্মীয় শিক্ষার শিক্ষক (ক্বারী/হাফেজ)", "ড্রয়িং ও আর্ট শিক্ষক", "সংগীত ও বাদ্যযন্ত্র শিক্ষক", 
      "ডান্স ও নৃত্য শিক্ষক", "লিগ্যাল এডভাইজার / আইনজীবী", "আয়কর ও ট্যাক্স কনসালটেন্ট", 
      "গ্রাফিক ডিজাইনার", "ওয়েব ডেভেলপার ও প্রোগ্রামার", "এসইও (SEO) বিশেষজ্ঞ", 
      "ডিজিটাল মার্কেটিং বিশেষজ্ঞ", "কন্টেন্ট রাইটার ও অনুবাদক", "ভিডিও এডিটর ও এনিমেশন কারিগর"
    ]
  },
  {
    category: "৮. ইভেন্ট, বিনোদন ও ডেকোরেশন",
    jobs: [
      "ইভেন্ট প্ল্যানার ও অর্গানাইজার", "সাউন্ড সিস্টেম অপারেটর ও টেকনিশিয়ান", "ডেকোরেটর ও প্যান্ডেল কারিগর", 
      "সামিয়ানা ও স্টেজ মিস্ত্রি", "লাইটিং ও ডেকোরেটিভ আলো কারিগর", "ফ্লাওয়ার ডেকোরেটর (ফুল দিয়ে সাজানো)", 
      "পেশাদার ফটোগ্রাফার (ইভেন্ট/ওয়েডিং)", "ভিডিওগ্রাফার ও ড্রোন অপারেটর", "ডিজে (DJ) ও মিউজিক মিক্সার", 
      "ক্যাটারিং বাবুর্চি (বিয়ে ও অনুষ্ঠানের রান্না)", "ওয়েটার ও সার্ভিং বয় (ইভেন্ট)"
    ]
  },
  {
    category: "৯. স্থানীয় কেনাকাটা, বাজার ও লজিস্টিকস",
    jobs: [
      "পার্সোনাল বাইয়ার / কাঁচাবাজারের বাজারকারী", "গ্রোসারী ও মুদি পণ্য হোম ডেলিভারিম্যান", "রান্নার গ্যাস সিলিন্ডার ডেলিভারিম্যান", 
      "খাবার পানির জেনো জিপ/ড্রাম সরবরাহকারী", "ফুড ডেলিভারি বয় (হোমমেড/রেস্টুরেন্ট)", "নিউজপেপার হকার", 
      "ডাব বিক্রেতা ও ফল ছাঁটাইকারী", "ভাঙারি ও পুরান জিনিসপত্র সংগ্রহকারী", "কুলি / ভারী মালামাল বহনকারী শ্রমিক", 
      "বাসাবাড়ি শিফটিং (লোডিং-আনলোডিং) লেবার", "ফার্নিচার ফিটিং ও ডিসম্যান্টল মিস্ত্রি"
    ]
  },
  {
    category: "১০. হস্তশিল্প, কুটির শিল্প ও কারুশিল্প",
    jobs: [
      "তাঁতি (জামদানি, তাঁত ও শাড়ি)", "কুমার / মৃৎশিল্পী (মাটির পাতিল ও টব)", "কামার (লোহার দা, বটি ও তৈরি কারিগর)", 
      "দর্জি / টেইলার্স (পুরুষ)", "দর্জি / টেইলার্স (নারী)", "এম্ব্রয়ডারি ও কারচুপি কারিগর", 
      "ব্লক ও বুটিক্স কারিগর", "জুতা ও চামড়াজাত পণ্য মেরামতকারী (মুচি)", "স্বর্ণকার / জুয়েলারি কারিগর"
    ]
  },
  {
    category: "১১. ধর্মীয়, সামাজিক ও অন্যান্য সেবা",
    jobs: [
      "ইমাম ও খতিব", "মুয়াজ্জিন", "কাজি (বিবাহ ও নিকাহ রেজিস্টার)", "পুরোহিত ও পূজা পরিচালনাকারী", 
      "ভেনতে (বৌদ্ধ ধর্মীয় ভিক্ষু/ধর্মগুরু)", "পাস্তর (খ্রিস্টান ধর্মীয় যাজক)", "কবর খোদক / গোসল প্রদানকারী"
    ]
  }
];

// বাংলাদেশের ৬৪টি জেলা এবং তার অধীনে থাকা সকল উপজেলা/থানার পূর্ণাঙ্গ লিস্ট
const ALL_BANGLADESH_DISTRICTS: Record<string, string[]> = {
  // চট্টগ্রাম বিভাগ
  "খাগড়াছড়ি": ["খাগড়াছড়ি সদর", "পানছড়ি", "দীঘিনালা", "মাটিরাঙ্গা", "মানিকছড়ি", "মহালছড়ি", "রামগড়", "লক্ষ্মীছড়ি", "গুয়াইমারা"],
  "রাঙ্গামাটি": ["রাঙ্গামাটি সদর", "কাপ্তাই", "কাউখালী", "বাঘাইছড়ি", "বরকল", "লংগদু", "রাজস্থলী", "জুরাছড়ি", "বেলাছড়ি", "নানিয়ারচর"],
  "বান্দরবান": ["বান্দরবান সদর", "রুমা", "থানচি", "রোয়াংছড়ি", "লামা", "আলীকদম", "নাইক্ষ্যংছড়ি"],
  "চট্টগ্রাম": ["কোতোয়ালী", "পাঁচলাইশ", "হালিশহর", "পতেঙ্গা", "ডাবলমুরিং", "আনোয়ারা", "বাঁশখালী", "বোয়ালখালী", "চন্দনাইশ", "ফটিকছড়ি", "হাটহাজারী", "মিরসরাই", "পটিয়া", "রাঙ্গুনিয়া", "রাওজান", "সন্দ্বীপ", "সীতাকুণ্ড"],
  "কক্সবাজার": ["কক্সবাজার সদর", "চকোরিয়া", "মহেশখালী", "টেকনাফ", "উখিয়া", "কুতুবদিয়া", "পেকুয়া", "রামু", "ঈদগাঁও"],
  "কুমিল্লা": ["কুমিল্লা আদর্শ সদর", "কুমিল্লা সদর দক্ষিণ", "চৌদ্দগ্রাম", "লাকসাম", "দাউদকান্দি", "দেবিদ্বার", "বরুড়া", "বুড়িচং", "ব্রাহ্মণপাড়া", "চান্দিনা", "হোমনা", "মেঘনা", "মুরাদনগর", "নাঙ্গলকোট", "তিতাস", "মনোহরগঞ্জ", "লালমাই"],
  "ফেনী": ["ফেনী সদর", "দাগনভূঁঞা", "ছাগলনাইয়া", "পরশুরাম", "ফুলগাজী", "সোনাগাজী"],
  "নোয়াখালী": ["নোয়াখালী সদর", "বেগমগঞ্জ", "চাটখিল", "কোম্পানীগঞ্জ", "হাতিয়া", "সেনবাগ", "সুবর্ণচর", "কবিরহাট", "সোনাইমুড়ী"],
  "লক্ষ্মীপুর": ["লক্ষ্মীপুর সদর", "রায়পুর", "রামগঞ্জ", "রামগতি", "কমলনগর"],
  "চাঁদপুর": ["চাঁদপুর সদর", "ফরিদগঞ্জ", "হাইমচর", "হাজীগঞ্জ", "কচুয়া", "মতলব উত্তর", "মতলব দক্ষিণ", "শাহরাস্তি"],
  "ব্রাহ্মণবাড়িয়া": ["ব্রাহ্মণবাড়িয়া সদর", "আশুগঞ্জ", "বাঞ্ছারামপুর", "কসবা", "নবীনগর", "নাসিরনগর", "সরাইল", "আখাউড়া", "বিজয়নগর"],

  // ঢাকা বিভাগ
  "ঢাকা": ["ধানমন্ডি", "মিরপুর", "উত্তরা", "গুলশান", "বনানী", "মোহাম্মদপুর", "তেজগাঁও", "রামপুরা", "মতিঝিল", "শাহবাগ", "সাভার", "ধামরাই", "কেরানীগঞ্জ", "নবাবগঞ্জ", "দোহার"],
  "গাজীপুর": ["গাজীপুর সদর", "কালিয়াকৈর", "কালীগঞ্জ", "কাপাসিয়া", "শ্রীপুর"],
  "নারায়ণগঞ্জ": ["নারায়ণগঞ্জ সদর", "আড়াইহাজার", "বন্দর", "রূপগঞ্জ", "সোনারগাঁ"],
  "টাঙ্গাইল": ["টাঙ্গাইল সদর", "বাসাইল", "ভূঞাপুর", "দে Physicians", "ঘাটাইল", "গোপালপুর", "কালিহাতী", "মধুপুর", "মির্জাপুর", "নাগরপুর", "সখিপুর", "ধনবাড়ী"],
  "নরসিংদী": ["নরসিংদী সদর", "বেলবো", "মনোহরদী", "পলাশ", "রায়পুরা", "শিবপুর"],
  "মানিকগঞ্জ": ["মানিকগঞ্জ সদর", "সিংগাইর", "শিবালয়", "সাটুরিয়া", "হরিরামপুর", "ঘিওর", "দৌলতপুর"],
  "মুন্সিগঞ্জ": ["মুন্সিগঞ্জ সদর", "গজারিয়া", "টঙ্গীবাড়ী", "সিরাজদিখান", "লৌহজং", "শ্রীনগর"],
  "ফরিদপুর": ["ফরিদপুর সদর", "বোয়ালমারী", "আলফাডাঙ্গা", "মধুখালী", "নগরকান্দা", "সালথা", "সদরপুর", "ভাঙ্গা", "চরভদ্রাসন"],
  "মাদারীপুর": ["মাদারীপুর সদর", "শিবচর", "কালকিনি", "রাজৈর", "ডাসার"],
  "গোপালগঞ্জ": ["গোপালগঞ্জ সদর", "কাশিয়ানী", "কোটালীপাড়া", "মুকসুদপুর", "টুঙ্গিপাড়া"],
  "রাজবাড়ী": ["রাজবাড়ী সদর", "পাংশা", "কালুখালী", "বালিয়াকান্দি", "গোয়ালন্দ"],
  "শরীয়তপুর": ["শরীয়তপুর সদর", "ডামুড্যা", "নড়িয়া", "ভেদরগঞ্জ", "জাজিরা", "গোসাইরহাট"],
  "কিশোরগঞ্জ": ["কিশোরগঞ্জ সদর", "অষ্টগ্রাম", "বাজিতপুর", "ভৈরব", "হোসেনপুর", "ইটনা", "করিমগঞ্জ", "কটিয়াদী", "কুলিয়ারচর", "মিঠামইন", "নিকলী", "পাকুন্দিয়া", "তাড়াইল"],

  // রাজশাহী বিভাগ
  "রাজশাহী": ["বোয়ালিয়া", "রাজপাড়া", "মতিহার", "শাহ মখদুম", "পবা", "গোদাগাড়ী", "তানোর", "মোহনপুর", "বাগমারা", "দুর্গাপুর", "পুঠিয়া", "চারঘাট", "বাঘা"],
  "বগুড়া": ["বগুড়া সদর", "শেরপুর", "শিবগঞ্জ", "ধুনট", "গাবতলী", "কাহালু", "নন্দীগ্রাম", "সারিয়াকান্দি", "শাজাহানপুর", "সোনারায়", "আদমদীঘি", "দুপচাঁচিয়া"],
  "পাবনা": ["পাবনা সদর", "আটঘরিয়া", "বেড়া", "ভঙ্গুড়া", "চাটমোহর", "ফরিদপুর", "ঈশ্বরদী", "সান্থিয়া", "সুজানগর"],
  "সিরাজগঞ্জ": ["সিরাজগঞ্জ সদর", "বেলকুচি", "চৌহালী", "কামারখন্দ", "কাজীপুর", "রায়গঞ্জ", "শাহজাদপুর", "তারাস", "উল্লাপাড়া"],
  "নওগাঁ": ["নওগাঁ সদর", "আত্রাই", "বদলগাছী", "ধামইরহাট", "মান্দা", "মহাদেবপুর", "নিয়ামতপুর", "পত্নীতলা", "পোরশা", "রানীনগর", "সাপাহার"],
  "নাটোর": ["নাটোর সদর", "বড়াইগ্রাম", "গুরুদাসপুর", "লালপুর", "নলডাঙ্গা", "সিংড়া", "বাগাতিপাড়া"],
  "জয়পুরহাট": ["জয়পুরহাট সদর", "আক্কেলপুর", "কালাই", "ক্ষেতলাল", "পাঁচবিবি"],
  "চাঁপাইনবাবগঞ্জ": ["চাঁপাইনবাবগঞ্জ সদর", "গোমস্তাপুর", "হাতিবান্ধা", "নাচোল", "ভোলাহাট", "শিবগঞ্জ"],

  // খুলনা বিভাগ
  "খুলনা": ["খুলনা সদর", "রূপসা", "ফুলতলা", "ডুমুরিয়া", "বটিয়াঘাটা", "দাকোপ", "পাইকগাছা", "কয়রা", "তেরখাদা", "দিঘলিয়া"],
  "যশোর": ["যশোর সদর", "অভয়নগর", "বাঘারপাড়া", "চৌগাছা", "ঝিকরগাছা", "কেশবপুর", "মণিরামপুর", "শার্শা"],
  "সাতক্ষীরা": ["সাতক্ষীরা সদর", "আশাশুনি", "দেবহাটা", "ক্যালারোয়া", "কালীগঞ্জ", "শ্যামনগর", "তালা"],
  "বাগেরহাট": ["বাগেরহাট সদর", "চিতলমারী", "ফকিরহাট", "কচুয়া", "মোল্লাহাট", "মংলা", "মোরেলগঞ্জ", "রামপাল", "শরণখোলা"],
  "ঝিনাইদহ": ["ঝিনাইদহ সদর", "হরিণাকুণ্ডু", "কালীগঞ্জ", "কোটচাঁদপুর", "মহেশপুর", "শৈলকুপা"],
  "কুষ্টিয়া": ["কুষ্টিয়া সদর", "কুমারখালী", "খোকসা", "মিরপুর", "দৌলতপুর", "ভেড়ামারা"],
  "মাগুরা": ["মাগুরা সদর", "মহম্মদপুর", "শালিখা", "শ্রীপুর"],
  "মেহেরপুর": ["মেহেরপুর সদর", "গাংনী", "মুজিবনগর"],
  "নড়াইল": ["নড়াইল সদর", "লোহাগড়া", "কালিয়া"],
  "চুয়াডাঙ্গা": ["চুয়াডাঙ্গা সদর", "আলমডাঙ্গা", "দামুড়হুদা", "জীবননগর"],

  // বরিশাল বিভাগ
  "বরিশাল": ["বরিশাল সদর", "বাকেরগঞ্জ", "উজিরপুর", "মেহেন্দিগঞ্জ", "বানারীপাড়া", "বাবুগঞ্জ", "গৌরনদী", "হিজলা", "আগৈলঝাড়া", "মুলাদী"],
  "পটুয়াখালী": ["পটুয়াখালী সদর", "বাউফল", "দশমিনা", "গলাচিপা", "কলাপাড়া", "মির্জাগঞ্জ", "দুুমকী", "রাঙ্গাবালী"],
  "ভোলা": ["ভোলা সদর", "বোরহানউদ্দিন", "চরফ্যাশন", "দৌলতখান", "লালমোহন", "মনপুরা", "তজুমদ্দিন"],
  "বরগুনা": ["বরগুনা সদর", "আমতলী", "বামনা", "বেতাগী", "পাথরঘাটা", "তালতলী"],
  "পিরোজপুর": ["পিরোজপুর সদর", "ভান্ডারিয়া", "কাউখালী", "মঠবাড়িয়া", "নাজিরপুর", "নেছারাবাদ (স্বরূপকাঠী)", "জিয়ানগর"],
  "ঝালকাঠি": ["ঝালকাঠি সদর", "কাঠালিয়া", "নলছিটি", "রাজাপুর"],

  // সিলেট বিভাগ
  "সিলেট": ["সিলেট সদর", "গোলাপগঞ্জ", "বীণাবাজার", "জৈন্তাপুর", "কানাইঘাট", "শ্রীমঙ্গল", "বিশ্বনাথ", "দক্ষিণ সুরমা", "ফেঞ্চুগঞ্জ", "কোম্পানীগঞ্জ", "বালাগঞ্জ", "জকিগঞ্জ", "ওসমানীনগর"],
  "মৌলভীবাজার": ["মৌলভীবাজার সদর", "বড়লেখা", "জুড়ী", "কমলগঞ্জ", "কুলউড়া", "রাজনগর", "শ্রীমঙ্গল"],
  "সুনামগঞ্জ": ["সুনামগঞ্জ সদর", "বিশ্বম্ভরপুর", "ছাতক", "দেরাই", "ধর্মপাশা", "দোয়ারাবাজার", "জগন্নাথপুর", "জামালগঞ্জ", "শাল্লা", "তাহিরপুর", "দক্ষিণ সুনামগঞ্জ"],
  "হবিগঞ্জ": ["হবিগঞ্জ সদর", "আজমিরীগঞ্জ", "বাহুবল", "ব্যানিয়াচং", "চুনারুঘাট", "নবীগঞ্জ", "মাধবপুর", "লাখাই", "শায়স্তাগঞ্জ"],

  // রংপুর বিভাগ
  "রংপুর": ["রংপুর সদর", "বদরগঞ্জ", "গঙ্গাচড়া", "কাউনিয়া", "মিঠাপুকুর", "পীরগাছা", "পীরগঞ্জ", "তারাগঞ্জ"],
  "দিনাজপুর": ["দিনাজপুর সদর", "বিরামপুর", "বীরগঞ্জ", "বোচাগঞ্জ", "ফুলবাড়ী", "ঘোড়াঘাট", "হাকিমপুর", "কাহারোল", "খানসামা", "খানসামা", "নবাবগঞ্জ", "পার্বতীপুর", "চিরিরবন্দর"],
  "নীলফামারী": ["নীলফামারী সদর", "সৈয়দপুর", "ডিমলা", "ডুমুরিয়া", "জলঢাকা", "কিশোরগঞ্জ"],
  "গাইবান্ধা": ["গাইবান্ধা সদর", "ফুলছড়ি", "গোবিন্দগঞ্জ", "পলাশবাড়ী", "সাদুল্লাপুর", "সাঘাটা", "সুন্দরগঞ্জ"],
  "কুড়িগ্রাম": ["কুড়িগ্রাম সদর", "ভুরুঙ্গামারী", "চর রাজিবপুর", "চিলমারী", "ফুলবাড়ী", "নাগেশ্বরী", "রাজারহাট", "রৌমারী", "উলিপুর"],
  "লালমনিরহাট": ["লালমনিরহাট সদর", "আদিতমারী", "হাতিবান্ধা", "কালীগঞ্জ", "পাটগ্রাম"],
  "পঞ্চগড়": ["পঞ্চগড় সদর", "আটোয়ারী", "বোদা", "দেবীগঞ্জ", "তেঁতুলিয়া"],
  "ঠাকুরগাঁও": ["ঠাকুরগাঁও সদর", "বালিয়াডাঙ্গী", "হরিপুর", "পীরগঞ্জ", "রাণীশংকৈল"],

  // ময়মনসিংহ বিভাগ
  "ময়মনসিংহ": ["ময়মনসিংহ সদর", "মুক্তাগাছা", "ফুলবাড়িয়া", "ত্রিশাল", "গফরগাঁও", "ভালুকা", "ধোবাউড়া", "ফুলপুর", "হালুয়াঘাট", "ঈশ্বরগঞ্জ", "নন্দাইল", "তারাকান্দা"],
  "জামালপুর": ["জামালপুর সদর", "বকশীগঞ্জ", "দেওয়ানগঞ্জ", "ইসলামপুর", "মাদারগঞ্জ", "মেলান্দহ", "সরিষাবাড়ী"],
  "শেরপুর": ["শেরপুর সদর", "ঝিনাইগাতী", "নকলা", "নালিতাবাড়ী", "শ্রীবরদী"],
  "নেত্রকোণা": ["নেত্রকোণা সদর", "আটপাড়া", "বারহাট্টা", "দুর্গাপুর", "খালিয়াজুরী", "কলমাকান্দা", "কেন্দুয়া", "মদন", "মহনগঞ্জ", "পূর্বধলা"]
};

// পণ্য ডেমো
const FEATURED_PRODUCTS = [
  { id: 1, name: "রাঙ্গামাটি স্পেশাল বোম্বাই শুটকি (২৫০ গ্রাম)", price: "৳ ৩৫০", loc: "রাঙ্গামাটি", img: "https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=300" },
  { id: 2, name: "পাহাড়ি প্রাকৃতিক খাঁটি সিদল (Sidol Paste 500g)", price: "৳ ৪৫০", loc: "খাগড়াছড়ি", img: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=300" },
  { id: 3, name: "ঝাড়িম্যাটি অর্গানিক পাহাড়ি প্রাকৃতিক মধু (১ কেজি)", price: "৳ ১২০০", loc: "বান্দরবান", img: "https://images.unsplash.com/photo-1587049352847-4a222e784d38?w=300" },
  { id: 4, name: "পাহাড়ি হস্তচালিত তাঁতের পিনন-হাদি ও থামি ড্রেস", price: "৳ ১৮৫০", loc: "রাঙ্গামাটি", img: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=300" }
];

export const CustomerApp: React.FC<CustomerAppProps> = ({ 
  onReplaySplash, 
  onNavigateToAdmin, 
  onOpenRoleSelect,
  onOpenAuth,
  onNavigateToMerchant,
  onNavigateToServiceProvider,
  initialTab
}) => {
  // নেটওয়ার্ক অবস্থা ও অফলাইন মনিটরিং
  const { isOnline, wasOffline, isChecking, checkConnection } = useNetworkStatus();

  // গ্লোবাল অথেন্টিকেশন ও রোল স্টেট (Global AuthContext)
  const {
    currentUser,
    userRole,
    userProfessionalProfile,
    isAuthModalOpen,
    authNoticeMessage,
    authModalInitialMode,
    isRoleModalOpen,
    activeProfileTab,
    setActiveProfileTab,
    openAuthModal,
    closeAuthModal,
    openRoleModal,
    closeRoleModal,
    login,
    logout,
    updateUser,
    selectRole,
    saveProfessionalProfile,
  } = useAuth();

  // গ্লোবাল ডাটা কন্টেক্সট থেকে পূর্ণাঙ্গ ডাটা কানেক্ট করা (100% Real-Time Dynamic Sync)
  const { 
    products: allProducts, 
    addProduct: contextAddProduct, 
    professionals, 
    addProfessional: contextAddProfessional,
    users,
    orders,
    banners,
    bloodDonors,
    complaints,
    locations,
    serviceCategories
  } = useData();

  const [activeSpProfileData, setActiveSpProfileData] = useState<any>(null);

  const [activeTab, setActiveTab] = useState<CustomerAppTab>(() => {
    try {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      const search = window.location.search.toLowerCase();
      if (
        path.includes('/portal/puja-gift-apply') ||
        path.includes('/puja-gift') ||
        hash === '#puja-gift' ||
        search.includes('view=puja-gift') ||
        search.includes('view=puja_gift')
      ) {
        return 'puja_gift';
      }
      if (
        hash === '#sp-form' ||
        hash === '#provider-form' ||
        search.includes('flow=sp-form') ||
        search.includes('flow=provider') ||
        search.includes('flow=service-provider') ||
        path.includes('/sp-form')
      ) {
        return 'sp_form';
      }
      if (
        hash === '#sp-profile' ||
        hash === '#resume' ||
        hash === '#provider-profile' ||
        search.includes('view=provider-profile') ||
        search.includes('view=resume') ||
        search.includes('flow=sp-profile')
      ) {
        return 'sp_profile';
      }
      if (
        hash === '#role-select' ||
        hash === '#select-role' ||
        search.includes('flow=role-select') ||
        search.includes('flow=onboarding')
      ) {
        return 'role_select';
      }
      if (
        hash === '#signin' ||
        hash === '#login' ||
        search.includes('flow=signin') ||
        search.includes('flow=login')
      ) {
        return 'signin';
      }
      if (
        hash === '#signup' ||
        hash === '#register' ||
        search.includes('flow=signup') ||
        search.includes('flow=register')
      ) {
        return 'signup';
      }
    } catch {
      // default
    }
    if (initialTab === 'ai_chat' || initialTab === 'message') {
      return 'home';
    }
    return initialTab || 'home';
  });

  // Handle incoming ai_chat or message initialTab
  useEffect(() => {
    if (initialTab === 'ai_chat' || initialTab === 'message') {
      setIsJhadimadiChatOpen(true);
    }
  }, [initialTab]);

  // URL route sync for Puja Gift, Service Provider Form, Profile, and PWA navigation
  useEffect(() => {
    const handleUrlRoute = () => {
      try {
        const path = window.location.pathname.toLowerCase();
        const hash = window.location.hash.toLowerCase();
        const search = window.location.search.toLowerCase();
        if (
          path.includes('/portal/puja-gift-apply') ||
          path.includes('/puja-gift') ||
          hash === '#puja-gift' ||
          search.includes('view=puja-gift') ||
          search.includes('view=puja_gift')
        ) {
          setActiveTab('puja_gift');
        } else if (
          hash === '#sp-form' ||
          hash === '#provider-form' ||
          search.includes('flow=sp-form') ||
          search.includes('flow=provider') ||
          search.includes('flow=service-provider') ||
          path.includes('/sp-form')
        ) {
          setActiveTab('sp_form');
        } else if (
          hash === '#sp-profile' ||
          hash === '#resume' ||
          hash === '#provider-profile' ||
          search.includes('view=provider-profile') ||
          search.includes('view=resume') ||
          search.includes('flow=sp-profile')
        ) {
          setActiveTab('sp_profile');
        } else if (
          hash === '#role-select' ||
          hash === '#select-role' ||
          search.includes('flow=role-select') ||
          search.includes('flow=onboarding')
        ) {
          setActiveTab('role_select');
        } else if (
          hash === '#signin' ||
          hash === '#login' ||
          search.includes('flow=signin') ||
          search.includes('flow=login')
        ) {
          setActiveTab('signin');
        } else if (
          hash === '#signup' ||
          hash === '#register' ||
          search.includes('flow=signup') ||
          search.includes('flow=register')
        ) {
          setActiveTab('signup');
        }
      } catch {
        // ignore
      }
    };

    window.addEventListener('popstate', handleUrlRoute);
    window.addEventListener('hashchange', handleUrlRoute);
    return () => {
      window.removeEventListener('popstate', handleUrlRoute);
      window.removeEventListener('hashchange', handleUrlRoute);
    };
  }, []);
  const [previousTab, setPreviousTab] = useState<string>('home');
  const [authRedirectTarget, setAuthRedirectTarget] = useState<'profile' | 'track_selection' | 'registration_flow' | 'home'>('profile');
  const [registrationInitialTab, setRegistrationInitialTab] = useState<'seller' | 'service' | 'permanent'>('seller');
  const [registrationIsEditMode, setRegistrationIsEditMode] = useState(false);
  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('jhadimadi_language');
      return (saved === 'en' || saved === 'bn') ? saved : 'bn';
    } catch {
      return 'bn';
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('jhadimadi_language', lang);
    } catch (e) {
      console.error(e);
    }
  }, [lang]);

  const t = getTranslation(lang);
  const [showToast, setShowToast] = useState('');

  // ক্যাটাগরি অনুভূমিক স্ক্রোলিং রেফারেন্স ও স্ট্যাটাস
  const categoryScrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkCategoryScroll = () => {
    if (categoryScrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = categoryScrollRef.current;
      setCanScrollLeft(scrollLeft > 6);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 6);
    }
  };

  const scrollCategories = (direction: 'left' | 'right') => {
    if (categoryScrollRef.current) {
      const offset = direction === 'left' ? -200 : 200;
      categoryScrollRef.current.scrollBy({ left: offset, behavior: 'smooth' });
      setTimeout(checkCategoryScroll, 350);
    }
  };

  // পণ্য অনুভূমিক ক্যাটাগরি ফিল্টার স্ক্রোলিং রেফারেন্স ও স্ট্যাটাস
  const productFilterScrollRef = useRef<HTMLDivElement>(null);
  const [canScrollFilterLeft, setCanScrollFilterLeft] = useState(false);
  const [canScrollFilterRight, setCanScrollFilterRight] = useState(true);

  const checkProductFilterScroll = () => {
    if (productFilterScrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = productFilterScrollRef.current;
      setCanScrollFilterLeft(scrollLeft > 6);
      setCanScrollFilterRight(scrollLeft < scrollWidth - clientWidth - 6);
    }
  };

  const scrollProductFilter = (direction: 'left' | 'right') => {
    if (productFilterScrollRef.current) {
      const offset = direction === 'left' ? -180 : 180;
      productFilterScrollRef.current.scrollBy({ left: offset, behavior: 'smooth' });
      setTimeout(checkProductFilterScroll, 350);
    }
  };

  // শপিং কার্ট ও প্রোডাক্ট স্টেট (Offline cached - starts clean with 0 items, strictly no fake counters)
  const [cartItems, setCartItems] = useState<CartItemType[]>(() => {
    try {
      const saved = offlineStorage.getItem<CartItemType[]>(OFFLINE_KEYS.CART, []);
      // Reset any legacy default preloaded fake seed items (e.g. initial 2 mock items)
      if (Array.isArray(saved)) {
        if (
          saved.length === 2 &&
          (saved.some(i => i?.product?.id === 'prod_1' || i?.product?.id === STORE_PRODUCTS[0]?.id))
        ) {
          offlineStorage.saveItem(OFFLINE_KEYS.CART, []);
          return [];
        }
        return saved;
      }
      return [];
    } catch {
      return [];
    }
  });
  const [isCartModalOpen, setIsCartModalOpen] = useState(false);
  const [isGeminiModalOpen, setIsGeminiModalOpen] = useState(false);
  const [isJhadimadiChatOpen, setIsJhadimadiChatOpen] = useState(false);
  const [geminiModalTab, setGeminiModalTab] = useState<'chat' | 'nid'>('chat');
  const [selectedDetailProduct, setSelectedDetailProduct] = useState<StoreProduct | null>(null);

  // Real unread notifications state (strictly 0 by default, no fake counts or mock badges)
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState<number>(0);
  const [notificationsList, setNotificationsList] = useState<Array<{ id: string; title: string; body: string; created_at: string; is_read: boolean }>>([]);
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState<boolean>(false);

  // Fetch real unread notifications from Supabase (defaults strictly to 0, no fake counter)
  useEffect(() => {
    let isMounted = true;
    const loadUnreadNotifications = async () => {
      if (!isSupabaseConfigured || !currentUser?.id) {
        if (isMounted) {
          setUnreadNotificationsCount(0);
          setNotificationsList([]);
        }
        return;
      }
      try {
        const { data, error } = await supabase
          .from('notifications')
          .select('id, title, body, created_at, is_read')
          .eq('user_id', currentUser.id)
          .order('created_at', { ascending: false })
          .limit(20);

        if (!error && Array.isArray(data) && isMounted) {
          setNotificationsList(data);
          const unread = data.filter((item: any) => !item.is_read).length;
          setUnreadNotificationsCount(unread);
        } else if (isMounted) {
          setUnreadNotificationsCount(0);
        }
      } catch {
        if (isMounted) setUnreadNotificationsCount(0);
      }
    };

    loadUnreadNotifications();
    return () => { isMounted = false; };
  }, [currentUser?.id]);

  // In-App Single Page Product Details Handler
  const handleOpenProductDetails = (product: StoreProduct) => {
    setSelectedDetailProduct(product);
    setPreviousTab(activeTab === 'product_details' ? 'home' : activeTab);
    setActiveTab('product_details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Convert StoreProduct to Rich ProductDetailItem for In-App View
  const formattedDetailProduct: ProductDetailItem | null = useMemo(() => {
    if (!selectedDetailProduct) return null;
    const p = selectedDetailProduct;
    return {
      id: p.id,
      name: lang === 'bn' ? p.nameBn : (p.nameEn || p.nameBn),
      nameBn: p.nameBn,
      nameEn: p.nameEn,
      category: p.category,
      categoryLabelBn: p.categoryLabelBn,
      pricePerUnit: p.price,
      originalPrice: p.originalPrice,
      unit: p.unit || '১ কেজি',
      stockQuantity: p.stock || 45,
      minOrderQuantity: 1,
      originLocation: p.origin || 'দিনাজপুর / খাগড়াছড়ি',
      qualityGrade: '১০০% অটো রাইস মিলের খাঁটি ও প্রিমিয়াম গ্রেড-এ',
      youtubeUrl: (p as any).youtubeUrl || 'https://www.youtube.com/embed/dQw4w9WgXcQ',
      qrCodeUrl: `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=JHADIMADI-VERIFIED-${encodeURIComponent(p.id)}-${encodeURIComponent(p.nameBn)}`,
      images: (p as any).galleryImages && (p as any).galleryImages.length > 0
        ? (p as any).galleryImages
        : [
            p.image,
            'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
            'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80'
          ],
      description: lang === 'bn' 
        ? (p.descriptionBn || `${p.nameBn} - সম্পূর্ণ নির্ভেজাল ও প্রাকৃতিক উপায়ে উৎপাদিত খাঁটি স্থানীয় পণ্য। রাসায়নিক বা ক্ষতিকর প্রিজারভেটিভমুক্ত।`)
        : (p.descriptionEn || `${p.nameBn} - 100% natural, chemical-free authentic premium local product.`),
      benefits: (p as any).features || [
        '১০০% প্রাকৃতিক ও প্রিজারভেটিভ বা ক্ষতিকর কেমিক্যাল মুক্ত।',
        'সহজে হজমযোগ্য এবং শরীরের প্রয়োজনীয় পুষ্টি ও শক্তি যোগায়।',
        'উন্নত প্রক্রিয়াজাতকরণে ধুলোবালি ও পাথর মুক্ত পরিচ্ছন্ন দানা।',
        'সরাসরি কৃষক ও স্থানীয় উদ্যোক্তার কাছ থেকে সংগৃহীত।'
      ],
      seller: {
        name: (p as any).sellerName || 'ঝাদিমাটি ভেরিফাইড অ্যাগ্রো ফার্ম',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
        phoneHidden: (p as any).sellerPhoneMasked || '018****4589',
        realPhone: '01819234589',
        isNidVerified: (p as any).verifiedSeller ?? true,
        rating: p.rating || 4.9,
        reviewsCount: p.reviewsCount || 28,
        location: p.origin || 'দিনাজপুর / খাগড়াছড়ি',
        uniqueId: (p as any).sellerUniqueId || 'JDM-V108'
      }
    };
  }, [selectedDetailProduct, lang]);
  const [vendorStores, setVendorStores] = useState<VendorStore[]>(() => {
    return offlineStorage.getItem<VendorStore[]>('jhadimadi_vendor_stores', INITIAL_VENDOR_STORES);
  });

  // অনুমোদিত মার্চেন্ট ও সেলার স্টোরফ্রন্ট (KYC ও ইউজার মোডারেশন থেকে রিয়েলটাইম সিঙ্ক)
  const activeVendorStores = useMemo(() => {
    const dynamicSellerStores: VendorStore[] = users
      .filter(u => u.role === 'seller' && u.status === 'Approved')
      .map(u => ({
        id: String(u.id),
        uniqueId: u.tradeLicense ? `V-${u.tradeLicense.slice(-4)}` : `V-${String(u.id).slice(-4)}`,
        shopName: u.name,
        shopNameEn: u.name,
        ownerName: u.name,
        avatar: u.avatar || 'https://images.unsplash.com/photo-1587049352847-4a222e784d38?w=150',
        banner: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=600',
        phoneMasked: u.phone ? `${u.phone.slice(0, 4)}****${u.phone.slice(-3)}` : '018****-***11',
        realPhone: u.phone || '01800000000',
        division: 'চট্টগ্রাম',
        district: u.district || 'খাগড়াছড়ি',
        upazila: u.upazila || 'সদর',
        mahalla: u.upazila || 'সদর',
        bazarName: 'সদর বাজার',
        detailedAddress: `${u.upazila || 'সদর'}, ${u.district || 'খাগড়াছড়ি'}`,
        rating: 5.0,
        reviewsCount: 12,
        positiveRatingPercent: 99,
        shipOnTimePercent: 99,
        responseRatePercent: 95,
        followersCount: 45,
        isVerified: true,
        verifiedBadgeText: 'ঝাডিমাটি ভেরিফাইড মার্চেন্ট',
        categories: ['কৃষি ও অর্গানিক', 'পাহাড়ি স্পেশাল'],
        aboutBn: `${u.name} এর নিজস্ব ভেরিফাইড পাহাড়ি স্টোরফ্রন্ট।`,
        tradeLicenseNumber: u.tradeLicense || 'TRD-2026-9901',
        nidNumberMasked: '1990********45',
        establishedYear: '২০২৩',
        wallet: {
          grossSales: 45000,
          totalCommissionPaid: 2250,
          availableBalance: 42750,
          pendingEscrowBalance: 0,
          cashouts: [],
          escrowSettlements: []
        },
        products: []
      }));

    const dynamicIds = new Set(dynamicSellerStores.map(s => s.id));
    const baseStores = vendorStores.filter(v => !dynamicIds.has(v.id));
    return [...dynamicSellerStores, ...baseStores];
  }, [users, vendorStores]);

  const [selectedVendorStore, setSelectedVendorStore] = useState<VendorStore | null>(null);
  const [activeProductFilter, setActiveProductFilter] = useState<string>('all');
  const [selectedTopCategoryId, setSelectedTopCategoryId] = useState<string | null>(null);
  const [productSearchTerm, setProductSearchTerm] = useState('');
  const [selectedWorkerProfile, setSelectedWorkerProfile] = useState<ServiceProvider | null>(null);

  const handleOpenVendorStore = (vendorOrUniqueId: string | VendorStore) => {
    if (typeof vendorOrUniqueId === 'string') {
      const found = activeVendorStores.find(v => v.id === vendorOrUniqueId || v.uniqueId === vendorOrUniqueId) ||
                    vendorStores.find(v => v.id === vendorOrUniqueId || v.uniqueId === vendorOrUniqueId);
      if (found) {
        setSelectedVendorStore(found);
      } else {
        setSelectedVendorStore(activeVendorStores[0] || vendorStores[0]);
      }
    } else {
      setSelectedVendorStore(vendorOrUniqueId);
    }
  };

  // Helper to convert RegisteredProfessional to ServiceProvider for modal
  const openProfessionalPortfolioModal = (pro: RegisteredProfessional) => {
    const providerObj: ServiceProvider = {
      id: String(pro.id || 'pro_' + Date.now()),
      name: pro.name,
      fatherName: pro.fatherName,
      motherName: pro.motherName,
      dateOfBirth: pro.dateOfBirth,
      gender: pro.gender,
      professionalHeadline: pro.professionalHeadline || pro.job,
      categoryBn: pro.job,
      subCategory: pro.job,
      categoryEn: pro.categoryGroup || 'Services',
      rating: pro.rating || 4.9,
      reviewsCount: 18,
      jobsCompleted: pro.completedJobs || 24,
      experienceYears: parseInt(pro.experience || '5', 10) || 5,
      hourlyRate: parseInt(pro.rateAmount || '800', 10) || 800,
      dailyRate: parseInt(pro.rateAmount || '800', 10) || 800,
      rateType: pro.rateType || 'দৈনিক',
      rateAmount: pro.rateAmount || '৮০০',
      district: (pro.district as any) || 'খাগড়াছড়ি',
      upazila: pro.upazila,
      mahalla: pro.area,
      detailedAddress: pro.fullAddress || `${pro.area}, ${pro.upazila}, ${pro.district}`,
      avatar: pro.img || 'https://images.unsplash.com/photo-1540569014015-19a7be504e3a?w=200',
      isAvailable: true,
      distanceKm: 1.5,
      blueTickActive: pro.verified ?? true,
      nidVerified: pro.verified ?? true,
      nidNumber: pro.nid || '19951234567890123',
      nidFrontUrl: pro.nidFrontUrl,
      nidBackUrl: pro.nidBackUrl,
      maskedPhone: '018****' + pro.phone.slice(-4),
      realPhone: pro.phone,
      bioBn: pro.bio || 'দক্ষ ও অভিজ্ঞ প্রফেশনাল হিসেবে সততা ও দায়িত্বশীলতার সাথে অন-ডিমান্ড সেবা প্রদান করি।',
      skills: pro.selectedSkillsList || [pro.job, 'সার্ভিস মেইনটেন্যান্স'],
      selectedSkillsList: pro.selectedSkillsList,
      coverageRadiusKm: pro.serviceRadiusKm || 15,
      coveredAreas: pro.coveredAreas || [pro.area, pro.upazila, pro.district],
      uniqueId: pro.uniqueId || `S-${pro.district ? pro.district.substring(0, 3).toUpperCase() : 'KHG'}-001`,
      portfolioItems: pro.portfolioItems,
      certificatesList: pro.certificatesList,
      educations: pro.educations,
      employments: pro.employments,
      otherExperiences: pro.otherExperiences,
      verificationFeePaid: pro.verificationFeePaid ?? true
    };
    setSelectedWorkerProfile(providerObj);
  };

  // Save changes to localStorage on updates
  useEffect(() => {
    offlineStorage.saveItem(OFFLINE_KEYS.CART, cartItems);
  }, [cartItems]);

  // ফিল্টার স্টেট (সার্ভিস, পণ্য ও ব্লাড ডোনার)
  const [searchMode, setSearchMode] = useState<'services' | 'products' | 'blood'>('services');
  const [selectedServiceCategoryFilter, setSelectedServiceCategoryFilter] = useState<string>('all');
  const [isSourceModalOpen, setIsSourceModalOpen] = useState(false);
  const [isListeningVoice, setIsListeningVoice] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryJob, setSelectedCategoryJob] = useState('');
  const [selectedBloodGroup, setSelectedBloodGroup] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('খাগড়াছড়ি');
  const [selectedUpazila, setSelectedUpazila] = useState('');
  const [selectedArea, setSelectedArea] = useState('');
  const [selectedPoliceCategory, setSelectedPoliceCategory] = useState<string>('all');
  const [selectedAmbulanceType, setSelectedAmbulanceType] = useState<string>('all');
  const [ambulanceIcuOnly, setAmbulanceIcuOnly] = useState<boolean>(false);
  const [ambulanceOxygenOnly, setAmbulanceOxygenOnly] = useState<boolean>(false);
  const [selectedHelplineCategory, setSelectedHelplineCategory] = useState<string>('all');
  const [hasSearched, setHasSearched] = useState(false);
  const [showSearchSuggestions, setShowSearchSuggestions] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // সাজেস্ট বক্সের বাইরে ক্লিক করলে ড্রপডাউন বন্ধ করা
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setShowSearchSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // ১,০০০টি পেশার লাইভ তালিকা (৬টি মূল ক্যাটাগরি অনুযায়ী ম্যাপড)
  const masterProfessionsList = useMemo(() => {
    return ALL_1000_PROFESSIONS_FLAT_LIST;
  }, []);

  // পণ্য ও স্টোর ক্যাটালগ আইটেম তালিকা (অটো-সাজেশনের জন্য)
  const masterProductsList = useMemo(() => {
    const list: { name: string; category?: string; subCategory?: string; categoryEn?: string }[] = [];
    const seen = new Set<string>();

    allProducts.forEach(p => {
      if (p.nameBn && !seen.has(p.nameBn.trim().toLowerCase())) {
        seen.add(p.nameBn.trim().toLowerCase());
        list.push({ name: p.nameBn.trim(), category: p.categoryLabelBn || p.origin });
      }
      if (p.nameEn && !seen.has(p.nameEn.trim().toLowerCase())) {
        seen.add(p.nameEn.trim().toLowerCase());
        list.push({ name: p.nameEn.trim(), category: p.categoryLabelBn || p.origin });
      }
    });

    CATEGORIES_CATALOG.forEach(c => {
      if (c.name && !seen.has(c.name.trim().toLowerCase())) {
        seen.add(c.name.trim().toLowerCase());
        list.push({ name: c.name.trim(), category: 'ক্যাটাগরি' });
      }
    });

    return list;
  }, [allProducts]);

  // সার্চ মোড অনুযায়ী ফিল্টার করা সাজেশন (১,০০০ পেশা ও পণ্যের সম্পূর্ণ ডাইনামিক লাইভ তালিকা)
  const activeSearchSuggestions = useMemo((): { name: string; category?: string; subCategory?: string; categoryEn?: string }[] => {
    const q = searchQuery.trim().toLowerCase();

    if (searchMode === 'services') {
      const list = masterProfessionsList;
      if (!q) {
        // সম্পূর্ণ ১,০০০ পেশার ডাইনামিক তালিকা সরাসরি ড্রপডাউনে
        return list;
      }
      return list.filter(item => 
        item.name.toLowerCase().includes(q) || 
        (item.category && item.category.toLowerCase().includes(q)) ||
        (item.subCategory && item.subCategory.toLowerCase().includes(q)) ||
        (item.categoryEn && item.categoryEn.toLowerCase().includes(q))
      );
    }

    if (searchMode === 'products') {
      const list = masterProductsList;
      if (!q) {
        return list;
      }
      return list.filter(item => 
        item.name.toLowerCase().includes(q) || 
        (item.category && item.category.toLowerCase().includes(q))
      );
    }

    return [];
  }, [searchQuery, searchMode, masterProfessionsList, masterProductsList]);

  // সেলার ইউজারদের নিজস্ব আপলোডকৃত পণ্যসমূহ
  const userSellerProducts = useMemo(() => {
    return allProducts.filter(p => p.id.startsWith('prod_seller_') || p.badge === 'নতুন বিক্রেতা');
  }, [allProducts]);

  // মোট কার্ট আইটেম সংখ্যা
  const totalCartCount = useMemo(() => {
    return cartItems.reduce((sum, item) => sum + item.quantity, 0);
  }, [cartItems]);

  // ফিল্টার করা ৪৮+ প্রোডাক্ট তালিকা (লাইভ অল প্রোডাক্টস থেকে)
  const filteredProducts = useMemo(() => {
    return allProducts.filter(p => {
      // ১. টপ ক্যাটাগরি বার ফিল্টার
      let matchesTopCategory = true;
      if (selectedTopCategoryId) {
        const catObj = ESSENTIAL_15_CATEGORIES.find(c => c.id === selectedTopCategoryId);
        if (catObj) {
          if (catObj.id === 'cat_jhadimadi_specials') {
            matchesTopCategory = true; // জাদি মাডি স্পেশাল সব প্রিমিয়াম আইটেম অন্তর্ভুক্ত
          } else if (catObj.categoryFilterKey === 'SpicesGrains') {
            matchesTopCategory = p.category === 'SpicesGrains' || p.category === 'ShutkiSidol';
          } else {
            matchesTopCategory = p.category === catObj.categoryFilterKey || 
              catObj.keywords.some(kw => 
                (p.nameBn && p.nameBn.toLowerCase().includes(kw.toLowerCase())) || 
                (p.nameEn && p.nameEn.toLowerCase().includes(kw.toLowerCase())) || 
                (p.categoryLabelBn && p.categoryLabelBn.toLowerCase().includes(kw.toLowerCase())) ||
                (p.descriptionBn && p.descriptionBn.toLowerCase().includes(kw.toLowerCase()))
              );
          }
        }
      }

      // ২. সাব-ফিল্টার চিপস (১১টি সুনির্দিষ্ট ক্যাটাগরি)
      let matchesSubFilter = true;
      if (activeProductFilter && activeProductFilter !== 'all') {
        const tab = PRODUCT_FILTER_TABS.find(t => t.key === activeProductFilter);
        if (tab) {
          if (tab.key === 'jhadimadi') {
            matchesSubFilter = p.category === 'Jhadimadi' || 
              p.category === 'SpicesGrains' || 
              p.category === 'ShutkiSidol' || 
              p.category === 'CraftsHoney' || 
              (p.badge && p.badge.includes('ঝাদিমাটি')) ||
              (p.nameBn && (p.nameBn.includes('ঝাদিমাটি') || p.nameBn.includes('পাহাড়ি') || p.nameBn.includes('অর্গানিক')));
          } else {
            matchesSubFilter = p.category === tab.categoryFilterKey || 
              p.category.toLowerCase() === tab.key.toLowerCase() ||
              (p.categoryLabelBn && p.categoryLabelBn.toLowerCase().includes(tab.nameBn.toLowerCase())) ||
              tab.keywords.some(kw => 
                (p.nameBn && p.nameBn.toLowerCase().includes(kw.toLowerCase())) || 
                (p.nameEn && p.nameEn.toLowerCase().includes(kw.toLowerCase())) || 
                (p.categoryLabelBn && p.categoryLabelBn.toLowerCase().includes(kw.toLowerCase())) ||
                (p.descriptionBn && p.descriptionBn.toLowerCase().includes(kw.toLowerCase())) ||
                (p.badge && p.badge.toLowerCase().includes(kw.toLowerCase()))
              );
          }
        } else {
          matchesSubFilter = p.category === activeProductFilter;
        }
      }

      // ৩. সার্চ টার্ম ফিল্টার
      const matchesSearch = !productSearchTerm || 
        p.nameBn.toLowerCase().includes(productSearchTerm.toLowerCase()) || 
        p.nameEn.toLowerCase().includes(productSearchTerm.toLowerCase()) ||
        p.origin.toLowerCase().includes(productSearchTerm.toLowerCase()) ||
        p.categoryLabelBn.toLowerCase().includes(productSearchTerm.toLowerCase());

      return matchesTopCategory && matchesSubFilter && matchesSearch;
    });
  }, [allProducts, selectedTopCategoryId, activeProductFilter, productSearchTerm]);

  // ক্যাটাগরি সিলেকশন হ্যান্ডলার
  const handleSelectTopCategory = (catId: string) => {
    if (selectedTopCategoryId === catId) {
      setSelectedTopCategoryId(null);
      setActiveProductFilter('all');
      setShowToast(lang === 'bn' ? 'সকল পণ্য প্রদর্শিত হচ্ছে' : 'Showing all categories');
    } else {
      setSelectedTopCategoryId(catId);
      const cat = ESSENTIAL_15_CATEGORIES.find(c => c.id === catId);
      if (cat) {
        setShowToast(
          lang === 'bn' 
            ? `'${cat.nameBn}' ক্যাটাগরির পণ্য ও সেবা প্রদর্শিত হচ্ছে` 
            : `Showing '${cat.nameEn}' items`
        );
      }
    }
    setTimeout(() => setShowToast(''), 3000);
  };

  // নতুন পণ্য সেলার ড্যাশবোর্ড থেকে যোগ করা (Add to Live Store Feed)
  const handleAddNewProduct = (newProd: StoreProduct) => {
    contextAddProduct(newProd);
    setShowToast(`'${newProd.nameBn}' সরাসরি হোমপেজে পাবলিশ হয়েছে!`);
    setTimeout(() => setShowToast(''), 4000);
  };

  // পেশাজীবী পোর্টফোলিও আপডেট বা সেভ করা (Save Professional Profile)
  const handleSaveProfessionalProfile = (pro: RegisteredProfessional) => {
    saveProfessionalProfile(pro);
    contextAddProfessional(pro);
    setShowToast(`অভিনন্দন ${pro.name}! আপনার পেশাজীবী পোর্টফোলিও লাইভ হয়েছে।`);
    setTimeout(() => setShowToast(''), 4000);
  };

  // রেজিস্ট্রেশন বাটনে ক্লিক করলে: ৩-ট্যাব বিশিষ্ট নতুন রেজিস্ট্রেশন পেজ প্রদর্শন
  const handleRegisterNavigation = (targetTab?: 'seller' | 'service' | 'permanent' | React.MouseEvent | any) => {
    const validTab: 'seller' | 'service' | 'permanent' = 
      (targetTab === 'seller' || targetTab === 'service' || targetTab === 'permanent') 
        ? targetTab 
        : 'seller';
    setRegistrationInitialTab(validTab);
    setRegistrationIsEditMode(false);
    setPreviousTab(activeTab);
    setActiveTab('registration');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // রোল অনুযায়ী নির্দিষ্ট এডিট ফর্মে নিয়ে যাওয়া
  const handleEditProfileRoleBased = (userToEdit?: any) => {
    const user = userToEdit || currentUser;
    const memberUID = user?.memberUID || user?.uniqueId || '';
    const role = user?.role;

    let targetTab: 'seller' | 'service' | 'permanent' = 'service';
    if (role === 'seller' || (typeof memberUID === 'string' && memberUID.startsWith('JH-S-'))) {
      targetTab = 'seller';
    } else if (role === 'permanent' || (typeof memberUID === 'string' && memberUID.startsWith('JH-M-'))) {
      targetTab = 'permanent';
    } else {
      targetTab = 'service';
    }

    setRegistrationInitialTab(targetTab);
    setRegistrationIsEditMode(true);
    setPreviousTab(activeTab);
    setActiveTab('registration');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // প্রোফাইল ট্যাবে প্রবেশের গেটিং লজিক (Auth-gating): Unauthenticated -> Sign In (Intent: Profile), Authenticated -> Completed Profile View
  const handleProfileNavigation = () => {
    if (!currentUser) {
      if (onOpenAuth) {
        onOpenAuth('signin');
        return;
      }
      setAuthRedirectTarget('profile');
      setPreviousTab(activeTab);
      setShowToast(
        lang === 'bn' 
          ? 'আপনার প্রোফাইল দেখতে অনুগ্রহ করে সাইন ইন করুন।' 
          : 'Please sign in to view your profile dashboard.'
      );
      setActiveTab('signin');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setPreviousTab(activeTab);
      setActiveTab('profile');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // সাইন আপ সফল হওয়া -> রিডাইরেকশন: সাইন আপ শেষে সরাসরি রোল নির্বাচন মডাল প্রদর্শন
  const handleAuthSuccess = (user: UserProfile, isNewSignUp: boolean = false) => {
    login(user, isNewSignUp);
    setShowToast(
      lang === 'bn' 
        ? `স্বাগতম ${user.name}! অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে।` 
        : `Welcome ${user.name}! Account created.`
    );
    setTimeout(() => setShowToast(''), 4000);

    // সাইন আপ সম্পন্ন হওয়ার পর সরাসরি রোল সিলেকশন প্রদর্শন
    if (onOpenRoleSelect) {
      onOpenRoleSelect();
    } else {
      openRoleModal();
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // সাইন ইন সফল হওয়া -> রিডাইরেকশন: সফল সাইন ইন এর সাথে সাথেই রোল সিলেকশন স্ক্রিন রেন্ডার হবে
  const handleSignInSuccess = (user: UserProfile) => {
    login(user, false);
    setShowToast(
      lang === 'bn' 
        ? `স্বাগতম ${user.name}! আপনি সফলভাবে সাইন ইন করেছেন।` 
        : `Welcome ${user.name}! Signed in successfully.`
    );
    setTimeout(() => setShowToast(''), 3500);

    // সাইন ইন করার সাথে সাথে সরাসরি রোল সিলেকশন প্রদর্শন
    if (onOpenRoleSelect) {
      onOpenRoleSelect();
    } else {
      openRoleModal();
    }
    setAuthRedirectTarget('profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // ধাপ ৩: অনবোর্ডিং রোল সাবমিট সম্পন্ন -> সরাসরি সংশ্লিষ্ট ড্যাশবোর্ডে রিডাইরেক্ট
  const handleSelectTrack = (
    track: 'track_a_vendor' | 'track_b_freelancer' | 'customer',
    extraData?: { title?: string; category?: string }
  ) => {
    if (track === 'track_a_vendor') {
      selectRole('seller');
      setActiveTab('track_a_vendor');
      setShowToast(
        lang === 'bn' 
          ? '🎉 অভিনন্দন! আপনার মার্চেন্ট স্টোরফ্রন্ট ড্যাশবোর্ড প্রস্তুত। নতুন পণ্য যোগ করুন!' 
          : 'Merchant Storefront & Dashboard is ready!'
      );
    } else if (track === 'track_b_freelancer') {
      selectRole('professional');
      setActiveTab('track_b_freelancer');
      setShowToast(
        lang === 'bn' 
          ? '🎉 অভিনন্দন! আপনার প্রফেশনাল পোর্টফোলিও বিল্ডার প্রস্তুত।' 
          : 'Professional Profile Builder is ready!'
      );
    } else {
      selectRole('buyer');
      setActiveTab('profile');
      setShowToast(
        lang === 'bn' 
          ? '🎉 স্বাগতম! আপনার সাধারণ কাস্টমার ড্যাশবোর্ড প্রস্তুত।' 
          : 'Customer Dashboard is ready!'
      );
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => setShowToast(''), 4500);
  };

  // রোল নির্বাচন (ধাপ ২ ড্রপডাউন মোডাল থেকে সাবমিট) -> সংশ্লিষ্ট পাথওয়েতে রিডাইরেক্ট
  const handleSelectRole = (role: 'seller' | 'professional') => {
    selectRole(role);
    closeRoleModal();
    if (role === 'seller') {
      // মার্চেন্ট সিলেক্ট করলে সরাসরি মার্চেন্ট প্রোফাইল/ড্যাশবোর্ডে রিডাইরেক্ট
      setActiveTab('track_a_vendor');
      setShowToast(lang === 'bn' ? 'মার্চেন্ট ড্যাশবোর্ড প্রস্তুত — পণ্য পরিচালনা করুন!' : 'Merchant dashboard ready!');
    } else {
      // সার্ভিস সিলেক্ট করলে সরাসরি সার্ভিস প্রোভাইডার রেজিস্ট্রেশন ফর্ম প্রদর্শন
      setActiveTab('registration_flow');
      setShowToast(lang === 'bn' ? 'সেবাদাতা রেজিস্ট্রেশন ফর্ম পূরণ করুন!' : 'Please complete provider registration form!');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => setShowToast(''), 3500);
  };

  // লগআউট
  const handleLogout = () => {
    logout();
    setActiveTab('home');
    setShowToast('সফলভাবে লগআউট করা হয়েছে।');
    setTimeout(() => setShowToast(''), 3000);
  };

  // কার্ট ফাংশনালিটি
  const handleAddToCart = (product: StoreProduct, qty: number = 1) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.product.id === product.id 
            ? { ...item, quantity: item.quantity + qty }
            : item
        );
      } else {
        return [...prev, { product, quantity: qty }];
      }
    });

    setShowToast(`'${product.nameBn}' কার্টে যুক্ত হয়েছে!`);
    setTimeout(() => setShowToast(''), 3000);
  };

  const handleUpdateCartQty = (productId: string, delta: number) => {
    setCartItems(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : null;
        }
        return item;
      }).filter(Boolean) as CartItemType[];
    });
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.product.id !== productId));
    setShowToast('পণ্যটি কার্ট থেকে সরানো হয়েছে।');
    setTimeout(() => setShowToast(''), 2500);
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // ডাইনামিক জেলা ও থানা ম্যাপিং (DataContext + Admin CMS থেকে রিয়েলটাইম সিঙ্ক)
  const dynamicDistricts = useMemo(() => {
    const map: Record<string, string[]> = { ...ALL_BANGLADESH_DISTRICTS };
    locations.forEach(loc => {
      if (loc.isActive && loc.districtBn && loc.upazilasBn && loc.upazilasBn.length > 0) {
        map[loc.districtBn] = loc.upazilasBn;
      }
    });
    return map;
  }, [locations]);

  // জেলা পরিবর্তনের সাথে থানা/উপজেলা লোড (ডাইনামিক)
  const availableUpazilas = useMemo(() => {
    return dynamicDistricts[selectedDistrict] || ALL_BANGLADESH_DISTRICTS[selectedDistrict] || [];
  }, [dynamicDistricts, selectedDistrict]);

  // ফিল্টার লজিক (পেশাজীবী - কেওয়াইসি ও অ্যাডমিন মডারেশন স্ট্যাটাস সিঙ্ক)
  const searchResults = useMemo(() => {
    return professionals.filter(p => {
      // Check if banned or rejected by Admin in KYC/User Moderation
      const matchingUser = users.find(u => String(u.id) === String(p.id) || (u.phone && u.phone === p.phone));
      if (matchingUser && matchingUser.status === 'Rejected') {
        return false;
      }

      const q = searchQuery.toLowerCase().trim();
      const matchesQuery = !q || 
        (p.job && p.job.toLowerCase().includes(q)) || 
        (p.name && p.name.toLowerCase().includes(q)) ||
        (p.phone && p.phone.includes(q)) ||
        (p.uniqueId && p.uniqueId.toLowerCase().includes(q)) ||
        (p.professionalHeadline && p.professionalHeadline.toLowerCase().includes(q)) ||
        (p.categoryGroup && p.categoryGroup.toLowerCase().includes(q)) ||
        (p.bio && p.bio.toLowerCase().includes(q)) ||
        (p.area && p.area.toLowerCase().includes(q)) ||
        (Array.isArray(p.skills) && p.skills.some(s => s.toLowerCase().includes(q))) ||
        (typeof p.skills === 'string' && p.skills.toLowerCase().includes(q)) ||
        (Array.isArray(p.selectedSkillsList) && p.selectedSkillsList.some(s => s.toLowerCase().includes(q)));
      const matchesCategory = !selectedCategoryJob || (p.job && p.job.includes(selectedCategoryJob));
      const matchesDistrict = !selectedDistrict || p.district === selectedDistrict;
      const matchesUpazila = !selectedUpazila || p.upazila === selectedUpazila;
      const matchesArea = !selectedArea || (p.area && p.area.toLowerCase().includes(selectedArea.toLowerCase()));
      return matchesQuery && matchesCategory && matchesDistrict && matchesUpazila && matchesArea;
    });
  }, [professionals, users, searchQuery, selectedCategoryJob, selectedDistrict, selectedUpazila, selectedArea]);

  // ফিল্টার লজিক (পণ্য সার্চ)
  const productSearchResults = useMemo(() => {
    return allProducts.filter(p => {
      const q = searchQuery.toLowerCase().trim();
      const matchesQuery = !q || 
        p.nameBn.toLowerCase().includes(q) || 
        (p.nameEn && p.nameEn.toLowerCase().includes(q)) ||
        (p.descriptionBn && p.descriptionBn.toLowerCase().includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q)) ||
        (p.categoryLabelBn && p.categoryLabelBn.toLowerCase().includes(q)) ||
        (p.origin && p.origin.toLowerCase().includes(q));
      const matchesCategory = !selectedCategoryJob || 
        p.category === selectedCategoryJob || 
        p.categoryLabelBn === selectedCategoryJob ||
        (p.nameBn && p.nameBn.includes(selectedCategoryJob));
      const matchesDistrict = !selectedDistrict || (p.origin && p.origin.includes(selectedDistrict));
      const matchesUpazila = !selectedUpazila || (p.origin && p.origin.includes(selectedUpazila));
      const matchesArea = !selectedArea || (p.origin && p.origin.includes(selectedArea));
      return matchesQuery && matchesCategory && matchesDistrict && matchesUpazila && matchesArea;
    });
  }, [allProducts, searchQuery, selectedCategoryJob, selectedDistrict, selectedUpazila, selectedArea]);

  // ফিল্টার লজিক (ব্লাড ডোনার সার্চ - রক্তদাতা CMS + নিবন্ধিত ইউজার/প্রফেশনালদের মধ্য থেকে ১০০% লাইভ)
  const bloodSearchResults = useMemo(() => {
    // ১. রক্তদাতা CMS থেকে ভেরিফাইড ও উপলব্ধ রক্তদাতারা
    const cmsDonors = bloodDonors
      .filter(d => d.isAvailable)
      .map(d => ({
        id: d.id,
        name: d.name,
        job: `রক্তদান করেছেন: ${d.totalDonations} বার • বয়স: ${d.age || 25} বছর`,
        district: d.district,
        upazila: d.upazila,
        area: d.area,
        phone: d.phone,
        img: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
        experience: `${d.totalDonations} বার রক্তদান`,
        rateType: '১০০% ফ্রি',
        rateAmount: '০',
        rating: 5.0,
        verified: d.verified,
        isBloodDonor: true,
        bloodGroup: d.bloodGroup,
        lastDonationDate: d.lastDonationDate
      }));

    // ২. নিবন্ধিত প্রফেশনাল ও ইউজার যারা রক্তদাতা
    const proDonors = professionals.filter(p => {
      return p.isBloodDonor || Boolean(p.bloodGroup) || (p.job && p.job.includes('রক্তদাতা'));
    });

    // ৩. নিবন্ধিত গ্রাহক ও রক্তদাতা ইউজার (Customer Blood Donors)
    const customerDonors = (users || [])
      .filter((u: any) => Boolean(u.bloodGroup))
      .map((u: any) => ({
        id: u.id || `user_${u.phone}`,
        name: u.fullName || u.name || 'নিবন্ধিত রক্তদাতা',
        job: 'নিবন্ধিত রক্তদাতা (কমিউনিটি নেটওয়ার্ক)',
        district: u.district || u.location?.district || 'খাগড়াছড়ি',
        upazila: u.upazila || u.location?.upazila || 'সদর',
        area: u.area || u.location?.upazila || '',
        phone: u.phone,
        img: u.avatar || u.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
        experience: 'স্বেচ্ছাসেবী রক্তদাতা',
        rateType: '১০০% ফ্রি',
        rateAmount: '০',
        rating: 5.0,
        verified: true,
        isBloodDonor: true,
        bloodGroup: u.bloodGroup,
        lastDonationDate: u.lastDonationDate || 'উপলব্ধ রক্তদাতা'
      }));

    const combined = [...cmsDonors, ...proDonors, ...customerDonors];

    return combined.filter(p => {
      const matchesBlood = !selectedBloodGroup || p.bloodGroup === selectedBloodGroup;
      const matchesQuery = !searchQuery || 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        (p.phone && p.phone.includes(searchQuery)) ||
        (p.bloodGroup && p.bloodGroup.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (p.job && p.job.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesDistrict = !selectedDistrict || p.district === selectedDistrict;
      const matchesUpazila = !selectedUpazila || p.upazila === selectedUpazila;

      return matchesBlood && matchesQuery && matchesDistrict && matchesUpazila;
    });
  }, [bloodDonors, professionals, users, selectedBloodGroup, searchQuery, selectedDistrict, selectedUpazila]);

  // ফিল্টার লজিক (সোর্স ও পুলিশ স্টেশন ডিরেক্টরি)
  const sourceSearchResults = useMemo(() => {
    return POLICE_STATIONS_DIRECTORY.filter(p => {
      const matchesQuery = !searchQuery ||
        p.officeNameBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.officeNameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.designationBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.mobileNumber.includes(searchQuery) ||
        (p.phoneLandline && p.phoneLandline.includes(searchQuery)) ||
        p.addressBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.district.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.upazila.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDistrict = !selectedDistrict || p.district === selectedDistrict;
      const matchesUpazila = !selectedUpazila || p.upazila === selectedUpazila;
      const matchesArea = !selectedArea || p.addressBn.toLowerCase().includes(selectedArea.toLowerCase());
      const matchesCategory = selectedPoliceCategory === 'all' || p.category === selectedPoliceCategory;

      return matchesQuery && matchesDistrict && matchesUpazila && matchesArea && matchesCategory;
    });
  }, [searchQuery, selectedDistrict, selectedUpazila, selectedArea, selectedPoliceCategory]);

  // ফিল্টার লজিক (জাতীয় জরুরি হটলাইনসমূহ)
  const helplineSearchResults = useMemo(() => {
    return NATIONAL_HELPLINES.filter(h => {
      const matchesQuery = !searchQuery ||
        h.nameBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        h.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        h.number.includes(searchQuery) ||
        (h.shortCode && h.shortCode.includes(searchQuery)) ||
        h.descriptionBn.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory = selectedHelplineCategory === 'all' || h.category === selectedHelplineCategory;
      return matchesQuery && matchesCategory;
    });
  }, [searchQuery, selectedHelplineCategory]);

  // ফিল্টার লজিক (অ্যাম্বুলেন্স সার্ভিসেস ডিরেক্টরি)
  const ambulanceSearchResults = useMemo(() => {
    return AMBULANCE_SERVICES_DIRECTORY.filter(a => {
      const matchesQuery = !searchQuery ||
        a.serviceNameBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.serviceNameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (a.driverNameBn && a.driverNameBn.toLowerCase().includes(searchQuery.toLowerCase())) ||
        a.contactNumber.includes(searchQuery) ||
        (a.alternateNumber && a.alternateNumber.includes(searchQuery)) ||
        a.baseLocationBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.typeLabelBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.district.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.upazila.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDistrict = !selectedDistrict || a.district === selectedDistrict;
      const matchesUpazila = !selectedUpazila || a.upazila === selectedUpazila;
      const matchesArea = !selectedArea || a.baseLocationBn.toLowerCase().includes(selectedArea.toLowerCase());
      const matchesType = selectedAmbulanceType === 'all' || a.ambulanceType === selectedAmbulanceType;
      const matchesIcu = !ambulanceIcuOnly || a.icuSupport;
      const matchesOxygen = !ambulanceOxygenOnly || a.oxygenAvailable;

      return matchesQuery && matchesDistrict && matchesUpazila && matchesArea && matchesType && matchesIcu && matchesOxygen;
    });
  }, [searchQuery, selectedDistrict, selectedUpazila, selectedArea, selectedAmbulanceType, ambulanceIcuOnly, ambulanceOxygenOnly]);

  // ব্যানার স্লাইডার হ্যান্ডলার
  const activeBanners = useMemo(() => {
    return banners.filter(b => b.isActive);
  }, [banners]);

  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);

  // অটো-ক্যারোসেল টাইমার
  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentBannerIndex(prev => (prev + 1) % activeBanners.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [activeBanners.length]);

  const handleBannerClick = (targetLink?: string) => {
    if (!targetLink) return;
    if (targetLink === 'registration_flow' || targetLink === 'track_a_vendor' || targetLink === 'track_b_freelancer') {
      if (!currentUser) {
        setShowToast(lang === 'bn' ? 'রেজিস্ট্রেশন বা সেবা প্রদানে যুক্ত হতে প্রথমে সাইন আপ অথবা সাইন ইন করুন।' : 'Please sign up or sign in first.');
        setPreviousTab(activeTab);
        setActiveTab('signup');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
    }
    if (targetLink === 'auto_directory' || targetLink === 'track_a_vendor' || targetLink === 'track_b_freelancer' || targetLink === 'services' || targetLink === 'search' || targetLink === 'profile' || targetLink === 'registration_flow' || targetLink === 'super_admin') {
      setPreviousTab(activeTab);
      setActiveTab(targetLink as any);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (targetLink === 'blood') {
      setSearchMode('blood');
      setActiveTab('search');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (targetLink === 'source' || targetLink === 'ambulance') {
      setIsSourceModalOpen(true);
    }
  };

  // AI Voice Search & Smart Bangla Parsing Handler
  const handleTriggerVoiceSearch = () => {
    const recognition = startBanglaVoiceRecognition({
      onStart: () => {
        setIsListeningVoice(true);
        setShowToast('🎙️ শুনছি... স্পষ্ট করে বাংলায় বলুন (যেমন: খাগড়াছড়ি সদরে ও পজিটিভ রক্ত চাই / জরুরি পুলিশ ৯৯৯ / অ্যাম্বুলেন্স)');
      },
      onResult: (transcript, parsed: ParsedSearchResult) => {
        setIsListeningVoice(false);
        setSearchQuery(parsed.cleanedKeyword);
        setProductSearchTerm(parsed.cleanedKeyword);

        // ১. অটো সিলেক্ট সার্চ টাইপ (সেবা / পণ্য / রক্তদাতা)
        if (parsed.searchType === 'blood') {
          setSearchMode('blood');
          if (parsed.bloodGroup) {
            setSelectedBloodGroup(parsed.bloodGroup);
          }
        } else if (parsed.searchType === 'product') {
          setSearchMode('products');
          if (parsed.category) {
            setSelectedCategoryJob(parsed.category);
          }
        } else if (parsed.searchType === 'ambulance' || parsed.searchType === 'source' || parsed.searchType === 'emergency') {
          setIsSourceModalOpen(true);
        } else {
          setSearchMode('services');
          if (parsed.category) {
            setSelectedCategoryJob(parsed.category);
          }
        }

        // ২. অটো সিলেক্ট জেলা ও উপজেলা
        if (parsed.district) {
          setSelectedDistrict(parsed.district);
        }
        if (parsed.upazila) {
          setSelectedUpazila(parsed.upazila);
        }

        // ৩. সার্চ ট্রিগার ও ট্যাব সুইচ
        setHasSearched(true);
        setActiveTab('search');

        // ৪. তথ্যবহুল নোটিফিকেশন প্রদর্শন
        setShowToast(`🎙️ "${transcript}" ➔ ${parsed.summaryBn}`);
        setTimeout(() => setShowToast(''), 5000);
      },
      onError: (errMsg) => {
        setIsListeningVoice(false);
        setShowToast(`ভয়েস ত্রুটি: ${errMsg}`);
        setTimeout(() => setShowToast(''), 3500);
      },
      onEnd: () => {
        setIsListeningVoice(false);
      }
    });

    if (!recognition) {
      setShowToast('ভয়েস সার্চ আপনার ব্রাউজারে সাপোর্ট করছে না। অনুগ্রহ করে লিখে সার্চ করুন।');
      setTimeout(() => setShowToast(''), 3500);
    }
  };

  const handleRegisterSuccess = (newPro: RegisteredProfessional) => {
    contextAddProfessional(newPro);
    setShowToast(`অভিনন্দন ${newPro.name}! আপনার রেজিস্ট্রেশন সফল হয়েছে।`);
    setTimeout(() => setShowToast(''), 4000);
  };

  const handleViewInSearch = (dist: string, upa: string, jobTitle: string) => {
    setSelectedDistrict(dist);
    setSelectedUpazila(upa);
    setSelectedCategoryJob(jobTitle);
    setHasSearched(true);
    setActiveTab('search');
  };

  return (
    <div className="flex flex-col h-full max-h-full overflow-hidden bg-[#009f4d] relative font-sans text-gray-900">
      
      {/* নোটিফিকেশন টোস্ট */}
      {showToast && (
        <div className="absolute top-14 left-4 right-4 z-[55] bg-emerald-700 text-white text-[9.5px] font-bold px-3 py-2 rounded-xl shadow-lg flex items-center justify-between animate-bounce">
          <div className="flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-amber-300 shrink-0" />
            <span>{showToast}</span>
          </div>
          <button onClick={() => setShowToast('')} className="text-white/80 hover:text-white text-xs">✕</button>
        </div>
      )}

      {/* ১. শীর্ষ হেডার এরিয়া লেআউট (Edge-to-Edge Status Bar & Compact Sleek Header Layout in Vibrant Green #009f4d) */}
      <header 
        className="sticky top-0 left-0 right-0 z-50 shrink-0 w-full bg-[#009f4d] text-white shadow-xs border-b border-[#008c43] m-0"
        style={{
          backgroundColor: '#009f4d',
          paddingTop: 'env(safe-area-inset-top, 0px)',
          paddingLeft: 'env(safe-area-inset-left, 0px)',
          paddingRight: 'env(safe-area-inset-right, 0px)',
        }}
      >
        {/* Top Navigation Bar Content - sleek, compact, and visually attractive (40-42px height) */}
        <div className="w-full px-2.5 sm:px-3.5 h-10 sm:h-10.5 flex items-center justify-between gap-1.5 sm:gap-2">
          {/* Left side: Brand / Logo area ("ঝাদিমাদি ডটকম") - Balanced & Centered */}
          <div 
            onClick={() => {
              setActiveTab('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-1.5 cursor-pointer select-none group shrink-0 min-w-0"
            title="Jhadimadi.com হোমপেজ"
          >
            {/* Runner Icon Badge in crisp white rounded frame */}
            <div className="relative p-0.5 rounded-md bg-white shadow-xs border border-white/70 group-hover:scale-105 transition-transform shrink-0 flex items-center justify-center w-6.5 h-6.5 sm:w-7 sm:h-7">
              <img
                src="https://i.ibb.co.com/sppWZhc9/logo33.png"
                alt="Jhadimadi Runner"
                className="w-4.5 h-4.5 sm:w-5 sm:h-5 object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = "/runner-logo.png";
                }}
              />
            </div>
            <div className="flex flex-col justify-center min-w-0">
              <span className="text-[7.5px] sm:text-[8px] font-bold text-amber-200 tracking-tight leading-none block">
                ঝাদিমাদি ডটকম
              </span>
              <div className="flex items-center gap-0.5 leading-none mt-0.5">
                <span className="text-[10px] sm:text-[11px] font-black tracking-wide text-white">JHADIMADI</span>
                <span className="text-[8px] sm:text-[8.5px] font-black text-amber-300">.COM</span>
              </div>
            </div>
          </div>

          {/* Right side controls: Language Switcher + Sign In / Profile + Cart */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            {/* Language Switcher: বাংলা / English option */}
            <button
              type="button"
              onClick={() => {
                const nextLang = lang === 'bn' ? 'en' : 'bn';
                setLang(nextLang);
                setShowToast(nextLang === 'bn' ? 'ভাষা বাংলায় পরিবর্তিত হয়েছে' : 'Language switched to English');
                setTimeout(() => setShowToast(''), 2000);
              }}
              className="h-6.5 px-1.5 sm:px-2 rounded-lg bg-black/25 hover:bg-black/35 active:scale-95 text-white transition flex items-center gap-1 border border-white/20 shadow-2xs cursor-pointer shrink-0"
              title={lang === 'bn' ? 'Switch to English' : 'বাংলা ভাষায় পরিবর্তন করুন'}
              aria-label={lang === 'bn' ? 'Switch to English' : 'বাংলা ভাষায় পরিবর্তন করুন'}
              id="btn-header-lang-toggle"
            >
              <Languages className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-amber-300 shrink-0" />
              <span className="text-[8px] sm:text-[8.5px] font-bold tracking-tight whitespace-nowrap">
                {lang === 'bn' ? 'English' : 'বাংলা'}
              </span>
            </button>

            {/* Sign Up / Sign In or User Profile */}
            {currentUser ? (
              <button
                type="button"
                onClick={() => {
                  setPreviousTab(activeTab);
                  setActiveTab('profile');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                id="btn-header-my-account"
                className="h-6.5 flex items-center gap-1 sm:gap-1.5 bg-white/20 hover:bg-white/30 text-white px-1.5 sm:px-2 rounded-lg text-[8px] sm:text-[9px] font-bold transition-all cursor-pointer border border-white/25 active:scale-95 shadow-2xs shrink-0"
                title={lang === 'bn' ? 'আমার প্রোফাইল' : 'My Profile'}
              >
                <img 
                  src={currentUser.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100"} 
                  alt="user avatar" 
                  className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full object-cover ring-1 ring-amber-300 shrink-0"
                />
                <span className="max-w-[40px] sm:max-w-[54px] truncate whitespace-nowrap">
                  {currentUser.name ? currentUser.name.split(' ')[0] : (lang === 'bn' ? 'প্রোফাইল' : 'Profile')}
                </span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  if (onOpenAuth) {
                    onOpenAuth('signin');
                    return;
                  }
                  setAuthRedirectTarget('profile');
                  setPreviousTab(activeTab);
                  setActiveTab('signin');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                id="btn-header-signin"
                className="h-6.5 bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 px-2 sm:px-2.5 rounded-lg text-[8px] sm:text-[9px] font-black shadow-2xs flex items-center gap-1 cursor-pointer transition shrink-0"
                title={lang === 'bn' ? 'সাইন ইন করুন' : 'Sign In'}
              >
                <User className="w-3 h-3 text-slate-950 shrink-0" />
                <span className="whitespace-nowrap">{lang === 'bn' ? 'সাইন ইন' : 'Sign In'}</span>
              </button>
            )}

            {/* Market / Cart Option */}
            <button 
              type="button"
              onClick={() => setIsCartModalOpen(true)}
              className="h-6.5 w-6.5 rounded-lg bg-white/15 hover:bg-white/25 active:scale-90 text-white relative transition flex items-center justify-center shadow-2xs border border-white/20 cursor-pointer shrink-0"
              title={lang === 'bn' ? 'মার্কেট কার্ট' : 'Market Cart'}
              aria-label={lang === 'bn' ? 'মার্কেট কার্ট' : 'Market Cart'}
              id="btn-header-cart"
            >
              <ShoppingCart className="w-3.5 h-3.5 text-white" />
              {totalCartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[7px] font-black w-3.5 h-3.5 rounded-full flex items-center justify-center shadow-xs border border-white animate-in zoom-in leading-none">
                  {totalCartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* নেটিভ অ্যাপ-স্টাইল অফলাইন ব্যানার ও স্ট্যাটাস বার */}
      <OfflineBanner
        isOnline={isOnline}
        wasOffline={wasOffline}
        isChecking={isChecking}
        onRetry={checkConnection}
        cachedCount={allProducts.length}
      />


      {/* ২. স্ক্রোলযোগ্য মূল কন্টেন্ট */}
      <main className="flex-1 overflow-y-auto scroll-smooth flex flex-col justify-between min-h-0 relative pointer-events-auto bg-[#FAF8F5]">

        {/* ================= (ক) হোম পেজ ================= */}
        {activeTab === 'home' && (
          <div className="p-3 space-y-3.5 pb-6">
            
            {/* Integrated AI Voice & Product Search Bar */}
            <div className="bg-white p-1.5 pl-3 rounded-2xl shadow-xs border border-gray-200 focus-within:border-[#0A6A32] focus-within:ring-2 focus-within:ring-[#0A6A32]/20 transition-all flex items-center gap-1.5">
              <input
                type="text"
                placeholder={lang === 'bn' ? 'পণ্য বা সেবা খুঁজুন অথবা এআই-কে মুখে বলুন...' : 'Search products, services or ask AI...'}
                value={productSearchTerm}
                onChange={(e) => setProductSearchTerm(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && productSearchTerm) {
                    setShowToast(`'${productSearchTerm}' এর ফলাফল ফিল্টার করা হয়েছে।`);
                    setTimeout(() => setShowToast(''), 2500);
                  }
                }}
                className="w-full text-xs font-medium text-gray-800 focus:outline-none placeholder:text-gray-400 bg-transparent"
              />
              
              {productSearchTerm && (
                <button 
                  onClick={() => setProductSearchTerm('')}
                  className="text-gray-400 hover:text-gray-600 text-xs px-1 cursor-pointer transition-colors"
                  title="মুছে ফেলুন"
                >
                  ✕
                </button>
              )}

              {/* Integrated AI Voice Assistant & Help */}
              <button 
                type="button"
                onClick={handleTriggerVoiceSearch}
                id="btn-search-ai-voice"
                title={lang === 'bn' ? 'এআই ভয়েস হেল্প ও সার্চ (মুখে বলুন)' : 'AI Voice Help & Search (Speak)'}
                className={`px-2 py-1.5 rounded-xl text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer select-none active:scale-95 shrink-0 ${
                  isListeningVoice 
                    ? 'bg-red-500 text-white animate-pulse shadow-xs ring-2 ring-red-300' 
                    : 'bg-emerald-50 text-[#0A6A32] hover:bg-emerald-100 border border-emerald-200/80 shadow-2xs'
                }`}
              >
                {isListeningVoice ? (
                  <>
                    <Mic className="w-3.5 h-3.5 animate-bounce" />
                    <span className="text-[9px] font-bold">{lang === 'bn' ? 'শুনছি...' : 'Listening...'}</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-3.5 h-3.5 text-[#0A6A32]" />
                    <Sparkles className="w-2.5 h-2.5 text-amber-500 fill-amber-400" />
                    <span className="text-[9px] font-black text-[#0A6A32]">AI Help</span>
                  </>
                )}
              </button>

              {/* Primary Search Button */}
              <button 
                onClick={() => {
                  if (productSearchTerm) {
                    setShowToast(`'${productSearchTerm}' এর ফলাফল ফিল্টার করা হয়েছে।`);
                    setTimeout(() => setShowToast(''), 2500);
                  }
                }} 
                className="bg-[#0A6A32] hover:bg-emerald-800 active:scale-95 text-white p-2 rounded-xl shrink-0 transition-transform shadow-2xs cursor-pointer flex items-center justify-center"
                title={lang === 'bn' ? 'অনুসন্ধান করুন' : 'Search'}
              >
                <Search className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* ১.৫ লাইভ ডায়নামিক হিরো প্রমোশনাল ব্যানার ক্যারোসেল (Admin Banner CMS থেকে রিয়েলটাইম সিঙ্ক) */}
            {activeBanners.length > 0 && (
              <div className="relative w-full rounded-2xl overflow-hidden shadow-sm border border-emerald-100 bg-slate-900 group">
                <div 
                  onClick={() => handleBannerClick(activeBanners[currentBannerIndex]?.targetLink)}
                  className="relative w-full h-32 sm:h-36 cursor-pointer overflow-hidden"
                >
                  <img 
                    src={activeBanners[currentBannerIndex]?.imageUrl} 
                    alt={activeBanners[currentBannerIndex]?.title} 
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  />
                  {/* Subtle dark gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent flex flex-col justify-end p-3 text-white">
                    <div className="space-y-1">
                      {activeBanners[currentBannerIndex]?.tag && (
                        <span className="inline-flex items-center gap-1 bg-amber-400 text-slate-950 text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                          <Sparkles className="w-2.5 h-2.5 fill-slate-950" />
                          {activeBanners[currentBannerIndex]?.tag}
                        </span>
                      )}
                      <h3 className="text-xs sm:text-sm font-black text-white leading-tight drop-shadow-sm">
                        {activeBanners[currentBannerIndex]?.title}
                      </h3>
                      {activeBanners[currentBannerIndex]?.subtitle && (
                        <p className="text-[9px] text-emerald-200 font-medium line-clamp-1">
                          {activeBanners[currentBannerIndex]?.subtitle}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Single-click Action CTA Badge */}
                  <div className="absolute top-2.5 right-2.5 bg-white/20 hover:bg-white/30 backdrop-blur-xs text-white border border-white/30 text-[8px] font-bold px-2 py-1 rounded-xl flex items-center gap-1 shadow-sm">
                    <span>{lang === 'bn' ? 'দেখুন' : 'Explore'}</span>
                    <ChevronRight className="w-3 h-3" />
                  </div>
                </div>

                {/* Slider Indicators & Navigation Arrows */}
                {activeBanners.length > 1 && (
                  <>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentBannerIndex(prev => (prev - 1 + activeBanners.length) % activeBanners.length);
                      }}
                      className="absolute left-1.5 top-1/2 -translate-y-1/2 w-6 h-6 bg-black/40 hover:bg-black/70 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer z-10"
                      title="পূর্ববর্তী ব্যানার"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentBannerIndex(prev => (prev + 1) % activeBanners.length);
                      }}
                      className="absolute right-1.5 top-1/2 -translate-y-1/2 w-6 h-6 bg-black/40 hover:bg-black/70 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer z-10"
                      title="পরবর্তী ব্যানার"
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                    {/* Navigation Dots */}
                    <div className="absolute bottom-1.5 right-3 flex items-center gap-1 z-10">
                      {activeBanners.map((b, idx) => (
                        <button
                          key={b.id || idx}
                          onClick={(e) => {
                            e.stopPropagation();
                            setCurrentBannerIndex(idx);
                          }}
                          className={`h-1.5 rounded-full transition-all cursor-pointer ${
                            idx === currentBannerIndex 
                              ? 'w-4 bg-amber-400' 
                              : 'w-1.5 bg-white/50 hover:bg-white'
                          }`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}

            {/* ২. স্লীক ও অনুভূমিক ১৫টি ক্যাটাগরি বার (Horizontal Scrollable 15 Essential Categories with Touch & Arrow Navigation) */}
            <div className="space-y-1.5 pt-0.5" id="essential-top-categories">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <h3 className="text-[10px] font-black text-gray-800 uppercase tracking-wide flex items-center gap-1">
                    <Sparkle className="w-3 h-3 text-amber-500 fill-amber-500" />
                    {lang === 'bn' ? 'টপ ক্যাটাগরিসমূহ (১৫টি)' : 'Top Categories (15)'}
                  </h3>
                  {/* Subtle navigation arrows */}
                  <div className="flex items-center gap-0.5 ml-1">
                    <button
                      onClick={() => scrollCategories('left')}
                      disabled={!canScrollLeft}
                      className={`p-0.5 rounded-md border text-[8px] transition-all ${
                        canScrollLeft
                          ? 'bg-white hover:bg-emerald-50 border-gray-300 text-gray-700 shadow-2xs cursor-pointer active:scale-90'
                          : 'bg-gray-100 border-gray-200 text-gray-300 opacity-40 cursor-not-allowed'
                      }`}
                      title="বামে স্ক্রোল করুন"
                    >
                      <ChevronLeft className="w-2.5 h-2.5" />
                    </button>
                    <button
                      onClick={() => scrollCategories('right')}
                      disabled={!canScrollRight}
                      className={`p-0.5 rounded-md border text-[8px] transition-all ${
                        canScrollRight
                          ? 'bg-white hover:bg-emerald-50 border-gray-300 text-gray-700 shadow-2xs cursor-pointer active:scale-90'
                          : 'bg-gray-100 border-gray-200 text-gray-300 opacity-40 cursor-not-allowed'
                      }`}
                      title="ডানে স্ক্রোল করুন"
                    >
                      <ChevronRight className="w-2.5 h-2.5" />
                    </button>
                  </div>
                </div>

                {selectedTopCategoryId ? (
                  <button 
                    onClick={() => {
                      setSelectedTopCategoryId(null);
                      setActiveProductFilter('all');
                      setShowToast(lang === 'bn' ? 'সকল পণ্য প্রদর্শিত হচ্ছে' : 'Showing all products');
                    }}
                    className="text-[8px] font-bold text-red-600 hover:underline flex items-center gap-0.5 cursor-pointer"
                  >
                    <X className="w-2.5 h-2.5" />
                    {lang === 'bn' ? 'ফিল্টার রিসেট' : 'Reset Filter'}
                  </button>
                ) : (
                  <button 
                    onClick={() => setActiveTab('services')}
                    className="text-[8px] font-bold text-[#2EAA26] hover:underline cursor-pointer"
                  >
                    {lang === 'bn' ? 'সকল সেবা ➔' : 'All Services ➔'}
                  </button>
                )}
              </div>

              {/* অনুভূমিক স্ক্রোলেবল ক্যাটাগরি বার with smooth drag/touch & indicator overlays */}
              <div className="relative group">
                {/* Floating Left Arrow Indicator */}
                {canScrollLeft && (
                  <button
                    onClick={() => scrollCategories('left')}
                    className="absolute -left-1 top-1/2 -translate-y-1/2 z-20 w-6 h-6 bg-white/95 backdrop-blur-xs border border-gray-200 text-gray-700 rounded-full shadow-md flex items-center justify-center hover:bg-emerald-50 hover:text-[#2EAA26] active:scale-90 transition-all cursor-pointer"
                    title="বামে দেখুন"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* Categories container */}
                <div 
                  ref={categoryScrollRef}
                  onScroll={checkCategoryScroll}
                  className="category-scroll-container flex items-center gap-2.5 flex-nowrap scroll-smooth py-1 px-1 select-none"
                  style={{ touchAction: 'pan-x', WebkitOverflowScrolling: 'touch' }}
                >
                  {ESSENTIAL_15_CATEGORIES.map((cat) => {
                    const isSelected = selectedTopCategoryId === cat.id;
                    const label = lang === 'bn' ? cat.nameBn : cat.nameEn;
                    
                    return (
                      <button
                        key={cat.id}
                        id={`top-cat-${cat.id}`}
                        onClick={() => handleSelectTopCategory(cat.id)}
                        className={`group flex flex-col items-center shrink-0 transition-all duration-200 active:scale-90 focus:outline-hidden cursor-pointer ${
                          isSelected ? 'scale-105' : 'hover:scale-102'
                        }`}
                        title={label}
                      >
                        {/* Compact Rounded / Circular Badge with Vector Icon */}
                        <div
                          className={`w-12 h-12 rounded-2xl flex items-center justify-center border shadow-xs transition-all duration-200 ${
                            isSelected
                              ? `${cat.activeBg} ${cat.activeRing} scale-105 ring-offset-1`
                              : `${cat.badgeBg} ${cat.badgeBorder} ${cat.iconColor}`
                          }`}
                        >
                          {cat.icon}
                        </div>

                        {/* Concise Category Label */}
                        <span
                          className={`text-[8.5px] font-bold mt-1 max-w-[66px] text-center leading-tight truncate ${
                            isSelected ? 'text-[#2EAA26] font-black' : 'text-gray-700'
                          }`}
                        >
                          {label}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Floating Right Arrow Indicator */}
                {canScrollRight && (
                  <button
                    onClick={() => scrollCategories('right')}
                    className="absolute -right-1 top-1/2 -translate-y-1/2 z-20 w-6 h-6 bg-white/95 backdrop-blur-xs border border-gray-200 text-gray-700 rounded-full shadow-md flex items-center justify-center hover:bg-emerald-50 hover:text-[#2EAA26] active:scale-90 transition-all cursor-pointer"
                    title="ডানে আরও ক্যাটাগরি দেখুন"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Active Filter Indicator Badge */}
              {selectedTopCategoryId && (
                <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 rounded-xl px-2.5 py-1 text-[8.5px] text-emerald-900 animate-fadeIn">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="font-medium text-gray-500">
                      {lang === 'bn' ? 'ফিল্টার:' : 'Filter:'}
                    </span>
                    <span className="font-black text-emerald-800">
                      {lang === 'bn' 
                        ? ESSENTIAL_15_CATEGORIES.find(c => c.id === selectedTopCategoryId)?.nameBn 
                        : ESSENTIAL_15_CATEGORIES.find(c => c.id === selectedTopCategoryId)?.nameEn}
                    </span>
                    <span className="text-[7.5px] bg-emerald-200/70 text-emerald-900 px-1.5 py-0.2 rounded-full font-bold">
                      {filteredProducts.length} {lang === 'bn' ? 'টি আইটেম' : 'items'}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedTopCategoryId(null);
                      setActiveProductFilter('all');
                    }}
                    className="text-emerald-700 hover:text-emerald-900 font-bold hover:underline shrink-0 ml-2 cursor-pointer"
                  >
                    ✕ {lang === 'bn' ? 'সকল দেখুন' : 'Show All'}
                  </button>
                </div>
              )}
            </div>

            {/* ৩. ২০+ পণ্যের বিশাল সমাহার (20+ Diverse Products with High Quality Images) */}
            <div className="space-y-2 pt-0.5">
              {/* Product Category Filter Pills */}
              <div className="flex items-center justify-between">
                <h3 className="text-[10px] font-black text-gray-800 uppercase flex items-center gap-1">
                  <ShoppingCart className="w-3 h-3 text-[#2EAA26]" />
                  পাহাড়ি পণ্য সম্ভার ({filteredProducts.length})
                </h3>
                {activeProductFilter !== 'all' && (
                  <button 
                    onClick={() => setActiveProductFilter('all')}
                    className="text-[8px] font-bold text-emerald-700 hover:underline"
                  >
                    সকল পণ্য দেখুন
                  </button>
                )}
              </div>

              {/* Horizontal Scrollable Category Filter Menu */}
              <div className="relative group/filter">
                {/* Left Scroll Arrow */}
                {canScrollFilterLeft && (
                  <button
                    onClick={() => scrollProductFilter('left')}
                    className="absolute -left-1.5 top-1/2 -translate-y-1/2 z-20 w-5 h-5 bg-white/95 backdrop-blur-xs border border-gray-200 text-gray-700 rounded-full shadow-md flex items-center justify-center hover:bg-emerald-50 hover:text-[#0A6A32] active:scale-90 transition-all cursor-pointer"
                    title="বামে স্ক্রোল করুন"
                  >
                    <ChevronLeft className="w-3 h-3" />
                  </button>
                )}

                {/* Horizontally Scrollable Tabs (11 exact items in required order) */}
                <div 
                  ref={productFilterScrollRef}
                  onScroll={checkProductFilterScroll}
                  className="flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth py-1 px-0.5 select-none"
                  style={{ touchAction: 'pan-x', WebkitOverflowScrolling: 'touch' }}
                >
                  {PRODUCT_FILTER_TABS.map(tab => {
                    const isActive = activeProductFilter === tab.key;
                    const label = lang === 'bn' ? tab.nameBn : tab.nameEn;

                    return (
                      <button
                        key={tab.key}
                        id={`product-tab-${tab.key}`}
                        onClick={() => {
                          setActiveProductFilter(tab.key);
                          if (tab.key === 'all') {
                            setSelectedTopCategoryId(null);
                          }
                        }}
                        className={`px-3 py-1.5 rounded-xl text-[9px] font-bold whitespace-nowrap transition-all duration-200 cursor-pointer shrink-0 shadow-2xs active:scale-95 ${
                          isActive
                            ? 'bg-[#0A6A32] text-white shadow-xs font-black ring-2 ring-emerald-600/30'
                            : 'bg-white text-gray-700 border border-gray-200 hover:border-emerald-300 hover:bg-emerald-50/50 hover:text-[#0A6A32]'
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>

                {/* Right Scroll Arrow */}
                {canScrollFilterRight && (
                  <button
                    onClick={() => scrollProductFilter('right')}
                    className="absolute -right-1.5 top-1/2 -translate-y-1/2 z-20 w-5 h-5 bg-white/95 backdrop-blur-xs border border-gray-200 text-gray-700 rounded-full shadow-md flex items-center justify-center hover:bg-emerald-50 hover:text-[#0A6A32] active:scale-90 transition-all cursor-pointer"
                    title="ডানে স্ক্রোল করুন"
                  >
                    <ChevronRight className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* ২৪+ পণ্য গ্রিড লেআউট */}
              {filteredProducts.length === 0 ? (
                <div className="bg-white p-6 rounded-2xl border border-gray-200 text-center space-y-2">
                  <Package className="w-8 h-8 text-gray-400 mx-auto" />
                  <p className="text-[9.5px] font-black text-gray-700">কোনো পণ্য খুঁজে পাওয়া যায়নি!</p>
                  <button 
                    onClick={() => {
                      setActiveProductFilter('all');
                      setProductSearchTerm('');
                    }}
                    className="text-[8.5px] font-bold text-[#2EAA26] underline"
                  >
                    সকল ফিল্টার মুছুন
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  {filteredProducts.map((p) => {
                    const discount = Math.round(((p.originalPrice - p.price) / p.originalPrice) * 100);
                    return (
                      <div 
                        key={p.id} 
                        onClick={() => handleOpenProductDetails(p)}
                        className="bg-white p-2 rounded-2xl border border-gray-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between cursor-pointer group relative overflow-hidden"
                      >
                        {/* Image Container with Badges */}
                        <div className="relative w-full h-24 bg-slate-100 rounded-xl overflow-hidden mb-1.5">
                          <img 
                            src={p.image} 
                            alt={p.nameBn} 
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                          />
                          {/* Origin Pin */}
                          <span className="absolute top-1.5 left-1.5 bg-black/60 backdrop-blur-xs text-white text-[6.5px] font-bold px-1.5 py-0.5 rounded-md flex items-center gap-0.5">
                            <MapPin className="w-2 h-2 text-amber-300" />
                            {p.origin.split(' ')[0]}
                          </span>
                          
                          {/* Discount / Custom Badge */}
                          {discount > 0 ? (
                            <span className="absolute top-1.5 right-1.5 bg-red-600 text-white text-[7px] font-black px-1.5 py-0.5 rounded-md shadow-xs">
                              {discount}% ছাড়
                            </span>
                          ) : p.badge ? (
                            <span className={`absolute top-1.5 right-1.5 ${p.badgeColor || 'bg-emerald-600'} text-white text-[6.5px] font-bold px-1.5 py-0.5 rounded-md shadow-xs`}>
                              {p.badge}
                            </span>
                          ) : null}
                        </div>

                        {/* Title & Category Info */}
                        <div className="space-y-0.5">
                          <span className="text-[7px] font-black text-emerald-700 uppercase bg-emerald-50 px-1.5 py-0.2 rounded-md inline-block">
                            {p.categoryLabelBn}
                          </span>
                          <h4 className="text-[9px] font-black text-gray-900 leading-snug line-clamp-2 mt-0.5">
                            {p.nameBn}
                          </h4>
                          <p className="text-[7.5px] text-gray-400 font-medium truncate">
                            {p.unit}
                          </p>

                          {/* Rating & Review */}
                          <div className="flex items-center gap-1 pt-0.5">
                            <Star className="w-2.5 h-2.5 text-amber-500 fill-amber-500" />
                            <span className="text-[8px] font-black text-gray-800">{p.rating}</span>
                            <span className="text-[7px] text-gray-400">({p.reviewsCount})</span>
                          </div>
                        </div>

                        {/* Price & Add to Cart button */}
                        <div className="flex items-center justify-between pt-2 mt-1 border-t border-gray-100">
                          <div className="flex flex-col">
                            <span className="text-[10.5px] font-black text-[#2EAA26] leading-none">
                              ৳ {p.price}
                            </span>
                            {p.originalPrice > p.price && (
                              <span className="text-[7.5px] text-gray-400 line-through font-bold">
                                ৳ {p.originalPrice}
                              </span>
                            )}
                          </div>

                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAddToCart(p, 1);
                            }}
                            className="bg-[#2EAA26] hover:bg-emerald-700 active:scale-90 text-white p-1.5 rounded-xl shadow-xs transition-transform flex items-center justify-center"
                            title="কার্টে যোগ করুন"
                          >
                            <ShoppingCart className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================= (খ) সার্চ পেজ (৬৪ জেলা ও সকল থানা সহ) ================= */}
        {activeTab === 'search' && (
          <div className="w-full flex flex-col bg-white">
            <div className="px-3.5 py-3 sm:px-6 flex flex-col items-center space-y-3 pb-12 w-full max-w-md mx-auto">
              
              {/* অফলাইন নোটিশ কার্ড */}
              {!isOnline && (
                <div className="w-full text-left">
                  <OfflineFallbackCard 
                    title="অফলাইন মোডে সার্চ সক্রিয়"
                    description="ইন্টারনেট সংযোগ ছাড়াই ডিভাইসে সংরক্ষিত ৬৪ জেলা, পণ্য, রক্তদাতা, পুলিশ ও অ্যাম্বুলেন্সের তথ্য সার্চ এবং সরাসরি ফোন করতে পারছেন।"
                    onRetry={checkConnection}
                  />
                </div>
              )}

              {/* ১. টপ ব্যানার ইমেজ (নির্বাচিত ৩টি ট্যাবের সাথে মিল রেখে স্লিক ওয়াইড ব্যানার) */}
              <div className="w-full relative h-20 sm:h-24 rounded-2xl overflow-hidden shadow-2xs border border-gray-200">
                <img 
                  src={
                    searchMode === 'services' 
                      ? "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80"
                      : searchMode === 'products'
                      ? "https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80"
                      : "https://images.unsplash.com/photo-1615461066841-6116e61058f4?w=800&auto=format&fit=crop&q=80"
                  } 
                  alt={searchMode}
                  className="w-full h-full object-cover" 
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/45 to-transparent flex items-center p-3 sm:p-4">
                  <div className="text-white space-y-0.5 text-left">
                    <span className="text-[7.5px] font-black uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full backdrop-blur-xs">
                      {searchMode === 'services' && 'পেশাজীবী ও কারিগর ডিরেক্টরি'}
                      {searchMode === 'products' && 'অনলাইন মার্কেটপ্লেস ও পণ্য'}
                      {searchMode === 'blood' && 'স্বেচ্ছাসেবী রক্তদাতা নেটওয়ার্ক'}
                    </span>
                    <h3 className="text-xs sm:text-sm font-black text-white drop-shadow-xs">
                      {searchMode === 'services' && 'প্রয়োজনীয় দক্ষ পেশাজীবী খুঁজুন'}
                      {searchMode === 'products' && 'সরাসরি উৎপাদক ও বিশ্বস্ত পণ্য খুঁজুন'}
                      {searchMode === 'blood' && 'জরুরি প্রয়োজনে রক্তদাতা খুঁজুন'}
                    </h3>
                  </div>
                </div>
              </div>

              {/* ৩. প্রাইমারি ৩টি ক্যাটাগরি নেভিগেশন ট্যাব (সেবা, পণ্য, ব্ল্যাড) */}
              <div className="w-full grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-2xl border border-slate-200 shadow-2xs">
                <button
                  type="button"
                  onClick={() => {
                    setSearchMode('services');
                    setSelectedCategoryJob('');
                    setHasSearched(true);
                  }}
                  className={`py-2 px-1 rounded-xl text-[9px] font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    searchMode === 'services'
                      ? 'bg-[#2EAA26] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <span className="text-xs">🛠️</span>
                  <span>সেবা</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSearchMode('products');
                    setSelectedCategoryJob('');
                    setHasSearched(true);
                  }}
                  className={`py-2 px-1 rounded-xl text-[9px] font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    searchMode === 'products'
                      ? 'bg-[#2EAA26] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <span className="text-xs">🛍️</span>
                  <span>পণ্য</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSearchMode('blood');
                    setSelectedCategoryJob('');
                    setSearchQuery('');
                    setHasSearched(true);
                  }}
                  className={`py-2 px-1 rounded-xl text-[9px] font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    searchMode === 'blood'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <span className="text-xs">🩸</span>
                  <span>রক্ত</span>
                </button>
              </div>

              {/* ৪. সার্চ ও ফিল্টারিং এরিয়া (৩টি ট্যাবের ফিল্টার) */}
              <div className="w-full space-y-2.5 bg-slate-50 p-3 sm:p-3.5 rounded-2xl border border-gray-200 shadow-sm text-left">
                
                {/* ১. সেবা (Service) ট্যাব: ১,০০০ পেশার লাইভ অটো-কমপ্লিট ড্রপডাউন ও ৬টি কোর ক্যাটাগরি */}
                {searchMode === 'services' && (
                  <div className="space-y-2">
                    {/* সার্চ কিওয়ার্ড ও অটো-সাজেশন ইনপুট */}
                    <div ref={searchContainerRef} className="relative">
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[7.5px] font-extrabold text-gray-600 flex items-center gap-1">
                          <Wrench className="w-2.5 h-2.5 text-[#2EAA26]" />
                          <span>পেশা বা কাজের ধরন (১,০০০টি পেশার লাইভ অটো-কমপ্লিট):</span>
                        </label>
                        {(searchQuery || selectedCategoryJob) && (
                          <button 
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setSelectedCategoryJob('');
                            }}
                            className="text-red-600 hover:underline font-bold text-[7.5px] cursor-pointer"
                          >
                            ক্লিয়ার
                          </button>
                        )}
                      </div>

                      <div className={`bg-white border ${isListeningVoice ? 'border-red-500 ring-2 ring-red-200 animate-pulse' : 'border-gray-300 focus-within:border-[#2EAA26]'} rounded-xl p-1.5 flex items-center gap-1.5 shadow-2xs transition-all`}>
                        <Search className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => {
                            setSearchQuery(e.target.value);
                            setSelectedCategoryJob('');
                            setShowSearchSuggestions(true);
                          }}
                          onFocus={() => setShowSearchSuggestions(true)}
                          onClick={() => setShowSearchSuggestions(true)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              setShowSearchSuggestions(false);
                              setSelectedCategoryJob('');
                              setHasSearched(true);
                            }
                          }}
                          placeholder="১,০০০টি পেশার মধ্য থেকে খুঁজুন বা যেকোনো কাস্টম সেবা লিখুন..."
                          className="w-full text-[9.5px] bg-transparent outline-none font-bold text-gray-800 placeholder:text-gray-400 placeholder:font-normal"
                        />

                        {/* ইনপুট ক্লিয়ার বাটন */}
                        {searchQuery && (
                          <button
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setSelectedCategoryJob('');
                            }}
                            className="p-1 text-gray-400 hover:text-gray-600 rounded-md hover:bg-gray-100 transition cursor-pointer shrink-0"
                            title="মুছে ফেলুন"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}

                        {/* Gemini AI Assistant Trigger */}
                        <button
                          type="button"
                          onClick={() => setIsGeminiModalOpen(true)}
                          className="p-1 rounded-lg text-emerald-600 hover:bg-emerald-50 transition cursor-pointer"
                          title="ঝাদিমাটি AI অ্যাসিস্ট্যান্ট"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                        </button>

                        {/* বাংলা ভয়েস সার্চ বাটন */}
                        <button
                          type="button"
                          onClick={handleTriggerVoiceSearch}
                          className={`p-1.5 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                            isListeningVoice 
                              ? 'bg-red-600 text-white animate-bounce shadow-xs' 
                              : 'bg-emerald-50 text-[#2EAA26] hover:bg-emerald-100'
                          }`}
                          title="মুখে বাংলায় বলুন"
                        >
                          <Mic className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* ডাইনামিক অটো-কমপ্লিট ড্রপডাউন পপআপ (১,০০০ পেশার সম্পূর্ণ তালিকা ও কাস্টম সার্চ সাপোর্ট) */}
                      {showSearchSuggestions && (activeSearchSuggestions.length > 0 || searchQuery.trim().length > 0) && (
                        <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden max-h-72 sm:max-h-80 overflow-y-auto">
                          {/* কাস্টম টেক্সট ইনপুট অ্যাকশন বাটন */}
                          {searchQuery.trim().length > 0 && (
                            <button
                              type="button"
                              onClick={() => {
                                setShowSearchSuggestions(false);
                                setSelectedCategoryJob('');
                                setHasSearched(true);
                              }}
                              className="w-full px-3 py-2 bg-emerald-50 hover:bg-emerald-100/80 border-b border-emerald-100 text-left flex items-center justify-between transition cursor-pointer group"
                            >
                              <div className="flex items-center gap-1.5 min-w-0">
                                <Search className="w-3.5 h-3.5 text-[#2EAA26] shrink-0" />
                                <span className="text-[9px] font-bold text-gray-900 truncate">
                                  "<span className="text-[#2EAA26] font-black">{searchQuery.trim()}</span>" লিখে সরাসরি অনুসন্ধান করুন
                                </span>
                              </div>
                              <span className="text-[7px] font-extrabold text-emerald-800 bg-white border border-emerald-200 px-2 py-0.5 rounded-md shrink-0 shadow-2xs">
                                কাস্টম সার্চ ↵
                              </span>
                            </button>
                          )}

                          <div className="p-1.5 bg-slate-50 border-b border-gray-100 flex items-center justify-between text-[7.5px] font-extrabold text-gray-500">
                            <span>
                              {searchQuery.trim() 
                                ? `পেশা তালিকা থেকে পাওয়া গেছে (${activeSearchSuggestions.length}টি):` 
                                : `সকল ১,০০০ পেশার সম্পূর্ণ ডিরেক্টরি (${activeSearchSuggestions.length}টি):`}
                            </span>
                            <span className="text-[7px] text-[#2EAA26]">ক্লিক করে নির্বাচন করুন</span>
                          </div>

                          {activeSearchSuggestions.length > 0 ? (
                            <div className="py-0.5">
                              {activeSearchSuggestions.map((item, idx) => (
                                <button
                                  key={`${item.name}-${idx}`}
                                  type="button"
                                  onClick={() => {
                                    setSearchQuery(item.name);
                                    setSelectedCategoryJob(item.name);
                                    setShowSearchSuggestions(false);
                                    setHasSearched(true);
                                  }}
                                  className="w-full px-3 py-1.5 text-left text-[9px] hover:bg-emerald-50 flex items-center justify-between transition cursor-pointer group border-b border-gray-50 last:border-0"
                                >
                                  <span className="font-bold text-gray-800 group-hover:text-[#2EAA26] truncate flex items-center gap-1.5">
                                    <span className="text-gray-400 group-hover:text-emerald-500 text-[8px]">🛠️</span>
                                    <span>{item.name}</span>
                                  </span>
                                  <div className="flex items-center gap-1 shrink-0 ml-1.5">
                                    {item.subCategory && (
                                      <span className="text-[6.5px] text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded-sm">
                                        {item.subCategory}
                                      </span>
                                    )}
                                    {item.category && (
                                      <span className="text-[7px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-100 px-1.5 py-0.5 rounded-full">
                                        {item.category.split(' ')[0]}...
                                      </span>
                                    )}
                                  </div>
                                </button>
                              ))}
                            </div>
                          ) : (
                            <div className="p-3 text-center bg-gray-50/70 space-y-1">
                              <p className="text-[8.5px] font-bold text-gray-700">
                                পূর্বনির্ধারিত ১,০০০ পেশার তালিকায় মেলেনি
                              </p>
                              <p className="text-[7.5px] text-gray-500">
                                উপরের "কাস্টম সার্চ" বাটনে অথবা কিবোর্ডের Enter চেপে যেকোনো কাস্টম সেবা সার্চ করুন।
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* জেলা ও থানা ড্রপডাউন (৬৪ জেলা ও সকল থানা) */}
                    <div className="grid grid-cols-2 gap-1.5">
                      <div>
                        <label className="text-[7.5px] font-extrabold text-gray-500 mb-0.5 flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5 text-[#2EAA26]" /> জেলা (District):
                        </label>
                        <select
                          value={selectedDistrict}
                          onChange={(e) => {
                            setSelectedDistrict(e.target.value);
                            setSelectedUpazila('');
                          }}
                          className="w-full p-1.5 bg-white border border-gray-300 rounded-xl text-[9px] font-bold text-gray-800 outline-none focus:border-[#2EAA26] shadow-2xs"
                        >
                          <option value="">সকল জেলা (৬৪ জেলা)</option>
                          {Object.keys(ALL_BANGLADESH_DISTRICTS).map(district => (
                            <option key={district} value={district}>{district}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[7.5px] font-extrabold text-gray-500 mb-0.5 flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5 text-[#2EAA26]" /> থানা/উপজেলা:
                        </label>
                        <select
                          value={selectedUpazila}
                          onChange={(e) => setSelectedUpazila(e.target.value)}
                          disabled={!selectedDistrict}
                          className="w-full p-1.5 bg-white border border-gray-300 rounded-xl text-[9px] font-bold text-gray-800 outline-none focus:border-[#2EAA26] shadow-2xs disabled:bg-gray-100 disabled:text-gray-400"
                        >
                          <option value="">সকল থানা/উপজেলা</option>
                          {availableUpazilas.map(upazila => (
                            <option key={upazila} value={upazila}>{upazila}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* পাড়া / মহল্লা / এলাকা ইনপুট */}
                    <div>
                      <label className="text-[7.5px] font-extrabold text-gray-500 mb-0.5 block">
                        পাড়া / মহল্লা / গ্রাম (ঐচ্ছিক):
                      </label>
                      <div className="bg-white border border-gray-300 rounded-xl p-1.5 flex items-center gap-1 shadow-2xs">
                        <MapPin className="w-3 h-3 text-gray-400 shrink-0" />
                        <input
                          type="text"
                          value={selectedArea}
                          onChange={(e) => setSelectedArea(e.target.value)}
                          placeholder="যেমন: বোয়ালখালী বাজার, আদালত রোড, কলেজ পাড়া..."
                          className="w-full text-[9px] bg-transparent outline-none font-bold text-gray-800 placeholder:text-gray-400 placeholder:font-normal"
                        />
                      </div>
                    </div>

                    {/* সেবা খুঁজুন বাটন */}
                    <div className="pt-0.5">
                      <button
                        type="button"
                        onClick={() => setHasSearched(true)}
                        className="w-full py-2 px-4 bg-[#2EAA26] hover:bg-emerald-700 active:scale-[0.98] text-white text-[10px] sm:text-xs font-bold rounded-xl shadow-2xs hover:shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Search className="w-3.5 h-3.5" />
                        <span>সেবা খুঁজুন</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* ২. পণ্য (Product) ট্যাব: হুবহু পূর্বের সকল লেআউট ও ফিচার সংরক্ষিত */}
                {searchMode === 'products' && (
                  <div className="space-y-2">
                    {/* সার্চ কিওয়ার্ড ও অটো-সাজেশন ইনপুট */}
                    <div ref={searchContainerRef} className="relative">
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[7.5px] font-extrabold text-gray-600 flex items-center gap-1">
                          <Search className="w-2.5 h-2.5 text-[#2EAA26]" />
                          <span>পণ্যের নাম বা ক্যাটাগরি:</span>
                        </label>
                        {(searchQuery || selectedCategoryJob) && (
                          <button 
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setSelectedCategoryJob('');
                            }}
                            className="text-red-600 hover:underline font-bold text-[7.5px] cursor-pointer"
                          >
                            ক্লিয়ার
                          </button>
                        )}
                      </div>

                      <div className={`bg-white border ${isListeningVoice ? 'border-red-500 ring-2 ring-red-200 animate-pulse' : 'border-gray-300 focus-within:border-[#2EAA26]'} rounded-xl p-1.5 flex items-center gap-1.5 shadow-2xs transition-all`}>
                        <Search className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => {
                            setSearchQuery(e.target.value);
                            setSelectedCategoryJob('');
                            setShowSearchSuggestions(true);
                          }}
                          onFocus={() => setShowSearchSuggestions(true)}
                          onClick={() => setShowSearchSuggestions(true)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              setShowSearchSuggestions(false);
                              setSelectedCategoryJob('');
                              setHasSearched(true);
                            }
                          }}
                          placeholder="যেমন: পাহাড়ি মধু, হলুদ গুঁড়া, পিনন হাদি, জুমের চাল বা যেকোনো পণ্য..."
                          className="w-full text-[9.5px] bg-transparent outline-none font-bold text-gray-800 placeholder:text-gray-400 placeholder:font-normal"
                        />

                        {/* ইনপুট ক্লিয়ার বাটন */}
                        {searchQuery && (
                          <button
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setSelectedCategoryJob('');
                            }}
                            className="p-1 text-gray-400 hover:text-gray-600 rounded-md hover:bg-gray-100 transition cursor-pointer shrink-0"
                            title="মুছে ফেলুন"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}

                        {/* Gemini AI Assistant Trigger */}
                        <button
                          type="button"
                          onClick={() => setIsGeminiModalOpen(true)}
                          className="p-1 rounded-lg text-emerald-600 hover:bg-emerald-50 transition cursor-pointer"
                          title="ঝাদিমাটি AI অ্যাসিস্ট্যান্ট"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                        </button>

                        {/* বাংলা ভয়েস সার্চ বাটন */}
                        <button
                          type="button"
                          onClick={handleTriggerVoiceSearch}
                          className={`p-1.5 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                            isListeningVoice 
                              ? 'bg-red-600 text-white animate-bounce shadow-xs' 
                              : 'bg-emerald-50 text-[#2EAA26] hover:bg-emerald-100'
                          }`}
                          title="মুখে বাংলায় বলুন"
                        >
                          <Mic className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* অটো-সাজেশন ড্রপডাউন পপআপ (সম্পূর্ণ তালিকা ও কাস্টম সার্চ সাপোর্ট) */}
                      {showSearchSuggestions && (activeSearchSuggestions.length > 0 || searchQuery.trim().length > 0) && (
                        <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden max-h-64 sm:max-h-72 overflow-y-auto">
                          {/* কাস্টম টেক্সট ইনপুট অ্যাকশন বাটন */}
                          {searchQuery.trim().length > 0 && (
                            <button
                              type="button"
                              onClick={() => {
                                setShowSearchSuggestions(false);
                                setSelectedCategoryJob('');
                                setHasSearched(true);
                              }}
                              className="w-full px-3 py-2 bg-emerald-50 hover:bg-emerald-100/80 border-b border-emerald-100 text-left flex items-center justify-between transition cursor-pointer group"
                            >
                              <div className="flex items-center gap-1.5 min-w-0">
                                <Search className="w-3.5 h-3.5 text-[#2EAA26] shrink-0" />
                                <span className="text-[9px] font-bold text-gray-900 truncate">
                                  "<span className="text-[#2EAA26] font-black">{searchQuery.trim()}</span>" পণ্য লিখে সরাসরি অনুসন্ধান করুন
                                </span>
                              </div>
                              <span className="text-[7px] font-extrabold text-emerald-800 bg-white border border-emerald-200 px-2 py-0.5 rounded-md shrink-0 shadow-2xs">
                                কাস্টম সার্চ ↵
                              </span>
                            </button>
                          )}

                          <div className="p-1.5 bg-slate-50 border-b border-gray-100 flex items-center justify-between text-[7.5px] font-extrabold text-gray-500">
                            <span>
                              {searchQuery.trim() 
                                ? `পণ্য তালিকা থেকে পাওয়া গেছে (${activeSearchSuggestions.length}টি):` 
                                : `সকল পণ্য ও ক্যাটাগরি তালিকা (${activeSearchSuggestions.length}টি):`}
                            </span>
                            <span className="text-[7px] text-[#2EAA26]">ক্লিক করে নির্বাচন করুন</span>
                          </div>

                          {activeSearchSuggestions.length > 0 ? (
                            <div className="py-0.5">
                              {activeSearchSuggestions.map((item, idx) => (
                                <button
                                  key={`${item.name}-${idx}`}
                                  type="button"
                                  onClick={() => {
                                    setSearchQuery(item.name);
                                    setSelectedCategoryJob(item.name);
                                    setShowSearchSuggestions(false);
                                    setHasSearched(true);
                                  }}
                                  className="w-full px-3 py-1.5 text-left text-[9px] hover:bg-emerald-50 flex items-center justify-between transition cursor-pointer group border-b border-gray-50 last:border-0"
                                >
                                  <span className="font-bold text-gray-800 group-hover:text-[#2EAA26] truncate">
                                    🛍️ {item.name}
                                  </span>
                                  {item.category && (
                                    <span className="text-[7px] text-gray-400 bg-gray-100 group-hover:bg-emerald-100 group-hover:text-[#2EAA26] px-1.5 py-0.5 rounded-full shrink-0 ml-1">
                                      {item.category}
                                    </span>
                                  )}
                                </button>
                              ))}
                            </div>
                          ) : (
                            <div className="p-3 text-center bg-gray-50/70 space-y-1">
                              <p className="text-[8.5px] font-bold text-gray-700">
                                প্রস্তাবিত পণ্য তালিকায় মেলেনি
                              </p>
                              <p className="text-[7.5px] text-gray-500">
                                উপরের "কাস্টম সার্চ" বাটনে অথবা কিবোর্ডের Enter চেপে যেকোনো কাস্টম পণ্য খুঁজুন।
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* জেলা ও থানা ড্রপডাউন (৬৪ জেলা ও সকল থানা) */}
                    <div className="grid grid-cols-2 gap-1.5">
                      <div>
                        <label className="text-[7.5px] font-extrabold text-gray-500 mb-0.5 flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5 text-[#2EAA26]" /> জেলা (District):
                        </label>
                        <select
                          value={selectedDistrict}
                          onChange={(e) => {
                            setSelectedDistrict(e.target.value);
                            setSelectedUpazila('');
                          }}
                          className="w-full p-1.5 bg-white border border-gray-300 rounded-xl text-[9px] font-bold text-gray-800 outline-none focus:border-[#2EAA26] shadow-2xs"
                        >
                          <option value="">সকল জেলা (৬৪ জেলা)</option>
                          {Object.keys(ALL_BANGLADESH_DISTRICTS).map(district => (
                            <option key={district} value={district}>{district}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[7.5px] font-extrabold text-gray-500 mb-0.5 flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5 text-[#2EAA26]" /> থানা/উপজেলা:
                        </label>
                        <select
                          value={selectedUpazila}
                          onChange={(e) => setSelectedUpazila(e.target.value)}
                          disabled={!selectedDistrict}
                          className="w-full p-1.5 bg-white border border-gray-300 rounded-xl text-[9px] font-bold text-gray-800 outline-none focus:border-[#2EAA26] shadow-2xs disabled:bg-gray-100 disabled:text-gray-400"
                        >
                          <option value="">সকল থানা/উপজেলা</option>
                          {availableUpazilas.map(upazila => (
                            <option key={upazila} value={upazila}>{upazila}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* পাড়া / মহল্লা / এলাকা ইনপুট */}
                    <div>
                      <label className="text-[7.5px] font-extrabold text-gray-500 mb-0.5 block">
                        পাড়া / মহল্লা / গ্রাম (ঐচ্ছিক):
                      </label>
                      <div className="bg-white border border-gray-300 rounded-xl p-1.5 flex items-center gap-1 shadow-2xs">
                        <MapPin className="w-3 h-3 text-gray-400 shrink-0" />
                        <input
                          type="text"
                          value={selectedArea}
                          onChange={(e) => setSelectedArea(e.target.value)}
                          placeholder="যেমন: বোয়ালখালী বাজার, আদালত রোড, কলেজ পাড়া..."
                          className="w-full text-[9px] bg-transparent outline-none font-bold text-gray-800 placeholder:text-gray-400 placeholder:font-normal"
                        />
                      </div>
                    </div>

                    {/* পণ্য খুঁজুন বাটন */}
                    <div className="pt-0.5">
                      <button
                        type="button"
                        onClick={() => setHasSearched(true)}
                        className="w-full py-2 px-4 bg-[#2EAA26] hover:bg-emerald-700 active:scale-[0.98] text-white text-[10px] sm:text-xs font-bold rounded-xl shadow-2xs hover:shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Search className="w-3.5 h-3.5" />
                        <span>পণ্য খুঁজুন</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* ৩. ব্লাড (রক্ত) ট্যাব: সার্চ বার সম্পূর্ণ অপসারণ করে ভয়েস সার্চ ও এআই সার্চ বাটন */}
                {searchMode === 'blood' && (
                  <div className="space-y-2">
                    {/* টপ সেকশন: ভয়েস সার্চ এবং এআই সার্চ ফিচার */}
                    <div className="bg-gradient-to-r from-rose-50 via-red-50 to-amber-50 border border-red-200/80 rounded-2xl p-3 shadow-2xs">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-1.5">
                          <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-600"></span>
                          </span>
                          <span className="text-[8.5px] font-black text-red-950">জরুরি রক্তদাতা অনুসন্ধান</span>
                        </div>
                        <span className="text-[7.5px] font-bold text-red-600 bg-white/90 px-2 py-0.5 rounded-full border border-red-200">
                          ভয়েস ও এআই ফিচার
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        {/* ভয়েস সার্চ বাটন */}
                        <button
                          type="button"
                          onClick={handleTriggerVoiceSearch}
                          className={`p-2.5 rounded-xl border flex items-center justify-center gap-2 transition-all cursor-pointer select-none active:scale-95 ${
                            isListeningVoice
                              ? 'bg-red-600 text-white border-red-700 ring-2 ring-red-300 animate-pulse shadow-xs'
                              : 'bg-white hover:bg-red-50 text-red-700 border-red-200 hover:border-red-300 shadow-2xs'
                          }`}
                          title="মুখে বলুন (যেমন: ও পজিটিভ রক্ত চাই)"
                        >
                          <div className={`p-1.5 rounded-lg shrink-0 ${isListeningVoice ? 'bg-white/20 text-white' : 'bg-red-100 text-red-600'}`}>
                            <Mic className={`w-3.5 h-3.5 ${isListeningVoice ? 'animate-bounce' : ''}`} />
                          </div>
                          <div className="text-left min-w-0">
                            <div className="text-[8.5px] font-black leading-tight">{isListeningVoice ? 'শুনছি...' : 'ভয়েস সার্চ'}</div>
                            <div className="text-[7px] text-gray-500 font-medium truncate">মুখে বলে খুঁজুন</div>
                          </div>
                        </button>

                        {/* এআই সার্চ বাটন */}
                        <button
                          type="button"
                          onClick={() => {
                            setIsGeminiModalOpen(true);
                            setShowToast('ঝাদিমাটি AI রক্তদাতা মেলানো চালু হয়েছে');
                          }}
                          className="p-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white border border-red-700 flex items-center justify-center gap-2 shadow-2xs hover:shadow-xs transition-all cursor-pointer select-none active:scale-95"
                          title="স্মার্ট AI রক্তদাতা সার্চ"
                        >
                          <div className="p-1.5 rounded-lg bg-white/20 text-amber-200 shrink-0">
                            <Sparkles className="w-3.5 h-3.5" />
                          </div>
                          <div className="text-left min-w-0">
                            <div className="text-[8.5px] font-black leading-tight">AI রক্তদাতা সার্চ</div>
                            <div className="text-[7px] text-red-100 font-medium truncate">স্মার্ট অ্যাসিস্ট্যান্ট</div>
                          </div>
                        </button>
                      </div>

                      {isListeningVoice && (
                        <div className="mt-2 bg-red-100/90 border border-red-200 rounded-xl px-2.5 py-1.5 flex items-center gap-1.5 text-[8px] font-bold text-red-800 animate-pulse">
                          <Mic className="w-3 h-3 text-red-600 animate-bounce shrink-0" />
                          <span>স্পষ্ট করে বাংলায় বলুন (যেমন: "খাগড়াছড়ি সদরে ও পজিটিভ রক্ত চাই")...</span>
                        </div>
                      )}
                    </div>

                    {/* ফিল্টার ১: রক্তের গ্রুপ নির্বাচন (ড্রপডাউন ও কুইক সিলেক্টর) */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[7.5px] font-extrabold text-gray-600 flex items-center gap-1">
                          <Droplet className="w-2.5 h-2.5 text-red-600 fill-red-600" />
                          <span>রক্তের গ্রুপ (Blood Group ড্রপডাউন):</span>
                        </label>
                        {selectedBloodGroup && (
                          <button
                            type="button"
                            onClick={() => setSelectedBloodGroup('')}
                            className="text-red-600 hover:underline text-[7px] font-bold cursor-pointer"
                          >
                            সকল গ্রুপ রিসেট
                          </button>
                        )}
                      </div>
                      <select
                        value={selectedBloodGroup}
                        onChange={(e) => setSelectedBloodGroup(e.target.value)}
                        className="w-full p-1.5 mb-1.5 bg-white border border-gray-300 rounded-xl text-[9px] font-bold text-gray-800 outline-none focus:border-red-500 shadow-2xs"
                      >
                        <option value="">সকল রক্তের গ্রুপ (All Groups)</option>
                        {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                          <option key={bg} value={bg}>{bg} গ্রুপ</option>
                        ))}
                      </select>
                      <div className="grid grid-cols-4 gap-1">
                        {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                          <button
                            key={bg}
                            type="button"
                            onClick={() => setSelectedBloodGroup(selectedBloodGroup === bg ? '' : bg)}
                            className={`py-1 rounded-lg text-[8.5px] font-black border transition cursor-pointer flex items-center justify-center gap-0.5 ${
                              selectedBloodGroup === bg
                                ? 'bg-red-600 text-white border-red-600 shadow-2xs'
                                : 'bg-white text-gray-700 border-gray-200 hover:border-red-300 hover:bg-red-50/50'
                            }`}
                          >
                            <span>{bg}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* ফিল্টার ২: জেলা ও থানা ড্রপডাউন */}
                    <div className="grid grid-cols-2 gap-1.5">
                      <div>
                        <label className="text-[7.5px] font-extrabold text-gray-500 mb-0.5 flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5 text-red-600" /> জেলা (District):
                        </label>
                        <select
                          value={selectedDistrict}
                          onChange={(e) => {
                            setSelectedDistrict(e.target.value);
                            setSelectedUpazila('');
                          }}
                          className="w-full p-1.5 bg-white border border-gray-300 rounded-xl text-[9px] font-bold text-gray-800 outline-none focus:border-red-500 shadow-2xs"
                        >
                          <option value="">সকল জেলা (৬৪ জেলা)</option>
                          {Object.keys(ALL_BANGLADESH_DISTRICTS).map(district => (
                            <option key={district} value={district}>{district}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[7.5px] font-extrabold text-gray-500 mb-0.5 flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5 text-red-600" /> থানা/উপজেলা:
                        </label>
                        <select
                          value={selectedUpazila}
                          onChange={(e) => setSelectedUpazila(e.target.value)}
                          disabled={!selectedDistrict}
                          className="w-full p-1.5 bg-white border border-gray-300 rounded-xl text-[9px] font-bold text-gray-800 outline-none focus:border-red-500 shadow-2xs disabled:bg-gray-100 disabled:text-gray-400"
                        >
                          <option value="">সকল থানা/উপজেলা</option>
                          {availableUpazilas.map(upazila => (
                            <option key={upazila} value={upazila}>{upazila}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* রক্তদাতা খুঁজুন বাটন */}
                    <div className="pt-0.5">
                      <button
                        type="button"
                        onClick={() => setHasSearched(true)}
                        className="w-full py-2 px-4 bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white text-[10px] sm:text-xs font-bold rounded-xl shadow-2xs hover:shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Search className="w-3.5 h-3.5" />
                        <span>রক্তদাতা খুঁজুন</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* ডেডিকেটেড সোর্স (জরুরি ৯৯৯ তথ্য ও হটলাইন) সেকশন — 'খুঁজুন' বাটনের ঠিক নিচে */}
                <div className="w-full pt-1">
                  <button
                    type="button"
                    onClick={() => setIsSourceModalOpen(true)}
                    className="w-full p-2.5 sm:p-3 bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white rounded-2xl shadow-xs border border-red-400/40 flex items-center justify-between gap-2 transition-all cursor-pointer group active:scale-[0.99]"
                  >
                    <div className="flex items-center gap-2 min-w-0 text-left">
                      <div className="bg-white text-red-600 p-1.5 rounded-xl shadow-2xs shrink-0 group-hover:scale-105 transition-transform">
                        <Siren className="w-4 h-4 animate-pulse" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-black tracking-wide">জরুরি সোর্স ও জাতীয় সেবা (Source)</span>
                          <span className="bg-white/20 text-[7px] font-bold px-1.5 py-0.2 rounded-full backdrop-blur-xs">২৪/৭ সেবা</span>
                        </div>
                        <p className="text-[7.5px] text-red-100 font-bold truncate">পুলিশ • অ্যাম্বুলেন্স • ফায়ার সার্ভিস (৯৯৯ কল)</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 bg-white text-red-600 font-black text-[8.5px] px-3 py-1.5 rounded-xl shadow-xs group-hover:bg-red-50">
                      <PhoneCall className="w-3 h-3 fill-red-600" />
                      <span>সোর্স দেখুন</span>
                    </div>
                  </button>
                </div>

              </div>

              {/* ৫. ফলাফল সেকশন */}
              {hasSearched && (
                <div className="w-full text-left space-y-2 pt-1 pb-4">
                  {/* ১. পেশাজীবী সার্চ ফলাফল */}
                  {searchMode === 'services' && (
                    <>
                      <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                        <span className="text-[9px] font-black text-gray-700">খুঁজে পাওয়া নিবন্ধিত পেশাজীবী:</span>
                        <span className="bg-green-100 text-[#2EAA26] text-[7.5px] font-bold px-2 py-0.5 rounded-full">{searchResults.length} জন নিবন্ধিত</span>
                      </div>

                      {searchResults.length > 0 ? (
                        <div className="space-y-2">
                          {searchResults.map((pro) => (
                            <div 
                              key={pro.id} 
                              className="bg-white p-2.5 rounded-2xl border border-gray-200 shadow-2xs hover:border-emerald-300 transition-all flex flex-col gap-2 cursor-pointer group"
                              onClick={() => openProfessionalPortfolioModal(pro)}
                            >
                              <div className="flex items-start gap-2.5">
                                <div className="relative shrink-0">
                                  <img src={pro.img} alt={pro.name} className="w-11 h-11 object-cover rounded-xl border border-emerald-100 shadow-xs" />
                                  {pro.verified && (
                                    <div className="absolute -bottom-1 -right-1 bg-emerald-600 text-white rounded-full p-0.5 shadow-xs" title="NID ভেরিফাইড প্রফেশনাল">
                                      <ShieldCheck className="w-2.5 h-2.5" />
                                    </div>
                                  )}
                                </div>
                                
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between gap-1">
                                    <h4 className="text-[10px] font-black text-gray-900 truncate group-hover:text-[#2EAA26] transition-colors">{pro.name}</h4>
                                    <span className="text-[7px] font-mono font-black bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded-md border border-emerald-100 shrink-0">
                                      {pro.uniqueId || pro.memberId || 'VERIFIED'}
                                    </span>
                                  </div>
                                  <p className="text-[8.5px] font-extrabold text-[#2EAA26] truncate">{pro.job}</p>
                                  <div className="flex items-center gap-2 text-[7.5px] text-gray-500 mt-0.5">
                                    <span className="flex items-center gap-0.5">
                                      <MapPin className="w-2.5 h-2.5 text-gray-400" /> {pro.district} ➔ {pro.upazila} {pro.area ? `(${pro.area})` : ''}
                                    </span>
                                    {pro.rateAmount && (
                                      <span className="font-bold text-gray-700">
                                        • ৳{pro.rateAmount}/{pro.rateType || 'দৈনিক'}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center justify-between gap-2 pt-1 border-t border-gray-100">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    openProfessionalPortfolioModal(pro);
                                  }}
                                  className="text-[8px] font-extrabold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2 py-1 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                                >
                                  <Briefcase className="w-2.5 h-2.5" />
                                  পোর্টফোলিও ও রেটিং দেখুন
                                </button>

                                <a 
                                  href={`tel:${pro.phone}`}
                                  onClick={(e) => e.stopPropagation()}
                                  className="bg-[#2EAA26] hover:bg-emerald-700 text-white text-[8px] font-black px-3 py-1 rounded-lg shrink-0 flex items-center gap-1 shadow-2xs active:scale-95 transition-all cursor-pointer"
                                >
                                  <Phone className="w-2.5 h-2.5" /> সরাসরি কল
                                </a>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="bg-gray-50 p-4 rounded-xl text-center text-gray-400 space-y-1 border border-gray-200">
                          <p className="text-[9px] font-bold text-gray-600">কোনো নিবন্ধিত পেশাজীবী পাওয়া যায়নি</p>
                          <p className="text-[7.5px] text-gray-500">অন্য কোনো পেশা বা জেলা/উপজেলা নির্বাচন করে পুনরায় খুঁজুন।</p>
                        </div>
                      )}
                    </>
                  )}

                  {/* ২. পণ্য সার্চ ফলাফল */}
                  {searchMode === 'products' && (
                    <>
                      <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                        <span className="text-[9px] font-black text-gray-700">খুঁজে পাওয়া পণ্য:</span>
                        <span className="bg-green-100 text-[#2EAA26] text-[7.5px] font-bold px-2 py-0.5 rounded-full">{productSearchResults.length} টি পণ্য</span>
                      </div>

                      {productSearchResults.length > 0 ? (
                        <div className="grid grid-cols-2 gap-2">
                          {productSearchResults.map((prod) => (
                            <div 
                              key={prod.id} 
                              className="bg-white rounded-2xl border border-gray-200 shadow-2xs overflow-hidden hover:border-emerald-300 transition-all flex flex-col justify-between cursor-pointer group"
                              onClick={() => handleOpenProductDetails(prod)}
                            >
                              <div className="relative h-24 bg-slate-100 overflow-hidden">
                                <img src={prod.image} alt={prod.nameBn} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                                {prod.badge && (
                                  <span className="absolute top-1 left-1 bg-[#2EAA26] text-white text-[7px] font-black px-1.5 py-0.5 rounded-md shadow-xs">
                                    {prod.badge}
                                  </span>
                                )}
                              </div>
                              <div className="p-2 space-y-1">
                                <h4 className="text-[9.5px] font-black text-gray-900 truncate group-hover:text-[#2EAA26]">{prod.nameBn}</h4>
                                <p className="text-[7.5px] text-gray-500 flex items-center gap-0.5">
                                  <MapPin className="w-2 h-2 text-gray-400" /> {prod.origin}
                                </p>
                                <div className="flex items-baseline gap-1">
                                  <span className="text-[10px] font-black text-[#2EAA26]">৳{prod.price}</span>
                                  <span className="text-[7px] text-gray-500 font-bold">/{prod.unit}</span>
                                </div>
                              </div>
                              <div className="p-2 pt-0 flex items-center justify-between gap-1">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleOpenProductDetails(prod);
                                  }}
                                  className="flex-1 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[8px] font-black rounded-lg transition cursor-pointer"
                                >
                                  বিস্তারিত
                                </button>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleAddToCart(prod, 1);
                                  }}
                                  className="p-1 bg-[#2EAA26] hover:bg-emerald-700 text-white rounded-lg transition shadow-2xs cursor-pointer"
                                  title="কার্টে যোগ"
                                >
                                  <ShoppingCart className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="bg-gray-50 p-4 rounded-xl text-center text-gray-400 space-y-1 border border-gray-200">
                          <p className="text-[9px] font-bold text-gray-600">এই ফিল্টারে কোনো পণ্য পাওয়া যায়নি</p>
                          <p className="text-[7.5px] text-gray-500">অন্যান্য ক্যাটাগরি বা জেলা সিলেক্ট করে পুনরায় সার্চ করুন।</p>
                        </div>
                      )}
                    </>
                  )}

                  {/* ৩. ব্লাড ডোনার সার্চ ফলাফল (১০০% ফ্রি মানবিক সেবা) */}
                  {searchMode === 'blood' && (
                    <>
                      <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                        <span className="text-[9px] font-black text-gray-700 flex items-center gap-1">
                          <Droplet className="w-3 h-3 text-red-600" />
                          খুঁজে পাওয়া নিবন্ধিত রক্তদাতা:
                        </span>
                        <span className="bg-red-100 text-red-700 text-[7.5px] font-black px-2 py-0.5 rounded-full">
                          {bloodSearchResults.length} জন রক্তদাতা
                        </span>
                      </div>

                      {/* ১০০% ফ্রি সার্ভিস নোটিশ */}
                      <div className="bg-red-50 border border-red-200 p-2 rounded-xl text-left space-y-0.5">
                        <p className="text-[8px] font-black text-red-800 flex items-center gap-1">
                          <Heart className="w-2.5 h-2.5 text-red-600 fill-red-600" />
                          মানবিক রক্তদান সেবা — কোনো প্রকার সার্ভিস চার্জ বা ফি নেই
                        </p>
                        <p className="text-[7px] text-red-700">
                          জরুরি প্রয়োজনে সরাসরি রক্তদাতার সাথে যোগাযোগ করুন। রক্তদান একটি নিঃস্বার্থ ও মহৎ কাজ।
                        </p>
                      </div>

                      {bloodSearchResults.length > 0 ? (
                        <div className="space-y-2.5">
                          {bloodSearchResults.map((donor) => {
                            const rawPhone = donor.phone ? String(donor.phone).trim() : '';
                            const cleanDigits = rawPhone.replace(/[^0-9+]/g, '');
                            const dialUri = cleanDigits
                              ? (cleanDigits.startsWith('+') 
                                  ? `tel:${cleanDigits}` 
                                  : cleanDigits.startsWith('880') 
                                  ? `tel:+${cleanDigits}` 
                                  : cleanDigits.startsWith('0') 
                                  ? `tel:+88${cleanDigits}` 
                                  : `tel:+880${cleanDigits}`)
                              : 'tel:999';

                            // গোপনীয়তা নীতিমালা অনুযায়ী মোবাইল নম্বর মাস্কড
                            const maskedPhone = cleanDigits.length >= 10
                              ? `${cleanDigits.slice(0, 3)}******${cleanDigits.slice(-2)}`
                              : '০১৮******XX';

                            return (
                              <div 
                                key={donor.id} 
                                className="bg-white p-3 rounded-2xl border border-red-100 hover:border-red-300 shadow-2xs transition-all flex flex-col gap-2.5"
                              >
                                <div className="flex items-start gap-2.5">
                                  <div className="relative shrink-0">
                                    <img 
                                      src={donor.img || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"} 
                                      alt={donor.name} 
                                      className="w-12 h-12 object-cover rounded-xl border border-red-100 shadow-xs" 
                                    />
                                    {donor.verified && (
                                      <div className="absolute -bottom-1 -right-1 bg-red-600 text-white rounded-full p-0.5 shadow-xs" title="NID ভেরিফাইড রক্তদাতা">
                                        <ShieldCheck className="w-2.5 h-2.5" />
                                      </div>
                                    )}
                                  </div>
                                  
                                  <div className="flex-1 min-w-0">
                                    {/* রক্তদাতার নাম ও ব্লাড গ্রুপ সরাসরি প্রদর্শন */}
                                    <div className="flex items-center justify-between gap-1">
                                      <h4 className="text-[11px] font-black text-gray-900 truncate">{donor.name}</h4>
                                      <span className="text-[9px] font-black bg-red-600 text-white px-2 py-0.5 rounded-full shadow-2xs shrink-0 flex items-center gap-0.5">
                                        <Droplet className="w-2.5 h-2.5 fill-white" />
                                        ব্লাড গ্রুপ: {donor.bloodGroup || 'O+'}
                                      </span>
                                    </div>
                                    
                                    <p className="text-[8px] font-bold text-gray-600 truncate mt-0.5">
                                      {donor.job || 'স্বেচ্ছাসেবী রক্তদাতা'}
                                    </p>

                                    {/* জেলা ও উপজেলা সরাসরি কার্ডে প্রদর্শন */}
                                    <div className="grid grid-cols-2 gap-1.5 mt-1.5 bg-stone-50 border border-stone-200/70 rounded-lg p-1.5 text-[8px]">
                                      <div className="flex items-center gap-1 text-stone-700 truncate">
                                        <MapPin className="w-3 h-3 text-red-500 shrink-0" />
                                        <span className="font-medium text-stone-500">জেলা:</span>
                                        <span className="font-bold text-stone-900 truncate">{donor.district || 'খাগড়াছড়ি'}</span>
                                      </div>
                                      <div className="flex items-center gap-1 text-stone-700 truncate">
                                        <MapPin className="w-3 h-3 text-red-500 shrink-0" />
                                        <span className="font-medium text-stone-500">উপজেলা:</span>
                                        <span className="font-bold text-stone-900 truncate">{donor.upazila || 'সদর'}</span>
                                      </div>
                                    </div>

                                    {/* গোপনীয়তা নীতিমালা অনুযায়ী মোবাইল নম্বর মাস্কড বা গোপন রাখা */}
                                    <div className="flex items-center justify-between gap-1 mt-1.5 text-[7.5px] bg-stone-50/90 border border-stone-200/80 rounded-md px-2 py-1">
                                      <div className="flex items-center gap-1 text-stone-600 truncate">
                                        <Lock className="w-2.5 h-2.5 text-stone-500 shrink-0" />
                                        <span>মোবাইল নম্বর:</span>
                                        <span className="font-mono font-bold text-stone-800 tracking-wider">{maskedPhone}</span>
                                      </div>
                                      <span className="text-[6.5px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1 py-0.2 rounded shrink-0">
                                        প্রাইভেসি সুরক্ষিত
                                      </span>
                                    </div>

                                    <div className="flex items-center gap-1.5 mt-1.5">
                                      <span className="text-[6.5px] font-black bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded-md">
                                        ✓ ১০০% ফ্রি মানবিক রক্তদান
                                      </span>
                                      {donor.lastDonationDate && (
                                        <span className="text-[6.5px] text-gray-500 font-bold truncate">
                                          সর্বশেষ রক্তদান: {donor.lastDonationDate}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                </div>

                                {/* জরুরি ডায়ালিং 'Emergency Contact' বাটন */}
                                <div className="pt-1.5 border-t border-gray-100">
                                  <a 
                                    href={dialUri}
                                    className="w-full bg-red-600 hover:bg-red-700 active:bg-red-800 text-white text-[9.5px] sm:text-[10px] font-black py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 shadow-2xs hover:shadow-xs active:scale-[0.99] transition-all cursor-pointer select-none text-center"
                                    title={`${donor.name}-এর সাথে জরুরি যোগাযোগে কল করুন`}
                                  >
                                    <PhoneCall className="w-3.5 h-3.5 animate-pulse" />
                                    <span>জরুরি যোগাযোগ করুন</span>
                                  </a>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="bg-gray-50 p-4 rounded-xl text-center text-gray-500 space-y-1 border border-gray-200">
                          <Droplet className="w-5 h-5 text-gray-300 mx-auto" />
                          <p className="text-[9px] font-bold text-gray-700">এই এলাকায় কোনো রক্তদাতা পাওয়া যায়নি</p>
                          <p className="text-[7.5px] text-gray-500">অন্য রক্তের গ্রুপ নির্বাচন করুন অথবা পার্শ্ববর্তী জেলা/উপজেলা সিলেক্ট করে সার্চ করুন।</p>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}

            </div>

          </div>
        )}

        {/* ================= (গ) ক্যাটাগরি পেজ ================= */}
        {activeTab === 'services' && (
          <div className="p-3 space-y-3">
            <div className="bg-white p-3 rounded-2xl border border-gray-200 shadow-2xs">
              <div className="flex items-center justify-between border-b border-gray-100 pb-2 mb-2">
                <div>
                  <h2 className="text-xs font-black text-gray-900">১৫টি প্রধান ক্যাটাগরি ও ক্যাটালগ</h2>
                  <p className="text-[8px] text-gray-500">আপনার প্রয়োজনীয় সেবা অথবা পণ্য নির্বাচন করুন</p>
                </div>
                <span className="text-[8px] font-bold bg-green-50 text-[#2EAA26] px-2 py-0.5 rounded-full">
                  ১৫টি ক্যাটালগ
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {CATEGORIES_CATALOG.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setSelectedCategoryJob(cat.name);
                      setActiveTab('search');
                      setHasSearched(true);
                    }}
                    className="flex flex-col items-center justify-center p-2.5 bg-slate-50 hover:bg-emerald-50 hover:border-emerald-300 border border-gray-100 rounded-xl transition-all group text-center cursor-pointer"
                  >
                    <div className="p-2 bg-white rounded-xl shadow-2xs group-hover:scale-110 transition-transform">
                      {cat.icon}
                    </div>
                    <span className="text-[8.5px] font-extrabold text-gray-800 group-hover:text-emerald-700 mt-1.5 line-clamp-1 leading-tight">
                      {cat.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* ১১টি গ্রুপে ১০০০+ পেশাজীবী তালিকা ড্রিলডাউন */}
            <div className="bg-white p-3 rounded-2xl border border-gray-200 shadow-2xs space-y-2">
              <h3 className="text-[10px] font-black text-gray-900 flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5 text-[#2EAA26]" />
                পেশাজীবী গ্রুপ ও সেবাসমূহ (১০০০+ পেশা)
              </h3>
              <div className="space-y-1.5">
                {ALL_PROFESSION_CATEGORIES.map((grp, idx) => (
                  <div key={idx} className="border border-gray-100 rounded-xl p-2 bg-slate-50/50">
                    <h4 className="text-[8.5px] font-black text-emerald-800 mb-1">{grp.category}</h4>
                    <div className="flex flex-wrap gap-1">
                      {grp.jobs.slice(0, 4).map((job, jIdx) => (
                        <button
                          key={jIdx}
                          onClick={() => {
                            setSelectedCategoryJob(job);
                            setActiveTab('search');
                            setHasSearched(true);
                          }}
                          className="text-[7.5px] font-medium bg-white hover:bg-[#2EAA26] hover:text-white text-gray-700 border border-gray-200 px-1.5 py-0.5 rounded-md transition-colors cursor-pointer"
                        >
                          {job}
                        </button>
                      ))}
                      <button
                        onClick={() => {
                          setActiveTab('search');
                        }}
                        className="text-[7.5px] font-bold text-[#2EAA26] hover:underline px-1 py-0.5 cursor-pointer"
                      >
                        +আরও {grp.jobs.length - 4}টি...
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= (ঘ) ঝাডিমাটি পার্টনার রেজিস্ট্রেশন ফ্লো (RegistrationFlow - Step 2: Role Selection) ================= */}
        {activeTab === 'registration_flow' && (
          !currentUser ? (
            <SignUpForm
              lang={lang}
              onBack={() => setActiveTab('home')}
              onAuthSuccess={(user, isNew) => {
                handleAuthSuccess(user, isNew);
              }}
              onNavigateToSignIn={() => {
                setActiveTab('signin');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          ) : (
            <div className="p-2 space-y-2">
              <RegistrationFlow
                allDistricts={dynamicDistricts}
                lang={lang}
                currentUser={currentUser}
                onSelectMerchant={() => {
                  selectRole('seller');
                  setActiveTab('track_a_vendor');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onBack={() => setActiveTab('home')}
                onSuccess={(newPro) => {
                  handleSaveProfessionalProfile(newPro as any);
                  selectRole('professional');
                  setShowToast(`অভিনন্দন ${newPro.name}! আপনার রেজিস্ট্রেশন সফল হয়েছে।`);
                  setTimeout(() => setShowToast(''), 4000);
                }}
              />
            </div>
          )
        )}

        {/* ================= (ঙ) এমবেডেড সাইন আপ ও রেজিস্ট্রেশন পেজ (Step 1: নতুন অ্যাকাউন্ট তৈরি করুন) ================= */}
        {activeTab === 'signup' && (
          <div className="w-full max-w-md mx-auto p-1 sm:p-2">
            <SignUpForm
              lang={lang}
              onBack={() => setActiveTab('home')}
              onAuthSuccess={(user, isNew) => {
                handleAuthSuccess(user, isNew);
              }}
              onNavigateToSignIn={() => {
                setActiveTab('signin');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>
        )}

        {/* ================= (ঙ-০) তিন ট্যাব বিশিষ্ট নতুন রেজিস্ট্রেশন পেজ ================= */}
        {activeTab === 'registration' && (
          <div className="w-full max-w-md mx-auto p-0 sm:p-2">
            <RegistrationPage
              lang={lang}
              onLanguageToggle={() => {
                const nextLang = lang === 'bn' ? 'en' : 'bn';
                setLang(nextLang);
              }}
              currentUser={currentUser}
              initialTab={registrationInitialTab}
              isEditMode={registrationIsEditMode}
              onBack={() => setActiveTab((previousTab as any) || 'home')}
              onSuccess={(user) => {
                handleAuthSuccess(user, true);
              }}
              onNavigateToSignIn={() => {
                setActiveTab('signin');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>
        )}

        {/* ================= (ঙ-১) এমবেডেড সাইন ইন পেজ (Clean In-Body Sign In Screen) ================= */}
        {activeTab === 'signin' && (
          <div className="w-full max-w-md mx-auto p-1 sm:p-2">
            <SignInScreen
              lang={lang}
              onBack={() => setActiveTab((previousTab as any) || 'home')}
              onSignInSuccess={(user) => {
                handleSignInSuccess(user);
              }}
              onNavigateToSignUp={() => {
                setActiveTab('registration');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>
        )}

        {/* ================= (ঙ-২) রেজিস্ট্রেশন ফ্লো (Registration Flow) ================= */}
        {activeTab === 'registration_flow' && (
          <div className="w-full max-w-md mx-auto p-1 sm:p-2">
            <RegistrationFlow
              lang={lang}
              currentUser={currentUser}
              onBack={() => setActiveTab((previousTab as any) || 'home')}
              onSuccess={() => setActiveTab('profile')}
              onSelectMerchant={() => setActiveTab('track_a_vendor')}
            />
          </div>
        )}

        {/* ================= (ঙ-৩) রোল সিলেকশন (Role Selection Modal / View) ================= */}
        {activeTab === 'role_select' && (
          <div className="w-full max-w-md mx-auto p-2 sm:p-4 flex flex-col items-center justify-start">
            <div className="w-full mb-3 flex items-center justify-between px-1">
              <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                {lang === 'bn' ? 'অ্যাকাউন্ট নির্বাচন' : 'Account Role Selection'}
              </span>
              <button
                type="button"
                onClick={() => setActiveTab('home')}
                className="text-xs text-stone-500 hover:text-stone-800 font-medium transition cursor-pointer p-1"
              >
                {lang === 'bn' ? 'হোমে যান' : 'Cancel'}
              </button>
            </div>
            <RoleSelectionModal
              userName={currentUser?.name}
              onSelect={(role) => {
                if (role === 'service') {
                  selectRole('professional');
                  setActiveTab('sp_form');
                } else if (role === 'merchant') {
                  selectRole('seller');
                  setActiveTab('track_a_vendor');
                } else {
                  setActiveTab('profile');
                }
              }}
              onNavigateToServiceProviderForm={() => setActiveTab('sp_form')}
              onNavigateToMerchantDashboard={() => setActiveTab('track_a_vendor')}
            />
          </div>
        )}

        {/* ================= (ঙ-৪) সার্ভিস প্রোভাইডার রেজিস্ট্রেশন ফর্ম (SP Registration Form) ================= */}
        {activeTab === 'sp_form' && (
          <div className="w-full max-w-md mx-auto p-1 sm:p-2">
            <ServiceProviderRegistrationForm
              currentUser={currentUser}
              initialData={activeSpProfileData || userProfessionalProfile || currentUser}
              isEditMode={Boolean(activeSpProfileData || userProfessionalProfile)}
              onSubmitSuccess={(data) => {
                setActiveSpProfileData(data);
                if (typeof saveProfessionalProfile === 'function') {
                  saveProfessionalProfile(data);
                }
                setShowToast('✅ প্রোফাইল তথ্য সফলভাবে আপডেট করা হয়েছে!');
                setActiveTab('sp_profile');
              }}
              onSuccess={(data) => {
                setActiveSpProfileData(data);
                if (typeof saveProfessionalProfile === 'function') {
                  saveProfessionalProfile(data);
                }
                setActiveTab('sp_profile');
              }}
              onBack={() => setActiveTab(activeSpProfileData || userProfessionalProfile ? 'sp_profile' : 'role_select')}
              lang={lang}
            />
          </div>
        )}

        {/* ================= (ঙ-৫) সার্ভিস প্রোভাইডার প্রোফাইল (SP Public Profile) ================= */}
        {activeTab === 'sp_profile' && (
          <div className="w-full max-w-md mx-auto p-1 sm:p-2">
            <ServiceProviderProfile
              profileData={activeSpProfileData || userProfessionalProfile || currentUser}
              currentUser={currentUser}
              isOwner={
                activeSpProfileData
                  ? Boolean(currentUser && (currentUser.id === activeSpProfileData.id || currentUser.id === activeSpProfileData.memberUID || (currentUser.phone && currentUser.phone === activeSpProfileData.phone)))
                  : Boolean(userProfessionalProfile || currentUser)
              }
              onEditProfile={(editData) => {
                handleEditProfileRoleBased(editData || activeSpProfileData || userProfessionalProfile || currentUser);
              }}
              onNavigateDashboard={() => setActiveTab('profile')}
              onSignOut={handleLogout}
              onDeleteAccount={() => {
                setActiveSpProfileData(null);
                handleLogout();
              }}
              onBack={() => setActiveTab('home')}
              onNavigateSignIn={() => setActiveTab('signin')}
              onBookService={(p) => {
                setShowToast(`🎉 ${p.fullName || p.name || 'সেবাদাতা'}-এর সার্ভিস সফলভাবে বুকিং অনুরোধ পাঠানো হয়েছে!`);
              }}
              onOpenChat={(proName) => {
                setShowToast(`💬 ${proName}-এর সাথে ইনবক্স চ্যাট সংযুক্ত হচ্ছে...`);
              }}
              lang={lang}
            />
          </div>
        )}

        {/* ================= (ঙ-২) এমবেডেড অনবোর্ডিং ও রোল সিলেকশন পেজ (Step 2: Role Setup) ================= */}
        {activeTab === 'track_selection' && (
          !currentUser ? (
            <SignInScreen
              lang={lang}
              onBack={() => setActiveTab((previousTab as any) || 'home')}
              onSignInSuccess={(user) => {
                handleSignInSuccess(user);
              }}
              onNavigateToSignUp={() => {
                setActiveTab('signup');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          ) : (
            <EmbeddedTrackSelectionPage
              lang={lang}
              currentUser={currentUser}
              userName={currentUser?.name}
              onSelectTrack={(track, extraData) => handleSelectTrack(track, extraData)}
              onBack={() => setActiveTab('home')}
            />
          )
        )}

        {/* ================= (চ) ট্র্যাক এ: সেলার স্টোরফ্রন্ট ও ইনভেন্টরি ম্যানেজমেন্ট ================= */}
        {activeTab === 'track_a_vendor' && (
          !currentUser ? (
            <SignInScreen
              lang={lang}
              onBack={() => setActiveTab((previousTab as any) || 'home')}
              onSignInSuccess={(user) => {
                handleSignInSuccess(user);
              }}
              onNavigateToSignUp={() => {
                setActiveTab('signup');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          ) : (
            <CleanMerchantPage
              lang={lang}
              store={selectedVendorStore || activeVendorStores[0] || vendorStores[0]}
              currentUserRole={userRole === 'seller' ? 'merchant' : 'customer'}
              isOwner={true}
              isAdmin={(currentUser?.role as string) === 'admin'}
              onBack={() => setActiveTab('home')}
              onAddToCart={(prod, qty) => handleAddToCart(prod as any, qty)}
              onViewProductDetail={(prod) => handleOpenProductDetails(prod)}
            />
          )
        )}

        {/* ================= (ছ) ট্র্যাক বি: প্রফেশনাল সার্ভিস প্রোফাইল বিল্ডার ================= */}
        {activeTab === 'track_b_freelancer' && (
          <EmbeddedServiceProfileBuilder
            lang={lang}
            currentUser={currentUser}
            onBack={() => setActiveTab('home')}
            onComplete={(savedProfile) => {
              handleSaveProfessionalProfile(savedProfile);
              setActiveTab('freelancer_dashboard');
            }}
          />
        )}

        {/* ================= (জ) ট্র্যাক বি: প্রাইভেট ফ্রিল্যান্সার ড্যাশবোর্ড ও এসক্রো ওয়ালেট ================= */}
        {activeTab === 'freelancer_dashboard' && (
          <EmbeddedFreelancerDashboard
            lang={lang}
            professional={userProfessionalProfile || professionals[0]}
            onBack={() => setActiveTab('home')}
            onEditPortfolio={() => setActiveTab('track_b_freelancer')}
          />
        )}

        {/* ================= (ঝ) প্রোফাইল পেজ (Auth-Gated & Dual Profile Dashboard) ================= */}
        {activeTab === 'profile' && (
          <div className="p-2 space-y-2">
            {currentUser ? (
              <UserProfileDashboard 
                currentUser={currentUser}
                onUpdateCurrentUser={(updated) => {
                  updateUser(updated);
                  setShowToast(lang === 'bn' ? 'প্রোফাইল তথ্য সফলভাবে আপডেট হয়েছে!' : 'Profile updated successfully!');
                  setTimeout(() => setShowToast(''), 3000);
                }}
                onLogout={handleLogout}
                allDistricts={ALL_BANGLADESH_DISTRICTS}
                professionCategories={ALL_PROFESSION_CATEGORIES}
                onAddNewProduct={handleAddNewProduct}
                onSaveProfessionalProfile={handleSaveProfessionalProfile}
                userProducts={userSellerProducts}
                userProfessionalProfile={userProfessionalProfile}
                onViewProductDetail={(prod) => handleOpenProductDetails(prod)}
                onNavigateHome={() => setActiveTab('home')}
                onNavigateToServiceProviderForm={(proData) => {
                  handleEditProfileRoleBased(proData || currentUser);
                }}
                onDeleteAccount={() => {
                  setActiveSpProfileData(null);
                  handleLogout();
                }}
                initialTab={activeProfileTab}
                lang={lang}
                onNavigateToPujaGift={() => {
                  setPreviousTab('profile');
                  setActiveTab('puja_gift');
                  window.history.pushState({}, '', '/portal/puja-gift-apply');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            ) : (
              <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-xs text-center space-y-4 my-2 max-w-md mx-auto">
                <div className="w-14 h-14 mx-auto bg-gray-100 text-gray-900 rounded-2xl flex items-center justify-center">
                  <User className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-gray-950">{t.login} / {t.register}</h3>
                  <p className="text-xs text-gray-500 max-w-xs mx-auto leading-relaxed">
                    {lang === 'bn' 
                      ? 'পণ্য বিক্রির জন্য পার্টনারশিপ সেলার প্রোফাইল অথবা সেবা প্রদানের পেশাজীবী পোর্টফোলিও তৈরি করতে সাইন ইন করুন।'
                      : 'Sign in to create a partnership seller profile or service professional portfolio.'}
                  </p>
                </div>

                <div className="pt-2 space-y-2.5">
                  <button
                    onClick={() => setActiveTab('signin')}
                    className="w-full py-3 bg-gray-900 hover:bg-black active:scale-[0.99] text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>{lang === 'bn' ? 'লগইন করুন' : 'Sign In'}</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('signup')}
                    className="w-full py-2.5 bg-white hover:bg-gray-50 text-gray-800 border border-gray-300 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <UserPlus className="w-4 h-4 text-gray-700" />
                    <span>{lang === 'bn' ? 'নতুন একাউন্ট তৈরি করুন' : 'Create New Account'}</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('home')}
                    className="w-full py-2 text-gray-500 hover:text-gray-900 text-xs font-medium cursor-pointer"
                  >
                    {t.backToHome}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= (ঞ) ইন-অ্যাপ সিঙ্গেল পেজ প্রোডাক্ট ডিটেইলস ভিউ (In-App Single Page Product Details View) ================= */}
        {activeTab === 'product_details' && formattedDetailProduct && (
          <div className="p-2 pb-6">
            <ProductDetailsScreen
              product={formattedDetailProduct}
              lang={lang}
              onBack={() => {
                setActiveTab(previousTab as any || 'home');
              }}
              onAddToCart={(item, qty) => {
                if (selectedDetailProduct) {
                  handleAddToCart(selectedDetailProduct, qty);
                } else {
                  const fallbackProd = STORE_PRODUCTS.find(p => p.id === item.id) || STORE_PRODUCTS[0];
                  handleAddToCart(fallbackProd, qty);
                }
              }}
              onBuyNow={(item, qty) => {
                if (selectedDetailProduct) {
                  handleAddToCart(selectedDetailProduct, qty);
                } else {
                  const fallbackProd = STORE_PRODUCTS.find(p => p.id === item.id) || STORE_PRODUCTS[0];
                  handleAddToCart(fallbackProd, qty);
                }
                setIsCartModalOpen(true);
              }}
              onOpenCart={() => setIsCartModalOpen(true)}
              cartCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
            />
          </div>
        )}

        {/* ================= (ট) স্মার্ট অটো-ক্যাটাগরি ডিরেক্টরি মার্কেটপ্লেস (Automated Multi-Vendor Profile Assignment) ================= */}
        {activeTab === 'auto_directory' && (
          <div className="p-2 pb-6">
            <DynamicAutoRoutingSystem 
              onBackToMain={() => setActiveTab(previousTab as any || 'home')}
              lang={lang}
            />
          </div>
        )}

        {/* ================= (ঠ) মাস্টার সুপার-অ্যাডমিন ড্যাশবোর্ড ও মডারেশন কন্ট্রোল (Super Admin) ================= */}
        {activeTab === 'super_admin' && (
          <div className="p-1 sm:p-2 pb-8">
            <SuperAdminDashboard 
              onBackToApp={() => setActiveTab(previousTab as any || 'home')}
              lang={lang}
            />
          </div>
        )}

        {/* ================= (ড) পূজা উৎসব উপহার আবেদন ফর্ম (Puja Gift Welfare Application) ================= */}
        {activeTab === 'puja_gift' && (
          <div className="pb-8">
            <PujaGiftApplicationForm 
              currentUser={currentUser}
              lang={lang}
              onBack={() => {
                if (window.history.length > 1) {
                  window.history.back();
                }
                setActiveTab(previousTab as any || 'home');
              }}
              onSuccess={(app) => {
                setShowToast(
                  lang === 'bn' 
                    ? `পূজা উপহার আবেদন সফলভাবে জমা হয়েছে! ট্র্যাকিং নম্বর: ${app.id.slice(0, 8).toUpperCase()}` 
                    : `Puja gift application submitted! Tracking ID: ${app.id.slice(0, 8).toUpperCase()}`
                );
                setTimeout(() => setShowToast(''), 4000);
              }}
            />
          </div>
        )}

        {/* Render Official Brand Footer STRICTLY on the Customer Home Page ONLY */}
        {activeTab === 'home' && (
          <Footer 
            lang={lang} 
            onCategoriesClick={() => setActiveTab('services')}
            onSearchClick={() => setActiveTab('search')}
            onPostClick={handleRegisterNavigation}
            onAdminClick={onNavigateToAdmin}
          />
        )}

      </main>

      {/* ৩. বটম নেভিগেশন বার (Full-Width Edge-to-Edge, Slim, Harmonious #009f4d Green Bar) */}
      <nav 
        className="sticky bottom-0 left-0 right-0 z-50 shrink-0 w-full bg-[#009f4d] text-white border-t border-[#008c43] shadow-[0_-2px_10px_rgba(0,0,0,0.06)] m-0 pointer-events-auto"
        style={{
          backgroundColor: '#009f4d',
          paddingBottom: 'env(safe-area-inset-bottom, 0px)',
          paddingLeft: 'env(safe-area-inset-left, 0px)',
          paddingRight: 'env(safe-area-inset-right, 0px)',
        }}
        id="customer-bottom-navigation"
      >
        <div className="w-full h-11 sm:h-12 grid grid-cols-5 items-center justify-items-center px-1">
          {/* Slot 1 (Far Left): Home */}
          <button 
            type="button"
            onClick={() => {
              setActiveTab('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }} 
            className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
            id="nav-tab-home"
            title={lang === 'en' ? 'Home' : 'হোম'}
          >
            <div className={`transition-colors flex items-center justify-center ${activeTab === 'home' ? 'text-amber-300' : 'text-white/85 group-hover:text-white'}`}>
              <Home className="w-4 h-4 stroke-[2.2]" />
            </div>
            <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${activeTab === 'home' ? 'font-bold text-amber-300' : 'font-medium text-white/90'}`}>
              {t.navHome}
            </span>
          </button>

          {/* Slot 2: Jhadimadi (Chat/Messaging icon, label "ঝাদিমাধি" / "Jhadimadi", opens AI chat overlay) */}
          <button 
            type="button"
            onClick={() => {
              setIsJhadimadiChatOpen(true);
            }} 
            className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none relative"
            title="ঝাদিমাধি এআই মেসেজিং ও সাপোর্ট"
            id="nav-tab-jhadimadi"
          >
            <div className={`transition-colors flex items-center justify-center relative ${isJhadimadiChatOpen ? 'text-amber-300' : 'text-white/85 group-hover:text-white'}`}>
              <MessageSquare className="w-4 h-4 stroke-[2.2]" />
              <span className="absolute -top-1 -right-2 bg-amber-400 text-slate-950 text-[6.5px] font-black px-1 rounded-full leading-none shadow-2xs">
                AI
              </span>
            </div>
            <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${isJhadimadiChatOpen ? 'font-bold text-amber-300' : 'font-medium text-white/90'}`}>
              {lang === 'en' ? 'Jhadimadi' : 'ঝাদিমাধি'}
            </span>
          </button>

          {/* Slot 3 (Center): Registration */}
          <button 
            type="button"
            onClick={handleRegisterNavigation} 
            className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
            title={lang === 'bn' ? 'রেজিস্ট্রেশন বা একাউন্ট রোল নির্বাচন' : 'Registration or Account Role Selection'}
            id="nav-tab-register-action"
          >
            <div className={`transition-colors flex items-center justify-center ${
              activeTab === 'registration' || activeTab === 'track_selection' || activeTab === 'registration_flow' || activeTab === 'signup' || activeTab === 'role_select' || activeTab === 'sp_form' 
                ? 'text-amber-300' 
                : 'text-white/85 group-hover:text-white'
            }`}>
              <UserPlus className="w-4 h-4 stroke-[2.2]" />
            </div>
            <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${
              activeTab === 'registration' || activeTab === 'track_selection' || activeTab === 'registration_flow' || activeTab === 'signup' || activeTab === 'role_select' || activeTab === 'sp_form' 
                ? 'font-bold text-amber-300' 
                : 'font-medium text-white/90'
            }`}>
              {t.navRegister}
            </span>
          </button>

          {/* Slot 4: Search */}
          <button 
            type="button"
            onClick={() => {
              setActiveTab('search');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }} 
            className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
            id="nav-tab-search"
            title={lang === 'en' ? 'Search' : 'সার্চ'}
          >
            <div className={`transition-colors flex items-center justify-center ${activeTab === 'search' ? 'text-amber-300' : 'text-white/85 group-hover:text-white'}`}>
              <Search className="w-4 h-4 stroke-[2.2]" />
            </div>
            <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${activeTab === 'search' ? 'font-bold text-amber-300' : 'font-medium text-white/90'}`}>
              {t.navSearch}
            </span>
          </button>

          {/* Slot 5 (Far Right): Profile (Strictly retained) */}
          <button 
            type="button"
            onClick={() => {
              setActiveTab('profile');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }} 
            className="w-full h-full flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer select-none group focus:outline-none"
            title={lang === 'bn' ? 'আমার প্রোফাইল' : 'Profile'}
            id="nav-tab-profile"
          >
            <div className={`transition-colors flex items-center justify-center ${activeTab === 'profile' ? 'text-amber-300' : 'text-white/85 group-hover:text-white'}`}>
              {currentUser?.avatar ? (
                <img 
                  src={currentUser.avatar} 
                  alt="Profile" 
                  className="w-4 h-4 rounded-full object-cover ring-1 ring-white" 
                />
              ) : (
                <User className="w-4 h-4 stroke-[2.2]" />
              )}
            </div>
            <span className={`text-[9px] sm:text-[9.5px] tracking-tight text-center leading-none mt-0.5 whitespace-nowrap truncate max-w-full px-0.5 ${activeTab === 'profile' ? 'font-bold text-amber-300' : 'font-medium text-white/90'}`}>
              {lang === 'en' ? 'Profile' : 'প্রোফাইল'}
            </span>
          </button>
        </div>
      </nav>

      {/* ধাপ ১: দ্রুত সাইন আপ ও লগইন মডাল (Facebook/Google/Email Quick Auth Modal) */}
      <QuickAuthModal 
        isOpen={isAuthModalOpen}
        onClose={closeAuthModal}
        onAuthSuccess={(user, isNewSignUp) => {
          handleAuthSuccess(user, isNewSignUp);
        }}
        initialNotice={authNoticeMessage}
        initialMode={authModalInitialMode}
        lang={lang}
      />

      {/* মার্চেন্ট স্টোরফ্রন্ট ও এসক্রো ওয়ালেট মডাল (Track A Vendor Storefront Modal) */}
      {selectedVendorStore && (
        <VendorStorefrontModal
          isOpen={!!selectedVendorStore}
          vendor={selectedVendorStore}
          onClose={() => setSelectedVendorStore(null)}
          onAddToCart={(prod, qty) => {
            handleAddToCart(prod as any, qty);
          }}
          onBuyNow={(prod, qty) => {
            handleAddToCart(prod as any, qty);
            setSelectedVendorStore(null);
            setIsCartModalOpen(true);
          }}
          lang={lang}
        />
      )}

      {/* শপিং কার্ট ও চেকআউট ড্রয়ার মডাল (Cart & Checkout Drawer) */}
      <CartDrawerModal 
        isOpen={isCartModalOpen}
        onClose={() => setIsCartModalOpen(false)}
        cartItems={cartItems}
        onUpdateQty={handleUpdateCartQty}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        lang={lang}
      />

      {/* নোটিফিকেশন মডাল (Real Notifications Modal - Clean without fake badges) */}
      {isNotificationModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[80vh]">
            <div className="bg-[#0A6A32] px-4 py-3 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-300" />
                <h3 className="text-sm font-black tracking-wide">
                  {lang === 'bn' ? 'নোটিফিকেশন' : 'Notifications'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsNotificationModalOpen(false)}
                className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="p-4 overflow-y-auto flex-1 divide-y divide-gray-100">
              {notificationsList.length === 0 ? (
                <div className="py-8 text-center space-y-2">
                  <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto border border-emerald-100">
                    <Bell className="w-6 h-6 stroke-[1.5]" />
                  </div>
                  <h4 className="text-xs font-bold text-gray-800">
                    {lang === 'bn' ? 'কোনো অপঠিত নোটিফিকেশন নেই' : 'No unread notifications'}
                  </h4>
                  <p className="text-[10px] text-gray-500 max-w-[220px] mx-auto leading-relaxed">
                    {lang === 'bn' 
                      ? 'আপনার অর্ডার, সেবা বুকিং ও অ্যাকাউন্টের সাম্প্রতিক আপডেটগুলো এখানে দেখতে পাবেন।'
                      : 'Your orders, service bookings, and account updates will appear here.'}
                  </p>
                </div>
              ) : (
                notificationsList.map((notif) => (
                  <div key={notif.id} className="py-2.5 first:pt-0 last:pb-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs font-bold text-gray-900">{notif.title}</h4>
                      {!notif.is_read && (
                        <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0 mt-1" />
                      )}
                    </div>
                    <p className="text-[11px] text-gray-600 mt-0.5">{notif.body}</p>
                    <span className="text-[9px] text-gray-400 mt-1 block">
                      {new Date(notif.created_at).toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US')}
                    </span>
                  </div>
                ))
              )}
            </div>

            {notificationsList.length > 0 && unreadNotificationsCount > 0 && (
              <div className="p-3 bg-stone-50 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => {
                    setNotificationsList(prev => prev.map(n => ({ ...n, is_read: true })));
                    setUnreadNotificationsCount(0);
                    setShowToast(lang === 'bn' ? 'সব নোটিফিকেশন পড়া হয়েছে' : 'All marked as read');
                    setTimeout(() => setShowToast(''), 2000);
                  }}
                  className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  {lang === 'bn' ? 'সবগুলো পড়া হয়েছে হিসেবে চিহ্নিত করুন' : 'Mark all as read'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* গ্লোবাল পেশাজীবী পোর্টফোলিও ও রিভিউ মডাল (Track B Portfolio & Public Modal) */}
      <WorkerProfileModal 
        isOpen={!!selectedWorkerProfile}
        provider={selectedWorkerProfile}
        currentUser={currentUser}
        onClose={() => setSelectedWorkerProfile(null)}
        onBookService={(p) => {
          setSelectedWorkerProfile(null);
          setShowToast(`🎉 ${p.name || 'সেবাদাতা'}-এর সার্ভিস সফলভাবে বুকিং অনুরোধ পাঠানো হয়েছে!`);
        }}
        onOpenChat={(proName) => {
          setSelectedWorkerProfile(null);
          setShowToast(`💬 ${proName}-এর সাথে ইনবক্স চ্যাট সংযুক্ত হচ্ছে...`);
        }}
        lang={lang}
      />

      {/* Jhadimadi AI Messaging Overlay Modal */}
      <JhadimadiChatModal
        isOpen={isJhadimadiChatOpen}
        onClose={() => setIsJhadimadiChatOpen(false)}
        lang={lang}
        currentUser={currentUser}
        onAddToCart={(prod, qty) => handleAddToCart(prod as any, qty || 1)}
        onDirectOrder={(prod) => {
          handleAddToCart(prod as any, 1);
          setIsCartModalOpen(true);
        }}
        onOpenProductDetails={(prod) => handleOpenProductDetails(prod as any)}
        onOpenNidVerification={() => {
          setIsJhadimadiChatOpen(false);
          setGeminiModalTab('nid');
          setIsGeminiModalOpen(true);
        }}
      />

      {/* Gemini AI Assistant & NID Verification Modal */}
      <GeminiAssistantModal
        isOpen={isGeminiModalOpen}
        onClose={() => setIsGeminiModalOpen(false)}
        lang={lang}
        initialTab={geminiModalTab}
        currentUser={currentUser}
        onAddToCart={(prod) => handleAddToCart(prod as any, 1)}
        onOpenProductDetails={(prod) => handleOpenProductDetails(prod)}
        onVerificationSuccess={(nidData) => {
          if (currentUser) {
            updateUser({
              ...currentUser,
              isNidVerified: true,
              nidNumber: nidData.nidNumber,
            });
          }
          setShowToast('🎉 জাতীয় পরিচয়পত্র (NID) সফলভাবে ভেরিফাই হয়েছে!');
        }}
      />

      {/* পোস্ট-সাইন আপ / পোস্ট-লগইন রোল সিলেকশন মডাল */}
      <RoleSelectionModal
        isOpen={isRoleModalOpen}
        onClose={closeRoleModal}
        userName={currentUser?.name}
        lang={lang}
        onSelect={(roleType) => {
          closeRoleModal();
          if (roleType === 'merchant') {
            selectRole('seller');
            if (onNavigateToMerchant) {
              onNavigateToMerchant();
            } else {
              setActiveTab('track_a_vendor');
            }
            setShowToast(lang === 'bn' ? 'মার্চেন্ট ড্যাশবোর্ড প্রস্তুত — পণ্য পরিচালনা করুন!' : 'Merchant dashboard ready!');
          } else {
            selectRole('professional');
            if (onNavigateToServiceProvider) {
              onNavigateToServiceProvider();
            } else {
              setActiveTab('registration_flow');
            }
            setShowToast(lang === 'bn' ? 'সার্ভিস প্রোভাইডার রেজিস্ট্রেশন ফর্ম পূরণ করুন!' : 'Please complete provider registration form!');
          }
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onNavigateToMerchantDashboard={() => {
          closeRoleModal();
          selectRole('seller');
          if (onNavigateToMerchant) {
            onNavigateToMerchant();
          } else {
            setActiveTab('track_a_vendor');
          }
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onNavigateToServiceProviderForm={() => {
          closeRoleModal();
          selectRole('professional');
          if (onNavigateToServiceProvider) {
            onNavigateToServiceProvider();
          } else {
            setActiveTab('registration_flow');
          }
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* ডেডিকেটেড সোর্স (জরুরি ৯৯৯ ও জাতীয় তথ্য সেবা) মডাল */}
      {isSourceModalOpen && (
        <div className="fixed inset-0 z-[60] bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl border border-red-100 flex flex-col text-left">
            {/* মডাল হেডার */}
            <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 p-4 text-white rounded-t-3xl relative">
              <button
                type="button"
                onClick={() => setIsSourceModalOpen(false)}
                className="absolute top-3.5 right-3.5 bg-black/20 hover:bg-black/40 text-white rounded-full p-1.5 transition-colors cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-2.5">
                <div className="bg-white text-red-600 p-2.5 rounded-2xl shadow-sm">
                  <Siren className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <span className="text-[8px] font-black uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full backdrop-blur-xs">
                    জরুরি সোর্স ডিরেক্টরি
                  </span>
                  <h3 className="text-base sm:text-lg font-black mt-0.5 text-white">জাতীয় জরুরি সেবা ও হটলাইন</h3>
                </div>
              </div>
            </div>

            {/* মডাল বডি */}
            <div className="p-4 sm:p-5 space-y-4">
              
              {/* প্রধান বার্তা (ব্যবহারকারীর চাহিদামাফিক অবিকল টেক্সট) */}
              <div className="bg-red-50 border-2 border-red-300 p-4 rounded-2xl text-center space-y-2 shadow-xs">
                <div className="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center mx-auto shadow-sm">
                  <PhoneCall className="w-5 h-5 animate-bounce" />
                </div>
                <h4 className="text-sm sm:text-base font-black text-red-700">জরুরি হেল্পলাইন ৯৯৯ (টোল ফ্রি)</h4>
                <p className="text-[11px] sm:text-xs font-bold text-gray-800 leading-relaxed px-1">
                  "জরুরি ভিত্তিতে যেকোনো জায়গায় পুলিশ, অ্যাম্বুলেন্স এবং ফায়ার সার্ভিস দরকার হলে 999 এ কল করুন। যেকোনো জায়গা থেকে 999 এ কল করলেই আপনি পুলিশ, অ্যাম্বুলেন্স এবং ফায়ার সার্ভিস পেয়ে যাবেন।"
                </p>
                
                {/* সরাসরি ৯৯৯ কল বাটন */}
                <div className="pt-2">
                  <a
                    href="tel:999"
                    className="inline-flex items-center justify-center gap-2 w-full py-3 bg-red-600 hover:bg-red-700 text-white text-sm font-black rounded-xl shadow-md active:scale-95 transition-all cursor-pointer"
                  >
                    <Phone className="w-4 h-4 fill-white" />
                    <span>সরাসরি 999 এ কল করুন</span>
                  </a>
                </div>
              </div>

              {/* ৩টি প্রধান সেবা কার্ড */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {/* পুলিশ */}
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl space-y-1">
                  <div className="flex items-center gap-1.5 text-blue-800 font-black text-xs">
                    <ShieldCheck className="w-4 h-4 text-blue-600" />
                    <span>বাংলাদেশ পুলিশ</span>
                  </div>
                  <p className="text-[9px] text-gray-600 leading-tight">
                    আইন-শৃঙ্খলা রক্ষা, নিরাপত্তা বা জরুরি আইনি সহায়তায় তাৎক্ষণিক ৯৯৯ এ কল করুন।
                  </p>
                  <a
                    href="tel:999"
                    className="inline-block mt-1 text-[8.5px] font-black text-blue-700 hover:underline"
                  >
                    কল: 999 ➔
                  </a>
                </div>

                {/* অ্যাম্বুলেন্স */}
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl space-y-1">
                  <div className="flex items-center gap-1.5 text-rose-800 font-black text-xs">
                    <Activity className="w-4 h-4 text-rose-600" />
                    <span>অ্যাম্বুলেন্স সার্ভিস</span>
                  </div>
                  <p className="text-[9px] text-gray-600 leading-tight">
                    জরুরি রোগী পরিবহন, অক্সিজেন ও আইসিইউ লাইফ সাপোর্টের জন্য ৯৯৯ এ যোগাযোগ করুন।
                  </p>
                  <a
                    href="tel:999"
                    className="inline-block mt-1 text-[8.5px] font-black text-rose-700 hover:underline"
                  >
                    কল: 999 ➔
                  </a>
                </div>

                {/* ফায়ার সার্ভিস */}
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl space-y-1">
                  <div className="flex items-center gap-1.5 text-amber-900 font-black text-xs">
                    <Flame className="w-4 h-4 text-amber-600" />
                    <span>ফায়ার সার্ভিস</span>
                  </div>
                  <p className="text-[9px] text-gray-600 leading-tight">
                    অগ্নিকাণ্ড, সড়ক দুর্ঘটনা ও যে কোনো উদ্ধার অভিযানে ৯৯৯ বা ১৬১৬৩ এ কল করুন।
                  </p>
                  <a
                    href="tel:16163"
                    className="inline-block mt-1 text-[8.5px] font-black text-amber-700 hover:underline"
                  >
                    কল: 16163 ➔
                  </a>
                </div>
              </div>

              {/* জাতীয় গুরুত্বপূর্ণ হটলাইন তালিকা */}
              <div className="space-y-1.5 pt-1 border-t border-gray-100">
                <h5 className="text-[10px] font-black text-gray-800">অন্যান্য জরুরি সরকারি সেবা নম্বর:</h5>
                <div className="grid grid-cols-2 gap-2 text-[9px]">
                  <div className="p-2 bg-gray-50 rounded-xl border border-gray-200 flex items-center justify-between">
                    <div>
                      <p className="font-black text-gray-900">৩৩৩ (333)</p>
                      <p className="text-[7.5px] text-gray-500">জাতীয় তথ্য ও সেবা</p>
                    </div>
                    <a href="tel:333" className="bg-slate-200 hover:bg-slate-300 text-gray-800 px-2 py-1 rounded-lg font-black text-[8px]">কল</a>
                  </div>

                  <div className="p-2 bg-gray-50 rounded-xl border border-gray-200 flex items-center justify-between">
                    <div>
                      <p className="font-black text-gray-900">১০৯ (109)</p>
                      <p className="text-[7.5px] text-gray-500">নারী ও শিশু নির্যাতন প্রতিরোধ</p>
                    </div>
                    <a href="tel:109" className="bg-slate-200 hover:bg-slate-300 text-gray-800 px-2 py-1 rounded-lg font-black text-[8px]">কল</a>
                  </div>

                  <div className="p-2 bg-gray-50 rounded-xl border border-gray-200 flex items-center justify-between">
                    <div>
                      <p className="font-black text-gray-900">১০৯৮ (1098)</p>
                      <p className="text-[7.5px] text-gray-500">চাইল্ড হেল্পলাইন (শিশু সহায়তা)</p>
                    </div>
                    <a href="tel:1098" className="bg-slate-200 hover:bg-slate-300 text-gray-800 px-2 py-1 rounded-lg font-black text-[8px]">কল</a>
                  </div>

                  <div className="p-2 bg-gray-50 rounded-xl border border-gray-200 flex items-center justify-between">
                    <div>
                      <p className="font-black text-gray-900">১০৬ (106)</p>
                      <p className="text-[7.5px] text-gray-500">দুদক (দুর্নীতি দমন কমিশন)</p>
                    </div>
                    <a href="tel:106" className="bg-slate-200 hover:bg-slate-300 text-gray-800 px-2 py-1 rounded-lg font-black text-[8px]">কল</a>
                  </div>
                </div>
              </div>

            </div>

            {/* মডাল ফুটার */}
            <div className="p-3 bg-gray-50 rounded-b-3xl border-t border-gray-100 text-center">
              <button
                type="button"
                onClick={() => setIsSourceModalOpen(false)}
                className="w-full py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-black text-xs rounded-xl transition cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
