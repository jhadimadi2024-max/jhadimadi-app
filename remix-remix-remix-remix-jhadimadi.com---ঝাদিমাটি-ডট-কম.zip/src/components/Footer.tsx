import React from 'react';
import { translations, Language } from '../utils/translations';
import { MapPin, Mail, MessageCircle, ShieldCheck } from 'lucide-react';

interface FooterProps {
  lang?: Language;
  onCategoriesClick?: () => void;
  onSearchClick?: () => void;
  onPostClick?: () => void;
  onAdminClick?: () => void;
}

/**
 * Jhadimadi.com Compact Official Footer
 * Restrictedly rendered strictly on the Customer Home Page.
 */
export const Footer: React.FC<FooterProps> = ({ 
  lang = 'bn',
  onAdminClick
}) => {
  const runnerImgSrc = "https://i.ibb.co.com/sppWZhc9/logo33.png";

  return (
    <footer 
      id="customer-app-footer"
      className="bg-[#F8FAF8] text-slate-700 py-3 px-3 border-t border-[#e2e8f0] pb-6 mt-2 transition-all select-none"
    >
      <div className="max-w-md mx-auto text-center space-y-2.5">
        
        {/* ১. হেডার / ব্র্যান্ডিং: লোগো + টেক্সট পাশাপাশি + ট্যাগলাইন */}
        <div className="flex items-center justify-center gap-2">
          {/* Logo icon */}
          <div className="w-7 h-7 rounded-lg bg-white p-0.5 shadow-2xs border border-emerald-200/80 flex items-center justify-center shrink-0">
            <img
              src={runnerImgSrc}
              alt="Jhadimadi Logo"
              className="w-full h-full object-contain"
              onError={(e) => {
                // Fallback to local image if external fails
                (e.currentTarget as HTMLImageElement).src = "/runner-logo.png";
              }}
            />
          </div>

          {/* Brand Name & Tagline */}
          <div className="text-left leading-tight">
            <div className="flex items-center gap-1">
              <span className="text-xs font-black text-emerald-950 font-sans tracking-tight">
                Jhadimadi.com
              </span>
              <span className="text-gray-400 text-[10px] font-semibold">/</span>
              <span className="text-[11px] font-bold text-red-600 font-sans">
                ঝাদিমাদি ডটকম
              </span>
            </div>
            <p className="text-[9px] text-emerald-850 font-medium text-emerald-800/90 tracking-normal mt-0.5">
              "বন্ধুর মতো সবসময় আপনার পাশে"
            </p>
          </div>
        </div>

        {/* ২. কমপ্যাক্ট কন্টাক্ট ইনফো রো (Compact Row with Icons) */}
        <div className="flex items-center justify-center gap-2 sm:gap-3 flex-wrap text-[10px] text-slate-600 pt-0.5">
          {/* 📱 WhatsApp */}
          <a 
            href="https://wa.me/8801870592699" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 hover:bg-emerald-100/80 text-emerald-800 rounded-full border border-emerald-200/60 font-semibold transition-colors cursor-pointer"
            title="WhatsApp এ মেসেজ পাঠান"
          >
            <MessageCircle className="w-3 h-3 text-emerald-600 shrink-0" />
            <span>📱 হোয়াটসঅ্যাপ: ০১৮৭০৫৯২৬৯৯</span>
          </a>

          {/* ✉️ Email */}
          <a 
            href="mailto:Jhadimadi2024@gmail.com" 
            className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full border border-slate-200 font-semibold transition-colors cursor-pointer"
            title="ইমেইল করুন"
          >
            <Mail className="w-3 h-3 text-slate-500 shrink-0" />
            <span>✉️ Jhadimadi2024@gmail.com</span>
          </a>

          {/* 📍 Location */}
          <div className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-700 rounded-full border border-slate-200 font-semibold">
            <MapPin className="w-3 h-3 text-red-500 shrink-0" />
            <span>📍 খাগড়াছড়ি পার্বত্য জেলা</span>
          </div>
        </div>

        {/* ৩. কপিরাইট নোটিশ ও অ্যাডমিন অ্যাক্সেস */}
        <div className="pt-0.5 flex flex-col items-center gap-1">
          <p 
            onClick={onAdminClick}
            className="text-[9.5px] text-slate-500 font-medium cursor-pointer hover:text-slate-750 select-none transition-colors"
            title="গোপন অ্যাডমিন পোর্টাল (ক্লিক করুন অথবা কীবোর্ডে Alt + A চাপুন)"
          >
            © 2026 Jhadimadi.com. All rights reserved.
          </p>

          {/* Discreet secret admin toggle */}
          {onAdminClick && (
            <button
              type="button"
              onClick={onAdminClick}
              className="inline-flex items-center gap-1 text-[8.5px] text-slate-400 hover:text-emerald-700 transition-colors pt-0.5 cursor-pointer opacity-60 hover:opacity-100 px-2 py-0.5 rounded-md hover:bg-emerald-50/70"
              title="অ্যাডমিন ড্যাশবোর্ড ভিউ (Alt + A)"
            >
              <ShieldCheck className="w-2.5 h-2.5 text-emerald-600" />
              <span>অ্যাডমিন পোর্টাল</span>
            </button>
          )}
        </div>

      </div>
    </footer>
  );
};

export default Footer;
