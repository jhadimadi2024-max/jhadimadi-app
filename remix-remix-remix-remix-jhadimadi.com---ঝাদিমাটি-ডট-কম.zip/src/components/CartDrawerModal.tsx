import React, { useState } from 'react';
import { StoreProduct } from '../data/productsData';
import { useData } from '../context/DataContext';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingCart, 
  Truck, 
  ShieldCheck, 
  CheckCircle2, 
  MapPin, 
  Phone, 
  ArrowRight, 
  Clock, 
  Sparkles 
} from 'lucide-react';
import { Language, getTranslation } from '../utils/translations';

export interface CartItemType {
  product: StoreProduct;
  quantity: number;
}

interface CartDrawerModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItemType[];
  onUpdateQty: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  lang?: Language;
}

export const CartDrawerModal: React.FC<CartDrawerModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  lang = 'bn'
}) => {
  const { addOrder } = useData();
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'bKash' | 'Nagad'>('COD');
  const [isOrderPlaced, setIsOrderPlaced] = useState(false);
  const [orderTrackingId, setOrderTrackingId] = useState('');

  const t = getTranslation(lang);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const deliveryCharge = subtotal > 0 ? (subtotal >= 2000 ? 0 : 60) : 0;
  const totalAmount = subtotal + deliveryCharge;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0) return;
    const tracking = 'JDM-ORD-' + Math.floor(100000 + Math.random() * 900000);
    setOrderTrackingId(tracking);
    
    // Add to global DataContext for Admin Panel
    addOrder({
      id: tracking,
      customerName: customerName || 'সম্মানিত কাস্টমার',
      customerPhone: customerPhone || '018XXXXXXXX',
      deliveryAddress: deliveryAddress || 'পার্বত্য চট্টগ্রাম',
      items: cartItems.map(item => ({
        productId: item.product.id,
        nameBn: item.product.nameBn,
        price: item.product.price,
        quantity: item.quantity,
        image: item.product.image
      })),
      totalAmount,
      paymentMethod,
      status: 'Pending',
      notes: 'কাস্টমার অ্যাপ থেকে প্লেস করা অর্ডার'
    });

    setIsOrderPlaced(true);
  };

  const handleFinish = () => {
    onClearCart();
    setIsOrderPlaced(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        className="bg-white w-full max-w-sm max-h-[90vh] rounded-3xl overflow-hidden shadow-2xl flex flex-col relative animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-[#2EAA26] text-white p-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <ShoppingCart className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="text-xs font-black leading-tight">
                {t.cartTitle}
              </h3>
              <span className="text-[8px] text-green-100 font-bold">
                {lang === 'bn' ? `${cartItems.length}টি পণ্য নির্বাচিত` : `${cartItems.length} items in bag`}
              </span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 bg-black/20 hover:bg-black/30 rounded-full text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Order Confirmed Screen */}
        {isOrderPlaced ? (
          <div className="p-5 text-center space-y-4 overflow-y-auto">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner animate-bounce">
              <CheckCircle2 className="w-9 h-9" />
            </div>
            
            <div className="space-y-1">
              <h3 className="text-base font-black text-gray-900">
                {t.orderSuccessMsg}
              </h3>
              <p className="text-[10px] text-gray-600">
                {lang === 'bn' ? 'অর্ডার ট্র্যাকিং কোড:' : 'Order Tracking ID:'}{' '}
                <span className="font-mono font-black text-[#2EAA26]">{orderTrackingId}</span>
              </p>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-2xl text-left space-y-1.5 text-[8.5px]">
              <div className="flex justify-between text-gray-700">
                <span>{lang === 'bn' ? 'গ্রাহকের নাম:' : 'Customer Name:'}</span>
                <span className="font-bold text-gray-900">{customerName}</span>
              </div>
              <div className="flex justify-between text-gray-700">
                <span>{lang === 'bn' ? 'মোবাইল:' : 'Mobile:'}</span>
                <span className="font-bold text-gray-900">{customerPhone}</span>
              </div>
              <div className="flex justify-between text-gray-700">
                <span>{lang === 'bn' ? 'ঠিকানা:' : 'Address:'}</span>
                <span className="font-bold text-gray-900 truncate max-w-[170px]">{deliveryAddress}</span>
              </div>
              <div className="flex justify-between text-gray-700">
                <span>{lang === 'bn' ? 'পেমেন্ট মেথড:' : 'Payment Method:'}</span>
                <span className="font-black text-emerald-800">{paymentMethod}</span>
              </div>
              <div className="flex justify-between text-gray-700 border-t border-emerald-200/60 pt-1">
                <span className="font-black text-gray-900">{lang === 'bn' ? 'মোট প্রদেয়:' : 'Total Amount:'}</span>
                <span className="font-black text-emerald-800 text-xs">৳ {totalAmount}</span>
              </div>
            </div>

            <p className="text-[8px] text-gray-500">
              {lang === 'bn' ? 'আমাদের প্রতিনিধি শীঘ্রই ফোন করে অর্ডার ভেরিফাই করবেন।' : 'Our representative will call you shortly to confirm.'}
            </p>

            <button
              onClick={handleFinish}
              className="w-full py-2.5 bg-[#2EAA26] hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md active:scale-95 transition-all"
            >
              {lang === 'bn' ? 'হোম পেজে ফিরে যান' : 'Back to Home'}
            </button>
          </div>
        ) : cartItems.length === 0 ? (
          /* Empty State */
          <div className="p-8 text-center space-y-3">
            <div className="w-14 h-14 bg-gray-100 text-gray-400 rounded-full flex items-center justify-center mx-auto">
              <ShoppingCart className="w-7 h-7" />
            </div>
            <h4 className="text-xs font-bold text-gray-700">
              {t.emptyCartText}
            </h4>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#2EAA26] text-white rounded-xl text-[10px] font-bold shadow-xs hover:bg-emerald-700"
            >
              {t.browseProducts}
            </button>
          </div>
        ) : (
          /* Cart items and Checkout Form */
          <div className="overflow-y-auto no-scrollbar p-3 space-y-3 flex-1">
            {/* Items List */}
            <div className="space-y-2">
              {cartItems.map((item) => (
                <div 
                  key={item.product.id} 
                  className="flex items-center gap-2.5 p-2 bg-gray-50 rounded-2xl border border-gray-200/80"
                >
                  <img 
                    src={item.product.image} 
                    alt={item.product.nameBn} 
                    className="w-12 h-12 rounded-xl object-cover shrink-0 border border-gray-200"
                  />
                  <div className="flex-1 min-w-0">
                    <h5 className="text-[9.5px] font-black text-gray-900 truncate">
                      {lang === 'bn' ? item.product.nameBn : (item.product.nameEn || item.product.nameBn)}
                    </h5>
                    <span className="text-[8px] text-gray-500 block">
                      {item.product.unit} • {item.product.origin}
                    </span>
                    <span className="text-[9px] font-black text-emerald-700">
                      ৳ {item.product.price} × {item.quantity} = ৳ {item.product.price * item.quantity}
                    </span>
                  </div>

                  {/* Quantity controls */}
                  <div className="flex items-center bg-white rounded-lg border border-gray-300 p-0.5 shrink-0">
                    <button 
                      onClick={() => onUpdateQty(item.product.id, -1)}
                      className="w-5 h-5 bg-white hover:bg-gray-200 rounded flex items-center justify-center text-gray-700 font-bold"
                    >
                      <Minus className="w-2.5 h-2.5" />
                    </button>
                    <span className="w-4 text-center text-[9px] font-black text-gray-900">
                      {item.quantity}
                    </span>
                    <button 
                      onClick={() => onUpdateQty(item.product.id, 1)}
                      className="w-5 h-5 bg-white hover:bg-gray-200 rounded flex items-center justify-center text-gray-700 font-bold"
                    >
                      <Plus className="w-2.5 h-2.5" />
                    </button>
                  </div>

                  {/* Delete button */}
                  <button 
                    onClick={() => onRemoveItem(item.product.id)}
                    className="p-1.5 text-gray-400 hover:text-red-500 rounded-lg shrink-0 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Clear Cart Button */}
            <div className="flex justify-end">
              <button 
                onClick={onClearCart}
                className="text-[8px] font-bold text-red-600 hover:underline flex items-center gap-0.5 cursor-pointer"
              >
                <Trash2 className="w-2.5 h-2.5" />
                {lang === 'bn' ? 'কার্ট খালি করুন' : 'Clear Cart'}
              </button>
            </div>

            {/* Checkout Form */}
            <form onSubmit={handlePlaceOrder} className="bg-slate-50 p-3 rounded-2xl border border-gray-200 space-y-2 text-left">
              <h4 className="text-[9.5px] font-black text-gray-900 flex items-center gap-1 border-b border-gray-200 pb-1.5">
                <MapPin className="w-3 h-3 text-[#2EAA26]" />
                {lang === 'bn' ? 'ডেলিভারি ও চেকআউট তথ্য' : 'Delivery & Checkout Info'}
              </h4>

              <div className="space-y-1.5">
                <div>
                  <label className="text-[7.5px] font-black text-gray-700">
                    {lang === 'bn' ? 'আপনার পুরো নাম' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={lang === 'bn' ? 'যেমন: অনিক মারমা / মো: তানভীর' : 'e.g. Anik Marma'}
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-white border border-gray-300 rounded-lg px-2 py-1 text-[8.5px] text-gray-900 focus:outline-none focus:border-[#2EAA26]"
                  />
                </div>

                <div>
                  <label className="text-[7.5px] font-black text-gray-700">
                    {lang === 'bn' ? 'মোবাইল নাম্বার (১১ ডিজিট)' : 'Phone Number (11 digits)'}
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="01XXXXXXXXX"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full bg-white border border-gray-300 rounded-lg px-2 py-1 text-[8.5px] text-gray-900 focus:outline-none focus:border-[#2EAA26]"
                  />
                </div>

                <div>
                  <label className="text-[7.5px] font-black text-gray-700">
                    {lang === 'bn' ? 'পূর্ণ ঠিকানা (জেলা, থানা ও পাড়া)' : 'Full Address (District, Thana & Para)'}
                  </label>
                  <textarea
                    required
                    rows={2}
                    placeholder={lang === 'bn' ? 'যেমন: পানখাইয়াপাড়া, খাগড়াছড়ি সদর, খাগড়াছড়ি' : 'e.g. Pankhaiyapara, Khagrachhari Sadar'}
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    className="w-full bg-white border border-gray-300 rounded-lg px-2 py-1 text-[8.5px] text-gray-900 focus:outline-none focus:border-[#2EAA26] resize-none"
                  />
                </div>

                {/* Payment Selection */}
                <div>
                  <label className="text-[7.5px] font-black text-gray-700">
                    {lang === 'bn' ? 'পেমেন্ট মেথড' : 'Payment Method'}
                  </label>
                  <div className="grid grid-cols-3 gap-1.5 mt-0.5">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('COD')}
                      className={`p-1.5 rounded-lg border text-center text-[7.5px] font-black transition-all ${
                        paymentMethod === 'COD'
                          ? 'border-[#2EAA26] bg-emerald-50 text-emerald-800 ring-1 ring-[#2EAA26]'
                          : 'border-gray-200 bg-white text-gray-700'
                      }`}
                    >
                      {lang === 'bn' ? 'ক্যাশ অন ডেলিভারি' : 'Cash on Delivery'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('bKash')}
                      className={`p-1.5 rounded-lg border text-center text-[7.5px] font-black transition-all ${
                        paymentMethod === 'bKash'
                          ? 'border-pink-500 bg-pink-50 text-pink-700 ring-1 ring-pink-500'
                          : 'border-gray-200 bg-white text-gray-700'
                      }`}
                    >
                      {lang === 'bn' ? 'বিকাশ (bKash)' : 'bKash'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('Nagad')}
                      className={`p-1.5 rounded-lg border text-center text-[7.5px] font-black transition-all ${
                        paymentMethod === 'Nagad'
                          ? 'border-orange-500 bg-orange-50 text-orange-700 ring-1 ring-orange-500'
                          : 'border-gray-200 bg-white text-gray-700'
                      }`}
                    >
                      {lang === 'bn' ? 'নগদ (Nagad)' : 'Nagad'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Price Calculation Box */}
              <div className="border-t border-gray-200 pt-2 space-y-1 text-[8px]">
                <div className="flex justify-between text-gray-600">
                  <span>{t.subtotal}</span>
                  <span className="font-bold text-gray-900">৳ {subtotal}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>{t.deliveryFee}</span>
                  <span className="font-bold text-emerald-700">
                    {deliveryCharge === 0 ? (lang === 'bn' ? 'ফ্রি ডেলিভারি (৳২০০০+ অর্ডারে)' : 'Free Delivery (orders 2000+)') : `৳ ${deliveryCharge}`}
                  </span>
                </div>
                <div className="border-t border-gray-200 pt-1 flex justify-between font-black text-[10px] text-gray-900">
                  <span>{t.totalAmount}</span>
                  <span className="text-[#2EAA26] text-xs font-black">৳ {totalAmount}</span>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full mt-2 bg-[#2EAA26] hover:bg-emerald-700 active:scale-95 text-white py-2.5 rounded-xl font-black text-xs shadow-md flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <span>{lang === 'bn' ? `অর্ডার নিশ্চিত করুন (৳ ${totalAmount})` : `Confirm Order (৳ ${totalAmount})`}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
