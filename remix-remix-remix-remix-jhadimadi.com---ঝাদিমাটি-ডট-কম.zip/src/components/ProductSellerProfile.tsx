import React, { useState, useRef, useEffect } from 'react';
import { 
  Store, 
  MapPin, 
  Phone, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowLeft, 
  MoreVertical, 
  LayoutDashboard, 
  UserCheck, 
  LogOut, 
  Trash2, 
  Plus, 
  Check, 
  Copy, 
  Star, 
  Package, 
  Droplet, 
  AlertTriangle, 
  X,
  Languages,
  Calendar,
  Sparkles,
  ShoppingBag
} from 'lucide-react';
import { Language } from '../utils/translations';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

export interface ProductSellerProfileProps {
  profileData: any;
  currentUser?: any;
  lang?: Language;
  isOwner?: boolean;
  onEditProfile?: (data?: any) => void;
  onNavigateDashboard?: () => void;
  onSignOut?: () => void;
  onDeleteAccount?: () => void;
  onBack?: () => void;
  onAddNewProduct?: () => void;
}

export const ProductSellerProfile: React.FC<ProductSellerProfileProps> = ({
  profileData,
  currentUser,
  lang: initialLang = 'bn',
  isOwner = true,
  onEditProfile,
  onNavigateDashboard,
  onSignOut,
  onDeleteAccount,
  onBack,
  onAddNewProduct,
}) => {
  const [lang, setLang] = useState<Language>(initialLang);
  const [showMenu, setShowMenu] = useState(false);
  const [copiedUID, setCopiedUID] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [showAddProductModal, setShowAddProductModal] = useState(false);

  // New product form state inside modal
  const [newProdName, setNewProdName] = useState('');
  const [newProdPrice, setNewProdPrice] = useState('');
  const [newProdCategory, setNewProdCategory] = useState('পাহাড়ি ফলমূল ও অর্গানিক');
  const [newProdImage, setNewProdImage] = useState('https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=600&q=80');

  const menuRef = useRef<HTMLDivElement>(null);
  const { logout } = useAuth();
  const { products, addProduct } = useData();

  const isBn = lang === 'bn';

  // Merge profile data
  const data = {
    ...(currentUser || {}),
    ...(profileData || {}),
  };

  const sellerUID = data.sellerCode || data.memberUID || data.uniqueId || data.id || 'JH-S-KHG-001';
  const shopName = data.shopName || data.storeName || `${data.name || data.fullName || 'মার্চেন্ট'}-এর পাহাড়ি স্টোর`;
  const ownerName = data.fullName || data.name || 'নিবন্ধিত বিক্রেতা';
  const phone = data.phone || data.realPhone || '018XXXXXXXX';
  const bloodGroup = data.bloodGroup || 'B+';
  const district = data.district || 'খাগড়াছড়ি';
  const upazila = data.upazila || 'খাগড়াছড়ি সদর';
  const area = data.mahalla || data.detailedAddress || 'বাজার এলাকা';
  const bio = data.bio || (isBn ? 'ঝাদিমাদি ডট কম প্ল্যাটফর্মের ভেরিফাইড পণ্য বিক্রেতা। আমরা সরাসরি পাহাড়ি বাগান ও গ্রাম থেকে খাঁটি অর্গানিক পণ্য সরবরাহ করি।' : 'Verified product seller on Jhadimadi.com providing fresh and authentic organic hill produce.');
  const avatar = data.avatar || 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=400&q=80';
  const createdAt = data.createdAt || new Date().toISOString().split('T')[0];

  // Filter seller's own products
  const sellerProducts = (products || []).filter((p: any) => {
    return (
      (p.sellerCode && p.sellerCode === sellerUID) ||
      (p.farmerName && p.farmerName.toLowerCase().includes(ownerName.toLowerCase())) ||
      (p.farmerName && p.farmerName.toLowerCase().includes(shopName.toLowerCase())) ||
      (data.id && p.id?.includes(data.id))
    );
  });

  // Close menu on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setShowMenu(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const handleCopyUID = () => {
    navigator.clipboard.writeText(sellerUID);
    setCopiedUID(true);
    setTimeout(() => setCopiedUID(false), 2000);
  };

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(phone);
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim() || !newProdPrice) return;

    const newProd = {
      id: `prod_${Date.now()}`,
      nameBn: newProdName.trim(),
      nameEn: newProdName.trim(),
      category: 'fruits_agro' as any,
      categoryBn: newProdCategory,
      price: parseInt(newProdPrice, 10) || 200,
      originalPrice: Math.round((parseInt(newProdPrice, 10) || 200) * 1.2),
      weight: '১ কেজি / ১ প্যাকেট',
      image: newProdImage,
      rating: 5.0,
      reviewsCount: 1,
      isOrganic: true,
      inStock: true,
      origin: `${upazila}, ${district}`,
      descriptionBn: `${shopName}-এর তাজা পাহাড়ি পণ্য।`,
      farmerName: shopName,
      unit: 'কেজি',
      sellerCode: sellerUID
    };

    if (typeof addProduct === 'function') {
      addProduct(newProd);
    }
    setShowAddProductModal(false);
    setNewProdName('');
    setNewProdPrice('');
  };

  return (
    <div className="bg-white min-h-screen text-gray-900 pb-20 font-sans" id="product-seller-profile-root">
      
      {/* ================= TOP NAVIGATION BAR ================= */}
      <div className="sticky top-0 z-30 bg-[#0E8246] text-white px-4 py-2 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="w-8 h-8 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition active:scale-95 cursor-pointer"
              title={isBn ? 'ফিরে যান' : 'Back'}
              id="seller-btn-back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <h1 className="text-xs sm:text-sm font-bold tracking-tight leading-tight">
              {isBn ? 'পণ্য বিক্রেতা প্রোফাইল' : 'Product Seller Profile'}
            </h1>
            <span className="text-[10px] text-emerald-100 font-medium block leading-none">
              {isBn ? 'ঝাদিমাদি ডট কম অনুমোদিত মার্চেন্ট' : 'Jhadimadi.com Verified Merchant'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Language Toggle */}
          <button
            type="button"
            onClick={() => setLang(prev => (prev === 'bn' ? 'en' : 'bn'))}
            className="px-2 py-1 bg-white/15 hover:bg-white/25 rounded-md text-[11px] font-bold text-white transition flex items-center gap-1 cursor-pointer"
            id="seller-btn-lang"
          >
            <Languages className="w-3 h-3" />
            <span>{isBn ? 'EN' : 'বাং'}</span>
          </button>

          {/* Three-Dot (⋮) Management Menu */}
          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setShowMenu(!showMenu)}
              className="w-8 h-8 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition active:scale-95 cursor-pointer"
              title={isBn ? 'মেনু' : 'Menu'}
              id="seller-profile-three-dot-btn"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {showMenu && (
              <div 
                className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-xl border border-gray-200 py-1 z-50 text-xs text-gray-800 animate-in fade-in zoom-in-95 duration-150"
                id="seller-profile-dropdown-menu"
              >
                {/* 1. Dashboard */}
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    if (onNavigateDashboard) {
                      onNavigateDashboard();
                    } else if (onBack) {
                      onBack();
                    }
                  }}
                  className="w-full text-left px-3.5 py-2.5 hover:bg-emerald-50 text-gray-800 font-semibold flex items-center gap-2.5 transition cursor-pointer"
                  id="seller-menu-dashboard-btn"
                >
                  <LayoutDashboard className="w-4 h-4 text-[#0E8246]" />
                  <span>{isBn ? 'ড্যাশবোর্ড' : 'Dashboard'}</span>
                </button>

                {/* 2. Edit Profile -> Opens Product Seller Edit Form */}
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    if (onEditProfile) {
                      onEditProfile(data);
                    }
                  }}
                  className="w-full text-left px-3.5 py-2.5 hover:bg-blue-50 text-gray-800 font-semibold flex items-center gap-2.5 transition cursor-pointer"
                  id="seller-menu-edit-profile-btn"
                >
                  <UserCheck className="w-4 h-4 text-blue-600" />
                  <span>{isBn ? 'প্রোফাইল এডিট' : 'Edit Profile'}</span>
                </button>

                <div className="h-px bg-gray-100 my-1"></div>

                {/* 3. Sign Out */}
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    if (onSignOut) {
                      onSignOut();
                    } else {
                      logout();
                    }
                  }}
                  className="w-full text-left px-3.5 py-2 hover:bg-gray-100 text-gray-700 font-medium flex items-center gap-2.5 transition cursor-pointer"
                  id="seller-menu-signout-btn"
                >
                  <LogOut className="w-4 h-4 text-gray-500" />
                  <span>{isBn ? 'সাইন আউট' : 'Sign Out'}</span>
                </button>

                {/* 4. Delete Profile */}
                <button
                  type="button"
                  onClick={() => {
                    setShowMenu(false);
                    setShowDeleteModal(true);
                  }}
                  className="w-full text-left px-3.5 py-2 hover:bg-red-50 text-red-600 font-semibold flex items-center gap-2.5 transition cursor-pointer"
                  id="seller-menu-delete-btn"
                >
                  <Trash2 className="w-4 h-4 text-red-600" />
                  <span>{isBn ? 'প্রোফাইল মুছে ফেলুন' : 'Delete Profile'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-4 space-y-4">

        {/* ================= SELLER IDENTITY CARD ================= */}
        <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm relative overflow-hidden" id="seller-identity-card">
          <div className="flex items-start gap-3.5">
            {/* Store Avatar */}
            <div className="relative shrink-0">
              <img
                src={avatar}
                alt={shopName}
                className="w-16 h-16 rounded-xl object-cover border-2 border-emerald-600 bg-gray-100 shadow-xs"
              />
              <span className="absolute -bottom-1 -right-1 bg-[#0E8246] text-white p-0.5 rounded-full shadow-xs" title="Verified">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </span>
            </div>

            {/* Shop & Owner Details */}
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h2 className="text-base font-black text-gray-950 tracking-tight leading-tight truncate">
                  {shopName}
                </h2>
              </div>
              <p className="text-xs font-semibold text-gray-700 flex items-center gap-1">
                <span>{isBn ? 'স্বত্বাধিকারী:' : 'Proprietor:'}</span>
                <span className="font-bold text-gray-900">{ownerName}</span>
              </p>
              
              {/* Category / Badge */}
              <div className="flex items-center gap-1.5 pt-0.5 flex-wrap">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-[#0E8246] border border-emerald-200">
                  <ShieldCheck className="w-3 h-3" />
                  <span>{isBn ? 'ভেরিফাইড পণ্য বিক্রেতা' : 'Verified Product Seller'}</span>
                </span>
                
                {/* Blood Group Tag */}
                <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-50 text-red-700 border border-red-200">
                  <Droplet className="w-2.5 h-2.5 text-red-600 fill-red-600" />
                  <span>{bloodGroup}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Seller Unique ID Bar */}
          <div className="mt-3.5 p-2.5 bg-gray-50 rounded-xl border border-gray-200 flex items-center justify-between text-xs">
            <div>
              <span className="text-[10px] text-gray-500 font-bold block">
                {isBn ? 'মার্চেন্ট আইডি কোড (UID):' : 'Merchant UID Code:'}
              </span>
              <span className="font-mono font-black text-gray-900 text-xs tracking-wider">
                {sellerUID}
              </span>
            </div>
            <button
              type="button"
              onClick={handleCopyUID}
              className="px-2.5 py-1 bg-white hover:bg-gray-100 border border-gray-300 rounded-lg font-semibold text-gray-800 text-[11px] flex items-center gap-1 transition cursor-pointer active:scale-95"
              id="btn-copy-seller-uid"
            >
              {copiedUID ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-gray-600" />}
              <span>{copiedUID ? (isBn ? 'কপি হয়েছে' : 'Copied') : (isBn ? 'কপি' : 'Copy')}</span>
            </button>
          </div>

          {/* Quick Contact & Location Info */}
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
            <div className="p-2 bg-emerald-50/50 rounded-xl border border-emerald-100 flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-[#0E8246] shrink-0" />
              <div className="min-w-0">
                <span className="text-[9px] font-bold text-gray-500 block">{isBn ? 'মোবাইল' : 'Phone'}</span>
                <span className="font-semibold text-gray-900 truncate block">{phone}</span>
              </div>
            </div>

            <div className="p-2 bg-emerald-50/50 rounded-xl border border-emerald-100 flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-[#0E8246] shrink-0" />
              <div className="min-w-0">
                <span className="text-[9px] font-bold text-gray-500 block">{isBn ? 'এলাকা' : 'Location'}</span>
                <span className="font-semibold text-gray-900 truncate block">{upazila}, {district}</span>
              </div>
            </div>
          </div>
        </div>

        {/* ================= BIO / STORE DESCRIPTION ================= */}
        <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm space-y-2">
          <h3 className="text-xs font-bold text-gray-900 flex items-center gap-1.5 border-b border-gray-100 pb-1.5">
            <Store className="w-3.5 h-3.5 text-[#0E8246]" />
            <span>{isBn ? 'দোকান ও পণ্য বিবরণী' : 'Shop & Produce Information'}</span>
          </h3>
          <p className="text-xs text-gray-700 leading-relaxed font-medium">
            {bio}
          </p>
          <div className="text-[11px] text-gray-500 pt-1 flex items-center gap-1">
            <MapPin className="w-3 h-3 text-gray-400" />
            <span>{area}, {upazila}, {district}</span>
          </div>
        </div>

        {/* ================= PRODUCTS & INVENTORY SECTION ================= */}
        <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-gray-100 pb-2">
            <div>
              <h3 className="text-xs font-bold text-gray-900 flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-[#0E8246]" />
                <span>{isBn ? 'আমার সংগৃহীত পণ্যসমূহ' : 'My Listed Products'}</span>
              </h3>
              <span className="text-[10px] text-gray-500">
                {sellerProducts.length} {isBn ? 'টি সক্রিয় পণ্য তালিকাভুক্ত' : 'active listings'}
              </span>
            </div>

            <button
              type="button"
              onClick={() => {
                if (onAddNewProduct) {
                  onAddNewProduct();
                } else {
                  setShowAddProductModal(true);
                }
              }}
              className="px-2.5 py-1.5 bg-[#0E8246] hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer active:scale-95 shadow-xs"
              id="btn-seller-add-product"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isBn ? 'নতুন পণ্য যোগ' : 'Add Product'}</span>
            </button>
          </div>

          {/* Product Items List */}
          {sellerProducts.length > 0 ? (
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              {sellerProducts.map((p: any) => (
                <div 
                  key={p.id}
                  className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-2xs hover:shadow-sm transition flex flex-col"
                >
                  <div className="h-24 w-full bg-gray-100 relative">
                    <img 
                      src={p.image} 
                      alt={p.nameBn} 
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute top-1 right-1 bg-[#0E8246] text-white text-[9px] font-black px-1.5 py-0.5 rounded-md shadow-xs">
                      {isBn ? 'অর্গানিক' : 'Organic'}
                    </span>
                  </div>
                  <div className="p-2 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-gray-900 line-clamp-1 leading-tight">
                        {p.nameBn}
                      </h4>
                      <p className="text-[10px] text-gray-500 line-clamp-1">
                        {p.categoryBn || p.category}
                      </p>
                    </div>
                    <div className="pt-1.5 flex items-center justify-between">
                      <span className="text-xs font-black text-[#0E8246]">
                        ৳{p.price}
                      </span>
                      <span className="text-[9px] text-gray-400">
                        {p.weight || 'প্রতি কেজি'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* Empty State: Prompt to add product */
            <div className="text-center py-6 bg-gray-50 rounded-xl border border-dashed border-gray-300 p-4 space-y-2">
              <ShoppingBag className="w-8 h-8 text-gray-400 mx-auto" />
              <p className="text-xs font-bold text-gray-700">
                {isBn ? 'এখনও কোনো অতিরিক্ত পণ্য যুক্ত করা হয়নি' : 'No additional products added yet'}
              </p>
              <p className="text-[11px] text-gray-500 max-w-xs mx-auto">
                {isBn ? 'আপনার দোকানের তাজা পাহাড়ি ফল, শাকসবজি বা হস্তশিল্প যুক্ত করে ক্রেতাদের আকর্ষণ করুন।' : 'Add your hill products to receive buyer inquiries directly.'}
              </p>
              <button
                type="button"
                onClick={() => setShowAddProductModal(true)}
                className="mt-1 px-3 py-1.5 bg-[#0E8246] text-white text-xs font-bold rounded-xl hover:bg-emerald-800 transition cursor-pointer"
              >
                {isBn ? '+ এখনই প্রথম পণ্য যোগ করুন' : '+ Add First Product'}
              </button>
            </div>
          )}
        </div>

        {/* ================= EDIT PROFILE DIRECT TRIGGER BUTTON ================= */}
        <div className="pt-2">
          <button
            type="button"
            onClick={() => {
              if (onEditProfile) {
                onEditProfile(data);
              }
            }}
            className="w-full py-3 bg-white hover:bg-emerald-50 text-[#0E8246] border border-[#0E8246] rounded-xl text-xs font-black flex items-center justify-center gap-2 transition cursor-pointer shadow-xs active:scale-98"
            id="btn-seller-edit-profile-cta"
          >
            <UserCheck className="w-4 h-4" />
            <span>{isBn ? 'পণ্য বিক্রেতা প্রোফাইল এডিট করুন' : 'Edit Product Seller Profile'}</span>
          </button>
        </div>

      </div>

      {/* ================= ADD PRODUCT MODAL ================= */}
      {showAddProductModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-4 space-y-3 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-gray-100 pb-2">
              <h3 className="text-xs sm:text-sm font-bold text-gray-900 flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-[#0E8246]" />
                <span>{isBn ? 'নতুন পণ্য তালিকাভুক্ত করুন' : 'List New Product'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddProductModal(false)}
                className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-2.5 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-gray-700 mb-1">
                  {isBn ? 'পণ্যের নাম *' : 'Product Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder={isBn ? 'যেমন: পাহাড়ি তাজা আদা' : 'e.g. Hill Ginger'}
                  className="w-full px-3 py-2 border border-gray-300 rounded-xl text-xs text-gray-900 focus:outline-none focus:border-[#0E8246]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-gray-700 mb-1">
                    {isBn ? 'মূল্য (টাকা) *' : 'Price (BDT) *'}
                  </label>
                  <input
                    type="number"
                    required
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(e.target.value)}
                    placeholder="৳ 250"
                    className="w-full px-3 py-2 border border-gray-300 rounded-xl text-xs text-gray-900 focus:outline-none focus:border-[#0E8246]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-700 mb-1">
                    {isBn ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value)}
                    className="w-full px-2 py-2 border border-gray-300 rounded-xl text-xs text-gray-900 focus:outline-none focus:border-[#0E8246]"
                  >
                    <option value="পাহাড়ি ফলমূল ও অর্গানিক">পাহাড়ি ফলমূল</option>
                    <option value="তাজা শাকসবজি">শাকসবজি</option>
                    <option value="প্রাকৃতিক মশলা ও হলুদ">প্রাকৃতিক মশলা</option>
                    <option value="পাহাড়ি মধু ও শুঁটকি">মধু ও শুঁটকি</option>
                    <option value="ঐতিহ্যবাহী পোশাক ও থামি">পোশাক ও থামি</option>
                    <option value="হস্তশিল্প ও আসবাব">হস্তশিল্প</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddProductModal(false)}
                  className="px-3 py-1.5 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-100 font-semibold cursor-pointer"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-[#0E8246] hover:bg-emerald-800 text-white font-bold cursor-pointer"
                >
                  {isBn ? 'সংরক্ষণ করুন' : 'Save Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= DELETE PROFILE CONFIRMATION MODAL ================= */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-4 space-y-3 shadow-2xl border border-red-200">
            <div className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-black text-gray-950">
                {isBn ? 'প্রোফাইল মুছে ফেলার নিশ্চয়তা' : 'Confirm Delete Profile'}
              </h3>
            </div>
            <p className="text-xs text-gray-600 leading-relaxed">
              {isBn 
                ? 'আপনি কি নিশ্চিতভাবে এই পণ্য বিক্রেতা প্রোফাইলটি চিরতরে মুছে ফেলতে চান? আপনার সমস্ত পণ্য তালিকা ও তথ্য মুছে যাবে।'
                : 'Are you sure you want to delete your Product Seller profile? All your listed products and account data will be erased.'}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="px-3 py-1.5 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-100 text-xs font-semibold cursor-pointer"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowDeleteModal(false);
                  if (onDeleteAccount) {
                    onDeleteAccount();
                  } else {
                    logout();
                  }
                }}
                className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer"
                id="btn-confirm-seller-delete"
              >
                {isBn ? 'হ্যাঁ, মুছে ফেলুন' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default ProductSellerProfile;
