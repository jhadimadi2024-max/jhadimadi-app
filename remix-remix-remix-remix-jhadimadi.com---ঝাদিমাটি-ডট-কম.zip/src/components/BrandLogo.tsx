import React from 'react';

interface BrandLogoProps {
  variant?: 'icon-only' | 'full-horizontal' | 'full-stacked' | 'header-badge';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  theme?: 'light' | 'dark' | 'on-emerald';
  showSlogan?: boolean;
}

/**
 * Jhadimadi.com Official Brand Logo Component
 * Incorporates the Red Runner Courier icon and authentic brand typography
 */
export const BrandLogo: React.FC<BrandLogoProps> = ({
  variant = 'full-horizontal',
  size = 'md',
  className = '',
  theme = 'light',
  showSlogan = true,
}) => {
  // Logo image sources with reliable fallback
  const runnerImgSrc = "https://i.ibb.co.com/sppWZhc9/logo33.png";

  const sizeStyles = {
    sm: {
      icon: 'w-6 h-6',
      title: 'text-xs',
      bnText: 'text-[8px]',
      slogan: 'text-[6.5px]',
      container: 'gap-1.5',
    },
    md: {
      icon: 'w-8 h-8',
      title: 'text-sm',
      bnText: 'text-[9.5px]',
      slogan: 'text-[7.5px]',
      container: 'gap-2',
    },
    lg: {
      icon: 'w-12 h-12',
      title: 'text-lg',
      bnText: 'text-xs',
      slogan: 'text-[9px]',
      container: 'gap-2.5',
    },
    xl: {
      icon: 'w-20 h-20 sm:w-24 sm:h-24',
      title: 'text-2xl sm:text-3xl',
      bnText: 'text-sm sm:text-base',
      slogan: 'text-[10px] sm:text-xs',
      container: 'gap-3 sm:gap-4',
    },
  };

  const currentSize = sizeStyles[size];

  // SVG representation of the runner figure as instant zero-latency fallback
  const RunnerIconGraphic = (
    <div className={`relative ${currentSize.icon} shrink-0 flex items-center justify-center`}>
      <img
        src={runnerImgSrc}
        alt="Jhadimadi Runner Logo"
        className="w-full h-full object-contain drop-shadow-xs select-none"
        onError={(e) => {
          // If image fails, fallback to inline custom runner SVG
          e.currentTarget.style.display = 'none';
          const sibling = e.currentTarget.nextElementSibling as HTMLElement;
          if (sibling) sibling.style.display = 'block';
        }}
      />
      {/* Inline High-Definition Vector SVG fallback */}
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full hidden fill-current text-red-600"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle cx="68" cy="22" r="10" />
        <path d="M45,18 C28,18 16,27 16,38 C16,48 26,56 42,54 C46,53 50,50 52,46 C50,38 52,28 58,24 C54,20 50,18 45,18 Z" />
        <path d="M56,36 C54,42 52,50 56,56 C60,62 65,65 72,67 L68,75 C60,73 53,68 48,60 C44,54 44,46 47,38 L56,36 Z" />
        <path d="M44,48 L35,66 C32,72 26,78 18,84 L14,80 C21,74 27,69 30,63 L38,47 Z" />
        <path d="M58,32 L78,45 L70,55 L58,42 Z" />
        <path d="M54,72 L62,88 L72,83 L64,68 Z" />
      </svg>
    </div>
  );

  if (variant === 'icon-only') {
    return (
      <div className={`inline-flex items-center justify-center ${className}`}>
        {RunnerIconGraphic}
      </div>
    );
  }

  if (variant === 'header-badge') {
    return (
      <div className={`inline-flex items-center gap-1.5 cursor-pointer select-none group ${className}`}>
        <div className="relative p-0.5 rounded-lg bg-white shadow-xs border border-white/40 group-hover:scale-105 transition-transform shrink-0 flex items-center justify-center w-7 h-7">
          <img
            src={runnerImgSrc}
            alt="Jhadimadi Runner"
            className="w-6 h-6 object-contain"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = "/runner-logo.png";
            }}
          />
        </div>
        <div className="flex flex-col text-left leading-none">
          <div className="flex items-center gap-0.5">
            <span className="text-[11px] font-black tracking-wider text-white">JHADIMADI</span>
            <span className="text-[9px] font-black text-amber-300">.COM</span>
          </div>
          <span className="text-[6.5px] text-emerald-100 font-bold tracking-tight mt-0.5">
            INTEGRITY IS OUR CAPITAL
          </span>
        </div>
      </div>
    );
  }

  // Full stacked or Full horizontal representation
  const isStacked = variant === 'full-stacked';
  const textColor = theme === 'on-emerald' ? 'text-white' : 'text-red-700';
  const subTextColor = theme === 'on-emerald' ? 'text-amber-300' : 'text-[#8B1A1A]';
  const sloganColor = theme === 'on-emerald' ? 'text-emerald-100' : 'text-stone-700';

  return (
    <div
      className={`inline-flex ${isStacked ? 'flex-col items-center text-center' : 'items-center text-left'} ${currentSize.container} ${className}`}
    >
      {RunnerIconGraphic}
      <div className={`flex flex-col ${isStacked ? 'items-center' : 'items-start'} leading-tight`}>
        <span className={`${currentSize.bnText} font-bold text-red-600 tracking-wide font-sans`}>
          ঝাদিমাদি ডটকম
        </span>
        <div className="flex items-baseline">
          <span className={`${currentSize.title} font-black tracking-tight ${textColor} uppercase font-sans`}>
            JHADIMADI
          </span>
          <span className={`${currentSize.title} font-black ${subTextColor} uppercase`}>
            .COM
          </span>
        </div>
        {showSlogan && (
          <span className={`${currentSize.slogan} font-extrabold tracking-widest uppercase ${sloganColor} mt-0.5`}>
            INTEGRITY IS OUR CAPITAL
          </span>
        )}
      </div>
    </div>
  );
};
