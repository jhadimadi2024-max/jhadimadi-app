import React, { useState } from 'react';
import { 
  TrendingUp, 
  Users, 
  Search, 
  DollarSign, 
  ArrowUpRight, 
  Mic, 
  MapPin, 
  Activity, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  Smartphone, 
  BarChart3, 
  Layers, 
  Filter, 
  Sparkles,
  ShoppingBag,
  HeartHandshake,
  Droplet
} from 'lucide-react';
import { useData } from '../../context/DataContext';

export const AdminAnalyticsTab: React.FC = () => {
  const { products, professionals, users, orders, bloodDonors, complaints } = useData();
  const [timeRange, setTimeRange] = useState<'today' | '7days' | '30days'>('today');
  const [activityFilter, setActivityFilter] = useState<'all' | 'orders' | 'registrations' | 'search'>('all');

  const totalGMV = orders.reduce((sum, o) => o.status !== 'Cancelled' ? sum + o.totalAmount : sum, 0);
  const deliveredOrdersCount = orders.filter(o => o.status === 'Delivered').length;
  const verifiedProsCount = professionals.filter(p => p.verified).length;
  const pendingKYC = professionals.filter(p => !p.verified).length;

  const khgCount = professionals.filter(p => p.district === 'Khagrachhari' || p.district === 'খাগড়াছড়ি').length;
  const rngCount = professionals.filter(p => p.district === 'Rangamati' || p.district === 'রাঙ্গামাটি').length;
  const bdbCount = professionals.filter(p => p.district === 'Bandarban' || p.district === 'বান্দরবান').length;
  const otherCount = Math.max(0, professionals.length - (khgCount + rngCount + bdbCount));
  const totalPros = Math.max(professionals.length, 1);

  const districtTraffic = [
    { district: 'খাগড়াছড়ি জেলা', share: professionals.length ? Math.round((khgCount / totalPros) * 100) : 0, queries: `${khgCount}`, pros: khgCount, color: 'bg-emerald-500' },
    { district: 'রাঙ্গামাটি জেলা', share: professionals.length ? Math.round((rngCount / totalPros) * 100) : 0, queries: `${rngCount}`, pros: rngCount, color: 'bg-teal-500' },
    { district: 'বান্দরবান জেলা', share: professionals.length ? Math.round((bdbCount / totalPros) * 100) : 0, queries: `${bdbCount}`, pros: bdbCount, color: 'bg-cyan-500' },
    { district: 'চট্টগ্রাম ও অন্যান্য', share: professionals.length ? Math.round((otherCount / totalPros) * 100) : 0, queries: `${otherCount}`, pros: otherCount, color: 'bg-blue-500' },
  ];

  const recentLogs: Array<{ id: string; type: 'order' | 'search' | 'registrations'; text: string; time: string; amount?: string; tag?: string }> = [
    ...orders.map(o => ({
      id: `LOG-ORD-${o.id}`,
      type: 'order' as const,
      text: `অর্ডার #${o.id}: ${o.customerName || 'গ্রাহক'} - ${o.items?.length || 1}টি আইটেম (${o.status})`,
      time: o.date || 'আজ',
      amount: `৳${(o.totalAmount || 0).toLocaleString()}`
    })),
    ...users.map(u => ({
      id: `LOG-USR-${u.id}`,
      type: 'registrations' as const,
      text: `নতুন ইউজার: "${u.name}" (${u.roleLabelBn || u.role})`,
      time: u.createdAt || 'আজ',
      tag: u.status || 'Active'
    }))
  ];

  const filteredLogs = recentLogs.filter(log => {
    if (activityFilter === 'all') return true;
    return log.type === activityFilter;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto" id="admin-analytics-tab">
      
      {/* Top Banner Header & Time Filter */}
      <div className="bg-slate-900 text-white p-5 sm:p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-emerald-500/30">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                প্ল্যাটফর্ম লাইভ অ্যানালিটিক্স ও মেট্রিক্স
              </h1>
              <p className="text-xs text-slate-400">
                দৈনিক ট্রাফিক, রেজিস্টার্ড ইউজার ও রেভিনিউ সম্পর্কিত লাইভ পরিসংখ্যান
              </p>
            </div>
          </div>
        </div>

        {/* Time Filter Pills */}
        <div className="bg-slate-800/90 border border-slate-700/80 p-1 rounded-2xl flex items-center gap-1 text-xs font-bold">
          <button
            onClick={() => setTimeRange('today')}
            className={`px-3 py-1.5 rounded-xl transition ${timeRange === 'today' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
          >
            আজকের দিন
          </button>
          <button
            onClick={() => setTimeRange('7days')}
            className={`px-3 py-1.5 rounded-xl transition ${timeRange === '7days' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
          >
            গত ৭ দিন
          </button>
          <button
            onClick={() => setTimeRange('30days')}
            className={`px-3 py-1.5 rounded-xl transition ${timeRange === '30days' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
          >
            ৩০ দিন (মাসিক)
          </button>
        </div>
      </div>

      {/* 4 LIVE OVERVIEW METRIC CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: অ্যাক্টিভ সার্ভিসেস / পণ্য */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3 relative overflow-hidden group hover:border-emerald-300 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">লিস্টেড পণ্য ও সার্ভিস</span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-900">{products.length}টি</span>
          </div>
          <p className="text-[11px] text-slate-400">ডাটাবেসে মোট সক্রিয় স্টোর ক্যাটালগ</p>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-blue-500 h-full w-[100%] rounded-full"></div>
          </div>
        </div>

        {/* Card 2: মোট রেজিস্টার্ড ইউজার */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3 relative overflow-hidden group hover:border-emerald-300 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">মোট রেজিস্টার্ড ইউজার</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-900">{users.length} জন</span>
          </div>
          <p className="text-[11px] text-slate-400">{verifiedProsCount} ভেরিফাইড প্রফেশনাল, {users.length} মোট মেম্বার</p>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full w-[100%] rounded-full"></div>
          </div>
        </div>

        {/* Card 3: রক্তদাতা সদস্য */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3 relative overflow-hidden group hover:border-emerald-300 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">নিবন্ধিত রক্তদাতা</span>
            <div className="w-9 h-9 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
              <Droplet className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-900">{bloodDonors.length} জন</span>
          </div>
          <p className="text-[11px] text-slate-400">জরুরি রক্তদানের জন্য প্রস্তুত তালিকা</p>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-red-500 h-full w-[100%] rounded-full"></div>
          </div>
        </div>

        {/* Card 4: মোট জিএমভি ও অর্ডার বিক্রয় */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3 relative overflow-hidden group hover:border-emerald-300 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">মোট বিক্রয় ভলিউম (GMV)</span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-900">৳{totalGMV.toLocaleString()}</span>
          </div>
          <p className="text-[11px] text-slate-400">মোট ডেলিভার্ড অর্ডার: {deliveredOrdersCount}টি / মোট অর্ডার: {orders.length}টি</p>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-amber-500 h-full w-[100%] rounded-full"></div>
          </div>
        </div>

      </div>

      {/* Middle Row: Area Distribution & Platform Health */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* District-wise Demand & Network Load */}
        <div className="lg:col-span-7 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">এলাকাভিত্তিক প্রফেশনাল নেটওয়ার্ক কভারেজ</h3>
                <p className="text-[11px] text-slate-400">পার্বত্য ৩ জেলা ও অন্যান্য অঞ্চলের প্রকৃত তথ্য</p>
              </div>
            </div>
          </div>

          <div className="space-y-4 pt-1">
            {districtTraffic.map((d, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-800">{d.district}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 font-medium text-[11px]">{d.pros} জন</span>
                    <span className="font-black text-slate-900">{d.share}%</span>
                  </div>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className={`${d.color} h-full rounded-full transition-all duration-500`} style={{ width: `${Math.max(d.share, 2)}%` }}></div>
                </div>
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>নিবন্ধিত প্রফেশনালস: {d.pros} জন</span>
                  <span className="text-emerald-600 font-bold">{d.pros > 0 ? 'সক্রিয়' : 'খালি'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* System Health */}
        <div className="lg:col-span-5 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">প্ল্যাটফর্ম ও ডাটাবেস স্বাস্থ্য</h3>
                  <p className="text-[11px] text-slate-400">রিয়েল-টাইম ফায়ারবেস ও সিকিউরিটি স্ট্যাটাস</p>
                </div>
              </div>
            </div>

            <div className="space-y-3 pt-3">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <span className="text-xs font-semibold text-slate-700">ফায়ারবেস কানেক্টিভিটি</span>
                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                  অনলাইন
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <span className="text-xs font-semibold text-slate-700">পেন্ডিং কমপ্লেইন</span>
                <span className={`text-xs font-bold px-2.5 py-1 rounded-lg border ${complaints.length > 0 ? 'text-amber-700 bg-amber-50 border-amber-200' : 'text-slate-600 bg-slate-100 border-slate-200'}`}>
                  {complaints.length}টি
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <span className="text-xs font-semibold text-slate-700">কেওয়াইসি ভেরিফিকেশন পেন্ডিং</span>
                <span className={`text-xs font-bold px-2.5 py-1 rounded-lg border ${pendingKYC > 0 ? 'text-blue-700 bg-blue-50 border-blue-200' : 'text-slate-600 bg-slate-100 border-slate-200'}`}>
                  {pendingKYC} জন
                </span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 space-y-1">
            <div className="flex items-center justify-between text-xs font-bold text-emerald-400">
              <span className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 animate-pulse" /> সিস্টেম স্ট্যাটাস
              </span>
              <span>100% Operational</span>
            </div>
            <p className="text-[11px] text-slate-400">রিয়েল ডাটা মোড সক্রিয়। কোনো কৃত্রিম পরিসংখ্যান অন্তর্ভুক্ত নেই।</p>
          </div>
        </div>

      </div>

      {/* Real Live Activity Stream */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">সাম্প্রতিক কার্যক্রম লগ</h3>
              <p className="text-[11px] text-slate-400">ডাটাবেস থেকে প্রাপ্ত লাইভ অ্যাক্টিভিটি</p>
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 text-xs font-bold">
            <button
              onClick={() => setActivityFilter('all')}
              className={`px-3 py-1.5 rounded-xl transition ${activityFilter === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              সব ইভেন্ট
            </button>
            <button
              onClick={() => setActivityFilter('orders')}
              className={`px-3 py-1.5 rounded-xl transition ${activityFilter === 'orders' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              অর্ডারস
            </button>
            <button
              onClick={() => setActivityFilter('registrations')}
              className={`px-3 py-1.5 rounded-xl transition ${activityFilter === 'registrations' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              রেজিস্ট্রেশন
            </button>
          </div>
        </div>

        <div className="space-y-2.5">
          {filteredLogs.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
              কোনো সাম্প্রতিক কার্যক্রম লগ পাওয়া যায়নি (০টি ইভেন্ট)।
            </div>
          ) : (
            filteredLogs.map(log => (
              <div key={log.id} className="p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/60 flex items-center justify-between gap-3 transition">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                    log.type === 'order' ? 'bg-emerald-100 text-emerald-700' :
                    log.type === 'search' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {log.type === 'order' && <ShoppingBag className="w-4 h-4" />}
                    {log.type === 'search' && <Search className="w-4 h-4" />}
                    {log.type === 'registrations' && <Users className="w-4 h-4" />}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">{log.text}</span>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3" /> {log.time}
                    </span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  {log.amount && (
                    <span className="text-xs font-black text-emerald-700 block">{log.amount}</span>
                  )}
                  {log.tag && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-200 text-slate-700">
                      {log.tag}
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
};
