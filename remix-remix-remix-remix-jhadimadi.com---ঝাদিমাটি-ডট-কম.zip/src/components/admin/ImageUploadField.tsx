import React, { useState, useRef } from 'react';
import { 
  UploadCloud, 
  Image as ImageIcon, 
  Trash2, 
  RefreshCw, 
  FolderOpen, 
  CheckCircle2, 
  AlertCircle,
  Link2,
  Eye
} from 'lucide-react';
import { compressImage } from '../../utils/imageUtils';

interface ImageUploadFieldProps {
  label: string;
  value: string;
  onChange: (imageUrl: string) => void;
  helperText?: string;
  recommendedSize?: string;
  aspectRatioLabel?: string;
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  presets?: { label: string; url: string }[];
  required?: boolean;
}

export const ImageUploadField: React.FC<ImageUploadFieldProps> = ({
  label,
  value,
  onChange,
  helperText = 'আপনার কম্পিউটার বা ডিভাইস থেকে ছবি নির্বাচন করুন (PNG, JPG, WebP)',
  recommendedSize = 'সর্বোচ্চ ৫ মেগাবাইট',
  aspectRatioLabel,
  maxWidth = 1000,
  maxHeight = 700,
  quality = 0.82,
  presets = [],
  required = false
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [manualUrl, setManualUrl] = useState('');

  const processFile = async (file: File) => {
    setErrorMessage(null);
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    const safeExtensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

    if (!file.type.startsWith('image/') || !safeExtensions.includes(ext) || file.type.includes('svg') || file.type.includes('html')) {
      setErrorMessage('নিরাপত্তা কারণে শুধুমাত্র ছবি ফাইল (PNG, JPG, WebP) আপলোড করুন।');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setErrorMessage('ছবির সাইজ ১০ মেগাবাইটের বেশি হতে পারবে না।');
      return;
    }

    setIsProcessing(true);
    try {
      const compressedDataUrl = await compressImage(file, maxWidth, maxHeight, quality);
      if (compressedDataUrl) {
        onChange(compressedDataUrl);
      } else {
        // Fallback to simple FileReader
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result) {
            onChange(e.target.result as string);
          }
        };
        reader.readAsDataURL(file);
      }
    } catch (err) {
      console.error('[ImageUpload] Error processing image:', err);
      setErrorMessage('ছবি প্রসেস করতে সমস্যা হয়েছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
    // reset input so the same file can be re-selected if desired
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleRemove = () => {
    onChange('');
    setErrorMessage(null);
    setManualUrl('');
  };

  const handleApplyUrl = () => {
    if (manualUrl.trim()) {
      onChange(manualUrl.trim());
      setShowUrlInput(false);
      setManualUrl('');
    }
  };

  return (
    <div className="space-y-2">
      {/* Label and Info */}
      <div className="flex items-center justify-between">
        <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
          <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
          <span>{label} {required && <span className="text-rose-500">*</span>}</span>
        </label>
        <div className="flex items-center gap-2 text-[10px]">
          {aspectRatioLabel && (
            <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-bold border border-emerald-200/60">
              {aspectRatioLabel}
            </span>
          )}
          <button
            type="button"
            onClick={() => setShowUrlInput(!showUrlInput)}
            className="text-slate-500 hover:text-slate-800 transition flex items-center gap-1 cursor-pointer font-medium"
          >
            <Link2 className="w-3 h-3" />
            <span>{showUrlInput ? 'ফাইল আপলোড মোড' : 'URL ইনপুট'}</span>
          </button>
        </div>
      </div>

      {/* Hidden File Input for Native PC/Phone Picker */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/png, image/jpeg, image/jpg, image/webp, image/gif"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Error Message */}
      {errorMessage && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 p-2.5 rounded-xl text-xs flex items-center gap-2 font-medium">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Optional Manual URL Input */}
      {showUrlInput && (
        <div className="flex gap-2 items-center bg-slate-50 p-2.5 rounded-xl border border-slate-200">
          <input
            type="url"
            value={manualUrl}
            onChange={(e) => setManualUrl(e.target.value)}
            placeholder="https://images.unsplash.com/..."
            className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono focus:outline-none focus:border-emerald-500"
          />
          <button
            type="button"
            onClick={handleApplyUrl}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition cursor-pointer"
          >
            প্রয়োগ করুন
          </button>
        </div>
      )}

      {/* Image Preview Box (If Image is Selected) */}
      {value ? (
        <div className="relative bg-slate-900 border-2 border-emerald-500/40 rounded-2xl overflow-hidden p-3 shadow-sm transition-all group">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            
            {/* Image Thumbnail */}
            <div className="relative w-full sm:w-48 h-32 bg-slate-950 rounded-xl overflow-hidden flex items-center justify-center border border-slate-700/60 shrink-0">
              <img
                src={value}
                alt="Selected Upload"
                className="w-full h-full object-contain sm:object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=300';
                }}
              />
              <div className="absolute top-1.5 right-1.5 bg-emerald-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-1 shadow-xs">
                <CheckCircle2 className="w-2.5 h-2.5" />
                <span>যুক্ত হয়েছে</span>
              </div>
            </div>

            {/* Actions & File Details */}
            <div className="flex-1 w-full space-y-2 text-left">
              <div>
                <div className="text-white text-xs font-bold flex items-center gap-1.5">
                  <span>ছবি নির্বাচন সফল</span>
                  <span className="text-[10px] text-emerald-400 font-mono">(Ready)</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1 font-mono">
                  {value.startsWith('data:') ? 'লোকাল পিসি / মেমোরি থেকে আপলোডকৃত' : value}
                </p>
              </div>

              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isProcessing}
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border border-slate-600 shadow-xs"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`} />
                  <span>অন্য ছবি নির্বাচন করুন</span>
                </button>

                <button
                  type="button"
                  onClick={handleRemove}
                  className="px-3.5 py-2 bg-rose-950/80 hover:bg-rose-900 active:scale-95 text-rose-200 border border-rose-800/80 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                  title="ছবি মুছে ফেলুন"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                  <span>মুছে ফেলুন</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Upload Drag-and-Drop Area */
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-2xl p-6 sm:p-7 text-center transition-all cursor-pointer select-none group ${
            isDragging
              ? 'border-emerald-500 bg-emerald-50/70 scale-[0.99]'
              : 'border-slate-300 hover:border-emerald-500 bg-slate-50/70 hover:bg-emerald-50/20'
          }`}
        >
          {isProcessing ? (
            <div className="py-4 space-y-2">
              <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto" />
              <p className="text-xs font-bold text-slate-700">ছবি প্রসেস ও অপ্টিমাইজ করা হচ্ছে...</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-slate-200 flex items-center justify-center mx-auto text-emerald-600 group-hover:scale-110 group-hover:text-emerald-700 transition">
                <UploadCloud className="w-6 h-6" />
              </div>

              <div>
                <p className="text-xs font-black text-slate-800 flex items-center justify-center gap-1.5">
                  <FolderOpen className="w-3.5 h-3.5 text-emerald-600" />
                  <span>পিসি বা মেমোরি ফোল্ডার থেকে সরাসরি ছবি আপলোড করুন</span>
                </p>
                <p className="text-[11px] text-slate-500 mt-1">
                  ব্রাউজ করতে এখানে ক্লিক করুন অথবা ছবি টেনে এনে (Drag & Drop) ছেড়ে দিন
                </p>
              </div>

              <div className="flex items-center justify-center gap-2 pt-1 text-[10px] text-slate-400">
                <span className="bg-white px-2 py-0.5 rounded-md border border-slate-200">PNG, JPG, WebP</span>
                <span>•</span>
                <span>{recommendedSize}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Preset Suggestions (If provided) */}
      {presets.length > 0 && !value && (
        <div className="pt-1 space-y-1">
          <span className="text-[10px] text-slate-400 block font-normal">অথবা ১-ক্লিকে প্রিসেট পাহাড়ি ছবি নিন:</span>
          <div className="flex flex-wrap gap-1.5">
            {presets.map((p, i) => (
              <button
                type="button"
                key={i}
                onClick={(e) => {
                  e.stopPropagation();
                  onChange(p.url);
                }}
                className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200 text-slate-600 border border-slate-200 rounded-lg text-[10px] font-bold transition cursor-pointer"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
