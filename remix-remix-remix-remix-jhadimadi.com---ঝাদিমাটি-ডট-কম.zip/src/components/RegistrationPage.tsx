import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  ShoppingBag, 
  Wrench, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  ArrowLeft, 
  Languages, 
  Upload, 
  Camera, 
  User, 
  Phone, 
  MapPin, 
  Lock, 
  Eye, 
  EyeOff, 
  Check, 
  Copy, 
  FileText, 
  Award, 
  DollarSign, 
  Sparkles,
  ArrowRight,
  Package,
  Layers,
  Store,
  CreditCard,
  QrCode,
  CheckCircle,
  MessageSquare,
  MessageCircle,
  PhoneCall,
  ExternalLink,
  Search,
  Plus,
  X,
  ChevronDown
} from 'lucide-react';
import { Language, UserProfile, ServiceProvider, OrganicProduct } from '../types';
import { databaseService } from '../services/databaseService';
import { generateMerchantOrServiceUID, generateJhadimadiCleanUID, generateDistrictUniqueId, maskPhoneNumber } from '../utils/uniqueIdGenerator';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { ServiceProviderRegistrationForm } from './ServiceProviderRegistrationForm';
import { ServiceProviderPublicProfile } from './ServiceProviderPublicProfile';
import { ProductSellerProfile } from './ProductSellerProfile';
import { PermanentMemberProfile } from './PermanentMemberProfile';
import { ALL_PROFESSIONS_FLAT_LIST } from '../data/professionsMasterData';

export type RegistrationTab = 'seller' | 'service' | 'permanent';

export interface RegistrationPageProps {
  initialTab?: RegistrationTab;
  isEditMode?: boolean;
  lang: Language;
  onLanguageToggle?: () => void;
  onSuccess?: (user: UserProfile, extraData?: any) => void;
  onNavigateToSignIn: () => void;
  onBack: () => void;
  currentUser?: UserProfile | null;
}

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

const CHT_DISTRICTS = ['Khagrachhari', 'Rangamati', 'Bandarban', 'Chittagong', 'Dhaka', 'Cox\'s Bazar', 'Comilla', 'Feni', 'Noakhali', 'Sylhet'];

const UPAZILA_MAP: Record<string, string[]> = {
  'Khagrachhari': ['Khagrachhari Sadar', 'Dighinala', 'Panchhari', 'Mahalchhari', 'Matiranga', 'Manikchhari', 'Ramgarh', 'Guimara', 'Lakshmichhari'],
  'Rangamati': ['Rangamati Sadar', 'Kaptai', 'Kaukhali', 'Baghaichhari', 'Barkal', 'Jurachhari', 'Rajasthali', 'Belaichhari', 'Naniarchar', 'Langadu'],
  'Bandarban': ['Bandarban Sadar', 'Ruma', 'Thanchi', 'Rowangchhari', 'Lama', 'Alikadam', 'Naikhongchhari'],
  'Chittagong': ['Kotwali', 'Panchlaish', 'Pahartali', 'Agrabad', 'Hathazari', 'Sitakunda', 'Raozan', 'Fatikchhari'],
  'Dhaka': ['Mirpur', 'Dhanmondi', 'Gulshan', 'Uttara', 'Mohammadpur', 'Motijheel', 'Badda', 'Tejgaon'],
  'Cox\'s Bazar': ['Cox\'s Bazar Sadar', 'Ramu', 'Chakaria', 'Teknaf', 'Ukhiya'],
  'Comilla': ['Comilla Sadar', 'Chandina', 'Debidwar', 'Burichang'],
  'Feni': ['Feni Sadar', 'Daganbhuiyan', 'Chhagalnaiya', 'Parshuram'],
  'Noakhali': ['Noakhali Sadar', 'Begumganj', 'Chatkhil', 'Companyganj'],
  'Sylhet': ['Sylhet Sadar', 'Golapganj', 'Beanibazar', 'Biswanath']
};

const SERVICE_PROFESSIONS = [
  { id: 'household', category: 'Household', bn: 'গৃহস্থালি সেবা ও হোম ক্লিনিং', en: 'Household & Home Cleaning' },
  { id: 'electrician', category: 'Technical', bn: 'ইলেকট্রিশিয়ান ও সোলার টেকনিশিয়ান', en: 'Electrician & Solar Technician' },
  { id: 'plumber', category: 'Technical', bn: 'প্লাম্বার ও পাইপ ফিটার', en: 'Plumber & Pipe Fitter' },
  { id: 'carpenter', category: 'Construction', bn: 'কাঠমিস্ত্রি ও ফার্নিচার কারিগর', en: 'Carpenter & Furniture Maker' },
  { id: 'mason', category: 'Construction', bn: 'রাজমিস্ত্রি ও কনস্ট্রাকশন শ্রমিক', en: 'Mason & Construction Worker' },
  { id: 'mechanic', category: 'Vehicle', bn: 'মোটরসাইকেল ও ইঞ্জিন মেকানিক', en: 'Auto & Bike Mechanic' },
  { id: 'driver', category: 'Vehicle', bn: 'সিএনজি, কার ও জিপ ড্রাইভার', en: 'Professional Driver' },
  { id: 'appliance', category: 'Technical', bn: 'ফ্রিজ, এসি ও টিভি টেকনিশিয়ান', en: 'AC, Fridge & TV Technician' },
  { id: 'it_freelance', category: 'IT', bn: 'আইটি, কম্পিউটার ও অনলাইন সাপোর্ট', en: 'IT & Freelancing Support' },
  { id: 'events_decor', category: 'Events', bn: 'ইভেন্ট ম্যানেজমেন্ট ও ডেকোরেশন', en: 'Events, Sound & Decor' },
  { id: 'tutor_education', category: 'Tuition', bn: 'হোম টিউটর ও শিক্ষকতা', en: 'Home Tutor & Teacher' },
  { id: 'health_care', category: 'Health', bn: 'স্বাস্থ্যসেবা ও নার্সিং সাপোর্ট', en: 'Health & Caregiving Support' },
  { id: 'painter', category: 'Construction', bn: 'রং মিস্ত্রি ও পেইন্টার', en: 'Painter & Decorator' },
  { id: 'tailor', category: 'Household', bn: 'দর্জি ও পাহাড়ি থামি সেলাই কারিগর', en: 'Tailor & Weaver' },
  { id: 'tree_agri', category: 'Agriculture', bn: 'বাগান পরিচর্যা ও কৃষি সহায়তা', en: 'Agri Worker & Gardening' },
];

const PRODUCT_CATEGORIES = [
  { id: 'electronics', bn: 'ইলেকট্রনিক্স ও মোবাইল গ্যাজেটস', en: 'Electronics & Gadgets' },
  { id: 'vegetables', bn: 'তাজা শাকসবজি ও পাহাড়ি কাঁচাবাজার', en: 'Fresh Vegetables & Greens' },
  { id: 'clothes_three_piece', bn: 'থ্রি-পিস, পাহাড়ি থামি ও পোশাক', en: 'Three-Pieces, Thami & Clothing' },
  { id: 'fruits_agro', bn: 'পাহাড়ি ফলমূল, আম্রপালি ও কৃষি পণ্য', en: 'Hill Fruits & Agro Produce' },
  { id: 'organic_food', bn: 'পাহাড়ি অর্গানিক খাবার, মধু ও শুঁটকি', en: 'Organic Food, Honey & Dried Fish' },
  { id: 'handicrafts', bn: 'বাঁশ, বেত ও কাঠের আসবাব ও হস্তশিল্প', en: 'Bamboo, Cane & Wood Crafts' },
  { id: 'spices_grain', bn: 'পাহাড়ি হলুদ, আদা ও প্রাকৃতিক মশলা', en: 'Hill Spices, Turmeric & Ginger' },
  { id: 'grocery_store', bn: 'মুদি, জেনারেল স্টোর ও নিত্যপ্রয়োজনীয় সামগ্রী', en: 'Grocery & General Store' },
  { id: 'other', bn: 'অন্যান্য পণ্য সামগ্রী', en: 'Other Products' },
];

const SAMPLE_PRODUCT_IMAGES = [
  { labelBn: 'পাহাড়ি অর্গানিক মধু', labelEn: 'Raw Hill Honey', url: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80' },
  { labelBn: 'পাহাড়ি তাজা আম্রপালি', labelEn: 'Hill Amrapali Mangoes', url: 'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=600&q=80' },
  { labelBn: 'ঐতিহ্যবাহী পাহাড়ি থামি', labelEn: 'Handwoven Thami', url: 'https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=600&q=80' },
  { labelBn: 'বাঁশ ও বেতের হস্তশিল্প', labelEn: 'Bamboo Cane Craft', url: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=600&q=80' }
];

export const RegistrationPage: React.FC<RegistrationPageProps> = ({
  initialTab = 'seller',
  isEditMode = false,
  lang: initialLang,
  onLanguageToggle,
  onSuccess,
  onNavigateToSignIn,
  onBack,
  currentUser
}) => {
  const { login, logout } = useAuth();
  const { addProduct } = useData();

  // Internal language state with fallback to prop
  const [currentLang, setCurrentLang] = useState<Language>(initialLang || 'bn');
  const lang = currentLang;

  const handleToggleLang = () => {
    const nextLang = currentLang === 'bn' ? 'en' : 'bn';
    setCurrentLang(nextLang);
    if (onLanguageToggle) onLanguageToggle();
  };

  // Active Tab: 1. Product Seller Member, 2. Service Provider Member, 3. Jhadimadi Permanent Member
  const [activeTab, setActiveTab] = useState<RegistrationTab>(initialTab);

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Common UI State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [generatedUser, setGeneratedUser] = useState<UserProfile | null>(null);
  const [generatedId, setGeneratedId] = useState<string>('');
  const [copiedId, setCopiedId] = useState(false);

  // ==========================================
  // TAB 1: PRODUCT SELLER MEMBER STATE
  // ==========================================
  const [sellerName, setSellerName] = useState(currentUser?.fullName || currentUser?.name || '');
  const [sellerShopName, setSellerShopName] = useState((currentUser as any)?.shopName || (currentUser as any)?.storeName || '');
  const [sellerPhone, setSellerPhone] = useState(currentUser?.phone || '');
  const [sellerPassword, setSellerPassword] = useState('');
  const [showSellerPassword, setShowSellerPassword] = useState(false);
  const [sellerDistrict, setSellerDistrict] = useState(currentUser?.district || 'Khagrachhari');
  const [sellerUpazila, setSellerUpazila] = useState(currentUser?.upazila || 'Khagrachhari Sadar');
  const [sellerArea, setSellerArea] = useState(currentUser?.mahalla || 'পৌর এলাকা (Bazar Area)');
  const [sellerBloodGroup, setSellerBloodGroup] = useState(currentUser?.bloodGroup || 'B+');
  const [productTitle, setProductTitle] = useState('');
  const [productCategory, setProductCategory] = useState('vegetables');
  const [productPrice, setProductPrice] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [productImageUrl, setProductImageUrl] = useState(SAMPLE_PRODUCT_IMAGES[0].url);
  const [sellerConsent, setSellerConsent] = useState(isEditMode);

  // ==========================================
  // TAB 2: SERVICE PROVIDER MEMBER STATE
  // ==========================================
  const [spName, setSpName] = useState(currentUser?.fullName || currentUser?.name || '');
  const [spPhone, setSpPhone] = useState(currentUser?.phone || '');
  const [spPassword, setSpPassword] = useState('');
  const [showSpPassword, setShowSpPassword] = useState(false);
  const [spProfession, setSpProfession] = useState(currentUser?.profession || currentUser?.professionBn || '');
  const [spSearchQuery, setSpSearchQuery] = useState(currentUser?.profession || currentUser?.professionBn || '');
  const [isSpDropdownOpen, setIsSpDropdownOpen] = useState(false);
  const [spDistrict, setSpDistrict] = useState(currentUser?.district || 'Khagrachhari');
  const [spUpazila, setSpUpazila] = useState(currentUser?.upazila || 'Khagrachhari Sadar');
  const [spArea, setSpArea] = useState(currentUser?.mahalla || 'সদর এলাকা (Main Area)');
  const [spBloodGroup, setSpBloodGroup] = useState(currentUser?.bloodGroup || 'B+');
  const [spExperienceYears, setSpExperienceYears] = useState((currentUser as any)?.experienceYears?.toString() || '2');
  const [spDailyRate, setSpDailyRate] = useState((currentUser as any)?.dailyRate?.toString() || '600');
  const [spBio, setSpBio] = useState(currentUser?.bio || '');
  const [spConsent, setSpConsent] = useState(isEditMode);

  // Synchronize with currentUser when editing or switching
  useEffect(() => {
    if (currentUser) {
      if (currentUser.role === 'seller' || (currentUser.memberUID && currentUser.memberUID.startsWith('JH-S-'))) {
        setSellerName(currentUser.fullName || currentUser.name || '');
        setSellerShopName((currentUser as any)?.shopName || (currentUser as any)?.storeName || '');
        setSellerPhone(currentUser.phone || '');
        setSellerDistrict(currentUser.district || 'Khagrachhari');
        setSellerUpazila(currentUser.upazila || 'Khagrachhari Sadar');
        setSellerArea(currentUser.mahalla || 'পৌর এলাকা (Bazar Area)');
        setSellerBloodGroup(currentUser.bloodGroup || 'B+');
      } else if (currentUser.role === 'permanent' || (currentUser.memberUID && currentUser.memberUID.startsWith('JH-M-'))) {
        setPermName(currentUser.fullName || currentUser.name || '');
        setPermPhone(currentUser.phone || '');
        setPermEmail(currentUser.email || '');
        setPermDistrict(currentUser.district || 'Khagrachhari');
        setPermUpazila(currentUser.upazila || 'Khagrachhari Sadar');
        setPermArea(currentUser.mahalla || 'পানখাইয়াপাড়া (Pankhaiyapara)');
        setPermBloodGroup(currentUser.bloodGroup || 'O+');
        setPermSpecialization(currentUser.profession || 'স্থায়ী প্রতিনিধি ও আঞ্চলিক কো-অর্ডিনেটর');
        setPermNidNumber(currentUser.nidNumber || '');
        setPermBio(currentUser.bio || '');
        setPermEmergencyContact((currentUser as any).emergencyContact || '');
      } else {
        setSpName(currentUser.fullName || currentUser.name || '');
        setSpPhone(currentUser.phone || '');
        setSpProfession(currentUser.profession || currentUser.professionBn || '');
        setSpSearchQuery(currentUser.profession || currentUser.professionBn || '');
        setSpDistrict(currentUser.district || 'Khagrachhari');
        setSpUpazila(currentUser.upazila || 'Khagrachhari Sadar');
        setSpArea(currentUser.mahalla || 'সদর এলাকা (Main Area)');
        setSpBloodGroup(currentUser.bloodGroup || 'B+');
        setSpExperienceYears((currentUser as any).experienceYears?.toString() || '2');
        setSpDailyRate((currentUser as any).dailyRate?.toString() || '600');
        setSpBio(currentUser.bio || '');
      }
    }
  }, [currentUser]);

  // Autocomplete suggestions for professions in Tab 2
  const filteredProfessions = useMemo(() => {
    const q = spSearchQuery.trim().toLowerCase();
    if (!q) {
      return SERVICE_PROFESSIONS.map(p => ({
        name: lang === 'bn' ? p.bn : p.en,
        category: p.category
      }));
    }
    const matches: { name: string; category?: string }[] = [];
    // Search in master 1,000+ list
    if (Array.isArray(ALL_PROFESSIONS_FLAT_LIST)) {
      for (const p of ALL_PROFESSIONS_FLAT_LIST) {
        if (p.name.toLowerCase().includes(q) || (p.category && p.category.toLowerCase().includes(q))) {
          if (!matches.some(m => m.name.toLowerCase() === p.name.toLowerCase())) {
            matches.push({ name: p.name, category: p.category });
          }
          if (matches.length >= 15) break;
        }
      }
    }
    // Also search in standard list
    for (const p of SERVICE_PROFESSIONS) {
      const bnMatch = p.bn.toLowerCase().includes(q);
      const enMatch = p.en.toLowerCase().includes(q);
      if (bnMatch || enMatch) {
        const val = lang === 'bn' ? p.bn : p.en;
        if (!matches.some(m => m.name.toLowerCase() === val.toLowerCase())) {
          matches.unshift({ name: val, category: p.category });
        }
      }
    }
    return matches;
  }, [spSearchQuery, lang]);

  // ==========================================
  // TAB 3: JHADIMADI PERMANENT MEMBER STATE
  // ==========================================
  const [permName, setPermName] = useState(currentUser?.fullName || currentUser?.name || '');
  const [permPhone, setPermPhone] = useState(currentUser?.phone || '');
  const [permEmail, setPermEmail] = useState(currentUser?.email || '');
  const [permPassword, setPermPassword] = useState('');
  const [showPermPassword, setShowPermPassword] = useState(false);
  const [permDistrict, setPermDistrict] = useState(currentUser?.district || 'Khagrachhari');
  const [permUpazila, setPermUpazila] = useState(currentUser?.upazila || 'Khagrachhari Sadar');
  const [permArea, setPermArea] = useState(currentUser?.mahalla || 'পানখাইয়াপাড়া (Pankhaiyapara)');
  const [permBloodGroup, setPermBloodGroup] = useState('O+');
  const [permSpecialization, setPermSpecialization] = useState('স্থায়ী প্রতিনিধি ও আঞ্চলিক কো-অর্ডিনেটর');
  const [permNidNumber, setPermNidNumber] = useState('');
  const [permNidPhotoUrl, setPermNidPhotoUrl] = useState('https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80');
  const [permCertificateText, setPermCertificateText] = useState('জাতীয় পরিচয়পত্র ও শিক্ষাগত/কারিগরি যোগ্যতা সনদ');
  const [permSelfieUrl, setPermSelfieUrl] = useState('https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80');
  const [permBio, setPermBio] = useState('');
  const [permEmergencyContact, setPermEmergencyContact] = useState('');
  const [permConsent, setPermConsent] = useState(false);

  // Helper for District changes
  const handleDistrictChange = (dist: string, type: 'seller' | 'sp' | 'perm') => {
    const upazilas = UPAZILA_MAP[dist] || ['Sadar'];
    if (type === 'seller') {
      setSellerDistrict(dist);
      setSellerUpazila(upazilas[0] || 'Sadar');
    } else if (type === 'sp') {
      setSpDistrict(dist);
      setSpUpazila(upazilas[0] || 'Sadar');
    } else {
      setPermDistrict(dist);
      setPermUpazila(upazilas[0] || 'Sadar');
    }
  };

  // ==========================================
  // SUBMISSION LOGIC (AUTO PROFILE + UNIQUE ID)
  // ==========================================

  const handleSellerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!sellerName.trim()) {
      setErrorMsg(lang === 'bn' ? 'অনুগ্রহ করে আপনার নাম লিখুন।' : 'Please enter your full name.');
      return;
    }
    if (!sellerPhone.trim() || sellerPhone.replace(/[^0-9]/g, '').length < 10) {
      setErrorMsg(lang === 'bn' ? 'সঠিক ১১ ডিজিটের মোবাইল বা হোয়াটসঅ্যাপ নম্বর প্রদান করুন।' : 'Please provide a valid 11-digit mobile/WhatsApp number.');
      return;
    }
    if (!isEditMode && (!sellerPassword.trim() || sellerPassword.trim().length < 6)) {
      setErrorMsg(lang === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.');
      return;
    }
    if (!isEditMode && !sellerConsent) {
      setErrorMsg(lang === 'bn' ? 'সম্মতি বক্সে টিক চিহ্ন প্রদান করতে হবে।' : 'Please accept the consent checkbox to continue.');
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Generate unique ID automatically (Format: JH-S-[DIST]-001)
      const generatedUID = currentUser?.memberUID || currentUser?.sellerCode || generateJhadimadiCleanUID('seller', sellerDistrict);
      const userId = currentUser?.id || currentUser?.uid || `seller_${Date.now()}`;

      // 2. Build User Profile
      const newProfile: UserProfile = {
        id: userId,
        uid: userId,
        name: sellerName.trim(),
        fullName: sellerName.trim(),
        shopName: sellerShopName.trim() || `${sellerName.trim()}-এর পাহাড়ি স্টোর`,
        phone: sellerPhone.trim(),
        password: sellerPassword.trim() || currentUser?.password || '123456',
        bloodGroup: sellerBloodGroup,
        division: 'চট্টগ্রাম',
        district: sellerDistrict,
        upazila: sellerUpazila,
        mahalla: sellerArea.trim(),
        detailedAddress: `${sellerArea.trim()}, ${sellerUpazila}, ${sellerDistrict}`,
        role: 'seller',
        memberType: 'seller',
        profession: 'মার্চেন্ট / বিক্রেতা',
        professionBn: 'পণ্য বিক্রেতা সদস্য',
        avatar: productImageUrl || currentUser?.avatar || 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=400&q=80',
        isNidVerified: true,
        isPaidMember: true,
        memberUID: generatedUID,
        sellerCode: generatedUID,
        createdAt: currentUser?.createdAt || new Date().toISOString().split('T')[0],
      };

      // 3. Save to database service
      await databaseService.saveUserProfile(newProfile, { skipUniqueCheck: true });

      // 4. If product details provided, save product
      if (productTitle.trim()) {
        const newProduct = {
          id: `prod_${Date.now()}`,
          nameBn: productTitle.trim(),
          nameEn: productTitle.trim(),
          category: productCategory as any,
          categoryBn: PRODUCT_CATEGORIES.find(c => c.id === productCategory)?.bn || 'পাহাড়ি পণ্য',
          price: parseInt(productPrice, 10) || 250,
          originalPrice: Math.round((parseInt(productPrice, 10) || 250) * 1.15),
          weight: '১ কেজি / ১ প্যাক',
          image: productImageUrl,
          rating: 5.0,
          reviewsCount: 1,
          isOrganic: true,
          inStock: true,
          origin: `${sellerUpazila}, ${sellerDistrict}`,
          descriptionBn: productDescription.trim() || `${sellerName.trim()}-এর সংগৃহীত তাজা ও খাঁটি পাহাড়ি পণ্য।`,
          farmerName: sellerShopName.trim() || sellerName.trim(),
          unit: 'কেজি'
        };

        if (typeof addProduct === 'function') {
          addProduct(newProduct);
        }
      }

      // 5. Automatically log in the user
      login(newProfile, true);
      setGeneratedUser(newProfile);
      setGeneratedId(generatedUID);

      if (onSuccess) {
        onSuccess(newProfile);
      }
    } catch (err: any) {
      console.error('[Registration] Seller Error:', err);
      setErrorMsg(err?.message || (lang === 'bn' ? 'রেজিস্ট্রেশন সম্পন্ন করা যায়নি। পুনরায় চেষ্টা করুন।' : 'Registration failed. Please try again.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!spName.trim()) {
      setErrorMsg(lang === 'bn' ? 'অনুগ্রহ করে আপনার নাম লিখুন।' : 'Please enter your full name.');
      return;
    }
    if (!spPhone.trim() || spPhone.replace(/[^0-9]/g, '').length < 10) {
      setErrorMsg(lang === 'bn' ? 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন।' : 'Please provide a valid 11-digit mobile number.');
      return;
    }
    if (!isEditMode && (!spPassword.trim() || spPassword.trim().length < 6)) {
      setErrorMsg(lang === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.');
      return;
    }
    let finalProfession = spProfession.trim();
    if (!finalProfession && spSearchQuery.trim()) {
      finalProfession = spSearchQuery.trim();
      setSpProfession(finalProfession);
    }

    if (!finalProfession) {
      setErrorMsg(lang === 'bn' ? 'অনুগ্রহ করে আপনার পেশা বা সেবা নির্বাচন বা টাইপ করুন।' : 'Please select or type your profession.');
      return;
    }
    if (!isEditMode && !spConsent) {
      setErrorMsg(lang === 'bn' ? 'সম্মতি বক্সে টিক চিহ্ন প্রদান করতে হবে।' : 'Please accept the consent checkbox to continue.');
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Generate unique ID automatically (Format: JH-P-[DIST]-002)
      const generatedUID = currentUser?.memberUID || generateJhadimadiCleanUID('service', spDistrict);
      const userId = currentUser?.id || currentUser?.uid || `sp_${Date.now()}`;

      // 2. Build User Profile
      const newProfile: UserProfile = {
        id: userId,
        uid: userId,
        name: spName.trim(),
        fullName: spName.trim(),
        phone: spPhone.trim(),
        password: spPassword.trim() || currentUser?.password || '123456',
        bloodGroup: spBloodGroup,
        division: 'চট্টগ্রাম',
        district: spDistrict,
        upazila: spUpazila,
        mahalla: spArea.trim(),
        detailedAddress: `${spArea.trim()}, ${spUpazila}, ${spDistrict}`,
        role: 'professional',
        memberType: 'service',
        profession: finalProfession,
        professionBn: finalProfession,
        bio: spBio.trim() || `${spName.trim()} - ঝাদিমাদি ভেরিফাইড প্রফেশনাল।`,
        avatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
        isNidVerified: true,
        isPaidMember: true,
        memberUID: generatedUID,
        createdAt: currentUser?.createdAt || new Date().toISOString().split('T')[0],
      };

      // 3. Save Service Provider record
      const newSpRecord: Partial<ServiceProvider> & Record<string, any> = {
        id: userId,
        name: spName.trim(),
        realPhone: spPhone.trim(),
        phoneHidden: maskPhoneNumber(spPhone.trim()),
        bloodGroup: spBloodGroup,
        categoryBn: finalProfession,
        categoryEn: finalProfession,
        subCategory: finalProfession,
        profession: finalProfession,
        professionBn: finalProfession,
        district: spDistrict as any,
        upazila: spUpazila,
        mahalla: spArea.trim(),
        detailedAddress: `${spArea.trim()}, ${spUpazila}, ${spDistrict}`,
        experienceYears: parseInt(spExperienceYears, 10) || 2,
        dailyRate: parseInt(spDailyRate, 10) || 600,
        hourlyRate: 150,
        rating: 5.0,
        jobsCompleted: 0,
        distanceKm: 1.2,
        bioBn: `${spName.trim()} - ঝাদিমাদি ভেরিফাইড প্রফেশনাল।`,
        nidVerified: true,
        blueTickActive: true,
        isAvailable: true,
        avatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
        memberUID: generatedUID,
      };

      await databaseService.saveUserProfile(newProfile, { skipUniqueCheck: true });

      // 4. Automatically log in user
      login(newProfile, true);
      setGeneratedUser(newProfile);
      setGeneratedId(generatedUID);

      if (onSuccess) {
        onSuccess(newProfile, newSpRecord);
      }
    } catch (err: any) {
      console.error('[Registration] Service Provider Error:', err);
      setErrorMsg(err?.message || (lang === 'bn' ? 'রেজিস্ট্রেশন সম্পন্ন করা যায়নি।' : 'Registration failed.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePermSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!permName.trim()) {
      setErrorMsg(lang === 'bn' ? 'অনুগ্রহ করে পূর্ণ নাম লিখুন।' : 'Please enter full name.');
      return;
    }
    if (!permPhone.trim() || permPhone.replace(/[^0-9]/g, '').length < 10) {
      setErrorMsg(lang === 'bn' ? 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন।' : 'Please provide a valid 11-digit phone number.');
      return;
    }
    if (!permNidNumber.trim()) {
      setErrorMsg(lang === 'bn' ? 'জাতীয় পরিচয়পত্র (NID) নম্বর আবশ্যক।' : 'National ID (NID) number is required.');
      return;
    }
    if (!isEditMode && (!permPassword.trim() || permPassword.trim().length < 6)) {
      if (!currentUser?.password) {
        setErrorMsg(lang === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.');
        return;
      }
    }
    if (!isEditMode && !permConsent) {
      setErrorMsg(lang === 'bn' ? 'সম্মতি বক্সে টিক চিহ্ন প্রদান করতে হবে।' : 'Please accept the consent checkbox to continue.');
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Generate unique Permanent Member ID (Format: JH-M-[DIST]-003)
      const generatedUID = currentUser?.memberUID || generateJhadimadiCleanUID('permanent', permDistrict);
      const userId = currentUser?.id || currentUser?.uid || `perm_${Date.now()}`;

      // 2. Build User Profile with comprehensive details
      const newProfile: UserProfile = {
        id: userId,
        uid: userId,
        name: permName.trim(),
        fullName: permName.trim(),
        phone: permPhone.trim(),
        email: permEmail.trim() || undefined,
        password: permPassword.trim() || currentUser?.password || '123456',
        division: 'চট্টগ্রাম',
        district: permDistrict,
        upazila: permUpazila,
        mahalla: permArea.trim(),
        detailedAddress: `${permArea.trim()}, ${permUpazila}, ${permDistrict}`,
        bloodGroup: permBloodGroup,
        role: 'permanent',
        memberType: 'permanent',
        profession: permSpecialization,
        professionBn: permSpecialization,
        nidNumber: permNidNumber.trim(),
        avatar: permSelfieUrl || currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        isNidVerified: true,
        isPaidMember: true,
        memberUID: generatedUID,
        bio: permBio.trim() || 'ঝাদিমাদি ডট কম-এর স্থায়ী নিবন্ধিত সদস্য ও সম্মানিত প্রতিনিধি।',
        emergencyContact: permEmergencyContact.trim() || undefined,
        createdAt: currentUser?.createdAt || new Date().toISOString().split('T')[0],
      };

      await databaseService.saveUserProfile(newProfile, { skipUniqueCheck: true });

      // 3. Automatically log in user
      login(newProfile, true);
      setGeneratedUser(newProfile);
      setGeneratedId(generatedUID);

      if (onSuccess) {
        onSuccess(newProfile);
      }
    } catch (err: any) {
      console.error('[Registration] Permanent Member Error:', err);
      setErrorMsg(err?.message || (lang === 'bn' ? 'স্থায়ী সদস্য রেজিস্ট্রেশন সম্পন্ন করা যায়নি।' : 'Permanent member registration failed.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyId = () => {
    if (!generatedId) return;
    navigator.clipboard.writeText(generatedId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2500);
  };

  // ==========================================
  // SUCCESS SCREEN: ROLE-BASED DYNAMIC PROFILE
  // ==========================================
  if (generatedUser) {
    const profileProps = {
      ...generatedUser,
      uniqueId: generatedId || generatedUser.uniqueId || generatedUser.memberUID,
      memberUID: generatedId || generatedUser.memberUID || generatedUser.uniqueId,
    };

    const isSeller = generatedUser.role === 'seller' || (profileProps.memberUID && profileProps.memberUID.startsWith('JH-S-'));
    const isPermanent = generatedUser.role === 'permanent' || (profileProps.memberUID && profileProps.memberUID.startsWith('JH-M-'));

    return (
      <div className="bg-white min-h-screen text-gray-900 pb-12" id="registration-success-root">
        {/* Top Success Alert Bar */}
        <div className="bg-[#0E8246] text-white px-4 py-2.5 flex items-center justify-between text-xs sticky top-0 z-30 shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0" />
            <span className="font-bold">
              {lang === 'bn' 
                ? `${isSeller ? 'পণ্য বিক্রেতা' : isPermanent ? 'স্থায়ী সদস্য' : 'সার্ভিস প্রোভাইডার'} প্রোফাইল সফলভাবে তৈরি হয়েছে!` 
                : `${isSeller ? 'Product Seller' : isPermanent ? 'Permanent Member' : 'Service Provider'} Profile Ready!`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onBack}
              className="px-2.5 py-1 bg-white/20 hover:bg-white/30 text-white rounded-lg text-xs font-semibold transition cursor-pointer"
            >
              {lang === 'bn' ? 'হোম পেজ' : 'Homepage'}
            </button>
          </div>
        </div>

        {/* Clean, role-based profile matching the exact registered category */}
        {isSeller ? (
          <ProductSellerProfile
            profileData={profileProps}
            currentUser={profileProps}
            lang={lang}
            isOwner={true}
            onBack={onBack}
            onEditProfile={() => {
              setGeneratedUser(null);
              setActiveTab('seller');
            }}
            onSignOut={() => {
              logout();
              if (onBack) onBack();
            }}
          />
        ) : isPermanent ? (
          <PermanentMemberProfile
            profileData={profileProps}
            currentUser={profileProps}
            lang={lang}
            isOwner={true}
            onBack={onBack}
            onEditProfile={() => {
              setGeneratedUser(null);
              setActiveTab('permanent');
            }}
            onSignOut={() => {
              logout();
              if (onBack) onBack();
            }}
          />
        ) : (
          <ServiceProviderPublicProfile
            profileData={profileProps}
            currentUser={profileProps}
            isOwner={true}
            lang={lang}
            onBack={onBack}
            onEditProfile={() => {
              setGeneratedUser(null);
              setActiveTab('service');
            }}
            onSignOut={() => {
              logout();
              if (onBack) onBack();
            }}
          />
        )}
      </div>
    );
  }

  // ==========================================
  // MAIN REGISTRATION PAGE WITH THREE TABS
  // ==========================================
  return (
    <div className="bg-white min-h-full flex-1 flex flex-col text-gray-900 pb-16 pointer-events-auto" id="registration-page-root">
      
      {/* Crisp White Top Bar with Title, Back & Language Switcher */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-gray-200 px-4 py-3">
        <div className="max-w-md mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onBack}
              className="w-8 h-8 rounded-xl bg-gray-100 hover:bg-gray-200 active:scale-95 text-gray-700 flex items-center justify-center transition cursor-pointer"
              title={lang === 'bn' ? 'ফিরে যান' : 'Back'}
              id="btn-reg-back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-base font-bold text-gray-950 tracking-tight leading-none">
                {isEditMode
                  ? (lang === 'bn' 
                      ? (activeTab === 'seller' ? 'পণ্য বিক্রেতা তথ্য এডিট' : activeTab === 'permanent' ? 'স্থায়ী সদস্য ফর্ম এডিট' : 'সার্ভিস প্রোভাইডার প্রোফাইল এডিট') 
                      : (activeTab === 'seller' ? 'Edit Product Seller Profile' : activeTab === 'permanent' ? 'Edit Permanent Member Form' : 'Edit Service Provider Profile'))
                  : (lang === 'bn' ? 'সদস্য রেজিস্ট্রেশন' : 'Member Registration')}
              </h1>
              <span className="text-[10px] text-gray-500 font-medium">
                {lang === 'bn' ? 'ঝাদিমাদি ডট কম ডিজিটাল প্ল্যাটফর্ম' : 'Jhadimadi.com Digital Platform'}
              </span>
            </div>
          </div>

          {/* Seamless Language Switcher (BN / EN) */}
          <button
            type="button"
            onClick={handleToggleLang}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl text-xs font-bold text-gray-800 transition cursor-pointer shadow-2xs active:scale-95"
            title="Toggle Language"
            id="btn-reg-lang-toggle"
          >
            <Languages className="w-3.5 h-3.5 text-emerald-700" />
            <span>{lang === 'bn' ? 'English' : 'বাংলা'}</span>
          </button>
        </div>
      </div>

      <div className="max-w-md mx-auto w-full px-4 sm:px-6 py-4 space-y-5">

        {/* Three Distinct Tabs Positioned Neatly at the Top */}
        <div className="bg-gray-100 p-1 rounded-2xl flex items-center gap-1 shadow-2xs border border-gray-200 select-none" id="reg-tabs-bar">
          
          {/* Tab 1: Product Seller Member */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('seller');
              setErrorMsg('');
            }}
            id="tab-btn-seller"
            className={`flex-1 py-2 px-1.5 rounded-xl text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
              activeTab === 'seller'
                ? 'bg-white text-gray-950 font-bold shadow-xs ring-1 ring-black/5'
                : 'text-gray-600 hover:text-gray-900 hover:bg-white/50 font-medium'
            }`}
          >
            <ShoppingBag className={`w-4 h-4 ${activeTab === 'seller' ? 'text-emerald-700' : 'text-gray-400'}`} />
            <span className="text-[10px] leading-tight">
              {lang === 'bn' ? 'পণ্য বিক্রেতা' : 'Product Seller'}
            </span>
          </button>

          {/* Tab 2: Service Provider Member */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('service');
              setErrorMsg('');
            }}
            id="tab-btn-service"
            className={`flex-1 py-2 px-1.5 rounded-xl text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
              activeTab === 'service'
                ? 'bg-white text-gray-950 font-bold shadow-xs ring-1 ring-black/5'
                : 'text-gray-600 hover:text-gray-900 hover:bg-white/50 font-medium'
            }`}
          >
            <Wrench className={`w-4 h-4 ${activeTab === 'service' ? 'text-emerald-700' : 'text-gray-400'}`} />
            <span className="text-[10px] leading-tight">
              {lang === 'bn' ? 'সার্ভিস প্রদানকারী' : 'Service Provider'}
            </span>
          </button>

          {/* Tab 3: Jhadimadi Permanent Member */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('permanent');
              setErrorMsg('');
            }}
            id="tab-btn-permanent"
            className={`flex-1 py-2 px-1.5 rounded-xl text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
              activeTab === 'permanent'
                ? 'bg-white text-gray-950 font-bold shadow-xs ring-1 ring-black/5'
                : 'text-gray-600 hover:text-gray-900 hover:bg-white/50 font-medium'
            }`}
          >
            <ShieldCheck className={`w-4 h-4 ${activeTab === 'permanent' ? 'text-emerald-700' : 'text-gray-400'}`} />
            <span className="text-[10px] leading-tight">
              {lang === 'bn' ? 'স্থায়ী সদস্য' : 'Permanent Member'}
            </span>
          </button>

        </div>

        {/* Tab Description Banner (Shown for Seller and Service Provider tabs only) */}
        {activeTab !== 'permanent' && (
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-3 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <p className="text-xs text-gray-600 leading-relaxed">
              {activeTab === 'seller' && (
                lang === 'bn' 
                  ? 'পণ্য বিক্রির সহজ রেজিস্ট্রেশন: কোনো জটিল সার্টিফিকেট ছাড়াই নাম, ঠিকানা ও পণ্যের ছবি দিয়ে শুরু করুন।'
                  : 'Simple product selling registration: Start without any certificate or complex NID friction.'
              )}
              {activeTab === 'service' && (
                lang === 'bn' 
                  ? 'সেবা প্রদানকারী রেজিস্ট্রেশন: আপনার নাম, মোবাইল, পেশা ও অবস্থান উল্লেখ করে প্রোফাইল তৈরি করুন।'
                  : 'Short service provider form: Register your skills, phone and location easily.'
              )}
            </p>
          </div>
        )}

        {/* Validation Errors */}
        {errorMsg && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-red-700 text-xs font-medium">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* ============================================================ */}
        {/* TAB 1 CONTENT: PRODUCT SELLER MEMBER FORM                     */}
        {/* ============================================================ */}
        {activeTab === 'seller' && (
          <form onSubmit={handleSellerSubmit} className="space-y-4" id="form-seller-member">
            
            {/* Full Name / Owner Name */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                {lang === 'bn' ? 'আপনার পূর্ণ নাম (মালিকের নাম) *' : 'Full Name (Owner Name) *'}
              </label>
              <input
                type="text"
                required
                value={sellerName}
                onChange={(e) => setSellerName(e.target.value)}
                placeholder={lang === 'bn' ? 'যেমন: মং মং মার্মা বা রিয়াজ আহমেদ' : 'e.g. Mong Mong Marma or Riaz Ahmed'}
                className="w-full px-3.5 py-2.5 bg-white border border-gray-300 focus:border-gray-900 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900 transition"
                id="input-seller-name"
              />
            </div>

            {/* Shop / Brand Name (Optional) */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                {lang === 'bn' ? 'দোকান বা ব্র্যান্ডের নাম (ঐচ্ছিক)' : 'Shop or Brand Name (Optional)'}
              </label>
              <input
                type="text"
                value={sellerShopName}
                onChange={(e) => setSellerShopName(e.target.value)}
                placeholder={lang === 'bn' ? 'যেমন: পাহাড়ি অর্গানিক স্টোর' : 'e.g. Hill Organic Store'}
                className="w-full px-3.5 py-2.5 bg-white border border-gray-300 focus:border-gray-900 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900 transition"
                id="input-seller-shop-name"
              />
            </div>

            {/* Mobile / WhatsApp Number */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                {lang === 'bn' ? 'মোবাইল / হোয়াটসঅ্যাপ নম্বর *' : 'Mobile / WhatsApp Number *'}
              </label>
              <input
                type="tel"
                required
                value={sellerPhone}
                onChange={(e) => setSellerPhone(e.target.value)}
                placeholder="018XXXXXXXX"
                className="w-full px-3.5 py-2.5 bg-white border border-gray-300 focus:border-gray-900 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900 transition"
                id="input-seller-phone"
              />
            </div>

            {/* Account Password Field */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                {lang === 'bn' ? 'অ্যাকাউন্ট পাসওয়ার্ড *' : 'Account Password *'}
              </label>
              <div className="relative">
                <input
                  type={showSellerPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={sellerPassword}
                  onChange={(e) => setSellerPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 pr-10 py-2.5 bg-white border border-gray-300 focus:border-gray-900 rounded-xl text-xs font-medium text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-1 focus:ring-gray-900 transition"
                  id="input-seller-password"
                />
                <button
                  type="button"
                  onClick={() => setShowSellerPassword(s => !s)}
                  className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-700 cursor-pointer p-0.5"
                  title={showSellerPassword ? 'Hide' : 'Show'}
                >
                  {showSellerPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <span className="text-[10px] text-gray-500 mt-0.5 block">
                {lang === 'bn' ? 'কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন (পরবর্তীতে লগইনে ব্যবহৃত হবে)' : 'Minimum 6 characters (used for subsequent login)'}
              </span>
            </div>

            {/* District & Upazila */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'জেলা *' : 'District *'}
                </label>
                <select
                  value={sellerDistrict}
                  onChange={(e) => handleDistrictChange(e.target.value, 'seller')}
                  className="w-full px-3 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900"
                  id="select-seller-district"
                >
                  {CHT_DISTRICTS.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'উপজেলা *' : 'Upazila *'}
                </label>
                <select
                  value={sellerUpazila}
                  onChange={(e) => setSellerUpazila(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900"
                  id="select-seller-upazila"
                >
                  {(UPAZILA_MAP[sellerDistrict] || ['Sadar']).map((u) => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Area / Village / Para & Blood Group */}
            <div className="grid grid-cols-3 gap-2.5">
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'এলাকা / গ্রাম / পাড়া *' : 'Area / Village / Para *'}
                </label>
                <input
                  type="text"
                  required
                  value={sellerArea}
                  onChange={(e) => setSellerArea(e.target.value)}
                  placeholder={lang === 'bn' ? 'যেমন: পানখাইয়াপাড়া বা বাজার এলাকা' : 'e.g. Bazar Area or Village'}
                  className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900"
                  id="input-seller-area"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'রক্তের গ্রুপ' : 'Blood Group'}
                </label>
                <select
                  value={sellerBloodGroup}
                  onChange={(e) => setSellerBloodGroup(e.target.value)}
                  className="w-full px-2.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900"
                  id="select-seller-blood"
                >
                  {BLOOD_GROUPS.map(bg => (
                    <option key={bg} value={bg}>{bg}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Easy Product Details & Category Selection */}
            <div className="pt-2 border-t border-gray-100 space-y-3">
              <span className="block text-xs font-bold text-gray-900">
                {lang === 'bn' ? 'পণ্যের ধরন ও বিবরণ (ক্যাটাগরি ভিত্তিক)' : 'Product Category & Details'}
              </span>

              {/* Product Category Selection */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'পণ্যের ক্যাটাগরি *' : 'Product Category *'}
                </label>
                <select
                  value={productCategory}
                  onChange={(e) => setProductCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900"
                  id="select-seller-prod-cat"
                >
                  {PRODUCT_CATEGORIES.map(c => (
                    <option key={c.id} value={c.id}>{lang === 'bn' ? c.bn : c.en}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'পণ্যের নাম / শিরোনাম' : 'Product Title / Name'}
                </label>
                <input
                  type="text"
                  value={productTitle}
                  onChange={(e) => setProductTitle(e.target.value)}
                  placeholder={lang === 'bn' ? 'যেমন: তাজা পাহাড়ি আম্রপালি বা অর্গানিক বন মধু' : 'e.g. Hill Amrapali Mangoes or Wild Honey'}
                  className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900"
                  id="input-seller-prod-title"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    {lang === 'bn' ? 'আনুমানিক মূল্য (টাকা)' : 'Price (BDT)'}
                  </label>
                  <input
                    type="number"
                    value={productPrice}
                    onChange={(e) => setProductPrice(e.target.value)}
                    placeholder="৳ 350"
                    className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none"
                    id="input-seller-prod-price"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    {lang === 'bn' ? 'সংক্ষিপ্ত বিবরণ' : 'Short Description'}
                  </label>
                  <input
                    type="text"
                    value={productDescription}
                    onChange={(e) => setProductDescription(e.target.value)}
                    placeholder={lang === 'bn' ? 'যেমন: ১০০% ক্যামিকেলমুক্ত' : 'e.g. 100% pure organic'}
                    className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none"
                    id="input-seller-prod-desc"
                  />
                </div>
              </div>

              {/* Product Image Presets & URL field */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  {lang === 'bn' ? 'পণ্যের স্যাম্পল ছবি নির্বাচন করুন' : 'Select Product Photo'}
                </label>
                <div className="grid grid-cols-4 gap-2 mb-2">
                  {SAMPLE_PRODUCT_IMAGES.map((img, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setProductImageUrl(img.url)}
                      className={`relative aspect-square rounded-xl overflow-hidden border-2 transition cursor-pointer ${
                        productImageUrl === img.url ? 'border-emerald-600 ring-2 ring-emerald-600/30' : 'border-gray-200 opacity-70 hover:opacity-100'
                      }`}
                      title={img.labelBn}
                    >
                      <img src={img.url} alt={img.labelBn} className="w-full h-full object-cover" />
                      {productImageUrl === img.url && (
                        <div className="absolute inset-0 bg-emerald-900/30 flex items-center justify-center">
                          <Check className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <input
                    type="url"
                    value={productImageUrl}
                    onChange={(e) => setProductImageUrl(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full px-3.5 py-2 bg-white border border-gray-300 rounded-xl text-[11px] font-mono text-gray-600 focus:outline-none"
                    id="input-seller-prod-image"
                  />
                </div>
              </div>
            </div>

            {/* Concise Consent Checkbox */}
            <div className="pt-2 border-t border-gray-100">
              <label className="flex items-start gap-2.5 cursor-pointer select-none text-xs text-gray-700 font-medium leading-snug">
                <input
                  type="checkbox"
                  required
                  checked={sellerConsent}
                  onChange={(e) => setSellerConsent(e.target.checked)}
                  className="w-4 h-4 mt-0.5 rounded border-gray-300 text-emerald-700 focus:ring-emerald-700 cursor-pointer accent-emerald-700 shrink-0"
                  id="checkbox-seller-consent"
                />
                <span>
                  {lang === 'bn' 
                    ? 'আমি সজ্ঞানে ও স্বেচ্ছায় এই তথ্যসমূহ প্রদান করতে সম্মতি জানাচ্ছি।' 
                    : 'I knowingly and willingly consent to provide these data.'}
                </span>
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting || !sellerConsent}
              className="w-full py-3 bg-gray-900 hover:bg-black active:scale-[0.99] text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50 mt-2"
              id="btn-submit-seller-member"
            >
              {isSubmitting ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <span>
                  {isEditMode 
                    ? (lang === 'bn' ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save Changes') 
                    : (lang === 'bn' ? 'পণ্য বিক্রেতা একাউন্ট তৈরি করুন' : 'Create Product Seller Account')}
                </span>
              )}
            </button>
          </form>
        )}

        {/* ============================================================ */}
        {/* TAB 2 CONTENT: SERVICE PROVIDER MEMBER FORM                  */}
        {/* ============================================================ */}
        {activeTab === 'service' && (
          <form onSubmit={handleSpSubmit} className="space-y-4" id="form-service-member">
            
            {/* Full Name */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                {lang === 'bn' ? 'আপনার পূর্ণ নাম *' : 'Your Full Name *'}
              </label>
              <input
                type="text"
                required
                value={spName}
                onChange={(e) => setSpName(e.target.value)}
                placeholder={lang === 'bn' ? 'যেমন: কামাল হোসেন' : 'e.g. Kamal Hossain'}
                className="w-full px-3.5 py-2.5 bg-white border border-gray-300 focus:border-gray-900 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900 transition"
                id="input-sp-name"
              />
            </div>

            {/* Mobile Number */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                {lang === 'bn' ? 'মোবাইল নম্বর *' : 'Mobile Number *'}
              </label>
              <input
                type="tel"
                required
                value={spPhone}
                onChange={(e) => setSpPhone(e.target.value)}
                placeholder="018XXXXXXXX"
                className="w-full px-3.5 py-2.5 bg-white border border-gray-300 focus:border-gray-900 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900 transition"
                id="input-sp-phone"
              />
            </div>

            {/* Account Password */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                {lang === 'bn' ? 'অ্যাকাউন্ট পাসওয়ার্ড *' : 'Account Password *'}
              </label>
              <div className="relative">
                <input
                  type={showSpPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={spPassword}
                  onChange={(e) => setSpPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 pr-10 py-2.5 bg-white border border-gray-300 focus:border-gray-900 rounded-xl text-xs font-medium text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-1 focus:ring-gray-900 transition"
                  id="input-sp-password"
                />
                <button
                  type="button"
                  onClick={() => setShowSpPassword(s => !s)}
                  className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-700 cursor-pointer p-0.5"
                  title={showSpPassword ? 'Hide' : 'Show'}
                >
                  {showSpPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <span className="text-[10px] text-gray-500 mt-0.5 block">
                {lang === 'bn' ? 'কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন (পরবর্তীতে লগইনে ব্যবহৃত হবে)' : 'Minimum 6 characters (used for subsequent login)'}
              </span>
            </div>

            {/* Profession / Service Category with Free Search & Custom Addition */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-gray-700">
                {lang === 'bn' ? 'পেশা / সার্ভিস ক্যাটাগরি * (লিস্ট থেকে খুঁজুন বা নতুন লিখুন)' : 'Profession / Service * (Search or Type New)'}
              </label>

              {/* Selected Profession Badge */}
              {spProfession ? (
                <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-700 shrink-0" />
                    <div>
                      <span className="text-[11px] text-emerald-800 font-semibold block">
                        {lang === 'bn' ? 'নির্বাচিত পেশা:' : 'Selected Profession:'}
                      </span>
                      <span className="text-xs font-bold text-gray-900">{spProfession}</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setSpProfession('');
                      setSpSearchQuery('');
                      setIsSpDropdownOpen(true);
                    }}
                    className="text-xs text-gray-600 hover:text-gray-900 underline font-medium px-2 py-1 cursor-pointer"
                  >
                    {lang === 'bn' ? 'পরিবর্তন করুন' : 'Change'}
                  </button>
                </div>
              ) : (
                <div className="relative">
                  <div className="relative flex items-center">
                    <Search className="w-4 h-4 text-gray-400 absolute left-3 pointer-events-none" />
                    <input
                        type="text"
                        value={spSearchQuery}
                        onChange={(e) => {
                          setSpSearchQuery(e.target.value);
                          setIsSpDropdownOpen(true);
                        }}
                        onFocus={() => setIsSpDropdownOpen(true)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            if (spSearchQuery.trim()) {
                              setSpProfession(spSearchQuery.trim());
                              setIsSpDropdownOpen(false);
                            }
                          }
                        }}
                        placeholder={lang === 'bn' ? 'পেশা খুঁজুন বা নতুন পেশা টাইপ করুন (যেমন: ইলেকট্রিশিয়ান, ড্রাইভার...)' : 'Search or type custom profession...'}
                        className="w-full pl-9 pr-20 py-2.5 bg-white border border-gray-300 focus:border-gray-900 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900"
                        id="input-sp-search-profession"
                      />
                      {spSearchQuery.trim() && (
                        <div className="absolute right-2 flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              setSpProfession(spSearchQuery.trim());
                              setIsSpDropdownOpen(false);
                            }}
                            className="px-2 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-[10px] font-bold cursor-pointer transition shadow-2xs"
                            title={lang === 'bn' ? 'এই পেশাটি যুক্ত করুন' : 'Add this profession'}
                          >
                            {lang === 'bn' ? '+ যোগ' : '+ Add'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setSpSearchQuery('')}
                            className="text-gray-400 hover:text-gray-600 text-xs p-1"
                          >
                            ✕
                          </button>
                        </div>
                      )}
                    </div>

                  {/* Dropdown Results & Custom Add Option */}
                  {isSpDropdownOpen && (
                    <div className="absolute z-30 left-0 right-0 mt-1 max-h-56 overflow-y-auto bg-white border border-gray-200 rounded-xl shadow-lg divide-y divide-gray-100">
                      {/* Option to add custom typed profession if typed */}
                      {spSearchQuery.trim() && (
                        <button
                          type="button"
                          onClick={() => {
                            const customVal = spSearchQuery.trim();
                            setSpProfession(customVal);
                            setIsSpDropdownOpen(false);
                          }}
                          className="w-full px-3 py-2.5 text-left text-xs bg-emerald-50/70 hover:bg-emerald-100 text-emerald-900 font-bold flex items-center gap-2 cursor-pointer transition"
                        >
                          <span className="w-5 h-5 rounded-full bg-emerald-200 text-emerald-800 flex items-center justify-center text-xs">+</span>
                          <span>
                            {lang === 'bn' 
                              ? `নতুন পেশা হিসেবে যোগ করুন: "${spSearchQuery.trim()}"` 
                              : `Add as custom profession: "${spSearchQuery.trim()}"`}
                          </span>
                        </button>
                      )}

                      {filteredProfessions.map((prof, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setSpProfession(prof.name);
                            setSpSearchQuery('');
                            setIsSpDropdownOpen(false);
                          }}
                          className="w-full px-3 py-2 text-left text-xs text-gray-800 hover:bg-gray-50 flex items-center justify-between cursor-pointer transition"
                        >
                          <span>{prof.name}</span>
                          <span className="text-[10px] text-gray-400">যুক্ত করুন</span>
                        </button>
                      ))}

                      {filteredProfessions.length === 0 && !spSearchQuery.trim() && (
                        <div className="p-3 text-xs text-gray-500 text-center">
                          {lang === 'bn' ? 'উপরে পেশার নাম টাইপ করুন' : 'Type a profession above'}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Popular Profession Quick Chips */}
              <div className="pt-1">
                <span className="text-[10px] font-semibold text-gray-500 block mb-1">
                  {lang === 'bn' ? 'জনপ্রিয় পেশাগুলো:' : 'Popular Professions:'}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'ইলেকট্রিশিয়ান',
                    'প্লাম্বার ও স্যানিটারি মিস্ত্রি',
                    'রাজমিস্ত্রি ও নির্মাণ কর্মী',
                    'মোটরসাইকেল মেকানিক',
                    'সিএনজি / অটো / কার ড্রাইভার',
                    'পেইন্টার / রং মিস্ত্রি',
                    'হোম টিউটর / শিক্ষক',
                    'কম্পিউটার ও মোবাইল সার্ভিসিং',
                    'দর্জি / টেইলার্স',
                    'কৃষি শ্রমিক / দিনমজুর'
                  ].map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setSpProfession(p);
                        setIsSpDropdownOpen(false);
                      }}
                      className={`px-2 py-1 rounded-lg text-[11px] font-medium border transition cursor-pointer ${
                        spProfession === p
                          ? 'bg-emerald-800 text-white border-emerald-800'
                          : 'bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-200'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Location: District & Upazila */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'জেলা *' : 'District *'}
                </label>
                <select
                  value={spDistrict}
                  onChange={(e) => handleDistrictChange(e.target.value, 'sp')}
                  className="w-full px-3 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none"
                  id="select-sp-district"
                >
                  {CHT_DISTRICTS.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'উপজেলা *' : 'Upazila *'}
                </label>
                <select
                  value={spUpazila}
                  onChange={(e) => setSpUpazila(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none"
                  id="select-sp-upazila"
                >
                  {(UPAZILA_MAP[spDistrict] || ['Sadar']).map((u) => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Area / Mahalla & Blood Group */}
            <div className="grid grid-cols-3 gap-2.5">
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'এলাকা / পাড়া *' : 'Area / Mahalla *'}
                </label>
                <input
                  type="text"
                  required
                  value={spArea}
                  onChange={(e) => setSpArea(e.target.value)}
                  placeholder={lang === 'bn' ? 'যেমন: হাসপাতাল মোড় বা মিলনপুর' : 'e.g. Central Market Area'}
                  className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none"
                  id="input-sp-area"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'রক্তের গ্রুপ' : 'Blood Group'}
                </label>
                <select
                  value={spBloodGroup}
                  onChange={(e) => setSpBloodGroup(e.target.value)}
                  className="w-full px-2 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-900"
                  id="select-sp-blood"
                >
                  {BLOOD_GROUPS.map((bg) => (
                    <option key={bg} value={bg}>{bg}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Experience & Daily Rate */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'অভিজ্ঞতা (বছর)' : 'Experience (Years)'}
                </label>
                <input
                  type="number"
                  value={spExperienceYears}
                  onChange={(e) => setSpExperienceYears(e.target.value)}
                  placeholder="2"
                  className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900"
                  id="input-sp-exp"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {lang === 'bn' ? 'দৈনিক মজুরি (টাকা)' : 'Daily Rate (BDT)'}
                </label>
                <input
                  type="number"
                  value={spDailyRate}
                  onChange={(e) => setSpDailyRate(e.target.value)}
                  placeholder="৳ 600"
                  className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900"
                  id="input-sp-rate"
                />
              </div>
            </div>

            {/* Short Bio / Service description */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                {lang === 'bn' ? 'আপনার সেবা সম্পর্কে সংক্ষিপ্ত বিবরণ (ঐচ্ছিক)' : 'Short Bio / About Your Service (Optional)'}
              </label>
              <input
                type="text"
                value={spBio}
                onChange={(e) => setSpBio(e.target.value)}
                placeholder={lang === 'bn' ? 'যেমন: যেকোনো ধরনের ওয়ারিং ও বাসা-বাড়ির কাজের অভিজ্ঞ মিস্ত্রি' : 'e.g. Experienced in residential and commercial wiring'}
                className="w-full px-3.5 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-medium text-gray-900 focus:outline-none"
                id="input-sp-bio"
              />
            </div>

            {/* Concise Consent Checkbox */}
            <div className="pt-2 border-t border-gray-100">
              <label className="flex items-start gap-2.5 cursor-pointer select-none text-xs text-gray-700 font-medium leading-snug">
                <input
                  type="checkbox"
                  required
                  checked={spConsent}
                  onChange={(e) => setSpConsent(e.target.checked)}
                  className="w-4 h-4 mt-0.5 rounded border-gray-300 text-emerald-700 focus:ring-emerald-700 cursor-pointer accent-emerald-700 shrink-0"
                  id="checkbox-sp-consent"
                />
                <span>
                  {lang === 'bn' 
                    ? 'আমি সজ্ঞানে ও স্বেচ্ছায় এই তথ্যসমূহ প্রদান করতে সম্মতি জানাচ্ছি।' 
                    : 'I knowingly and willingly consent to provide these data.'}
                </span>
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting || !spConsent}
              className="w-full py-3 bg-gray-900 hover:bg-black active:scale-[0.99] text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50 mt-2"
              id="btn-submit-service-member"
            >
              {isSubmitting ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <span>
                  {isEditMode 
                    ? (lang === 'bn' ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save Changes') 
                    : (lang === 'bn' ? 'সার্ভিস প্রোভাইডার একাউন্ট তৈরি করুন' : 'Create Service Provider Account')}
                </span>
              )}
            </button>
          </form>
        )}

        {/* ============================================================ */}
        {/* TAB 3 CONTENT: JHADIMADI PERMANENT MEMBER                    */}
        {/* ============================================================ */}
        {activeTab === 'permanent' && (
          <div className="space-y-4" id="section-permanent-member">
            {/* Exact Full Detailed Service Provider Registration Form */}
            <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-xs">
              <ServiceProviderRegistrationForm
                lang={lang}
                onSuccess={(savedData: any) => {
                  const user = savedData?.user || savedData;
                  if (user) {
                    const permanentUID = user.memberUID || generateJhadimadiCleanUID('permanent', user.district || 'Khagrachhari');
                    user.memberUID = permanentUID;
                    user.role = 'permanent';
                    user.isPaidMember = true;
                    user.isNidVerified = true;
                    login(user, true);
                    setGeneratedUser(user);
                    setGeneratedId(permanentUID);
                  }
                  if (onSuccess) {
                    onSuccess(user || savedData);
                  }
                }}
                onSubmitSuccess={(savedData: any) => {
                  const user = savedData?.user || savedData;
                  if (user) {
                    const permanentUID = user.memberUID || generateJhadimadiCleanUID('permanent', user.district || 'Khagrachhari');
                    user.memberUID = permanentUID;
                    user.role = 'permanent';
                    user.isPaidMember = true;
                    user.isNidVerified = true;
                    login(user, true);
                    setGeneratedUser(user);
                    setGeneratedId(permanentUID);
                  }
                  if (onSuccess) {
                    onSuccess(user || savedData);
                  }
                }}
              />
            </div>
          </div>
        )}

        {/* Bottom Link: Direct to Sign In */}
        <div className="pt-4 border-t border-gray-100 text-center">
          <p className="text-xs text-gray-600">
            {lang === 'bn' ? 'পূর্বে রেজিস্ট্রেশন করা অ্যাকাউন্ট আছে? ' : 'Already have an existing account? '}
            <button
              type="button"
              onClick={onNavigateToSignIn}
              className="font-bold text-gray-950 hover:underline cursor-pointer ml-1 inline-flex items-center gap-1"
              id="btn-reg-to-signin"
            >
              <span>{lang === 'bn' ? 'সাইন ইন করুন' : 'Sign In'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </p>
        </div>

      </div>
    </div>
  );
};
