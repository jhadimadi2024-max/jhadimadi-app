import React, { useState } from 'react';
import { 
  X, ShoppingBag, Image as ImageIcon, Camera, Upload, 
  MapPin, CheckCircle2, QrCode, Tag, DollarSign, Layers, 
  ShieldCheck, AlertCircle, FileText, Barcode, Plus, Trash2,
  Sparkles
} from 'lucide-react';
import { Language, OrganicProduct, UserProfile } from '../types';
import { VendorStoreProduct } from '../data/vendorsData';
import { compressImage } from '../utils/imageUtils';

interface ProductAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newProduct: any) => void;
  currentUser?: UserProfile | null;
  vendorId?: string;
  vendorShopName?: string;
  vendorUniqueId?: string;
  lang: Language;
  defaultDivision?: string;
  defaultDistrict?: string;
  defaultUpazila?: string;
  defaultMahalla?: string;
}

const PRODUCT_CATEGORIES = [
  { id: 'ShutkiSidol', labelBn: 'পাহাড়ি শুঁটকি ও সিদল', labelEn: 'Dried Fish & Sidol' },
  { id: 'SpicesGrains', labelBn: 'পাহাড়ি মশলা, চালের গুঁড়া ও খাদ্য', labelEn: 'Spices, Grains & Food' },
  { id: 'Fruits', labelBn: 'পাহাড়ি ফলমূল ও ফসল', labelEn: 'Hill Fruits' },
  { id: 'Clothing', labelBn: 'পাহাড়ি পোশাক ও কোমর তাঁত', labelEn: 'Clothing & Handloom' },
  { id: 'Electronics', labelBn: 'ইলেকট্রনিক্স ও সোলার', labelEn: 'Electronics & Solar' },
  { id: 'Handicrafts', labelBn: 'হস্তশিল্প ও আদিবাসী পণ্য', labelEn: 'Handicrafts & Native' },
  { id: 'General', labelBn: 'অন্যান্য পাইকারি বা খুচরা পণ্য', labelEn: 'General Merchandise' },
];

const UNIT_OPTIONS = [
  { id: '১ কেজি প্যাকেট', label: '১ কেজি প্যাকেট' },
  { id: '৫০০ গ্রাম প্যাক', label: '৫০০ গ্রাম প্যাক' },
  { id: '২৫০ গ্রাম জার', label: '২৫০ গ্রাম জার' },
  { id: '১ পিস', label: '১ পিস' },
  { id: '১ সেট', label: '১ সেট' },
  { id: '১ লিটার বোতল', label: '১ লিটার বোতল' },
  { id: '১ বক্স/প্যাকেট', label: '১ বক্স/প্যাকেট' },
];

export const ProductAddModal: React.FC<ProductAddModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  currentUser,
  vendorId,
  vendorShopName,
  vendorUniqueId,
  lang,
  defaultDivision = 'Chittagong Division (চট্টগ্রাম)',
  defaultDistrict = 'Khagrachhari',
  defaultUpazila = 'Khagrachhari Sadar',
  defaultMahalla = 'মধুপুর বাজার',
}) => {
  const [titleBn, setTitleBn] = useState('');
  const [category, setCategory] = useState<string>('SpicesGrains');
  const [price, setPrice] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [unit, setUnit] = useState('১ কেজি প্যাকেট');
  const [stock, setStock] = useState('50');
  const [badgeText, setBadgeText] = useState('১০০% খাঁটি ও তাজা');
  const [descriptionBn, setDescriptionBn] = useState('');
  const [barcodeOrQr, setBarcodeOrQr] = useState('');
  
  // Gallery of 5-10 images
  const [imagesList, setImagesList] = useState<string[]>([
    'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80'
  ]);
  const [newImageUrl, setNewImageUrl] = useState('');

  // Location selector state
  const [division, setDivision] = useState(defaultDivision);
  const [district, setDistrict] = useState(defaultDistrict);
  const [upazila, setUpazila] = useState(defaultUpazila);
  const [mahalla, setMahalla] = useState(defaultMahalla);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Specifications
  const [specGrade, setSpecGrade] = useState('গ্রেড-১ প্রিমিয়াম এক্সপোর্ট কোয়ালিটি');
  const [specShelfLife, setSpecShelfLife] = useState('শুষ্ক স্থানে ৯০ দিন');
  const [specPreservative, setSpecPreservative] = useState('০% কেমিক্যাল (সম্পূর্ণ প্রাকৃতিক)');

  if (!isOpen) return null;

  const handleAddImage = () => {
    if (newImageUrl.trim()) {
      if (imagesList.length >= 10) {
        alert(lang === 'bn' ? 'সর্বোচ্চ ১০টি ছবি যুক্ত করা যাবে।' : 'Max 10 images allowed.');
        return;
      }
      setImagesList([...imagesList, newImageUrl.trim()]);
      setNewImageUrl('');
    }
  };

  const handleRemoveImage = (index: number) => {
    setImagesList(imagesList.filter((_, i) => i !== index));
  };

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const ext = file.name.split('.').pop()?.toLowerCase() || '';
      const safeExtensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
      if (!safeExtensions.includes(ext) || file.type.includes('svg') || file.type.includes('html')) {
        alert(lang === 'bn' ? 'শুধুমাত্র JPG, JPEG, PNG, WEBP ছবি গ্রহণযোগ্য।' : 'Only JPG, JPEG, PNG, WEBP images allowed.');
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        alert(lang === 'bn' ? 'ছবির আকার সর্বোচ্চ ১০ মেগাবাইট হতে পারবে।' : 'File size cannot exceed 10MB.');
        return;
      }
      const compressed = await compressImage(file, 400, 400, 0.75);
      if (compressed && imagesList.length < 10) {
        setImagesList([...imagesList, compressed]);
      }
    }
  };

  const handleGenerateBarcode = () => {
    const uId = vendorUniqueId || 'V-KHG-001';
    const randomCode = `JM-${uId}-${Math.floor(1000 + Math.random() * 9000)}`;
    setBarcodeOrQr(randomCode);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!titleBn.trim()) {
      alert(lang === 'bn' ? 'অনুগ্রহ করে পণ্যের নাম লিখুন।' : 'Please enter product title.');
      return;
    }
    if (!price || Number(price) <= 0) {
      alert(lang === 'bn' ? 'অনুগ্রহ করে সঠিক মূল্য লিখুন।' : 'Please enter a valid price.');
      return;
    }

    setIsSubmitting(true);

    const effectiveVendorId = vendorId || 'vendor_khg_001';
    const effectiveUniqueId = vendorUniqueId || 'V-KHG-001';
    const effectiveShopName = vendorShopName || 'পাহাড়ি কৃষি ও অর্গানিক খামার';

    const newProd: VendorStoreProduct = {
      id: 'vprod_' + Date.now(),
      nameBn: titleBn.trim(),
      nameEn: titleBn.trim(),
      category: category,
      categoryLabelBn: PRODUCT_CATEGORIES.find(c => c.id === category)?.labelBn || 'পণ্য',
      price: Number(price),
      originalPrice: Number(originalPrice) || Math.round(Number(price) * 1.2),
      unit: unit,
      stock: Number(stock) || 30,
      origin: `${district} > ${upazila} (${mahalla})`,
      district: district,
      upazila: upazila,
      mahalla: mahalla,
      bazarName: mahalla,
      image: imagesList[0] || 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80',
      images: imagesList.length > 0 ? imagesList : [
        'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?auto=format&fit=crop&w=800&q=80',
      ],
      rating: 5.0,
      reviewsCount: 1,
      badge: badgeText,
      badgeColor: 'bg-emerald-600',
      descriptionBn: descriptionBn.trim() || `${titleBn} - ১০০% খাঁটি পণ্য, সরাসরি প্রস্তুতকারক ও ভেরিফাইড বিক্রেতার কাছ থেকে সংগ্রহকৃত।`,
      descriptionEn: descriptionBn.trim() || 'Authentic hill tract product with verified quality guarantee.',
      features: [
        'রাসায়নিক সার ও প্রিজারভেটিভমুক্ত শতভাগ নিরাপদ',
        'ঘরোয়া ও পাহাড়ি ঐতিহ্যবাহী প্রক্রিয়াজাতকরণ',
        'ঝাদিমাদি ১০০% ডেলিভারি ও ইন-অ্যাপ এসক্রো প্রটেকশন',
        'মান সন্তুষ্ট না হলে ৭ দিনের রিটার্ন ও ক্যাশব্যাক পলিসি'
      ],
      specifications: [
        { labelBn: 'বারকোড / পণ্য কোড', valueBn: barcodeOrQr || `JM-${effectiveUniqueId}-PROD-01` },
        { labelBn: 'গুণগত মান', valueBn: specGrade },
        { labelBn: 'সংরক্ষণ মেয়াদ', valueBn: specShelfLife },
        { labelBn: 'প্রিজারভেটিভ স্ট্যাটাস', valueBn: specPreservative },
        { labelBn: 'মাইক্রো-লোকেশন', valueBn: `${mahalla}, ${upazila}, ${district}` },
      ],
      variants: {
        sizes: [
          { nameBn: '২৫০ গ্রাম প্যাক', priceOffset: -Math.round(Number(price) * 0.4) },
          { nameBn: '৫০০ গ্রাম রেগুলার', priceOffset: 0 },
          { nameBn: '১ কেজি ফ্যামিলি প্যাক', priceOffset: Math.round(Number(price) * 0.8) },
        ]
      },
      warranty: 'শতভাগ খাঁটি না হলে দ্বিগুণ টাকা ফেরত।',
      qrCode: `JM-${effectiveUniqueId}-${titleBn.slice(0, 4)}`,
      barcode: barcodeOrQr || '8941200192847',
      isOrganic: true,
      sellerId: effectiveVendorId,
      sellerUniqueId: effectiveUniqueId,
      sellerShopName: effectiveShopName,
      sellerOwnerName: currentUser?.name || 'বিপ্লব ত্রিপুরা',
      sellerRating: 4.9,
      sellerPhoneMasked: '01812****-***89',
      sellerRealPhone: '01812345689'
    };

    setIsSubmitting(false);
    onSuccess(newProd);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl border border-slate-200 flex flex-col max-h-[94vh] my-auto">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-950 text-white p-3.5 sm:p-4 flex items-center justify-between shrink-0 shadow-sm">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center font-bold">
              <ShoppingBag className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-black text-xs sm:text-sm leading-none flex items-center gap-1.5">
                <span>দোকানে নতুন পণ্য যোগ করুন (Add Product)</span>
                {vendorUniqueId && (
                  <span className="bg-emerald-500/20 text-emerald-300 font-mono text-[9px] px-2 py-0.5 rounded-md border border-emerald-400/30">
                    {vendorUniqueId}
                  </span>
                )}
              </h3>
              <p className="text-[9.5px] text-gray-300 mt-1">
                ৫-১০টি ছবি, সাইজ ভ্যারিয়েন্ট ও গুণগত স্পেসিফিকেশন দিয়ে স্টোরফ্রন্টে যুক্ত করুন
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-3.5 sm:p-4 overflow-y-auto space-y-3.5 text-xs">
          
          {/* 1. Title */}
          <div>
            <label className="font-black text-gray-800 block text-[10.5px] mb-1">
              ১. পণ্যের শিরোনাম / নাম: <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={titleBn}
              onChange={(e) => setTitleBn(e.target.value)}
              placeholder="যেমন: খাঁটি পাহাড়ি চালের গুঁড়া / জুমের বোম্বাই মরিচের গুঁড়া"
              className="w-full px-3 py-2 bg-slate-50 border border-gray-200 rounded-xl text-xs font-bold text-gray-800 focus:outline-none focus:border-emerald-600 focus:bg-white"
            />
          </div>

          {/* 2. Category & Unit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="font-black text-gray-800 block text-[10.5px] mb-1">
                ২. ক্যাটাগরি: <span className="text-red-500">*</span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-gray-200 rounded-xl text-xs font-bold text-gray-800 focus:outline-none focus:border-emerald-600 focus:bg-white cursor-pointer"
              >
                {PRODUCT_CATEGORIES.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.labelBn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-black text-gray-800 block text-[10.5px] mb-1">
                ৩. প্রাথমিক পরিমাপ একক (Unit):
              </label>
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-gray-200 rounded-xl text-xs font-bold text-gray-800 focus:outline-none focus:border-emerald-600 focus:bg-white cursor-pointer"
              >
                {UNIT_OPTIONS.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 3. Price & Stock */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="font-black text-gray-800 block text-[10.5px] mb-1">
                ৪. বিক্রয় মূল্য (৳): <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                required
                min="10"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="যেমন: 120"
                className="w-full px-3 py-2 bg-slate-50 border border-gray-200 rounded-xl text-xs font-black text-emerald-700 focus:outline-none focus:border-emerald-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="font-black text-gray-800 block text-[10.5px] mb-1">
                ৫. পূর্বের মূল দাম (ছাড় দেখাতে ৳):
              </label>
              <input
                type="number"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(e.target.value)}
                placeholder="যেমন: 150"
                className="w-full px-3 py-2 bg-slate-50 border border-gray-200 rounded-xl text-xs font-bold text-gray-600 focus:outline-none focus:border-emerald-600 focus:bg-white"
              />
            </div>
          </div>

          {/* 4. Stock & Badge */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="font-black text-gray-800 block text-[10.5px] mb-1">
                ৬. উপলব্ধ স্টক সংখ্যা:
              </label>
              <input
                type="number"
                min="1"
                value={stock}
                onChange={(e) => setStock(e.target.value)}
                placeholder="যেমন: 50"
                className="w-full px-3 py-2 bg-slate-50 border border-gray-200 rounded-xl text-xs font-bold text-gray-800 focus:outline-none focus:border-emerald-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="font-black text-gray-800 block text-[10.5px] mb-1">
                ৭. হাইলাইট ব্যাজ:
              </label>
              <input
                type="text"
                value={badgeText}
                onChange={(e) => setBadgeText(e.target.value)}
                placeholder="যেমন: ১০০% ঢেঁকি ছাঁটা খাঁটি"
                className="w-full px-3 py-2 bg-slate-50 border border-gray-200 rounded-xl text-xs font-bold text-gray-800 focus:outline-none focus:border-emerald-600 focus:bg-white"
              />
            </div>
          </div>

          {/* 5. Multi-Image Gallery (5 to 10 High Quality Images) */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-gray-200 space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-black text-gray-800 text-[10.5px] flex items-center gap-1">
                <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                <span>৮. পণ্যের ছবি গ্যালারি ({imagesList.length}/১০ টি ছবি)</span>
              </label>
              <label className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[9px] font-bold cursor-pointer transition shadow-2xs">
                <Upload className="w-3 h-3" />
                <span>ডিভাইস থেকে আপলোড</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageFileChange}
                  className="hidden"
                />
              </label>
            </div>

            {/* Thumbnail Previews with Delete option */}
            <div className="grid grid-cols-5 gap-1.5">
              {imagesList.map((img, idx) => (
                <div key={idx} className="relative h-14 rounded-xl overflow-hidden border border-gray-200 group bg-slate-200">
                  <img src={img} alt={`Preview ${idx}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => handleRemoveImage(idx)}
                    className="absolute top-1 right-1 w-4 h-4 bg-red-600 text-white rounded-full flex items-center justify-center opacity-80 hover:opacity-100 transition shadow-xs"
                    title="মুছে ফেলুন"
                  >
                    <X className="w-2.5 h-2.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Direct Image URL input */}
            <div className="flex gap-1.5 pt-1">
              <input
                type="text"
                placeholder="অথবা ইমেজের অনলাইন লিঙ্ক (URL) পেস্ট করুন"
                value={newImageUrl}
                onChange={(e) => setNewImageUrl(e.target.value)}
                className="flex-1 px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-[9.5px] font-medium"
              />
              <button
                type="button"
                onClick={handleAddImage}
                className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-[9.5px] font-bold cursor-pointer hover:bg-slate-900"
              >
                + যুক্ত করুন
              </button>
            </div>
          </div>

          {/* 6. Location Selector (Division, District, Upazila, Mahalla) */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-gray-200 space-y-2">
            <div className="flex items-center gap-1 text-gray-800 font-black text-[10.5px]">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              <span>৯. পণ্যের মাইক্রো-লোকেশন (Micro-Location):</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[9.5px]">
              <div>
                <label className="text-[9px] font-bold text-gray-500 block mb-0.5">জেলা (District)</label>
                <input
                  type="text"
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg font-bold text-gray-800"
                />
              </div>

              <div>
                <label className="text-[9px] font-bold text-gray-500 block mb-0.5">উপজেলা / থানা</label>
                <input
                  type="text"
                  value={upazila}
                  onChange={(e) => setUpazila(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg font-bold text-gray-800"
                />
              </div>

              <div className="col-span-2">
                <label className="text-[9px] font-bold text-gray-500 block mb-0.5">পাড়া / মহল্লা / বাজার (Micro Area)</label>
                <input
                  type="text"
                  value={mahalla}
                  onChange={(e) => setMahalla(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg font-bold text-gray-800"
                />
              </div>
            </div>
          </div>

          {/* 7. Barcode & Specifications */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-gray-200 space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-black text-gray-800 text-[10.5px] flex items-center gap-1">
                <Barcode className="w-3.5 h-3.5 text-gray-600" />
                <span>১০. কোয়ালিটি স্পেসিফিকেশন ও ডিজিটাল বারকোড:</span>
              </label>
              <button
                type="button"
                onClick={handleGenerateBarcode}
                className="text-[9px] text-emerald-700 font-black hover:underline cursor-pointer flex items-center gap-0.5"
              >
                <QrCode className="w-3 h-3" />
                <span>অটো কোড জেনারেট</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[9.5px]">
              <div>
                <label className="text-[8.5px] text-gray-500 font-bold block mb-0.5">ডিজিটাল বারকোড</label>
                <input
                  type="text"
                  value={barcodeOrQr}
                  onChange={(e) => setBarcodeOrQr(e.target.value)}
                  placeholder="JM-KHG-001-PROD-01"
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg font-mono text-[9px]"
                />
              </div>

              <div>
                <label className="text-[8.5px] text-gray-500 font-bold block mb-0.5">সংরক্ষণ মেয়াদ</label>
                <input
                  type="text"
                  value={specShelfLife}
                  onChange={(e) => setSpecShelfLife(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-[9px]"
                />
              </div>
            </div>
          </div>

          {/* 8. Description */}
          <div>
            <label className="font-black text-gray-800 block text-[10.5px] mb-1">
              ১১. পণ্যের বিস্তারিত বিবরণ (Description):
            </label>
            <textarea
              rows={3}
              value={descriptionBn}
              onChange={(e) => setDescriptionBn(e.target.value)}
              placeholder="পণ্যের উপাদান, প্রক্রিয়াজাতকরণের নিয়ম ও বিশেষত্ব সম্পর্কে বিস্তারিত লিখুন..."
              className="w-full p-2.5 bg-slate-50 border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-emerald-600 focus:bg-white resize-none"
            />
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-lg shadow-emerald-600/30 cursor-pointer transition-all flex items-center justify-center gap-1.5 active:scale-98"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'সংরক্ষণ হচ্ছে...' : 'স্টোরফ্রন্টে পণ্যটি সংরক্ষণ করুন ➔'}</span>
            </button>
          </div>

        </form>

        {/* Footer Note */}
        <div className="bg-slate-50 border-t border-slate-100 p-2.5 px-4 text-[9.5px] text-slate-500 flex items-center justify-between shrink-0">
          <span className="flex items-center gap-1 text-emerald-700 font-bold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>প্রোফাইল-সেন্ট্রিক ইনভেন্টরি প্রকাশনা</span>
          </span>
          <span className="text-slate-400 font-mono text-[9px]">{vendorUniqueId || 'V-KHG-001'}</span>
        </div>

      </div>
    </div>
  );
};
