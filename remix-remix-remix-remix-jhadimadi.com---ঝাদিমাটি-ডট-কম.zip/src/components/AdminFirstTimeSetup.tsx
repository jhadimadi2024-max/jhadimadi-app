import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  Mail, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  ShieldAlert,
  ArrowLeft,
  KeyRound,
  Sparkles
} from 'lucide-react';
import { adminSecurityService } from '../services/adminSecurityService';

interface AdminFirstTimeSetupProps {
  onSetupSuccess: (chosenUsername: string) => void;
  onNavigateToCustomerApp?: () => void;
}

export const AdminFirstTimeSetup: React.FC<AdminFirstTimeSetupProps> = ({
  onSetupSuccess,
  onNavigateToCustomerApp,
}) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Real-time validations
  const isUsernameValid = username.trim().length >= 3 && /^[a-zA-Z0-9_.\-]{3,30}$/.test(username.trim());
  const isPasswordLongEnough = password.length >= 6;
  const doPasswordsMatch = password.length > 0 && password === confirmPassword;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanUser = username.trim();
    const cleanEmail = email.trim();

    if (!cleanUser) {
      setErrorMessage('অনুগ্রহ করে সুপার অ্যাডমিন ইউজারনেম লিখুন।');
      return;
    }

    if (!/^[a-zA-Z0-9_.\-]{3,30}$/.test(cleanUser)) {
      setErrorMessage('ইউজারনেম ৩ থেকে ৩০ অক্ষরের হতে হবে (শুধুমাত্র ইংরেজি বর্ণ, সংখ্যা, আন্ডারস্কোর, ডট বা হাইফেন)।');
      return;
    }

    if (!password) {
      setErrorMessage('অনুগ্রহ করে একটি নিরাপদ পাসওয়ার্ড লিখুন।');
      return;
    }

    if (password.length < 6) {
      setErrorMessage('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('পাসওয়ার্ড এবং নিশ্চিতকরণ পাসওয়ার্ড মিলছে না।');
      return;
    }

    if (cleanEmail) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(cleanEmail)) {
        setErrorMessage('অনুগ্রহ করে সঠিক ইমেইল এড্রেস লিখুন (যেমন: owner@jhadimadi.com)।');
        return;
      }
    }

    setLoading(true);

    try {
      const res = await adminSecurityService.setupSuperAdmin({
        username: cleanUser,
        email: cleanEmail || undefined,
        password,
        confirmPassword,
      });

      if (res.success) {
        onSetupSuccess(cleanUser);
      } else {
        setErrorMessage(res.message || 'সেটআপ সম্পন্ন করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4 sm:p-6 text-slate-100 selection:bg-emerald-500 selection:text-white relative overflow-hidden">
      {/* Background Decorative Blur Orbs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-teal-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Container */}
      <div className="w-full max-w-lg mb-4 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-3 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          <span>প্রথম-বার প্রাথমিক ইনিশিয়ালাইজেশন (Initial Setup)</span>
        </div>
      </div>

      {/* Main Setup Card */}
      <div className="w-full max-w-lg bg-slate-900/95 backdrop-blur-xl border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative z-10">
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-900/40 border border-emerald-400/30">
            <KeyRound className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            সুপার অ্যাডমিন অ্যাকাউন্ট সেটআপ
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed">
            ড্যাশবোর্ড ও অ্যাপ্লিকেশনের সর্বোচ্চ নিয়ন্ত্রণের জন্য আপনার পছন্দের নিজস্ব অ্যাডমিন ইউজারনেম ও পাসওয়ার্ড তৈরি করুন।
          </p>
        </div>

        {/* Security Policy Reminder Banner */}
        <div className="mb-6 p-3.5 rounded-2xl bg-slate-950/80 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5 leading-relaxed">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-amber-300">নিরাপত্তা নীতি: </span>
            সিস্টেমে কোনো ডিফল্ট পাসওয়ার্ড ব্যবহার করা হয় না। আপনি এই ফর্মের মাধ্যমে যে ইউজারনেম ও পাসওয়ার্ড নির্ধারণ করবেন, তা দিয়েই পরবর্তীতে লগইন করতে হবে। একবার সেটআপ সফল হলে এই পেজটি চিরতরে লক হয়ে যাবে।
          </div>
        </div>

        {errorMessage && (
          <div className="mb-5 p-3 rounded-xl bg-red-950/80 border border-red-500/40 text-red-200 text-xs flex items-center gap-2 animate-shake">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Super Admin Username */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>সুপার অ্যাডমিন ইউজারনেম <span className="text-emerald-400">*</span></span>
              {username.length > 0 && (
                <span className={`text-[10px] ${isUsernameValid ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {isUsernameValid ? 'সঠিক ইউজারনেম' : '৩-৩০ অক্ষর, বর্ণ ও সংখ্যা'}
                </span>
              )}
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="setup-super-admin-username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="যেমন: admin_owner বা jhadimadi_boss"
                required
                autoComplete="off"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
              />
            </div>
          </div>

          {/* Super Admin Email */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>লগইন ইমেইল এড্রেস <span className="text-slate-500 text-[10px] font-normal">(ঐচ্ছিক কিন্তু সুপারিশকৃত)</span></span>
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="setup-super-admin-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="যেমন: owner@jhadimadi.com"
                autoComplete="off"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
              />
            </div>
            <p className="text-[10px] text-slate-500 mt-1">
              ইউজারনেম অথবা এই ইমেইল—উভয়টি দিয়েই লগইন করা যাবে।
            </p>
          </div>

          {/* Super Admin Password */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>নতুন পাসওয়ার্ড <span className="text-emerald-400">*</span></span>
              {password.length > 0 && (
                <span className={`text-[10px] ${isPasswordLongEnough ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {isPasswordLongEnough ? 'পাসওয়ার্ডের দৈর্ঘ্য ঠিক আছে' : 'কমপক্ষে ৬ অক্ষর প্রয়োজন'}
                </span>
              )}
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="setup-super-admin-password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="আপনার নিজস্ব গোপনীয় পাসওয়ার্ড দিন"
                required
                className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition p-1"
                title={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>পাসওয়ার্ড নিশ্চিতকরণ (Confirm Password) <span className="text-emerald-400">*</span></span>
              {confirmPassword.length > 0 && (
                <span className={`text-[10px] ${doPasswordsMatch ? 'text-emerald-400' : 'text-red-400'}`}>
                  {doPasswordsMatch ? 'পাসওয়ার্ড মিলেছে ✓' : 'পাসওয়ার্ড মিলছে না ✕'}
                </span>
              )}
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="setup-super-admin-confirm-password"
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="পাসওয়ার্ড পুনরায় লিখুন"
                required
                className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition p-1"
                title={showConfirmPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
              >
                {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Validation Checklist Pills */}
          <div className="grid grid-cols-2 gap-2 pt-1 pb-1">
            <div className={`p-2 rounded-xl border text-[11px] font-medium flex items-center gap-1.5 ${
              isPasswordLongEnough 
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
                : 'bg-slate-950/50 border-slate-800 text-slate-500'
            }`}>
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              <span>কমপক্ষে ৬ অক্ষর</span>
            </div>
            <div className={`p-2 rounded-xl border text-[11px] font-medium flex items-center gap-1.5 ${
              doPasswordsMatch 
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
                : 'bg-slate-950/50 border-slate-800 text-slate-500'
            }`}>
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              <span>পাসওয়ার্ড মিল রয়েছে</span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            id="setup-super-admin-submit-btn"
            type="submit"
            disabled={loading || !isUsernameValid || !isPasswordLongEnough || !doPasswordsMatch}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-500 text-white font-bold text-sm shadow-lg shadow-emerald-900/30 transition flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed mt-2"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>অ্যাকাউন্ট সুরক্ষিত করা হচ্ছে...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>সুপার অ্যাডমিন অ্যাকাউন্ট তৈরি করুন</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </>
            )}
          </button>
        </form>

        {/* Back Link */}
        {onNavigateToCustomerApp && (
          <div className="mt-6 text-center border-t border-slate-800/80 pt-4">
            <button
              onClick={onNavigateToCustomerApp}
              className="text-xs text-slate-400 hover:text-emerald-400 inline-flex items-center gap-1.5 transition"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>কাস্টমার অ্যাপে ফিরে যান</span>
            </button>
          </div>
        )}
      </div>

      {/* Security Footer Note */}
      <div className="text-[11px] text-slate-500 mt-6 text-center max-w-sm">
        ঝাড়িমাদি বাজার • সিকিউর ক্রিপ্টোগ্রাফিক সল্টেড হ্যাশিং ও সেশন ম্যানেজমেন্ট সিস্টেম
      </div>
    </div>
  );
};
