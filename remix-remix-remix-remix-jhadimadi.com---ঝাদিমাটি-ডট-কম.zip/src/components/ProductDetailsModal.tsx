import React, { useState } from 'react';
import { 
  X, Share2, ShoppingCart, MapPin, Phone, MessageSquare, 
  Star, Award, Minus, Plus, Play, Lock, Eye, AlertCircle,
  ShieldCheck, CheckCircle2, Zap, Store, Truck, RotateCcw,
  QrCode, Barcode, Check, Heart, ExternalLink, HelpCircle
} from 'lucide-react';
import { OrganicProduct, Language } from '../types';
import { DetailedItem } from './ProductDetailsScreen';
import { VendorStoreProduct } from '../data/vendorsData';

interface ProductDetailsModalProps {
  isOpen: boolean;
  product: OrganicProduct | DetailedItem | VendorStoreProduct | null;
  onClose: () => void;
  onAddToCart: (product: any, quantity?: number, selectedSize?: string, selectedColor?: string) => void;
  onBuyNow?: (product: any, quantity?: number, selectedSize?: string, selectedColor?: string) => void;
  onVisitStore?: (sellerIdOrUniqueId: string) => void;
  lang: Language;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  isOpen,
  product,
  onClose,
  onAddToCart,
  onBuyNow,
  onVisitStore,
  lang,
}) => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedSizeIndex, setSelectedSizeIndex] = useState<number>(0);
  const [selectedColorIndex, setSelectedColorIndex] = useState<number>(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [copiedToast, setCopiedToast] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'specs' | 'escrow' | 'qr'>('details');

  if (!isOpen || !product) return null;

  // Adapt any product type (VendorStoreProduct, OrganicProduct, DetailedItem)
  const isVendorProduct = 'sellerUniqueId' in product;
  const isOrganicProduct = 'nameBn' in product && !isVendorProduct;

  const title = (product as any).nameBn || (product as any).title || 'পাহাড়ি অর্গানিক পণ্য';
  const category = (product as any).categoryLabelBn || (product as any).category || 'অর্গানিক ফুড';
  const basePrice = (product as any).price || 120;
  const originalPrice = (product as any).originalPrice || Math.round(basePrice * 1.25);
  const unit = (product as any).unit || 'কেজি';
  const location = (product as any).origin || (product as any).location || 'খাগড়াছড়ি সদর > মধুপুর বাজার';
  const description = (product as any).descriptionBn || (product as any).description || 'ঝাদিমাদি ডট কমে সরাসরি পাহাড়ি স্থানীয় চাষী ও উদ্যোক্তাদের নিকট হতে সংগৃহীত ১০০% বিষমুক্ত ও রাসায়নিকমুক্ত পণ্য।';
  const stock = (product as any).stock ?? 45;
  const rating = (product as any).rating || 4.9;
  const reviewsCount = (product as any).reviewsCount || 124;
  const badge = (product as any).badge || '১০০% খাঁটি ও প্রাকৃতিক';
  const badgeColor = (product as any).badgeColor || 'bg-emerald-600';
  const features: string[] = (product as any).features || [
    'রাসায়নিক সার ও কীটনাশকমুক্ত শতভাগ নিরাপদ',
    'ঘরোয়া ও পাহাড়ি ঐতিহ্যবাহী প্রক্রিয়াজাতকরণ',
    'অন-টাইম হোম ডেলিভারি ও এসক্রো সুরক্ষা',
    'মান সন্তুষ্ট না হলে সহজ রিটার্ন ও রিফান্ড পলিসি'
  ];

  const sellerUniqueId = (product as any).sellerUniqueId || 'V-KHG-001';
  const sellerShopName = (product as any).sellerShopName || 'পাহাড়ি কৃষি ও অর্গানিক খামার';
  const sellerOwnerName = (product as any).sellerOwnerName || 'বিপ্লব ত্রিপুরা';
  const sellerRating = (product as any).sellerRating || 4.9;
  const sellerAvatar = (product as any).sellerAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80';
  const sellerPhoneMasked = (product as any).sellerPhoneMasked || '01812****-***89';

  // Multi-image gallery (5-10 images)
  const defaultImages = [
    (product as any).image || 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?auto=format&fit=crop&w=800&q=80',
  ];
  const images: string[] = (product as any).images && (product as any).images.length > 0 
    ? (product as any).images 
    : defaultImages;

  // Variants (Sizes & Colors)
  const sizeVariants = (product as any).variants?.sizes || [
    { nameBn: '২৫০ গ্রাম প্যাক', priceOffset: -50 },
    { nameBn: '৫০০ গ্রাম রেগুলার', priceOffset: 0 },
    { nameBn: '১ কেজি ফ্যামিলি প্যাক', priceOffset: 120 },
    { nameBn: '২ কেজি বাল্ক প্যাক', priceOffset: 260 },
  ];

  const colorVariants = (product as any).variants?.colors || null;

  const currentSize = sizeVariants[selectedSizeIndex] || sizeVariants[0];
  const calculatedUnitPrice = Math.max(10, basePrice + (currentSize?.priceOffset || 0));
  const totalPrice = calculatedUnitPrice * quantity;
  const discountPercent = Math.round(((originalPrice - basePrice) / originalPrice) * 100);

  // Specifications list
  const specifications = (product as any).specifications || [
    { labelBn: 'পণ্য কোড / আইডি', valueBn: (product as any).barcode || `JM-${sellerUniqueId}-P01` },
    { labelBn: 'ব্র্যান্ড / খামার', valueBn: sellerShopName },
    { labelBn: 'উৎপত্তিস্থল (মাইক্রো-লোকেশন)', valueBn: location },
    { labelBn: 'প্রিজারভেটিভ ও কালার', valueBn: '০% রাসায়নিক (সম্পূর্ণ প্রাকৃতিক)' },
    { labelBn: 'সংরক্ষণ মেয়াদ', valueBn: 'শুষ্ক ও শীতল স্থানে ৯০ দিন' },
    { labelBn: 'কোয়ালিটি গ্রেড', valueBn: 'গ্রেড-১ প্রিমিয়াম এক্সপোর্ট কোয়ালিটি' },
    { labelBn: 'এসক্রো নিরাপত্তা', valueBn: 'ঝাদিমাদি ১০০% ডেলিভারি ও পেমেন্ট প্রটেকশন' }
  ];

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title,
        text: `${title} - ৳${calculatedUnitPrice} ঝাদিমাটি ডট কমে দেখুন!`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedToast(true);
      setTimeout(() => setCopiedToast(false), 2000);
    }
  };

  const handleAddToCart = () => {
    onAddToCart(product, quantity, currentSize?.nameBn, colorVariants ? colorVariants[selectedColorIndex]?.nameBn : undefined);
    setCopiedToast(true);
    setTimeout(() => setCopiedToast(false), 2000);
  };

  const handleBuyNow = () => {
    if (onBuyNow) {
      onBuyNow(product, quantity, currentSize?.nameBn, colorVariants ? colorVariants[selectedColorIndex]?.nameBn : undefined);
      onClose();
    } else {
      handleAddToCart();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div 
        className="bg-slate-50 border border-emerald-500/30 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl text-slate-800 my-auto flex flex-col max-h-[94vh] animate-in zoom-in-95"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Daraz-Style Top Navigation Bar */}
        <div className="bg-slate-900 text-white px-3.5 py-2.5 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 min-w-0 pr-2">
            <span className="px-2 py-0.5 bg-emerald-600 text-white font-mono font-black text-[9px] rounded-lg shadow-xs flex items-center gap-1 shrink-0">
              <ShieldCheck className="w-3 h-3" />
              {sellerUniqueId}
            </span>
            <h3 className="font-black text-xs sm:text-sm text-white truncate">
              {title}
            </h3>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setIsLiked(!isLiked)}
              className="p-1.5 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl transition-colors cursor-pointer"
              title="পছন্দের তালিকা"
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
            </button>
            <button
              type="button"
              onClick={handleShare}
              className="p-1.5 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl transition-colors cursor-pointer"
              title="শেয়ার করুন"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {copiedToast && (
          <div className="bg-emerald-600 text-white text-[10px] font-bold text-center py-1.5 shrink-0 shadow-md">
            ✓ কার্টে সফলভাবে যোগ করা হয়েছে! (মোট: ৳{totalPrice})
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="p-3 sm:p-4 space-y-3.5 overflow-y-auto flex-1 bg-slate-50">
          
          {/* SECTION 1: Interactive Multi-Image Gallery (5 to 10 Images with Zoom) */}
          <div className="bg-white border border-gray-200 rounded-3xl overflow-hidden shadow-2xs space-y-2">
            <div className="relative h-60 sm:h-72 bg-slate-950 group overflow-hidden">
              <img
                src={images[selectedImageIndex] || images[0]}
                alt={title}
                className={`w-full h-full object-cover transition-transform duration-300 ${isZoomed ? 'scale-135 cursor-zoom-out' : 'scale-100 cursor-zoom-in'}`}
                onClick={() => setIsZoomed(!isZoomed)}
              />

              {/* Floating Badges */}
              <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
                <span className="bg-black/75 text-white text-[9px] font-black px-2.5 py-1 rounded-lg backdrop-blur-sm flex items-center gap-1 shadow-md">
                  <MapPin className="w-3 h-3 text-emerald-400" />
                  <span>{location}</span>
                </span>
                <span className={`${badgeColor} text-white text-[8.5px] font-black px-2 py-0.5 rounded-md shadow-xs`}>
                  {badge}
                </span>
              </div>

              {discountPercent > 0 && (
                <div className="absolute top-2.5 right-2.5 bg-red-600 text-white text-[9px] font-black px-2 py-1 rounded-lg shadow-md">
                  {discountPercent}% OFF
                </div>
              )}

              <button
                type="button"
                onClick={() => setIsZoomed(!isZoomed)}
                className="absolute bottom-2.5 right-2.5 bg-black/60 hover:bg-black/80 text-white text-[9px] font-bold px-2.5 py-1 rounded-xl backdrop-blur-sm flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Eye className="w-3 h-3" />
                <span>{isZoomed ? 'জুম আউট' : 'জুম ইন 🔍'}</span>
              </button>

              {/* Image Counter Badge */}
              <div className="absolute bottom-2.5 left-2.5 bg-black/60 text-white text-[8.5px] font-bold px-2 py-0.5 rounded-lg backdrop-blur-sm">
                ছবি: {selectedImageIndex + 1} / {images.length}
              </div>
            </div>

            {/* Thumbnail Carousel (5-10 Thumbnails) */}
            <div className="p-2.5 flex items-center gap-2 overflow-x-auto scrollbar-none">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-14 h-14 rounded-2xl overflow-hidden border-2 shrink-0 cursor-pointer transition-all ${
                    selectedImageIndex === idx 
                      ? 'border-emerald-600 ring-2 ring-emerald-500/30 scale-105' 
                      : 'border-gray-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`Thumb ${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* SECTION 2: Title, Pricing, Variant Selectors & Stock Status */}
          <div className="bg-white border border-gray-200 rounded-3xl p-3.5 sm:p-4 space-y-3 shadow-2xs">
            <div className="flex items-start justify-between gap-2">
              <div className="space-y-1">
                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[8.5px] font-black uppercase">
                  {category}
                </span>
                <h2 className="font-black text-sm sm:text-base text-gray-900 leading-snug">
                  {title}
                </h2>
              </div>
              <div className="text-right shrink-0">
                <span className={`px-2 py-0.5 font-bold text-[8.5px] rounded-lg ${
                  stock > 10 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800 animate-pulse'
                }`}>
                  {stock > 10 ? `✓ স্টকে আছে (${stock}টি)` : `⚠️ স্টক সীমিত (${stock}টি)`}
                </span>
              </div>
            </div>

            {/* Price & Rating Bar */}
            <div className="flex items-baseline justify-between border-y border-gray-100 py-2.5">
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-xl sm:text-2xl font-black text-emerald-700">
                    ৳{calculatedUnitPrice}
                  </span>
                  {originalPrice > calculatedUnitPrice && (
                    <span className="text-xs text-gray-400 line-through font-bold">
                      ৳{originalPrice}
                    </span>
                  )}
                  <span className="text-[10px] text-gray-500 font-bold">
                    / {currentSize?.nameBn || unit}
                  </span>
                </div>
                <p className="text-[8.5px] text-emerald-700 font-bold flex items-center gap-1 mt-0.5">
                  <ShieldCheck className="w-3 h-3" />
                  ঝাদিমাদি ৫% প্ল্যাটফর্ম এসক্রো চার্জ অন্তর্ভুক্ত
                </p>
              </div>

              <div className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-xl">
                <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span className="text-[10.5px] font-black text-amber-950">{rating}</span>
                <span className="text-[8.5px] text-amber-800 font-medium">({reviewsCount}+ রিভিউ)</span>
              </div>
            </div>

            {/* Size / Weight Variant Selector */}
            {sizeVariants && sizeVariants.length > 0 && (
              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-[9.5px]">
                  <span className="font-black text-gray-700">ওজন / সাইজ নির্বাচন করুন:</span>
                  <span className="text-emerald-700 font-bold">{currentSize?.nameBn}</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  {sizeVariants.map((s: any, idx: number) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedSizeIndex(idx)}
                      className={`p-2 rounded-xl text-center border text-[9.5px] font-bold transition-all cursor-pointer ${
                        selectedSizeIndex === idx 
                          ? 'bg-emerald-50 border-emerald-600 text-emerald-900 ring-2 ring-emerald-500/20 font-black' 
                          : 'bg-slate-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <div>{s.nameBn}</div>
                      <div className="text-[8px] text-gray-500 mt-0.5">
                        {s.priceOffset === 0 ? 'বেস প্রাইস' : s.priceOffset > 0 ? `+৳${s.priceOffset}` : `-৳${Math.abs(s.priceOffset)}`}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Color Variant Selector if available */}
            {colorVariants && colorVariants.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between items-center text-[9.5px]">
                  <span className="font-black text-gray-700">রং ও শেড নির্বাচন:</span>
                  <span className="text-purple-700 font-bold">{colorVariants[selectedColorIndex]?.nameBn}</span>
                </div>
                <div className="flex items-center gap-2">
                  {colorVariants.map((c: any, idx: number) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedColorIndex(idx)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-[9px] font-bold cursor-pointer transition-all ${
                        selectedColorIndex === idx
                          ? 'border-purple-600 bg-purple-50 text-purple-900 ring-2 ring-purple-500/20'
                          : 'border-gray-200 bg-white text-gray-700'
                      }`}
                    >
                      <span className="w-3 h-3 rounded-full border border-black/20" style={{ backgroundColor: c.hex }} />
                      <span>{c.nameBn}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity Stepper */}
            <div className="flex items-center justify-between pt-1 border-t border-gray-100">
              <span className="text-[10px] font-black text-gray-800">পরিমাণ (Quantity):</span>
              <div className="flex items-center bg-slate-100 rounded-2xl p-1 border border-gray-200">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-7 h-7 flex items-center justify-center rounded-xl bg-white text-gray-700 hover:bg-gray-200 font-bold active:scale-95 transition-all cursor-pointer shadow-2xs"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="w-10 text-center font-black text-xs text-gray-900">{quantity}</span>
                <button
                  type="button"
                  onClick={() => setQuantity(Math.min(stock, quantity + 1))}
                  className="w-7 h-7 flex items-center justify-center rounded-xl bg-white text-gray-700 hover:bg-gray-200 font-bold active:scale-95 transition-all cursor-pointer shadow-2xs"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* SECTION 3: Verified Vendor Store Card & "Visit Storefront" Button */}
          <div className="bg-gradient-to-r from-slate-900 to-slate-950 text-white rounded-3xl p-3.5 sm:p-4 shadow-md space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <img
                  src={sellerAvatar}
                  alt={sellerShopName}
                  className="w-11 h-11 rounded-2xl object-cover border-2 border-emerald-400 shadow-md bg-white shrink-0"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-1">
                    <h4 className="font-black text-xs text-white truncate">{sellerShopName}</h4>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  </div>
                  <p className="text-[9px] text-gray-300 font-medium">মালিক: {sellerOwnerName} • {sellerUniqueId}</p>
                  <p className="text-[8.5px] text-emerald-300 font-mono">ফোন: {sellerPhoneMasked}</p>
                </div>
              </div>

              {/* Visit Store Button */}
              {onVisitStore && (
                <button
                  type="button"
                  onClick={() => {
                    onVisitStore(sellerUniqueId);
                    onClose();
                  }}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white text-[9.5px] font-black px-3.5 py-2 rounded-xl shadow-md flex items-center gap-1 active:scale-95 transition-all cursor-pointer shrink-0"
                >
                  <Store className="w-3.5 h-3.5" />
                  <span>দোকান ভিজিট করুন</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/10 text-center text-[8.5px]">
              <div className="bg-white/10 p-1.5 rounded-xl">
                <span className="text-gray-300 block">বিক্রেতা রেটিং</span>
                <strong className="text-amber-400 font-black">★ {sellerRating} / 5.0</strong>
              </div>
              <div className="bg-white/10 p-1.5 rounded-xl">
                <span className="text-gray-300 block">পজেটিভ ফিডব্যাক</span>
                <strong className="text-emerald-400 font-black">৯৮% সন্তুষ্টি</strong>
              </div>
              <div className="bg-white/10 p-1.5 rounded-xl">
                <span className="text-gray-300 block">শিপিং গতি</span>
                <strong className="text-blue-400 font-black">৯৯% অন-টাইম</strong>
              </div>
            </div>
          </div>

          {/* SECTION 4: In-App Escrow Guarantee & 5% Platform Commission Policy */}
          <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100 border border-emerald-200 rounded-3xl p-3.5 space-y-2 shadow-2xs">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black shrink-0 shadow-xs">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-[10.5px] font-black text-emerald-950">
                  ঝাদিমাদি ১০০% নিরাপদ ইন-অ্যাপ এসক্রো পেমেন্ট
                </h4>
                <p className="text-[8px] text-emerald-800">
                  সরাসরি অফ-প্ল্যাটফর্ম লেনদেন নিষিদ্ধ • অর্ডার ডেলিভারি না হওয়া পর্যন্ত অর্থ প্ল্যাটফর্মের মার্চেন্ট এসক্রোতে সুরক্ষিত
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-1.5 pt-1 text-[8.5px] text-center">
              <div className="bg-white/80 p-2 rounded-xl border border-emerald-200/60">
                <strong className="block text-emerald-950 font-black">১. bKash/Nagad/Card</strong>
                <span className="text-gray-600 text-[7.5px]">এসক্রোতে জমা</span>
              </div>
              <div className="bg-white/80 p-2 rounded-xl border border-emerald-200/60">
                <strong className="block text-emerald-950 font-black">২. ডেলিভারি যাচাই</strong>
                <span className="text-gray-600 text-[7.5px]">ক্রেতার সন্তুষ্টি কনফার্ম</span>
              </div>
              <div className="bg-white/80 p-2 rounded-xl border border-emerald-200/60">
                <strong className="block text-emerald-950 font-black">৩. ৯৫% নেট পেমেন্ট</strong>
                <span className="text-gray-600 text-[7.5px]">৫% ফি কেটে বিক্রেতাকে</span>
              </div>
            </div>
          </div>

          {/* SECTION 5: Quality Specs & Full Product Details */}
          <div className="bg-white border border-gray-200 rounded-3xl p-3.5 sm:p-4 space-y-3 shadow-2xs">
            <h3 className="font-black text-xs text-gray-900 border-b border-gray-100 pb-2 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-emerald-600" />
              <span>গুণগত বৈশিষ্ট্য ও বিবরণী (Specifications)</span>
            </h3>

            <div className="space-y-1.5">
              <h4 className="text-[9.5px] font-black text-gray-800">প্রধান সুবিধাসমূহ:</h4>
              <div className="grid grid-cols-1 gap-1">
                {features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-1.5 text-[9px] text-gray-700 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-gray-100 text-[9px]">
              {specifications.map((spec: any, idx: number) => (
                <div key={idx} className="p-2 bg-slate-50 border border-gray-200/80 rounded-xl">
                  <span className="text-gray-400 block text-[8px] font-bold">{spec.labelBn}</span>
                  <strong className="text-gray-900 font-bold">{spec.valueBn}</strong>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-gray-100">
              <h4 className="font-black text-[9.5px] text-gray-800 mb-1">বিস্তারিত বিবরণ:</h4>
              <p className="text-[9.5px] text-gray-600 leading-relaxed bg-slate-50 p-2.5 rounded-2xl border border-gray-200/80">
                {description}
              </p>
            </div>

            {/* QR & Barcode Section */}
            <div className="pt-2 border-t border-gray-100 flex items-center justify-between bg-slate-50 p-2.5 rounded-2xl">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 bg-white border border-gray-300 rounded-xl flex items-center justify-center text-slate-800 shadow-2xs">
                  <QrCode className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[8px] text-gray-500 font-bold block">পণ্য কিউআর ও ডিজিটাল ভেরিফিকেশন কোড</span>
                  <span className="font-mono text-[9.5px] font-black text-gray-900">{sellerUniqueId}-PROD-{title.slice(0, 4)}</span>
                </div>
              </div>
              <span className="text-[8px] bg-emerald-100 text-emerald-800 font-bold px-2 py-1 rounded-lg">
                যাচাইকৃত [✓]
              </span>
            </div>
          </div>

        </div>

        {/* Modal Fixed Footer: Buy Now & Add To Cart */}
        <div className="p-3 bg-white border-t border-gray-200 shrink-0 flex items-center gap-2 shadow-2xl">
          <button
            type="button"
            onClick={handleAddToCart}
            className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-2xl flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
          >
            <ShoppingCart className="w-4 h-4 text-emerald-400" />
            <span>কার্টে যোগ করুন (৳{totalPrice})</span>
          </button>

          <button
            type="button"
            onClick={handleBuyNow}
            className="flex-1 py-3 bg-[#FF6B35] hover:bg-[#e05a2b] text-white font-black text-xs rounded-2xl flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
          >
            <Zap className="w-4 h-4 fill-white" />
            <span>⚡ সরাসরি অর্ডার (এসক্রো)</span>
          </button>
        </div>

      </div>
    </div>
  );
};
