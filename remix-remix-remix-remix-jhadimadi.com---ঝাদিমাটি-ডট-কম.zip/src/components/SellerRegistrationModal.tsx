import React, { useState } from 'react';
import { 
  X, Store, ShoppingBag, ShieldCheck, MapPin, Upload, 
  Camera, CheckCircle2, Phone, Mail, Lock, Eye, EyeOff,
  Sparkles, FileText, Award, Building, User
} from 'lucide-react';
import { Language, District, UserProfile } from '../types';
import { databaseService } from '../services/databaseService';
import { sanitizeDatabasePayload } from '../utils/imageUtils';

interface SellerRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
  lang: Language;
  defaultDivision?: string;
  defaultDistrict?: string;
  defaultUpazila?: string;
  defaultMahalla?: string;
}

const BUSINESS_CATEGORIES = [
  { id: 'organic_food', labelBn: 'পাহাড়ি অর্গানিক খাবার, শুটকি ও মধু' },
  { id: 'fruits_agro', labelBn: 'ফলমূল, নার্সারি ও এগ্রো ফার্ম' },
  { id: 'clothing_handloom', labelBn: 'পাহাড়ি থামি, পোশাক ও কোমর তাঁত' },
  { id: 'electronics_mobile', labelBn: 'ইলেকট্রনিক্স, গ্যাজেট ও মোবাইল এক্সেসরিজ' },
  { id: 'furniture_craft', labelBn: 'কাঠ ও বাঁশ-বেতের ফার্নিচার ও হস্তশিল্প' },
  { id: 'general_store', labelBn: 'ডিপার্টমেন্টাল ও জেনারেল স্টোর' },
  { id: 'realestate_rent', labelBn: 'বাসা ভাড়া ও রিয়েল এস্টেট প্রপার্টি' },
  { id: 'automotive_parts', labelBn: 'বাইক, গাড়ি ও পার্টস শপ' },
];

export const SellerRegistrationModal: React.FC<SellerRegistrationModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  lang,
  defaultDivision = 'Chittagong Division (চট্টগ্রাম)',
  defaultDistrict = 'Rangamati',
  defaultUpazila = 'Rangamati Sadar',
  defaultMahalla = 'বনরুপা (Bonorupa)',
}) => {
  const [shopName, setShopName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [businessCategory, setBusinessCategory] = useState('organic_food');
  const [tradeLicenseOrNid, setTradeLicenseOrNid] = useState('');
  const [shopAddress, setShopAddress] = useState('বনরুপা বাজার, মেইন রোড');
  const [division, setDivision] = useState(defaultDivision);
  const [district, setDistrict] = useState(defaultDistrict);
  const [upazila, setUpazila] = useState(defaultUpazila);
  const [mahalla, setMahalla] = useState(defaultMahalla);
  const [shopBannerUrl, setShopBannerUrl] = useState('https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=600&q=80');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!shopName.trim() || !ownerName.trim()) {
      alert(lang === 'bn' ? 'অনুগ্রহ করে দোকানের নাম ও মালিকের নাম লিখুন।' : 'Please enter shop and owner name.');
      return;
    }
    if (!phone.trim()) {
      alert(lang === 'bn' ? 'মোবাইল নম্বর প্রদান করুন।' : 'Please provide mobile number.');
      return;
    }

    setIsSubmitting(true);

    const userId = 'seller_' + Date.now();
    const newSellerProfile: UserProfile = {
      id: userId,
      name: `${shopName} (${ownerName})`,
      fullName: ownerName.trim(),
      phone: phone.trim(),
      email: email.trim() || undefined,
      password: password,
      division,
      district,
      upazila,
      thana: upazila,
      mahalla,
      para: mahalla,
      paraMahalla: `${mahalla}, ${upazila}`,
      avatar: shopBannerUrl || 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=600&q=80',
      categorySkill: 'ভেরিফাইড মার্চেন্ট / বিক্রেতা',
      profession: 'মার্চেন্ট / বিক্রেতা',
      professionBn: 'মার্চেন্ট / বিক্রেতা',
      role: 'seller',
      detailedAddress: shopAddress,
      nidNumber: tradeLicenseOrNid || 'NID-VERIFIED-SELLER',
      isNidVerified: true,
      isPaidMember: true,
      createdAt: new Date().toISOString().split('T')[0],
    };

    try {
      const result = await databaseService.saveUserProfile({
        ...newSellerProfile,
        shopName,
        ownerName,
        businessCategory,
        tradeLicenseOrNid,
      });

      if (!result.success) {
        throw new Error(result.error || 'ফায়ারস্টোরে সেভ করা সম্ভব হয়নি');
      }

      await fetch('/api/auth/register-seller', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newSellerProfile,
          shopName,
          ownerName,
          businessCategory,
          tradeLicenseOrNid,
        }),
      }).catch(() => {});

      setIsSubmitting(false);
      alert(
        lang === 'bn'
          ? `🎉 অভিনন্দন ${shopName}!\nআপনার বিক্রেতা/দোকান একাউন্ট সফলভাবে নিবন্ধিত হয়েছে। এখন আপনি সরাসরি আনলিমিটেড পণ্য পোস্ট করতে পারবেন!`
          : `Congratulations ${shopName}! Your Seller Account is active.`
      );
      onSuccess(newSellerProfile);
      onClose();
    } catch (err: any) {
      console.error('Registration error for seller:', err);
      setIsSubmitting(false);
      alert(
        lang === 'bn'
          ? `রেজিস্ট্রেশন ব্যর্থ হয়েছে: ${err?.message || 'ডাটাবেস কানেকশন এরর'}`
          : `Registration failed: ${err?.message || 'Database connection error'}`
      );
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl border border-slate-200 flex flex-col max-h-[92vh] my-auto">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#B80000] to-[#8A0000] text-white p-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
              <Store className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm leading-none">
                {lang === 'bn' ? '🏪 বিক্রেতা রেজিস্ট্রেশন (Seller Registration)' : 'Seller / Merchant Registration'}
              </h3>
              <p className="text-[10px] text-white/80 mt-1">
                {lang === 'bn' ? 'দোকান বা পণ্যের বিক্রেতা হিসেবে সহজে রেজিস্ট্রেশন করুন' : 'Sell your products on Jhadimadi Marketplace'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 overflow-y-auto space-y-3.5 text-xs">
          
          {/* Shop / Business Name */}
          <div>
            <label className="font-extrabold text-slate-800 block text-[11px] mb-1">
              {lang === 'bn' ? '১. দোকান / প্রতিষ্ঠানের নাম (Shop Name):' : '1. Shop / Business Name:'} <span className="text-red-500">*</span>
            </label>
            <div className="relative flex items-center">
              <Store className="w-4 h-4 text-slate-400 absolute left-3" />
              <input
                type="text"
                required
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                placeholder="যেমন: রাঙ্গামাটি অর্গানিক ভান্ডার / চাকমা টেক্সটাইল"
                className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-[#B80000] focus:bg-white"
              />
            </div>
          </div>

          {/* Owner Full Name */}
          <div>
            <label className="font-extrabold text-slate-800 block text-[11px] mb-1">
              {lang === 'bn' ? '২. স্বত্বাধিকারী / বিক্রেতার নাম (Owner Name):' : '2. Owner Full Name:'} <span className="text-red-500">*</span>
            </label>
            <div className="relative flex items-center">
              <User className="w-4 h-4 text-slate-400 absolute left-3" />
              <input
                type="text"
                required
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="যেমন: মোঃ রফিকুল ইসলাম / জয়ন্ত চাকমা"
                className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-[#B80000] focus:bg-white"
              />
            </div>
          </div>

          {/* Business Category */}
          <div>
            <label className="font-extrabold text-slate-800 block text-[11px] mb-1">
              {lang === 'bn' ? '৩. ব্যবসার প্রধান ক্যাটাগরি:' : '3. Business Category:'}
            </label>
            <select
              value={businessCategory}
              onChange={(e) => setBusinessCategory(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-[#B80000] cursor-pointer"
            >
              {BUSINESS_CATEGORIES.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.labelBn}
                </option>
              ))}
            </select>
          </div>

          {/* Phone Number & Email */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-extrabold text-slate-800 block text-[11px] mb-1">
                {lang === 'bn' ? '৪. মোবাইল নম্বর (Phone):' : '4. Phone:'} <span className="text-red-500">*</span>
              </label>
              <div className="relative flex items-center">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3" />
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01812345678"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-[#B80000] focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="font-extrabold text-slate-800 block text-[11px] mb-1">
                {lang === 'bn' ? '৫. ইমেইল এড্রেস (ঐচ্ছিক):' : '5. Email (Optional):'}
              </label>
              <div className="relative flex items-center">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="shop@jhadimadi.com"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:border-[#B80000] focus:bg-white"
                />
              </div>
            </div>
          </div>

          {/* Custom Password */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-extrabold text-slate-800 text-[11px]">
                {lang === 'bn' ? '৬. পছন্দসই পাসওয়ার্ড সেট করুন:' : '6. Set Custom Password:'} <span className="text-red-500">*</span>
              </label>
              <span className="text-[9px] text-[#B80000] font-bold">লগইন করার জন্য পিন/পাসওয়ার্ড</span>
            </div>
            <div className="relative flex items-center">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="পাসওয়ার্ড লিখুন (কমপক্ষে ৬ অক্ষর)"
                className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-[#B80000] focus:bg-white"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Trade License / NID Number */}
          <div>
            <label className="font-extrabold text-slate-800 block text-[11px] mb-1">
              {lang === 'bn' ? '৭. ট্রেড লাইসেন্স বা এনআইডি নম্বর (NID / Trade License):' : '7. NID or Trade License:'}
            </label>
            <input
              type="text"
              value={tradeLicenseOrNid}
              onChange={(e) => setTradeLicenseOrNid(e.target.value)}
              placeholder="এনআইডি বা ট্রেড লাইসেন্স নম্বর (ভেরিফিকেশনের জন্য)"
              className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:border-[#B80000] focus:bg-white"
            />
          </div>

          {/* Location Details */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex items-center gap-1.5 text-slate-800 font-extrabold text-[11px]">
              <MapPin className="w-3.5 h-3.5 text-[#B80000]" />
              <span>{lang === 'bn' ? '৮. দোকানের ভৌগোলিক অবস্থান ও ঠিকানা:' : '8. Shop Location & Address:'}</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="জেলা (District)"
                className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-[10.5px] font-bold text-slate-800"
              />
              <input
                type="text"
                value={upazila}
                onChange={(e) => setUpazila(e.target.value)}
                placeholder="উপজেলা / থানা (Upazila)"
                className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-[10.5px] font-bold text-slate-800"
              />
            </div>

            <input
              type="text"
              value={shopAddress}
              onChange={(e) => setShopAddress(e.target.value)}
              placeholder="দোকানের পূর্ণ ঠিকানা / বাজার / রোড নম্বর"
              className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-[10.5px] font-medium text-slate-800"
            />
          </div>

          {/* Submit */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-[#B80000] hover:bg-[#990000] text-white font-black text-xs rounded-xl shadow-lg shadow-[#B80000]/30 cursor-pointer transition-all flex items-center justify-center gap-1.5 active:scale-98"
            >
              <Store className="w-4 h-4" />
              <span>{isSubmitting ? 'প্রসেস হচ্ছে...' : 'বিক্রেতা হিসেবে রেজিস্ট্রেশন সম্পন্ন করুন ➔'}</span>
            </button>
          </div>

        </form>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-100 p-2.5 px-4 text-[9.5px] text-slate-500 flex items-center justify-between shrink-0">
          <span className="flex items-center gap-1 text-emerald-700 font-bold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>১০০% নিরাপদ ভেরিফাইড বিক্রেতা পোর্টাল</span>
          </span>
          <span className="text-slate-400">Jhadimadi Seller Portal</span>
        </div>

      </div>
    </div>
  );
};
