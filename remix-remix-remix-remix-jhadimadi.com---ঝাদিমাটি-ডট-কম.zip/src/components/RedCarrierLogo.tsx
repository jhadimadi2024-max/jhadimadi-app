import React from 'react';

interface RedCarrierLogoProps {
  size?: number | string;
  className?: string;
  color?: string;
}

export const RedCarrierLogo: React.FC<RedCarrierLogoProps> = ({
  size = 36,
  className = '',
  color = '#B80000',
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 200 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block shrink-0 ${className}`}
      aria-label="Jhadimadi Red Running Carrier"
    >
      {/* Head */}
      <circle cx="161" cy="26" r="17.5" fill={color} />

      {/* Arm reaching / pump */}
      <path
        d="M140 50 L158 96 L198 58 L184 54 L154 84 L142 50 Z"
        fill={color}
      />

      {/* Main Carrier Sack (Backpack Bundle) */}
      <path
        d="M136 67 C130 38 108 10 65 11 C28 12 21 39 23 58 C25 76 43 89 72 90 C96 91 120 83 136 67 Z"
        fill={color}
      />

      {/* Neck & Draped Scarf / Sash */}
      <path
        d="M128 32 C120 40 114 48 114 62 C114 74 122 84 128 85 C132 85 136 78 135 68 C134 52 144 42 147 36 C143 32 135 30 128 32 Z"
        fill={color}
      />

      {/* Upper Torso & Flowing Sash loop */}
      <path
        d="M102 78 C92 88 88 100 90 108 C93 118 105 124 116 116 C126 109 130 94 132 86 C124 88 111 88 102 78 Z"
        fill={color}
      />

      {/* Front Striding Leg & Knee */}
      <path
        d="M74 97 C68 112 70 126 80 137 C90 148 114 153 129 143 C127 151 118 160 106 166 L124 148 L96 164 L107 152 C91 144 80 134 76 116 L74 97 Z"
        fill={color}
      />

      {/* Lower Stride Leg & Dynamic Feet Path */}
      <path
        d="M68 97 C66 110 56 122 47 137 L41 148 C34 158 24 167 9 176 L0 188 L10 188 C32 181 50 162 55 146 L76 106 L68 97 Z"
        fill={color}
      />
      <path
        d="M110 134 C124 144 125 152 119 160 L97 165 C107 157 114 148 110 134 Z"
        fill={color}
      />
    </svg>
  );
};
