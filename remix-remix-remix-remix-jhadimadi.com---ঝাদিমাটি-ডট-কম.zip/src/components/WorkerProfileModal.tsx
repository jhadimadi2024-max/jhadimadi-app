import React from 'react';
import { ServiceProvider, Language, UserProfile } from '../types';
import { ServiceProviderPublicProfile } from './ServiceProviderPublicProfile';

export interface WorkerProfileModalProps {
  isOpen: boolean;
  provider: ServiceProvider | UserProfile | null;
  onClose: () => void;
  onBookService?: (provider: ServiceProvider | any) => void;
  onOpenChat?: (providerName: string) => void;
  lang: Language;
  isAdminMode?: boolean;
  isOwnProfile?: boolean;
  currentUser?: UserProfile | null;
}

export const WorkerProfileModal: React.FC<WorkerProfileModalProps> = ({
  isOpen,
  provider,
  onClose,
  onBookService,
  onOpenChat,
  lang,
  isAdminMode = false,
  isOwnProfile,
  currentUser = null,
}) => {
  if (!isOpen || !provider) return null;

  // Determine owner status: true if explicitly true, or if current user matches provider
  const isOwner = Boolean(
    isOwnProfile ||
    isAdminMode ||
    (currentUser && provider && (
      (currentUser.id && (currentUser.id === provider.id || currentUser.id === (provider as any).memberUID)) ||
      (currentUser.phone && (provider as any).phone && currentUser.phone === (provider as any).phone) ||
      (currentUser.email && (provider as any).email && currentUser.email === (provider as any).email)
    ))
  );

  return (
    <div 
      id="worker-profile-modal-backdrop" 
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-1.5 sm:p-4 overflow-y-auto overflow-x-hidden animate-in fade-in"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-full sm:max-w-4xl my-auto overflow-x-hidden box-border"
        onClick={(e) => e.stopPropagation()}
      >
        <ServiceProviderPublicProfile
          provider={provider}
          currentUser={currentUser}
          isOwner={isOwner}
          onClose={onClose}
          onBookService={onBookService}
          onOpenChat={onOpenChat}
          lang={lang}
        />
      </div>
    </div>
  );
};
