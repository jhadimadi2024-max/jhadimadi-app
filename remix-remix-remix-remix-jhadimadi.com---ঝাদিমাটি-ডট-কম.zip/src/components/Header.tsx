import React, { useState, useRef } from 'react';
import { ShoppingCart, Search, Sparkles, Mic, User, Bell } from 'lucide-react';

export interface HeaderProps {
  currentUser?: any;
  cartCount?: number;
  onOpenCart?: () => void;
  onOpenMemberModal?: () => void;
  onOpenProfile?: () => void;
  onOpenAiAssistant?: () => void;
  searchQuery?: string;
  onSearchChange?: (q: string) => void;
  onSearchSubmit?: () => void;
  lang?: string;
  onLogoClick?: () => void;
  district?: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  cartCount = 0,
  onOpenCart,
  onOpenMemberModal,
  onOpenProfile,
  onOpenAiAssistant,
  searchQuery = '',
  onSearchChange,
  onSearchSubmit,
  lang = 'bn',
  onLogoClick,
  district = 'Khagrachari',
}) => {
  const [isVoiceListening, setIsVoiceListening] = useState(false);
  const [isImageSearching, setIsImageSearching] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  return (
    <header
      className="sticky top-0 z-50 w-full border-b border-[#008c43] shadow-xs"
      style={{
        paddingTop: 'calc(env(safe-area-inset-top, 0px) + 2px)',
        paddingLeft: 'env(safe-area-inset-left, 0px)',
        paddingRight: 'env(safe-area-inset-right, 0px)',
        backgroundColor: '#009f4d',
      }}
    >
      {/* Sleek, compact Green Header (#009f4d) */}
      <div className="w-full bg-[#009f4d]">
        {/* Subtle vibrant emerald brand accent line */}
        <div 
          className="w-full h-0.5 bg-gradient-to-r from-[#009f4d] via-emerald-300/80 to-[#009f4d] opacity-90"
          title="Jhadimadi Brand Accent"
        />

        <div className="max-w-7xl mx-auto px-2.5 sm:px-5 py-1.5 sm:py-2">
          <div className="flex items-center justify-between gap-2 sm:gap-3">
            {/* LEFT: Official Brand Logo & Identity */}
            <div
              onClick={onLogoClick}
              className="flex items-center cursor-pointer select-none group min-w-0"
              title="Jhadimadi.com হোমপেজ"
            >
              <div className="relative p-0.5 rounded-lg border border-white/40 bg-white shadow-xs group-hover:scale-105 transition-transform mr-2 shrink-0 flex items-center justify-center w-7 h-7 sm:w-8 sm:h-8">
                <img
                  src="https://i.ibb.co.com/sppWZhc9/logo33.png"
                  alt="Jhadimadi.com Logo"
                  className="h-5.5 sm:h-6.5 w-auto object-contain"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/logo11.png';
                  }}
                />
              </div>

              <div className="flex flex-col justify-center min-w-0">
                <span className="text-[14px] sm:text-[17px] font-black tracking-tight text-white font-sans leading-none truncate drop-shadow-xs">
                  Jhadimadi<span className="text-yellow-300">.com</span>
                </span>
                <span className="text-[8px] sm:text-[9.5px] font-bold text-amber-200 tracking-tight leading-none mt-0.5 truncate">
                  পার্বত্য ই-কমার্স সাইট
                </span>
              </div>
            </div>

            {/* RIGHT: Actions (Profile & Cart) */}
            <div className="flex items-center gap-1.5 shrink-0">
              {currentUser && onOpenProfile && (
                <button
                  type="button"
                  onClick={onOpenProfile}
                  className="h-7 px-2 rounded-lg bg-white/15 hover:bg-white/25 active:scale-95 border border-white/25 text-white transition-all text-[9px] font-bold flex items-center gap-1 shadow-2xs cursor-pointer"
                  title="প্রোফাইল ড্যাশবোর্ড"
                >
                  <User className="w-3.5 h-3.5" />
                  <span className="max-w-[48px] truncate">{currentUser.name?.split(' ')[0] || 'প্রোফাইল'}</span>
                </button>
              )}

              {onOpenCart && (
                <button
                  type="button"
                  onClick={onOpenCart}
                  className="h-7 w-7 rounded-lg bg-white/15 hover:bg-white/25 active:scale-95 border border-white/25 text-white transition-all relative cursor-pointer shadow-2xs flex items-center justify-center"
                  title="কার্ট"
                  aria-label="শপিং কার্ট"
                >
                  <ShoppingCart className="w-4 h-4 text-white" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-600 border border-white/80 text-white text-[8px] font-black w-3.5 h-3.5 rounded-full flex items-center justify-center shadow-xs leading-none">
                      {cartCount}
                    </span>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
