import React, { useState } from 'react';
import { CartItem, Language } from '../types';
import { ShoppingBag, Trash2, Plus, Minus, X, CheckCircle, ShieldCheck, CreditCard, MapPin, Phone, Truck } from 'lucide-react';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  lang: Language;
}

export const CartModal: React.FC<CartModalProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  lang,
}) => {
  const [address, setAddress] = useState('পানখাইয়াপাড়া, খাগড়াছড়ি সদর');
  const [phone, setPhone] = useState('01870592699');
  const [paymentMethod, setPaymentMethod] = useState<'bKash' | 'Nagad' | 'COD' | 'Rocket'>('COD');
  const [isOrdered, setIsOrdered] = useState(false);
  const [assignedRider, setAssignedRider] = useState<{ riderName: string; riderPhone: string } | null>(null);

  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const deliveryFee = subtotal > 0 ? 50 : 0;
  const total = subtotal + deliveryFee;

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    try {
      const res = await fetch('/api/food-grocery-orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: 'সম্মানিত পাহাড়ি ক্রেতা',
          customerPhone: phone || '01870592699',
          district: 'Khagrachhari',
          upazila: 'Khagrachhari Sadar',
          items: cart.map(c => ({ name: c.product.nameBn, qty: c.quantity, price: c.product.price })),
          totalPrice: total,
          paymentMethod,
          deliveryAddress: address || 'পানখাইয়াপাড়া, খাগড়াছড়ি সদর',
        }),
      });
      const data = await res.json();
      if (data.success && data.assignedRider) {
        setAssignedRider(data.assignedRider);
      } else {
        setAssignedRider({ riderName: 'মংনু মারমা (খাগড়াছড়ি এক্সপ্রেস ডেলিভারি)', riderPhone: '01870592699' });
      }
    } catch {
      setAssignedRider({ riderName: 'মংনু মারমা (খাগড়াছড়ি এক্সপ্রেস ডেলিভারি)', riderPhone: '01870592699' });
    }

    setIsOrdered(true);
  };

  const handleDone = () => {
    onClearCart();
    setIsOrdered(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white border border-stone-200 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl text-stone-900 max-h-[90vh] flex flex-col my-auto animate-in zoom-in-95">
        
        {/* Header */}
        <div className="p-4 bg-[#1E4D2B] text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#D97706]" />
            <h3 className="font-black text-base sm:text-lg">
              {lang === 'bn' ? 'ঝাদিমাটি শপিং কার্ট ও চেকআউট' : 'Jhadimadi Shopping Cart'}
            </h3>
          </div>
          <button 
            onClick={onClose} 
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {isOrdered ? (
          <div className="p-6 sm:p-8 text-center space-y-4 my-auto">
            <div className="w-16 h-16 bg-emerald-100 text-[#1E4D2B] rounded-full flex items-center justify-center mx-auto border border-emerald-300 animate-bounce">
              <CheckCircle className="w-10 h-10" />
            </div>
            <h4 className="text-xl font-black text-stone-900">
              {lang === 'bn' ? 'অর্ডার সফলভাবে গ্রহণ করা হয়েছে!' : 'Order Placed Successfully!'}
            </h4>
            <p className="text-xs sm:text-sm text-stone-600 max-w-sm mx-auto">
              আপনার পাহাড়ি অর্গানিক পণ্যসমূহ প্যাক করে দ্রুত পাঠানো হচ্ছে।
            </p>

            {assignedRider && (
              <div className="p-3.5 bg-[#FAF6F0] rounded-2xl border border-stone-200 max-w-sm mx-auto text-left space-y-1.5 shadow-2xs">
                <div className="flex items-center gap-2 text-xs font-black text-[#1E4D2B]">
                  <Truck className="w-4 h-4 text-[#D97706]" />
                  <span>নিযুক্ত ডেলিভারি রাইডার:</span>
                </div>
                <div className="text-xs font-bold text-stone-800">{assignedRider.riderName}</div>
                <div className="text-xs text-stone-600">ফোন: {assignedRider.riderPhone}</div>
              </div>
            )}

            <button
              onClick={handleDone}
              className="w-full max-w-xs mx-auto py-3 bg-[#1E4D2B] hover:bg-[#15371e] text-white font-bold rounded-xl cursor-pointer"
            >
              ঠিক আছে
            </button>
          </div>
        ) : cart.length === 0 ? (
          <div className="p-8 text-center space-y-3 my-auto">
            <ShoppingBag className="w-12 h-12 text-stone-300 mx-auto" />
            <p className="text-sm font-bold text-stone-500">আপনার শপিং কার্ট খালি রয়েছে</p>
            <button
              onClick={onClose}
              className="px-5 py-2 bg-[#1E4D2B] text-white text-xs font-bold rounded-xl cursor-pointer"
            >
              পণ্য সম্ভার দেখুন
            </button>
          </div>
        ) : (
          <form onSubmit={handleCheckout} className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
            
            {/* Cart Items */}
            <div className="space-y-2.5">
              {cart.map((item) => (
                <div
                  key={item.product.id}
                  className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between gap-2"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.nameBn}
                    className="w-12 h-12 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h5 className="font-extrabold text-xs text-stone-900 truncate">
                      {item.product.nameBn}
                    </h5>
                    <span className="text-[11px] font-black text-[#8B4513]">
                      ৳{item.product.price} <span className="font-normal text-stone-500">/{item.product.unit}</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => onUpdateQuantity(item.product.id, -1)}
                      className="w-6 h-6 rounded-lg bg-white border border-stone-300 flex items-center justify-center text-xs font-bold hover:bg-stone-100"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="font-black text-xs px-1">{item.quantity}</span>
                    <button
                      type="button"
                      onClick={() => onUpdateQuantity(item.product.id, 1)}
                      className="w-6 h-6 rounded-lg bg-white border border-stone-300 flex items-center justify-center text-xs font-bold hover:bg-stone-100"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemoveItem(item.product.id)}
                      className="p-1 text-rose-600 hover:bg-rose-50 rounded-lg ml-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Delivery & Contact Details */}
            <div className="space-y-3 pt-2 border-t border-stone-200">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  ডেলিভারি ঠিকানা (Delivery Address) *
                </label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-medium"
                  placeholder="উদা: পানখাইয়াপাড়া, খাগড়াছড়ি সদর"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  যোগাযোগ নম্বর (Phone) *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-medium"
                />
              </div>

              {/* Payment Method */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  পেমেন্ট মাধ্যম (Payment Method)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'COD', label: 'ক্যাশ অন ডেলিভারি' },
                    { id: 'bKash', label: 'বিকাশ (bKash)' },
                    { id: 'Nagad', label: 'নগদ (Nagad)' },
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPaymentMethod(m.id as any)}
                      className={`py-2 px-1 text-[11px] font-bold rounded-xl border transition-all ${
                        paymentMethod === m.id
                          ? 'bg-[#1E4D2B] text-white border-[#1E4D2B]'
                          : 'bg-stone-50 border-stone-200 text-stone-700'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Total calculation */}
            <div className="p-3 bg-[#FAF6F0] rounded-2xl border border-stone-200 space-y-1.5 text-xs font-medium text-stone-700">
              <div className="flex justify-between">
                <span>পণ্যের মোট মূল্য:</span>
                <span className="font-bold">৳{subtotal}</span>
              </div>
              <div className="flex justify-between">
                <span>পাহাড়ি হোম ডেলিভারি ফি:</span>
                <span className="font-bold">৳{deliveryFee}</span>
              </div>
              <div className="flex justify-between text-sm font-black text-[#1E4D2B] pt-1 border-t border-stone-200">
                <span>সর্বমোট পরিশোধযোগ্য:</span>
                <span>৳{total}</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-[#1E4D2B] hover:bg-[#15371e] text-white font-black text-sm rounded-2xl shadow-md cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-4 h-4 text-[#D97706]" />
              <span>অর্ডার নিশ্চিত করুন (৳{total})</span>
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
