import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface JhadimadiSplashScreenProps {
  onFinish: () => void;
  durationMs?: number;
}

/**
 * Jhadimadi.com Official Modern Splash Screen (App Startup Loading Screen)
 * 
 * Features:
 * - Clean brand theme background (#FAF8F5 with smooth subtle gradient)
 * - Prominent, centered courier/runner vector logo (New official graphic)
 * - Exact Bengali tagline: "সকল প্রয়োজনে, সবসময় ‘ঝাদিমাদি ডটকম’ আপনার পাশে।"
 * - Elegant entrance motion (fade-in, subtle scale-up, and delayed tagline reveal)
 * - Sleek modern organic green loading progress indicator at the bottom
 * - Safe-area aware for edge-to-edge Android WebView (Median) & iOS devices
 * - Smooth fade-out exit transition into the main app
 */

// Fallback cascade to guarantee instant, reliable rendering on any device
const LOGO_CANDIDATES = [
  '/logo11.png',
  'https://i.ibb.co.com/sppWZhc9/logo33.png',
  '/runner-logo.png',
  '/assets/images/runner-logo.png',
];

export const JhadimadiSplashScreen: React.FC<JhadimadiSplashScreenProps> = ({
  onFinish,
  durationMs = 2600,
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [logoIndex, setLogoIndex] = useState(0);
  const [progress, setProgress] = useState(0);

  const currentLogoSrc = LOGO_CANDIDATES[logoIndex] || '/logo11.png';

  useEffect(() => {
    // 1. Progress animation loop for the organic green indicator
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(Math.round((elapsed / durationMs) * 100), 100);
      setProgress(pct);
      if (pct >= 100) {
        clearInterval(interval);
      }
    }, 40);

    // 2. Auto-dismiss timer after duration
    const timer = setTimeout(() => {
      setIsVisible(false);
      const exitTimer = setTimeout(() => {
        onFinish();
      }, 400); // Wait for exit animation to complete
      return () => clearTimeout(exitTimer);
    }, durationMs);

    // 3. Optional key listener for immediate dismiss (Escape, Enter, Space)
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') {
        clearInterval(interval);
        clearTimeout(timer);
        setIsVisible(false);
        setTimeout(onFinish, 200);
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      clearInterval(interval);
      clearTimeout(timer);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [durationMs, onFinish]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          key="jhadimadi-modern-splash"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 0.99 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-0 z-[99999] w-screen h-[100dvh] min-h-[100dvh] flex flex-col items-center justify-between select-none overflow-hidden cursor-default"
          style={{
            backgroundColor: '#FAF8F5',
            backgroundImage: 'radial-gradient(circle at 50% 38%, #FFFFFF 0%, #FAF8F5 65%, #F4F0E8 100%)',
            paddingTop: 'env(safe-area-inset-top, 0px)',
            paddingBottom: 'env(safe-area-inset-bottom, 0px)',
            paddingLeft: 'env(safe-area-inset-left, 0px)',
            paddingRight: 'env(safe-area-inset-right, 0px)',
          }}
          aria-label="Jhadimadi.com Startup Screen"
          role="dialog"
          aria-modal="true"
        >
          {/* Top spacer for optical balance */}
          <div className="w-full h-8 sm:h-12 shrink-0 pointer-events-none" />

          {/* Absolute Center Content: New Courier Runner Logo + Tagline */}
          <div className="relative w-full max-w-sm sm:max-w-md flex flex-col items-center justify-center px-6 my-auto">
            {/* Soft organic emerald ambient aura behind the logo */}
            <div 
              className="absolute -top-6 w-48 h-48 sm:w-56 sm:h-56 rounded-full bg-emerald-500/8 blur-3xl pointer-events-none -z-10"
              aria-hidden="true"
            />

            {/* 1. New Logo: Running Delivery / Courier Vector Graphic */}
            <motion.div
              className="relative flex items-center justify-center"
              initial={{ opacity: 0, scale: 0.82, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{
                duration: 0.65,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              <div className="relative w-28 h-28 xs:w-32 xs:h-32 sm:w-36 sm:h-36 flex items-center justify-center p-2 rounded-2xl bg-white/70 backdrop-blur-xs border border-stone-200/50 shadow-sm transition-all">
                <img
                  src={currentLogoSrc}
                  alt="Jhadimadi.com Courier Runner Logo"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain select-none pointer-events-none drop-shadow-xs"
                  onError={() => {
                    setLogoIndex((prev) => (prev + 1 < LOGO_CANDIDATES.length ? prev + 1 : prev));
                  }}
                />
              </div>
            </motion.div>

            {/* 2. Brand Name Header ("ঝাদিমাদি ডটকম") */}
            <motion.div
              className="mt-4 flex flex-col items-center text-center"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.22, ease: 'easeOut' }}
            >
              <h1 className="text-xl sm:text-2xl font-black text-[#0A6A32] tracking-tight flex items-center gap-1.5">
                <span>ঝাদিমাদি ডটকম</span>
              </h1>
              <span className="text-[11px] sm:text-xs font-semibold tracking-widest uppercase text-stone-500 mt-0.5">
                Jhadimadi.com
              </span>
            </motion.div>

            {/* 3. Bengali Tagline below logo */}
            <motion.div
              className="mt-3.5 sm:mt-4 text-center px-3 max-w-[320px] sm:max-w-sm"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.38, ease: 'easeOut' }}
            >
              <p 
                className="text-[14px] xs:text-[15px] sm:text-[16px] font-medium text-stone-700 leading-relaxed tracking-normal select-none"
              >
                সকল প্রয়োজনে, সবসময় <span className="font-bold text-[#0A6A32]">‘ঝাদিমাদি ডটকম’</span> আপনার পাশে।
              </p>
            </motion.div>
          </div>

          {/* Bottom Area: Sleek Organic Green Loading Progress Indicator */}
          <motion.div
            className="w-full flex flex-col items-center justify-center pb-6 sm:pb-8 shrink-0 px-6"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.45, ease: 'easeOut' }}
          >
            {/* Sleek organic green loading bar */}
            <div className="w-36 sm:w-44 h-1.5 bg-stone-200/80 rounded-full overflow-hidden relative shadow-inner">
              <motion.div
                className="h-full bg-gradient-to-r from-[#0A6A32] via-[#16A34A] to-emerald-400 rounded-full"
                style={{ width: `${progress}%` }}
                transition={{ ease: 'linear' }}
              />
            </div>

            {/* Loading text with organic pulse */}
            <div className="mt-2.5 flex items-center gap-1.5 text-stone-500 text-[11px] sm:text-xs font-medium">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#0A6A32] animate-pulse" />
              <span>লোডিং হচ্ছে...</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
