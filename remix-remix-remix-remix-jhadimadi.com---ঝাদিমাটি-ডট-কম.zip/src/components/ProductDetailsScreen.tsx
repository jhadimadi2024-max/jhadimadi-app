import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Share2, 
  ShoppingCart, 
  CheckCircle2, 
  MapPin, 
  Phone, 
  MessageSquare, 
  ShieldCheck, 
  Star, 
  Truck, 
  Award, 
  Minus, 
  Plus, 
  Play, 
  Lock, 
  Eye, 
  Check, 
  AlertCircle,
  QrCode,
  Youtube,
  Package,
  Sparkles,
  Info,
  Calendar,
  Layers,
  Heart
} from 'lucide-react';
import { Language } from '../types';

export interface ProductDetailItem {
  id: string;
  name: string;
  nameBn?: string;
  nameEn?: string;
  category?: string;
  categoryLabelBn?: string;
  pricePerUnit: number;
  originalPrice?: number;
  unit: string; // e.g. 'কেজি' or 'পিস' or '১ কেজি প্যাকেট'
  stockQuantity: number;
  minOrderQuantity?: number;
  originLocation: string; // উৎপাদনস্থল
  qualityGrade: string; // পণ্যের মান/গুণাগুণ
  youtubeUrl: string; // Embedded YouTube Link
  qrCodeUrl: string; // QR Code Verification
  images: string[];
  description: string;
  benefits?: string[];
  specifications?: { label: string; value: string }[];
  seller?: {
    name: string;
    avatar: string;
    phoneHidden: string;
    realPhone?: string;
    isNidVerified: boolean;
    rating?: number;
    reviewsCount?: number;
    location?: string;
    uniqueId?: string;
  };
}

export type DetailedItem = ProductDetailItem;

interface ProductDetailsScreenProps {
  product: ProductDetailItem;
  onBack: () => void;
  onAddToCart?: (product: ProductDetailItem, quantity: number) => void;
  onBuyNow?: (product: ProductDetailItem, quantity: number) => void;
  onOpenCart?: () => void;
  onOpenChat?: (sellerName: string) => void;
  cartCount?: number;
  lang?: Language;
}

export const ProductDetailsScreen: React.FC<ProductDetailsScreenProps> = ({
  product,
  onBack,
  onAddToCart,
  onBuyNow,
  onOpenCart,
  onOpenChat,
  cartCount = 0,
  lang = 'bn',
}) => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(product.minOrderQuantity || 1);
  const [isZoomed, setIsZoomed] = useState(false);
  const [isContactUnlocked, setIsContactUnlocked] = useState(false);
  const [copiedToast, setCopiedToast] = useState(false);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [activeInfoTab, setActiveInfoTab] = useState<'desc' | 'specs' | 'video' | 'qr'>('desc');

  // Fallback image gallery
  const galleryImages = product.images && product.images.length > 0 
    ? product.images 
    : [
        'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1587049352847-4a222e784d38?auto=format&fit=crop&w=600&q=80'
      ];

  // Default seller if not provided
  const seller = product.seller || {
    name: 'ঝাদিমাটি ভেরিফাইড অ্যাগ্রো ফার্ম',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
    phoneHidden: '018****4589',
    realPhone: '01819234589',
    isNidVerified: true,
    rating: 4.9,
    reviewsCount: 38,
    location: product.originLocation || 'দিনাজপুর / খাগড়াছড়ি',
    uniqueId: 'JDM-V108'
  };

  // Convert regular YouTube URL to embed URL if needed
  const getEmbedYouTubeUrl = (url: string) => {
    if (!url) return 'https://www.youtube.com/embed/dQw4w9WgXcQ';
    if (url.includes('youtube.com/embed/')) return url;
    if (url.includes('youtu.be/')) {
      const id = url.split('youtu.be/')[1]?.split('?')[0];
      return `https://www.youtube.com/embed/${id}`;
    }
    if (url.includes('watch?v=')) {
      const id = url.split('watch?v=')[1]?.split('&')[0];
      return `https://www.youtube.com/embed/${id}`;
    }
    return url;
  };

  const embedUrl = getEmbedYouTubeUrl(product.youtubeUrl);

  const qrCodeUrl = product.qrCodeUrl || 
    `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=JHADIMADI-VERIFIED-${encodeURIComponent(product.id)}-${encodeURIComponent(product.name)}`;

  const discountPercent = product.originalPrice && product.originalPrice > product.pricePerUnit
    ? Math.round(((product.originalPrice - product.pricePerUnit) / product.originalPrice) * 100)
    : 0;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: `${product.name} - ৳${product.pricePerUnit} (${product.unit}) ঝাদিমাটি ডট কমে দেখুন!`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedToast(true);
      setTimeout(() => setCopiedToast(false), 2500);
    }
  };

  const handleContactUnlock = () => {
    setIsContactUnlocked(true);
  };

  return (
    <div className="w-full bg-slate-50 min-h-full font-sans text-slate-800 pb-28 relative">
      
      {/* 1. Header Navigation Bar */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md px-3.5 py-2.5 border-b border-slate-200 flex items-center justify-between shadow-xs">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition cursor-pointer active:scale-95"
          id="product-details-back-btn"
        >
          <ArrowLeft className="w-4 h-4 text-emerald-700" />
          <span>{lang === 'bn' ? 'ফিরে যান' : 'Back'}</span>
        </button>

        <h3 className="font-black text-xs text-slate-900 truncate max-w-[180px] text-center">
          {product.name}
        </h3>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsFavorite(!isFavorite)}
            className="p-2 rounded-xl hover:bg-slate-100 text-slate-600 cursor-pointer transition"
            title="পছন্দের তালিকা"
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'text-red-500 fill-red-500' : 'text-slate-600'}`} />
          </button>

          <button
            onClick={handleShare}
            className="p-2 rounded-xl hover:bg-slate-100 text-slate-600 cursor-pointer transition"
            title="শেয়ার করুন"
          >
            <Share2 className="w-4 h-4 text-slate-700" />
          </button>

          {onOpenCart && (
            <button
              onClick={onOpenCart}
              className="relative p-2 rounded-xl hover:bg-slate-100 text-slate-600 cursor-pointer transition"
              title="কার্ট দেখুন"
            >
              <ShoppingCart className="w-4 h-4 text-emerald-700" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-red-600 text-white text-[8.5px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                  {cartCount}
                </span>
              )}
            </button>
          )}
        </div>
      </div>

      {copiedToast && (
        <div className="bg-emerald-600 text-white text-[11px] font-bold text-center py-1.5 sticky top-11 inset-x-0 z-40 transition-all shadow-md">
          ✓ পণ্যের লিঙ্ক ক্লিপবোর্ডে কপি করা হয়েছে!
        </div>
      )}

      {/* Main Container */}
      <div className="p-3 sm:p-4 space-y-4 max-w-2xl mx-auto">

        {/* 2. PRODUCT GALLERY (Main image + Thumbnails + Full Zoom) */}
        <div className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden shadow-xs space-y-3 p-3">
          
          {/* Main Visual Display */}
          <div className="relative h-60 sm:h-72 bg-slate-900 rounded-xl overflow-hidden group">
            <img
              src={galleryImages[selectedImageIndex]}
              alt={product.name}
              className={`w-full h-full object-cover transition-transform duration-300 ${
                isZoomed ? 'scale-130 cursor-zoom-out' : 'scale-100 cursor-zoom-in'
              }`}
              onClick={() => setIsZoomed(!isZoomed)}
            />

            {/* Origin Pill & Discount Badge */}
            <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
              <span className="bg-black/75 backdrop-blur-md text-white text-[8.5px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-1 shadow-sm">
                <MapPin className="w-2.5 h-2.5 text-emerald-400" />
                <span>{product.originLocation}</span>
              </span>
              
              {discountPercent > 0 && (
                <span className="bg-red-600 text-white text-[8.5px] font-black px-2 py-0.5 rounded-lg shadow-sm">
                  {discountPercent}% ছাড়
                </span>
              )}
            </div>

            {/* Quality Grade Badge */}
            <div className="absolute top-2.5 right-2.5 z-10">
              <span className="bg-emerald-700/90 backdrop-blur-md text-white text-[8px] font-black px-2 py-0.5 rounded-lg shadow-sm flex items-center gap-1 border border-emerald-400/40">
                <Sparkles className="w-2.5 h-2.5 text-amber-300" />
                <span>{product.qualityGrade || '১০০% খাঁটি প্রিমিয়াম গ্রেড-এ'}</span>
              </span>
            </div>

            {/* Zoom Action Button */}
            <button
              onClick={() => setIsZoomed(!isZoomed)}
              className="absolute bottom-2.5 right-2.5 bg-black/70 hover:bg-black/90 text-white text-[9px] font-bold px-2.5 py-1 rounded-lg backdrop-blur-xs flex items-center gap-1 cursor-pointer transition shadow-sm"
            >
              <Eye className="w-3 h-3" />
              <span>{isZoomed ? 'জুম স্বাভাবিক' : 'জুম ইন 🔍'}</span>
            </button>
          </div>

          {/* Thumbnail Gallery Selector */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {galleryImages.map((img, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setSelectedImageIndex(idx);
                  setIsZoomed(false);
                }}
                className={`w-14 h-14 rounded-xl overflow-hidden border-2 shrink-0 cursor-pointer transition-all ${
                  selectedImageIndex === idx
                    ? 'border-emerald-600 ring-2 ring-emerald-600/30 scale-102'
                    : 'border-slate-200 opacity-70 hover:opacity-100'
                }`}
              >
                <img src={img} alt={`Thumb ${idx}`} className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* 3. TITLE, ORIGIN & SOURCE INFO, QUALITY GRADE */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs">
          
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-black uppercase">
              {product.categoryLabelBn || product.category || 'পাহাড়ি ও দেশীয় খাঁটি পণ্য'}
            </span>
            <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[9px] font-black flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-700" />
              <span>স্টকে উপলব্ধ ({product.stockQuantity} {product.unit})</span>
            </span>
          </div>

          <h1 className="text-base sm:text-lg font-black text-slate-900 leading-snug">
            {product.name}
          </h1>

          {/* Origin & Quality Callout Box */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <div className="bg-emerald-50/70 border border-emerald-200/80 p-2.5 rounded-xl flex items-start gap-2">
              <MapPin className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
              <div>
                <span className="text-[9px] font-bold text-slate-500 block">উৎপাদনস্থল (Origin & Source):</span>
                <span className="text-xs font-black text-slate-800">{product.originLocation}</span>
              </div>
            </div>

            <div className="bg-amber-50/70 border border-amber-200/80 p-2.5 rounded-xl flex items-start gap-2">
              <Award className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="text-[9px] font-bold text-slate-500 block">পণ্যের মান ও গ্রেড (Quality Grade):</span>
                <span className="text-xs font-black text-slate-800">{product.qualityGrade}</span>
              </div>
            </div>
          </div>
        </div>

        {/* 4. STOCK & PRICING TABLE (Price per KG/Unit, Min Order, Stock Quantity) */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs">
          <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5 border-b border-slate-100 pb-2">
            <Package className="w-4 h-4 text-emerald-600" />
            <span>মূল্য ও স্টক তালিকা (Stock & Pricing Matrix)</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-600 text-[10px] font-black uppercase">
                  <th className="p-2 rounded-l-lg">একক / ইউনিট</th>
                  <th className="p-2">প্রতি একক মূল্য</th>
                  <th className="p-2">সর্বনিম্ন অর্ডার</th>
                  <th className="p-2 rounded-r-lg">বর্তমান স্টক</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800 font-medium">
                <tr>
                  <td className="p-2.5 font-bold">{product.unit}</td>
                  <td className="p-2.5 font-black text-emerald-700 text-sm">
                    ৳ {product.pricePerUnit}
                    {product.originalPrice && product.originalPrice > product.pricePerUnit && (
                      <span className="text-[10px] text-slate-400 line-through block font-normal">
                        ৳ {product.originalPrice}
                      </span>
                    )}
                  </td>
                  <td className="p-2.5">{product.minOrderQuantity || 1} {product.unit}</td>
                  <td className="p-2.5 font-bold text-emerald-600">
                    {product.stockQuantity} {product.unit}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Interactive Quantity Selector & Subtotal */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200 pt-2.5">
            <div>
              <span className="text-[10px] font-bold text-slate-500 block">পরিমাণ নির্বাচন করুন:</span>
              <div className="flex items-center border border-slate-300 rounded-xl overflow-hidden bg-white mt-1 shadow-2xs">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(product.minOrderQuantity || 1, quantity - 1))}
                  className="px-3 py-1.5 hover:bg-slate-100 text-slate-700 font-black text-xs transition cursor-pointer active:scale-95"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="px-3.5 font-black text-xs text-slate-900">{quantity} {product.unit}</span>
                <button
                  type="button"
                  onClick={() => setQuantity(Math.min(product.stockQuantity, quantity + 1))}
                  className="px-3 py-1.5 hover:bg-slate-100 text-slate-700 font-black text-xs transition cursor-pointer active:scale-95"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-bold text-slate-500 block">মোট মূল্য (Subtotal):</span>
              <span className="text-lg font-black text-emerald-700 block">
                ৳ {product.pricePerUnit * quantity}
              </span>
              <span className="text-[9px] text-slate-400 font-medium">ক্যাশ অন ডেলিভারি প্রযোজ্য</span>
            </div>
          </div>
        </div>

        {/* 5. EMBEDDED YOUTUBE VIDEO SECTION (Origin, Harvesting & Processing Video) */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
              <Youtube className="w-4 h-4 text-red-600" />
              <span>উৎপাদন ও প্রক্রিয়াজাতকরণ ভিডিও (Origin & Harvesting Video)</span>
            </h3>
            <span className="text-[9px] font-bold bg-red-50 text-red-700 px-2 py-0.5 rounded-full border border-red-200">
              HD Video
            </span>
          </div>

          <p className="text-[11px] text-slate-600 leading-relaxed">
            সরাসরি ক্ষেত থেকে ফসল কাটা, বাছাই এবং খাঁটিভাবে প্রক্রিয়াজাতকরণের বাস্তব ভিডিও চিত্র নিচে দেখুন:
          </p>

          <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-slate-900 border border-slate-200 shadow-inner">
            <iframe
              src={embedUrl}
              title={`${product.name} উৎপাদন প্রক্রিয়া ভিডিও`}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </div>

        {/* 6. QR CODE AUTHENTICITY VERIFICATION */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
              <QrCode className="w-4 h-4 text-emerald-600" />
              <span>পণ্যের সত্যতা যাচাই কিউআর কোড (QR Code Authenticity)</span>
            </h3>
            <span className="text-[9px] font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              <span>১০০% অথেনটিক</span>
            </span>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div className="bg-white p-2 rounded-xl border border-slate-300 shadow-2xs shrink-0 text-center">
              <img
                src={qrCodeUrl}
                alt="Product Verification QR Code"
                className="w-28 h-28 mx-auto object-contain"
              />
              <span className="text-[8px] font-mono text-slate-500 mt-1 block">
                ID: {product.id}
              </span>
            </div>

            <div className="space-y-1.5 text-center sm:text-left">
              <h4 className="text-xs font-black text-slate-900 flex items-center justify-center sm:justify-start gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>ঝাদিমাটি ভেরিফাইড কোয়ালিটি সনদ</span>
              </h4>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                মোবাইল ক্যামেরা অথবা কিউআর স্ক্যানার দিয়ে স্ক্যান করে এই ব্যাচের উৎপাদন তারিখ, চাষী বা প্রস্তুতকারকের তথ্য ও ল্যাব টেস্টের রিপোর্ট যাচাই করুন।
              </p>
              <div className="pt-1 flex flex-wrap gap-2 justify-center sm:justify-start text-[9px] font-bold text-slate-500">
                <span className="bg-white px-2 py-0.5 rounded-md border border-slate-200">সরাসরি কৃষক সংগ্রহ</span>
                <span className="bg-white px-2 py-0.5 rounded-md border border-slate-200">রাসায়নিকমুক্ত</span>
                <span className="bg-white px-2 py-0.5 rounded-md border border-slate-200">ইকো-ফ্রেন্ডলি প্যাকিং</span>
              </div>
            </div>
          </div>
        </div>

        {/* 7. COMPREHENSIVE DESCRIPTION & BENEFITS LIST */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs">
          
          {/* Tabs for detailed info */}
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <button
              onClick={() => setActiveInfoTab('desc')}
              className={`text-xs font-black pb-1 transition cursor-pointer border-b-2 ${
                activeInfoTab === 'desc'
                  ? 'border-emerald-600 text-emerald-700'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              বিস্তারিত বিবরণ (Description)
            </button>
            <button
              onClick={() => setActiveInfoTab('specs')}
              className={`text-xs font-black pb-1 transition cursor-pointer border-b-2 ${
                activeInfoTab === 'specs'
                  ? 'border-emerald-600 text-emerald-700'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              পুষ্টি ও বৈশিষ্ট্য (Nutrition & Specs)
            </button>
          </div>

          {activeInfoTab === 'desc' ? (
            <div className="space-y-3">
              <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200">
                {product.description || 'দিনাজপুরের নিজস্ব ক্ষেত থেকে সংগৃহীত সম্পূর্ণ রাসায়নিক ও ভেজাল মুক্ত নাজিরশাইল চাল। ঐতিহ্যবাহী পদ্ধতিতে বাছাইকৃত ও স্বাস্থ্যকর উপায়ে প্যাকেটজাত। প্রতিদিনের সুস্বাদু খাবারের জন্য সর্বোত্তম পছন্দ।'}
              </p>

              {/* Key Benefits Checklist */}
              <div className="space-y-1.5 pt-1">
                <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>স্বাস্থ্যগত উপকারিতা ও মূল বৈশিষ্ট্য (Key Benefits):</span>
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-700">
                  {(product.benefits && product.benefits.length > 0 ? product.benefits : [
                    '১০০% প্রাকৃতিক ও প্রিজারভেটিভ বা ক্ষতিকর কেমিক্যাল মুক্ত।',
                    'সহজে হজমযোগ্য এবং শরীরের প্রয়োজনীয় শক্তি ও পুষ্টি যোগায়।',
                    'রান্নার পর ভাত থাকে সুবাসিত, ঝরঝরে ও অত্যন্ত সুস্বাদু।',
                    'উন্নত প্রক্রিয়াজাতকরণে ধুলোবালি ও পাথর মুক্ত পরিচ্ছন্ন দানা।'
                  ]).map((benefit, bIdx) => (
                    <li key={bIdx} className="flex items-start gap-2 bg-emerald-50/40 p-2 rounded-lg border border-emerald-100">
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span className="font-medium text-[11px]">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500 block">ক্যাটাগরি</span>
                  <span className="font-bold text-slate-800">{product.categoryLabelBn || product.category || 'খাদ্য শস্য'}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500 block">প্যাকিং ধরন</span>
                  <span className="font-bold text-slate-800">ফুড-গ্রেড ভ্যাকুয়াম প্যাক</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500 block">সংরক্ষণ মেয়াদ</span>
                  <span className="font-bold text-slate-800">১২ মাস (শুকনো স্থানে)</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500 block">ডেলিভারি এরিয়া</span>
                  <span className="font-bold text-emerald-700">সমগ্র বাংলাদেশ</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 8. SELLER / PROVIDER INFORMATION CARD */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>বিক্রেতা বা প্রস্তুতকারক প্রোফাইল (Seller Info)</span>
            </h3>
            <span className="text-[9px] font-mono font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
              ID: {seller.uniqueId || 'JDM-V101'}
            </span>
          </div>

          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="relative shrink-0">
                <img
                  src={seller.avatar}
                  alt={seller.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-emerald-600 shadow-xs"
                />
                {seller.isNidVerified && (
                  <span className="absolute -bottom-1 -right-1 bg-emerald-600 text-white p-0.5 rounded-full shadow-xs">
                    <CheckCircle2 className="w-3 h-3 fill-emerald-600 text-white" />
                  </span>
                )}
              </div>

              <div>
                <h4 className="font-black text-xs text-slate-900 flex items-center gap-1">
                  <span>{seller.name}</span>
                  <span className="text-[8px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">
                    NID Verified [✓]
                  </span>
                </h4>
                <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5">
                  <span className="text-amber-600 font-bold flex items-center">
                    ★ {seller.rating || 4.9} ({seller.reviewsCount || 25} রিভিউ)
                  </span>
                  <span>•</span>
                  <span>{seller.location}</span>
                </div>
              </div>
            </div>

            {onOpenChat && (
              <button
                type="button"
                onClick={() => onOpenChat(seller.name)}
                className="p-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 rounded-xl font-bold text-xs flex items-center gap-1 transition cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>চ্যাট</span>
              </button>
            )}
          </div>

          {/* Contact info unlock */}
          <div className="bg-slate-50 border border-slate-200 p-2.5 rounded-xl flex items-center justify-between text-xs">
            <span className="text-[10px] text-slate-600 font-medium">মোবাইল নম্বর:</span>
            {isContactUnlocked ? (
              <a
                href={seller.realPhone ? `tel:${seller.realPhone}` : '#'}
                className="font-black text-xs text-emerald-700 flex items-center gap-1 bg-emerald-100 px-2.5 py-1 rounded-lg"
              >
                <Phone className="w-3 h-3" />
                <span>{seller.realPhone || 'নম্বর উপলব্ধ নেই'}</span>
              </a>
            ) : (
              <button
                type="button"
                onClick={handleContactUnlock}
                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] rounded-lg flex items-center gap-1 cursor-pointer transition"
              >
                <Lock className="w-3 h-3" />
                <span>{seller.phoneHidden} (নম্বর দেখুন)</span>
              </button>
            )}
          </div>
        </div>

      </div>

      {/* 9. FIXED BOTTOM ACTION BAR (Add to Cart, Buy Now, Call) */}
      <div className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-slate-200 p-2.5 px-3 z-40 max-w-[440px] mx-auto shadow-2xl flex items-center gap-2">
        <button
          type="button"
          onClick={() => {
            if (onAddToCart) onAddToCart(product, quantity);
          }}
          className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition whitespace-nowrap"
          id="product-add-to-cart-action"
        >
          <ShoppingCart className="w-3.5 h-3.5 text-emerald-400" />
          <span>কার্টে যোগ করুন</span>
        </button>

        <button
          type="button"
          onClick={() => {
            if (onBuyNow) {
              onBuyNow(product, quantity);
            } else if (onAddToCart) {
              onAddToCart(product, quantity);
              if (onOpenCart) onOpenCart();
            }
          }}
          className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition whitespace-nowrap"
          id="product-buy-now-action"
        >
          <span>⚡ এখনই অর্ডার</span>
        </button>

        <a
          href={seller.realPhone ? `tel:${seller.realPhone}` : '#'}
          className="p-2.5 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-800 font-bold rounded-xl flex items-center justify-center transition shadow-xs"
          title="কল করুন"
        >
          <Phone className="w-4 h-4 text-emerald-700" />
        </a>
      </div>

    </div>
  );
};

export default ProductDetailsScreen;
