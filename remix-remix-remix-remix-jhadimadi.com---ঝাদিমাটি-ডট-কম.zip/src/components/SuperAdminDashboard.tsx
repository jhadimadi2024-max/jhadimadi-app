import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Lock, ArrowLeft, RefreshCw 
} from 'lucide-react';
import { AdminScreen } from './AdminPanelModal';
import { adminSecurityService, AdminSession } from '../services/adminSecurityService';

interface SuperAdminDashboardProps {
  onBackToApp?: () => void;
  lang?: 'bn' | 'en';
}

export const SuperAdminDashboard: React.FC<SuperAdminDashboardProps> = ({
  onBackToApp,
  lang = 'bn'
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isVerifyingSession, setIsVerifyingSession] = useState<boolean>(true);
  const [adminSession, setAdminSession] = useState<AdminSession | null>(null);

  const [adminId, setAdminId] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Validate real Supabase Auth session & role on mount
  useEffect(() => {
    let isMounted = true;
    const checkAuth = async () => {
      try {
        const session = await adminSecurityService.getCurrentAdminSession();
        if (isMounted) {
          if (session && session.isSuperAdmin) {
            setAdminSession(session);
            setIsAuthenticated(true);
          } else {
            setIsAuthenticated(false);
          }
          setIsVerifyingSession(false);
        }
      } catch {
        if (isMounted) {
          setIsAuthenticated(false);
          setIsVerifyingSession(false);
        }
      }
    };

    checkAuth();
    return () => {
      isMounted = false;
    };
  }, []);

  // Handle Admin Login with Supabase Authentication and RBAC Verification
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoading(true);

    try {
      const result = await adminSecurityService.signInAdmin(adminId, password);
      setIsLoading(false);

      if (result.success && result.session) {
        if (!result.session.isSuperAdmin) {
          setLoginError(
            lang === 'bn' 
              ? 'অননুমোদিত! এই সেকশনে প্রবেশের জন্য সুপার অ্যাডমিন পারমিশন প্রয়োজন।' 
              : 'Super Admin permissions are required for this panel.'
          );
          return;
        }

        setAdminSession(result.session);
        setIsAuthenticated(true);
        setLoginError('');
      } else {
        setLoginError(result.message || (lang === 'bn' ? 'ভুল অ্যাডমিন আইডি বা পাসওয়ার্ড!' : 'Invalid credentials!'));
      }
    } catch {
      setIsLoading(false);
      setLoginError(lang === 'bn' ? 'লগইন যাচাইকরণে ত্রুটি হয়েছে।' : 'Login verification error.');
    }
  };

  if (isVerifyingSession) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="flex items-center gap-2.5 text-emerald-400 text-xs font-bold">
          <RefreshCw className="w-4 h-4 animate-spin" />
          <span>সুরক্ষিত অ্যাডমিন সেশন যাচাই করা হচ্ছে...</span>
        </div>
      </div>
    );
  }

  // SCENE 1: ADMIN LOGIN SCREEN
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-3 sm:p-4 font-sans relative">
        <div className="absolute inset-0 bg-radial from-emerald-900/20 via-transparent to-transparent pointer-events-none" />

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 w-full max-w-md shadow-2xl space-y-6 relative z-10 text-white">
          
          {onBackToApp && (
            <button
              id="btn-super-admin-back"
              type="button"
              onClick={onBackToApp}
              className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition font-bold cursor-pointer"
            >
              <ArrowLeft size={14} /> মূল অ্যাপে ফিরুন
            </button>
          )}

          <div className="text-center space-y-2">
            <div className="w-16 h-16 bg-gradient-to-tr from-emerald-600 to-teal-400 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-emerald-900/50">
              <ShieldCheck className="w-9 h-9 text-white" />
            </div>
            <h2 className="text-xl font-black text-white">
              ঝাড়িমাদি অ্যাডমিন হাব
            </h2>
            <p className="text-xs text-slate-400">
              সেন্ট্রাল সুপার-অ্যাডমিন কন্ট্রোল প্যানেল (Supabase Auth)
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            {loginError && (
              <div className="bg-rose-500/20 border border-rose-500/40 text-rose-300 p-3 rounded-xl text-center font-bold">
                {loginError}
              </div>
            )}

            <div>
              <label className="block text-slate-400 font-bold mb-1.5">
                সুপার অ্যাডমিন ইমেইল / ইউজারনেম
              </label>
              <input
                id="input-super-admin-id"
                type="text"
                value={adminId}
                onChange={(e) => setAdminId(e.target.value)}
                placeholder="অ্যাডমিন ইমেইল লিখুন"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 font-bold text-xs"
                required
              />
            </div>

            <div>
              <label className="block text-slate-400 font-bold mb-1.5">
                সিক্রেট পাসওয়ার্ড
              </label>
              <input
                id="input-super-admin-pass"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="পাসওয়ার্ড লিখুন"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 font-bold text-xs"
                required
              />
            </div>

            <button
              id="btn-super-admin-login"
              type="submit"
              disabled={isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black py-3 rounded-xl shadow-lg transition flex justify-center items-center gap-2 text-xs uppercase tracking-wide cursor-pointer"
            >
              {isLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Lock size={15} />
              )}
              <span>{isLoading ? 'যাচাই করা হচ্ছে...' : 'সিকিউর লগইন করুন'}</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  // SCENE 2: MASTER ADMIN DASHBOARD PANEL WITH ALL MODULES
  return <AdminScreen onBack={onBackToApp} />;
};

export default SuperAdminDashboard;
