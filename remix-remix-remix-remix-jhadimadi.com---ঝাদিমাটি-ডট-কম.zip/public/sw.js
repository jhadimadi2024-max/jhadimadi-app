// Jhadimadi.com Service Worker (sw.js)
// Enables native app-like offline caching, asset caching, and offline fallback UI

const CACHE_NAME = 'jhadimadi-v3.0-cache';

const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/logo.png',
  '/runner-logo.png',
  '/runner-fixed.png',
  '/assets/images/logo.png',
  '/assets/images/runner-logo.png',
  '/favicon.ico'
];

// 1. Install event: Pre-cache core shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      // Pre-cache all essential static assets
      await Promise.allSettled(
        STATIC_ASSETS.map(async (url) => {
          try {
            const response = await fetch(url);
            if (response.ok) {
              await cache.put(url, response);
            }
          } catch (e) {
            // Ignore optional file errors during install
          }
        })
      );
    }).then(() => self.skipWaiting())
  );
});

// 2. Activate event: Clean up old caches & take control immediately
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

// 3. Fetch event: Network-First fallback to Cache strategy for SPA
self.addEventListener('fetch', (event) => {
  const request = event.request;

  // Ignore non-GET requests or non-HTTP/HTTPS URLs
  if (request.method !== 'GET' || !request.url.startsWith('http')) {
    return;
  }

  // A. Navigation / HTML Document requests (Network-First, fallback to cached index.html)
  if (request.mode === 'navigate' || request.headers.get('accept')?.includes('text/html')) {
    event.respondWith(
      fetch(request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseToCache);
              cache.put('/index.html', networkResponse.clone());
            });
          }
          return networkResponse;
        })
        .catch(async () => {
          // Offline fallback: serve cached index.html so React App launches seamlessly
          const cache = await caches.open(CACHE_NAME);
          const cachedResponse = await cache.match(request);
          if (cachedResponse) return cachedResponse;

          const cachedIndex = await cache.match('/index.html') || await cache.match('/');
          if (cachedIndex) return cachedIndex;

          // If no cache at all, provide basic offline shell
          return new Response(
            `<!DOCTYPE html>
            <html lang="bn">
              <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>ঝাদিমাটি ডটকম - অফলাইন</title>
                <style>
                  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0f172a; color: #fff; text-align: center; padding: 40px 20px; margin: 0; }
                  .card { background: #1e293b; max-width: 400px; margin: 40px auto; padding: 24px; border-radius: 20px; border: 1px solid #334155; }
                  .logo { width: 70px; height: 70px; margin: 0 auto 16px; border-radius: 16px; background: #2EAA26; display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: bold; }
                  h2 { color: #facc15; font-size: 20px; margin-bottom: 8px; }
                  p { color: #94a3b8; font-size: 14px; line-height: 1.5; margin-bottom: 20px; }
                  button { background: #2EAA26; color: #fff; border: none; padding: 10px 24px; border-radius: 12px; font-weight: bold; cursor: pointer; }
                </style>
              </head>
              <body>
                <div class="card">
                  <div class="logo">🏃</div>
                  <h2>ঝাদিমাটি ডটকম</h2>
                  <p>⚠️ আপনি বর্তমানে অফলাইনে আছেন। ইন্টারনেট সংযোগ পুনরায় পরীক্ষা করুন অথবা অ্যাপ রিলোড করুন।</p>
                  <button onclick="window.location.reload()">পুনরায় চেষ্টা করুন (Retry)</button>
                </div>
              </body>
            </html>`,
            {
              headers: { 'Content-Type': 'text/html; charset=utf-8' }
            }
          );
        })
    );
    return;
  }

  // B. Static Assets, Scripts, Stylesheets, Images, Fonts:
  // Try Network first to get latest updates, dynamically cache successful responses, fallback to cache when offline
  event.respondWith(
    fetch(request)
      .then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, responseToCache);
          });
        }
        return networkResponse;
      })
      .catch(async () => {
        const cached = await caches.match(request);
        if (cached) {
          return cached;
        }
        // If image not found in cache, return an empty SVG placeholder if appropriate
        if (request.destination === 'image') {
          return new Response(
            '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><rect width="100" height="100" fill="#334155"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#94a3b8" font-size="12">Offline</text></svg>',
            { headers: { 'Content-Type': 'image/svg+xml' } }
          );
        }
        return new Response('Network error occurred', {
          status: 408,
          headers: { 'Content-Type': 'text/plain' },
        });
      })
  );
});

